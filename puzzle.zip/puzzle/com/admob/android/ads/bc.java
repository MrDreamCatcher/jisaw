// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import java.io.File;
import java.util.Comparator;

final class bc
    implements java.util.Comparator
{

    bc()
    {
    }

    public final volatile int compare(java.lang.Object obj, java.lang.Object obj1)
    {
        obj = (java.io.File)obj;
        obj1 = (java.io.File)obj1;
        if(obj == null && obj1 == null)
            return 0;
        if(obj != null && obj1 != null)
        {
            long l = ((java.io.File) (obj)).lastModified();
            long l1 = ((java.io.File) (obj1)).lastModified();
            if(l == l1)
                return 0;
            if(l >= l1)
                return 1;
        } else
        if(obj != null)
            return 1;
        return -1;
    }
}
