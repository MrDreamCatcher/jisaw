// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.graphics.Camera;
import android.graphics.Matrix;
import android.view.animation.Animation;
import android.view.animation.Transformation;

public final class bd extends android.view.animation.Animation
{

    public bd(float f1, float f2, float f3, float f4, float f5, boolean flag)
    {
        this(new float[] {
            0.0F, f1, 0.0F
        }, new float[] {
            0.0F, f2, 0.0F
        }, f3, f4, f5, flag);
    }

    public bd(float af[], float af1[], float f1, float f2, float f3, boolean flag)
    {
        a = af;
        b = af1;
        c = f1;
        d = f2;
        e = f3;
        f = flag;
    }

    protected final void applyTransformation(float f1, android.view.animation.Transformation transformation)
    {
        if((double)f1 < 0.0D || (double)f1 > 1.0D)
        {
            transformation.setTransformationType(android.view.animation.Transformation.TYPE_IDENTITY);
            return;
        }
        float af1[] = a;
        float af2[] = b;
        float af[] = new float[3];
        for(int i = 0; i < 3; i++)
            af[i] = af1[i] + (af2[i] - af1[i]) * f1;

        float f2 = c;
        float f3 = d;
        android.graphics.Camera camera = g;
        android.graphics.Matrix matrix = transformation.getMatrix();
        camera.save();
        if(f)
            camera.translate(0.0F, 0.0F, e * f1);
        else
            camera.translate(0.0F, 0.0F, e * (1.0F - f1));
        camera.rotateX(af[0]);
        camera.rotateY(af[1]);
        camera.rotateZ(af[2]);
        camera.getMatrix(matrix);
        camera.restore();
        matrix.preTranslate(-f2, -f3);
        matrix.postTranslate(f2, f3);
        transformation.setTransformationType(android.view.animation.Transformation.TYPE_MATRIX);
    }

    public final void initialize(int i, int j, int k, int l)
    {
        super.initialize(i, j, k, l);
        g = new Camera();
    }

    private final float a[];
    private final float b[];
    private final float c;
    private final float d;
    private final float e;
    private final boolean f;
    private android.graphics.Camera g;
}
