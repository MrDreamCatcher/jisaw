// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.admob.android.ads.a.a;
import java.lang.ref.WeakReference;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.StringTokenizer;

// Referenced classes of package com.admob.android.ads:
//            bn, bu, al, az

public class bo extends android.webkit.WebViewClient
{

    public bo(com.admob.android.ads.a.a a1)
    {
        this(a1, null);
    }

    public bo(com.admob.android.ads.a.a a1, java.lang.ref.WeakReference weakreference)
    {
        d = new WeakReference(a1);
        a = weakreference;
        b = new bn((android.app.Activity)weakreference.get(), d);
        c = null;
        a1.addJavascriptInterface(b, "JsProxy");
    }

    public static java.util.Hashtable a(java.lang.String s)
    {
        java.lang.Object obj = null;
        if(s != null)
        {
            java.util.Hashtable hashtable = new Hashtable();
            s = new StringTokenizer(s, "&");
            do
            {
                obj = hashtable;
                if(!s.hasMoreTokens())
                    break;
                java.lang.String s1 = s.nextToken();
                int i = s1.indexOf('=');
                if(i != -1)
                {
                    obj = s1.substring(0, i);
                    s1 = s1.substring(i + 1);
                    if(obj != null && s1 != null)
                        hashtable.put(obj, s1);
                }
            } while(true);
        }
        return ((java.util.Hashtable) (obj));
    }

    public void onPageFinished(android.webkit.WebView webview, java.lang.String s)
    {
        webview = (com.admob.android.ads.a.a)d.get();
        if(webview != null)
            if(s == null || !s.equals(((com.admob.android.ads.a.a) (webview)).a))
            {
                if(com.admob.android.ads.bu.a("AdMobSDK", 4))
                {
                    android.util.Log.i("AdMobSDK", (new StringBuilder()).append("Unexpected page loaded, urlThatFinished: ").append(s).toString());
                    return;
                }
            } else
            {
                if(c == null)
                {
                    c = new HashMap();
                    s = webview.getContext();
                    c.put("sdkVersion", "20101109-ANDROID-3312276cc1406347");
                    c.put("ua", com.admob.android.ads.al.h());
                    c.put("portrait", com.admob.android.ads.az.j(s));
                    c.put("width", java.lang.String.valueOf(webview.getWidth()));
                    c.put("height", java.lang.String.valueOf(webview.getHeight()));
                    c.put("isu", com.admob.android.ads.az.g(s));
                }
                webview.a("onEvent", new java.lang.Object[] {
                    "loaded", c
                });
                return;
            }
    }

    public boolean shouldOverrideUrlLoading(android.webkit.WebView webview, java.lang.String s)
    {
        android.content.Context context;
        com.admob.android.ads.a.a a1;
        if(com.admob.android.ads.bu.a("AdMobSDK", 2))
            android.util.Log.v("AdMobSDK", (new StringBuilder()).append("shouldOverrideUrlLoading, url: ").append(s).toString());
        a1 = (com.admob.android.ads.a.a)d.get();
        if(a1 == null)
            return false;
        context = a1.getContext();
        java.net.URI uri;
        java.lang.String s1;
        uri = new URI(s);
        if(!"admob".equals(uri.getScheme()))
            break MISSING_BLOCK_LABEL_401;
        s1 = uri.getHost();
        if(!"launch".equals(s1))
            break MISSING_BLOCK_LABEL_176;
        webview = uri.getQuery();
        if(webview == null)
            break MISSING_BLOCK_LABEL_401;
        webview = com.admob.android.ads.bo.a(webview);
        if(webview == null)
            break MISSING_BLOCK_LABEL_401;
        s = (java.lang.String)webview.get("url");
        if(s == null)
            break MISSING_BLOCK_LABEL_401;
        webview = context;
        if(!(context instanceof android.app.Activity))
            webview = (android.content.Context)a.get();
        if(webview == null)
            break MISSING_BLOCK_LABEL_403;
        webview.startActivity(new Intent("android.intent.action.VIEW", android.net.Uri.parse(s)));
        break MISSING_BLOCK_LABEL_403;
        if(!"open".equals(s1))
            break MISSING_BLOCK_LABEL_250;
        webview = uri.getQuery();
        if(webview == null)
            break MISSING_BLOCK_LABEL_401;
        webview = com.admob.android.ads.bo.a(webview);
        if(webview == null)
            break MISSING_BLOCK_LABEL_401;
        webview = (java.lang.String)webview.get("vars");
        if(webview == null)
            break MISSING_BLOCK_LABEL_401;
        a1.loadUrl((new StringBuilder()).append("javascript: JsProxy.setDataAndOpen(").append(webview).append(")").toString());
        return true;
        if(!"closecanvas".equals(s1))
            break MISSING_BLOCK_LABEL_273;
        if(webview != a1)
            break MISSING_BLOCK_LABEL_401;
        a1.a();
        return true;
        if(!"log".equals(s1))
            break MISSING_BLOCK_LABEL_353;
        webview = uri.getQuery();
        if(webview == null)
            break MISSING_BLOCK_LABEL_401;
        webview = com.admob.android.ads.bo.a(webview);
        if(webview == null)
            break MISSING_BLOCK_LABEL_401;
        webview = (java.lang.String)webview.get("string");
        if(webview != null)
            try
            {
                if(com.admob.android.ads.bu.a("AdMobSDK", 3))
                    android.util.Log.d("AdMobSDK", (new StringBuilder()).append("<AdMob:WebView>: ").append(webview).toString());
                break MISSING_BLOCK_LABEL_405;
            }
            // Misplaced declaration of an exception variable
            catch(android.webkit.WebView webview)
            {
                android.util.Log.w("AdMobSDK", "Bad link URL in AdMob web view.", webview);
            }
        break MISSING_BLOCK_LABEL_401;
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
            android.util.Log.d("AdMobSDK", (new StringBuilder()).append("Received message from JS but didn't know how to handle: ").append(s).toString());
        return true;
        return false;
        return true;
        return true;
    }

    private java.lang.ref.WeakReference a;
    private com.admob.android.ads.bn b;
    private java.util.Map c;
    protected java.lang.ref.WeakReference d;
}
