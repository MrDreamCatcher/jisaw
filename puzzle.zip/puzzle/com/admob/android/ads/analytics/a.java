// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads.analytics;

import android.util.Log;
import com.admob.android.ads.ak;
import com.admob.android.ads.bu;
import com.admob.android.ads.z;

// Referenced classes of package com.admob.android.ads.analytics:
//            InstallReceiver

final class a
    implements com.admob.android.ads.z
{

    a(com.admob.android.ads.analytics.InstallReceiver installreceiver)
    {
    }

    public final void a(com.admob.android.ads.ak ak)
    {
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
            android.util.Log.d("AdMobSDK", "Recorded install from an AdMob ad.");
    }

    public final void a(com.admob.android.ads.ak ak, java.lang.Exception exception)
    {
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
            android.util.Log.d("AdMobSDK", "Failed to record install from an AdMob ad.", exception);
    }
}
