// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads.analytics;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageItemInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import com.admob.android.ads.ak;
import com.admob.android.ads.az;
import com.admob.android.ads.bu;
import com.admob.android.ads.y;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Iterator;
import java.util.Set;

// Referenced classes of package com.admob.android.ads.analytics:
//            a

public class InstallReceiver extends android.content.BroadcastReceiver
{

    public InstallReceiver()
    {
    }

    private static java.lang.String a(java.lang.String s, java.lang.String s1, java.lang.String s2)
    {
        int i = 0;
        if(s == null) goto _L2; else goto _L1
_L1:
        java.lang.String as[] = s.split("&");
        s = null;
_L12:
        if(i >= as.length) goto _L4; else goto _L3
_L3:
        java.lang.String s3;
        java.lang.String s4;
        s4 = as[i];
        s3 = s;
        if(!s4.startsWith("admob_")) goto _L6; else goto _L5
_L5:
        java.lang.String as1[] = s4.substring("admob_".length()).split("=");
        s3 = java.net.URLEncoder.encode(as1[0], "UTF-8");
        as1 = java.net.URLEncoder.encode(as1[1], "UTF-8");
        if(s != null) goto _L8; else goto _L7
_L7:
        s = new StringBuilder(128);
_L9:
        s.append(s3).append("=").append(as1);
        s3 = s;
          goto _L6
_L8:
        s.append("&");
          goto _L9
        s;
        if(com.admob.android.ads.bu.a("AdMobSDK", 6))
            android.util.Log.e("AdMobSDK", "Could not create install URL.  Install not tracked.", s);
_L2:
        return null;
_L4:
        if(s == null) goto _L2; else goto _L10
_L10:
        s1 = java.net.URLEncoder.encode(s1, "UTF-8");
        s.append("&").append("isu").append("=").append(s1);
        s1 = java.net.URLEncoder.encode(s2, "UTF-8");
        s.append("&").append("app_id").append("=").append(s1);
        s = (new StringBuilder()).append("http://a.admob.com/f0?").append(s.toString()).toString();
        return s;
_L6:
        i++;
        s = s3;
        if(true) goto _L12; else goto _L11
_L11:
    }

    private static void a(android.content.Context context, android.content.Intent intent)
    {
        java.lang.Object obj = context.getPackageManager();
        if(obj == null) goto _L2; else goto _L1
_L1:
        android.content.pm.ActivityInfo activityinfo = ((android.content.pm.PackageManager) (obj)).getReceiverInfo(new ComponentName(context, com/admob/android/ads/analytics/InstallReceiver), 128);
        if(activityinfo == null) goto _L2; else goto _L3
_L3:
        if(((android.content.pm.PackageItemInfo) (activityinfo)).metaData == null) goto _L2; else goto _L4
_L4:
        obj = ((android.content.pm.PackageItemInfo) (activityinfo)).metaData.keySet();
        if(obj == null) goto _L2; else goto _L5
_L5:
        java.util.Iterator iterator = ((java.util.Set) (obj)).iterator();
_L8:
        if(!iterator.hasNext()) goto _L2; else goto _L6
_L6:
        java.lang.String s = (java.lang.String)iterator.next();
        obj = null;
        s = ((android.content.pm.PackageItemInfo) (activityinfo)).metaData.getString(s);
        obj = s;
        if(s.equals("com.google.android.apps.analytics.AnalyticsReceiver")) goto _L8; else goto _L7
_L7:
        obj = s;
        ((android.content.BroadcastReceiver)java.lang.Class.forName(s).newInstance()).onReceive(context, intent);
        obj = s;
        if(!com.admob.android.ads.bu.a("AdMobSDK", 3)) goto _L8; else goto _L9
_L9:
        obj = s;
        android.util.Log.d("AdMobSDK", (new StringBuilder()).append("Successfully forwarded install notification to ").append(s).toString());
          goto _L8
        java.lang.Exception exception;
        exception;
        android.util.Log.w("AdMobSDK", (new StringBuilder()).append("Could not forward Market's INSTALL_REFERRER intent to ").append(((java.lang.String) (obj))).toString(), exception);
          goto _L8
        context;
        if(com.admob.android.ads.bu.a("AdMobSDK", 5))
            android.util.Log.w("AdMobSDK", "Unhandled exception while forwarding install intents.  Possibly lost some install information.", context);
_L10:
        return;
_L2:
        ((android.content.BroadcastReceiver)java.lang.Class.forName("com.google.android.apps.analytics.AnalyticsReceiver").newInstance()).onReceive(context, intent);
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
        {
            android.util.Log.d("AdMobSDK", "Successfully forwarded install notification to com.google.android.apps.analytics.AnalyticsReceiver");
            return;
        }
          goto _L10
        context;
        if(!com.admob.android.ads.bu.a("AdMobSDK", 2)) goto _L10; else goto _L11
_L11:
        android.util.Log.v("AdMobSDK", "Google Analytics not installed.");
        return;
        context;
        if(!com.admob.android.ads.bu.a("AdMobSDK", 5)) goto _L10; else goto _L12
_L12:
        android.util.Log.w("AdMobSDK", "Exception from the Google Analytics install receiver.", context);
        return;
    }

    public void onReceive(android.content.Context context, android.content.Intent intent)
    {
        java.lang.Object obj;
        java.lang.String s;
        s = intent.getStringExtra("referrer");
        obj = com.admob.android.ads.az.g(context);
        s = com.admob.android.ads.analytics.InstallReceiver.a(s, ((java.lang.String) (obj)), com.admob.android.ads.az.b(context));
        if(s == null)
            break MISSING_BLOCK_LABEL_100;
        if(com.admob.android.ads.bu.a("AdMobSDK", 2))
            android.util.Log.v("AdMobSDK", (new StringBuilder()).append("Processing install from an AdMob ad (").append(s).append(").").toString());
        obj = com.admob.android.ads.y.a(s, "Conversion", ((java.lang.String) (obj)));
        ((com.admob.android.ads.ak) (obj)).a(new a(this));
        ((com.admob.android.ads.ak) (obj)).a();
        com.admob.android.ads.analytics.InstallReceiver.a(context, intent);
_L1:
        return;
        context;
        if(com.admob.android.ads.bu.a("AdMobSDK", 6))
        {
            android.util.Log.e("AdMobSDK", "Unhandled exception processing Market install.", context);
            return;
        }
          goto _L1
    }
}
