// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.SystemClock;
import android.util.Log;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

// Referenced classes of package com.admob.android.ads:
//            az, AdMobActivity, bu, au, 
//            y, ak, ab, v, 
//            s, q, c, ac, 
//            w, aw, ag, ae

final class ah
{

    ah()
    {
    }

    static com.admob.android.ads.ab a(com.admob.android.ads.ae ae, android.content.Context context, java.lang.String s1, java.lang.String s2, int i, int j, int k, com.admob.android.ads.ac ac1, 
            int l, com.admob.android.ads.v v1, com.admob.android.ads.q q1, com.admob.android.ads.c c1)
    {
        if(context.checkCallingOrSelfPermission("android.permission.INTERNET") == -1)
            com.admob.android.ads.az.a("Cannot request an ad without Internet permissions!  Open manifest.xml and just before the final </manifest> tag add:  <uses-permission android:name=\"android.permission.INTERNET\" />");
        if(!f)
        {
            f = true;
            boolean flag = true;
            android.content.pm.ResolveInfo resolveinfo = context.getPackageManager().resolveActivity(new Intent(context, com/admob/android/ads/AdMobActivity), 0x10000);
            if(resolveinfo == null || resolveinfo.activityInfo == null || !"com.admob.android.ads.AdMobActivity".equals(resolveinfo.activityInfo.name))
            {
                if(com.admob.android.ads.bu.a("AdMobSDK", 6))
                    android.util.Log.e("AdMobSDK", "could not find com.admob.android.ads.AdMobActivity, please make sure it is registered in AndroidManifest.xml");
                flag = false;
            } else
            {
                if(resolveinfo.activityInfo.theme != 0x1030007)
                {
                    if(com.admob.android.ads.bu.a("AdMobSDK", 6))
                        android.util.Log.e("AdMobSDK", "The activity Theme for com.admob.android.ads.AdMobActivity is not @android:style/Theme.NoTitleBar.Fullscreen, please change in AndroidManifest.xml");
                    flag = false;
                }
                if((resolveinfo.activityInfo.configChanges & 0x80) == 0)
                {
                    if(com.admob.android.ads.bu.a("AdMobSDK", 6))
                        android.util.Log.e("AdMobSDK", "The android:configChanges value of the com.admob.android.ads.AdMobActivity must include orientation");
                    flag = false;
                }
                if((resolveinfo.activityInfo.configChanges & 0x10) == 0)
                {
                    if(com.admob.android.ads.bu.a("AdMobSDK", 6))
                        android.util.Log.e("AdMobSDK", "The android:configChanges value of the com.admob.android.ads.AdMobActivity must include keyboard");
                    flag = false;
                }
                if((resolveinfo.activityInfo.configChanges & 0x20) == 0)
                {
                    if(com.admob.android.ads.bu.a("AdMobSDK", 6))
                        android.util.Log.e("AdMobSDK", "The android:configChanges value of the com.admob.android.ads.AdMobActivity must include keyboardHidden");
                    flag = false;
                }
            }
            e = flag;
        }
        if(e) goto _L2; else goto _L1
_L1:
        if(com.admob.android.ads.bu.a("AdMobSDK", 6))
            android.util.Log.e("AdMobSDK", "com.admob.android.ads.AdMobActivity must be registered in your AndroidManifest.xml file.");
        context = null;
_L4:
        return context;
_L2:
        com.admob.android.ads.au.a(context);
        long l1 = android.os.SystemClock.uptimeMillis();
        s1 = com.admob.android.ads.ah.a(context, s1, s2, l, v1, q1, c1);
        s2 = com.admob.android.ads.y.a(a, null, com.admob.android.ads.az.g(context), null, 3000, null, s1);
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
            android.util.Log.d("AdMobSDK", (new StringBuilder()).append("Requesting an ad with POST params:  ").append(s1).toString());
        boolean flag1 = s2.a();
        long l2;
        if(flag1)
            s1 = new String(s2.c());
        else
            s1 = null;
        if(!flag1)
            break; /* Loop/switch isn't completed */
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
            android.util.Log.d("AdMobSDK", "Ad response: ");
        if(s1.equals(""))
            break; /* Loop/switch isn't completed */
        s2 = new JSONTokener(s1);
        s2 = new JSONObject(s2);
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
            android.util.Log.d("AdMobSDK", s2.toString(4));
        ae = com.admob.android.ads.ab.a(ae, context, s2, i, j, k, ac1, v1);
_L5:
        context = ae;
        if(com.admob.android.ads.bu.a("AdMobSDK", 4))
        {
            l2 = android.os.SystemClock.uptimeMillis();
            context = ae;
            if(ae == null)
            {
                android.util.Log.i("AdMobSDK", (new StringBuilder()).append("No fill.  Server replied that no ads are available (").append(l2 - l1).append("ms)").toString());
                return ae;
            }
        }
        if(true) goto _L4; else goto _L3
        ae;
        if(com.admob.android.ads.bu.a("AdMobSDK", 5))
            android.util.Log.w("AdMobSDK", (new StringBuilder()).append("Problem decoding ad response.  Cannot display ad: \"").append(s1).append("\"").toString(), ae);
_L3:
        ae = null;
          goto _L5
    }

    static com.admob.android.ads.ab a(com.admob.android.ads.ae ae, android.content.Context context, java.lang.String s1, java.lang.String s2, com.admob.android.ads.q q1)
    {
        return com.admob.android.ads.ah.a(ae, context, s1, s2, -1, -1, -1, null, -1, com.admob.android.ads.v.b, q1, null);
    }

    static java.lang.String a(android.content.Context context, java.lang.String s1, java.lang.String s2, int i)
    {
        return com.admob.android.ads.ah.a(context, null, null, 0, null, null, null);
    }

    private static java.lang.String a(android.content.Context context, java.lang.String s1, java.lang.String s2, int i, com.admob.android.ads.v v1, com.admob.android.ads.q q1, com.admob.android.ads.c c1)
    {
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
            android.util.Log.d("AdMobSDK", "Ad request:");
        com.admob.android.ads.az.a(context);
        java.lang.StringBuilder stringbuilder = new StringBuilder();
        long l = java.lang.System.currentTimeMillis();
        stringbuilder.append("z").append("=").append(l / 1000L).append(".").append(l % 1000L);
        com.admob.android.ads.v v2;
        if(v1 == null)
            v2 = com.admob.android.ads.v.c;
        else
            v2 = v1;
        com.admob.android.ads.ah.a(stringbuilder, "ad_type", v2.toString());
        com.admob.android.ads.s.a[v2.ordinal()];
        JVM INSTR tableswitch 1 2: default 124
    //                   1 181
    //                   2 205;
           goto _L1 _L2 _L3
_L1:
        com.admob.android.ads.ah.a(stringbuilder, "rt", "0");
        q1 = null;
        if(v1 == com.admob.android.ads.v.b)
            q1 = com.admob.android.ads.az.e(context);
        c1 = q1;
        if(q1 == null)
            c1 = com.admob.android.ads.az.d(context);
        if(c1 == null)
            throw new IllegalStateException("Publisher ID is not set!  To serve ads you must set your publisher ID assigned from www.admob.com.  Either add it to AndroidManifest.xml under the <application> tag or call AdManager.setPublisherId().");
        break; /* Loop/switch isn't completed */
_L2:
        if(q1 != null)
            com.admob.android.ads.ah.a(stringbuilder, "event", java.lang.String.valueOf(q1.ordinal()));
        continue; /* Loop/switch isn't completed */
_L3:
        if(c1 != null)
            com.admob.android.ads.ah.a(stringbuilder, "dim", c1.toString());
        if(true) goto _L1; else goto _L4
_L4:
        com.admob.android.ads.ah.a(stringbuilder, "s", ((java.lang.String) (c1)));
        com.admob.android.ads.ah.a(stringbuilder, "l", com.admob.android.ads.au.a());
        com.admob.android.ads.ah.a(stringbuilder, "f", "jsonp");
        com.admob.android.ads.ah.a(stringbuilder, "client_sdk", "1");
        com.admob.android.ads.ah.a(stringbuilder, "ex", "1");
        com.admob.android.ads.ah.a(stringbuilder, "v", "20101109-ANDROID-3312276cc1406347");
        com.admob.android.ads.ah.a(stringbuilder, "isu", com.admob.android.ads.az.g(context));
        com.admob.android.ads.ah.a(stringbuilder, "so", com.admob.android.ads.az.j(context));
        if(i > 0)
            com.admob.android.ads.ah.a(stringbuilder, "screen_width", java.lang.String.valueOf(i));
        com.admob.android.ads.ah.a(stringbuilder, "d[coord]", com.admob.android.ads.az.i(context));
        com.admob.android.ads.ah.a(stringbuilder, "d[coord_timestamp]", com.admob.android.ads.az.c());
        com.admob.android.ads.ah.a(stringbuilder, "d[pc]", com.admob.android.ads.az.d());
        com.admob.android.ads.ah.a(stringbuilder, "d[dob]", com.admob.android.ads.az.f());
        com.admob.android.ads.ah.a(stringbuilder, "d[gender]", com.admob.android.ads.az.g());
        com.admob.android.ads.ah.a(stringbuilder, "k", s1);
        com.admob.android.ads.ah.a(stringbuilder, "search", s2);
        com.admob.android.ads.ah.a(stringbuilder, "density", java.lang.String.valueOf(com.admob.android.ads.ac.d()));
        if(com.admob.android.ads.az.f(context))
        {
            if(com.admob.android.ads.bu.a("AdMobSDK", 4))
                android.util.Log.i("AdMobSDK", "Making ad request in test mode");
            com.admob.android.ads.ah.a(stringbuilder, "m", "test");
            s2 = com.admob.android.ads.az.a();
            s1 = s2;
            if(v1 == com.admob.android.ads.v.b)
            {
                s1 = s2;
                if(com.admob.android.ads.w.a.toString().equals(s2))
                    s1 = "video_int";
            }
            com.admob.android.ads.ah.a(stringbuilder, "test_action", s1);
        }
        if(d == null)
        {
            s1 = new StringBuilder();
            s2 = context.getPackageManager();
            v1 = s2.queryIntentActivities(new Intent("android.intent.action.VIEW", android.net.Uri.parse("geo:0,0?q=donuts")), 0x10000);
            if(v1 == null || v1.size() == 0)
                s1.append("m");
            v1 = s2.queryIntentActivities(new Intent("android.intent.action.VIEW", android.net.Uri.parse("market://search?q=pname:com.admob")), 0x10000);
            if(v1 == null || v1.size() == 0)
            {
                if(s1.length() > 0)
                    s1.append(",");
                s1.append("a");
            }
            s2 = s2.queryIntentActivities(new Intent("android.intent.action.VIEW", android.net.Uri.parse("tel://6509313940")), 0x10000);
            if(s2 == null || s2.size() == 0)
            {
                if(s1.length() > 0)
                    s1.append(",");
                s1.append("t");
            }
            d = s1.toString();
        }
        s1 = d;
        if(s1 != null && s1.length() > 0)
            com.admob.android.ads.ah.a(stringbuilder, "ic", s1);
        com.admob.android.ads.ah.a(stringbuilder, "audio", java.lang.String.valueOf(com.admob.android.ads.az.a(new aw(context)).ordinal()));
        i = b + 1;
        b = i;
        if(i == 1)
        {
            c = java.lang.System.currentTimeMillis();
            com.admob.android.ads.ah.a(stringbuilder, "pub_data[identifier]", com.admob.android.ads.az.b(context));
            com.admob.android.ads.ah.a(stringbuilder, "pub_data[version]", java.lang.String.valueOf(com.admob.android.ads.az.c(context)));
        } else
        {
            com.admob.android.ads.ah.a(stringbuilder, "stats[reqs]", java.lang.String.valueOf(b));
            com.admob.android.ads.ah.a(stringbuilder, "stats[time]", java.lang.String.valueOf((java.lang.System.currentTimeMillis() - c) / 1000L));
        }
        return stringbuilder.toString();
    }

    private static void a(java.lang.StringBuilder stringbuilder, java.lang.String s1, java.lang.String s2)
    {
        if(s2 == null || s2.length() <= 0)
            break MISSING_BLOCK_LABEL_89;
        stringbuilder.append("&").append(java.net.URLEncoder.encode(s1, "UTF-8")).append("=").append(java.net.URLEncoder.encode(s2, "UTF-8"));
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
            android.util.Log.d("AdMobSDK", (new StringBuilder()).append("    ").append(s1).append(": ").append(s2).toString());
_L1:
        return;
        stringbuilder;
        if(com.admob.android.ads.bu.a("AdMobSDK", 6))
        {
            android.util.Log.e("AdMobSDK", "UTF-8 encoding is not supported on this device.  Ad requests are impossible.", stringbuilder);
            return;
        }
          goto _L1
    }

    private static java.lang.String a = "http://r.admob.com/ad_source.php";
    private static int b;
    private static long c;
    private static java.lang.String d = null;
    private static boolean e = false;
    private static boolean f = false;

}
