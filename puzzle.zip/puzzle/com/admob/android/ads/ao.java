// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.content.Context;
import com.admob.android.ads.a.a;
import org.json.JSONObject;

// Referenced classes of package com.admob.android.ads:
//            p, ab

public final class ao extends com.admob.android.ads.a.a
{

    public ao(android.content.Context context, com.admob.android.ads.ab ab)
    {
        super(context, false, null);
        c = null;
        d = null;
        e = false;
        b = new p(this, this, ab);
        setWebViewClient(b);
    }

    public final void b()
    {
        if((b instanceof com.admob.android.ads.p) && ((com.admob.android.ads.p)b).b && !e)
        {
            e = true;
            java.lang.Object obj;
            java.lang.Object obj1;
            if(c == null)
                obj = "null";
            else
                obj = c;
            if(d == null)
                obj1 = "null";
            else
                obj1 = d;
            a("init", new java.lang.Object[] {
                obj, obj1
            });
        }
    }

    public org.json.JSONObject c;
    public org.json.JSONObject d;
    private boolean e;
}
