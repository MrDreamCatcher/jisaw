// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.util.Log;
import com.admob.android.ads.a.a;
import java.lang.ref.WeakReference;
import java.util.Iterator;
import java.util.Vector;

// Referenced classes of package com.admob.android.ads:
//            as, bp, bu, az, 
//            at, ck, w, k, 
//            ac, br

public class AdMobActivity extends android.app.Activity
{

    public AdMobActivity()
    {
    }

    public void finish()
    {
        if(a != null && a.l)
        {
            android.content.Intent intent = new Intent();
            intent.putExtra("admob_activity", true);
            setResult(-1, intent);
        }
        super.finish();
    }

    public void onConfigurationChanged(android.content.res.Configuration configuration)
    {
        for(java.util.Iterator iterator = b.iterator(); iterator.hasNext(); ((com.admob.android.ads.bp)iterator.next()).a(configuration));
        super.onConfigurationChanged(configuration);
    }

    protected void onCreate(android.os.Bundle bundle)
    {
        java.lang.Object obj;
        super.onCreate(bundle);
        b = new Vector();
        bundle = getIntent().getBundleExtra("o");
        obj = new as();
        if(((com.admob.android.ads.as) (obj)).a(bundle))
            a = ((com.admob.android.ads.as) (obj));
        else
            a = null;
        if(a == null)
        {
            if(com.admob.android.ads.bu.a("AdMobSDK", 6))
                android.util.Log.e("AdMobSDK", "Unable to get openerInfo from intent");
            return;
        }
        com.admob.android.ads.at.a(a.c, null, com.admob.android.ads.az.g(this));
        obj = a.a;
        bundle = new WeakReference(this);
        com.admob.android.ads.ck.a[((com.admob.android.ads.w) (obj)).ordinal()];
        JVM INSTR tableswitch 1 2: default 144
    //                   1 216
    //                   2 260;
           goto _L1 _L2 _L3
_L1:
        bundle = null;
_L11:
        if(bundle == null) goto _L5; else goto _L4
_L4:
        com.admob.android.ads.ck.b[a.e.ordinal()];
        JVM INSTR tableswitch 1 2: default 188
    //                   1 295
    //                   2 320;
           goto _L6 _L7 _L8
_L6:
        if(com.admob.android.ads.bu.a("AdMobSDK", 2))
            android.util.Log.v("AdMobSDK", "Setting target orientation to sensor");
        setRequestedOrientation(4);
_L9:
        setContentView(bundle);
        return;
_L2:
        setTheme(0x1030007);
        bundle = com.admob.android.ads.a.a.a(getApplicationContext(), a.d, false, a.f, a.g, com.admob.android.ads.ac.a(this), bundle);
        continue; /* Loop/switch isn't completed */
_L3:
        com.admob.android.ads.as as1 = a;
        bundle = new br(getApplicationContext(), bundle);
        bundle.a(as1);
        b.add(bundle);
        continue; /* Loop/switch isn't completed */
_L7:
        if(com.admob.android.ads.bu.a("AdMobSDK", 2))
            android.util.Log.v("AdMobSDK", "Setting target orientation to landscape");
        setRequestedOrientation(0);
        continue; /* Loop/switch isn't completed */
_L8:
        if(com.admob.android.ads.bu.a("AdMobSDK", 2))
            android.util.Log.v("AdMobSDK", "Setting target orientation to portrait");
        setRequestedOrientation(1);
        if(true) goto _L9; else goto _L5
_L5:
        finish();
        return;
        if(true) goto _L11; else goto _L10
_L10:
    }

    protected void onDestroy()
    {
        b.clear();
        super.onDestroy();
    }

    private com.admob.android.ads.as a;
    private java.util.Vector b;
}
