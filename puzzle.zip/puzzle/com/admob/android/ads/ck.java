// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;


// Referenced classes of package com.admob.android.ads:
//            k, w

final class ck
{

    static final int a[];
    static final int b[];

    static 
    {
        b = new int[com.admob.android.ads.k.values().length];
        try
        {
            b[com.admob.android.ads.k.b.ordinal()] = 1;
        }
        catch(java.lang.NoSuchFieldError nosuchfielderror4) { }
        try
        {
            b[com.admob.android.ads.k.a.ordinal()] = 2;
        }
        catch(java.lang.NoSuchFieldError nosuchfielderror3) { }
        try
        {
            b[com.admob.android.ads.k.c.ordinal()] = 3;
        }
        catch(java.lang.NoSuchFieldError nosuchfielderror2) { }
        a = new int[com.admob.android.ads.w.values().length];
        try
        {
            a[com.admob.android.ads.w.d.ordinal()] = 1;
        }
        catch(java.lang.NoSuchFieldError nosuchfielderror1) { }
        try
        {
            a[com.admob.android.ads.w.c.ordinal()] = 2;
        }
        catch(java.lang.NoSuchFieldError nosuchfielderror)
        {
            return;
        }
    }
}
