// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.app.Activity;
import android.util.Log;
import android.view.View;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.admob.android.ads:
//            br, ar, aj, at, 
//            bu

public final class cd
    implements android.view.View.OnClickListener
{

    public cd(com.admob.android.ads.br br1, com.admob.android.ads.ar ar1, java.lang.ref.WeakReference weakreference)
    {
        a = new WeakReference(br1);
        b = new WeakReference(ar1);
        c = weakreference;
    }

    public final void onClick(android.view.View view)
    {
        com.admob.android.ads.br br1 = (com.admob.android.ads.br)a.get();
        if(br1 != null)
        {
            com.admob.android.ads.br.a(br1, false);
            com.admob.android.ads.ar ar1 = (com.admob.android.ads.ar)b.get();
            if(ar1 != null)
            {
                android.content.Context context = br1.getContext();
                boolean flag;
                if(!br1.j)
                {
                    br1.j = true;
                    view = new HashMap();
                    view.put("event", "interaction");
                } else
                {
                    view = null;
                }
                br1.f.a(ar1.e, view);
                flag = br1.e();
                if(flag)
                    br1.f();
                br1.a(flag);
                view = new at();
                try
                {
                    view.a(context, new JSONObject(ar1.f), null);
                }
                catch(org.json.JSONException jsonexception)
                {
                    if(com.admob.android.ads.bu.a("AdMobSDK", 6))
                        android.util.Log.e("AdMobSDK", "Could not create JSONObject from button click", jsonexception);
                }
                view.d();
                if(c != null)
                {
                    android.app.Activity activity = (android.app.Activity)c.get();
                    if(activity != null)
                    {
                        view.a(activity, br1);
                        return;
                    }
                }
            }
        }
    }

    private java.lang.ref.WeakReference a;
    private java.lang.ref.WeakReference b;
    private java.lang.ref.WeakReference c;
}
