// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.GregorianCalendar;

// Referenced classes of package com.admob.android.ads:
//            w, bu, aw, ag, 
//            bs, ba

public class az
{

    private az()
    {
    }

    static long a(long l1)
    {
        k = l1;
        return l1;
    }

    static android.location.Location a(android.location.Location location)
    {
        h = location;
        return location;
    }

    static com.admob.android.ads.ag a(com.admob.android.ads.aw aw1)
    {
        int i1 = aw1.a();
        if(com.admob.android.ads.az.b())
            return com.admob.android.ads.ag.c;
        if(aw1.b() || aw1.c() || i1 == 2 || i1 == 1)
            return com.admob.android.ads.ag.b;
        i1 = aw1.d();
        if(i1 == 0 || i1 == 1)
            return com.admob.android.ads.ag.b;
        else
            return com.admob.android.ads.ag.a;
    }

    public static java.lang.String a()
    {
        return e;
    }

    private static java.lang.String a(android.os.Bundle bundle, java.lang.String s, java.lang.String s1)
    {
        Object obj = null;
        s = bundle.getString(s);
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
            android.util.Log.d("AdMobSDK", (new StringBuilder()).append("Publisher ID read from AndroidManifest.xml is ").append(s).toString());
        bundle = obj;
        if(s1 == null)
        {
            bundle = obj;
            if(s != null)
                bundle = s;
        }
        return bundle;
    }

    static void a(android.content.Context context)
    {
        if(o)
            break MISSING_BLOCK_LABEL_222;
        o = true;
        android.content.pm.PackageManager packagemanager;
        android.content.pm.ApplicationInfo applicationinfo;
        java.lang.String s;
        try
        {
            packagemanager = context.getPackageManager();
            context = context.getPackageName();
            applicationinfo = packagemanager.getApplicationInfo(context, 128);
        }
        // Misplaced declaration of an exception variable
        catch(android.content.Context context)
        {
            return;
        }
        if(applicationinfo == null)
            break MISSING_BLOCK_LABEL_168;
        if(applicationinfo.metaData == null)
            break MISSING_BLOCK_LABEL_101;
        s = com.admob.android.ads.az.a(applicationinfo.metaData, "ADMOB_PUBLISHER_ID", c);
        if(s == null)
            break MISSING_BLOCK_LABEL_61;
        com.admob.android.ads.az.b(s);
        s = com.admob.android.ads.az.a(applicationinfo.metaData, "ADMOB_INTERSTITIAL_PUBLISHER_ID", d);
        if(s == null)
            break MISSING_BLOCK_LABEL_82;
        com.admob.android.ads.az.c(s);
        if(!j)
            i = applicationinfo.metaData.getBoolean("ADMOB_ALLOW_LOCATION_FOR_ADS", false);
        a = applicationinfo.packageName;
        if(c != null)
            com.admob.android.ads.az.e(c);
        if(d != null)
            com.admob.android.ads.az.e(d);
        if(com.admob.android.ads.bu.a("AdMobSDK", 2))
            android.util.Log.v("AdMobSDK", (new StringBuilder()).append("Application's package name is ").append(a).toString());
        context = packagemanager.getPackageInfo(context, 0);
        if(context == null)
            break MISSING_BLOCK_LABEL_222;
        b = ((android.content.pm.PackageInfo) (context)).versionCode;
        if(com.admob.android.ads.bu.a("AdMobSDK", 2))
            android.util.Log.v("AdMobSDK", (new StringBuilder()).append("Application's version number is ").append(b).toString());
    }

    protected static void a(java.lang.String s)
    {
        if(com.admob.android.ads.bu.a("AdMobSDK", 6))
            android.util.Log.e("AdMobSDK", s);
        throw new IllegalArgumentException(s);
    }

    public static java.lang.String b(android.content.Context context)
    {
        if(a == null)
            com.admob.android.ads.az.a(context);
        return a;
    }

    public static void b(java.lang.String s)
    {
        com.admob.android.ads.az.e(s);
        if(com.admob.android.ads.bu.a("AdMobSDK", 4))
            android.util.Log.i("AdMobSDK", (new StringBuilder()).append("Publisher ID set to ").append(s).toString());
        c = s;
    }

    public static boolean b()
    {
        return "unknown".equals(android.os.Build.BOARD) && "generic".equals(android.os.Build.DEVICE) && "generic".equals(android.os.Build.BRAND);
    }

    protected static int c(android.content.Context context)
    {
        if(a == null)
            com.admob.android.ads.az.a(context);
        return b;
    }

    static java.lang.String c()
    {
        return java.lang.String.valueOf(k / 1000L);
    }

    public static void c(java.lang.String s)
    {
        com.admob.android.ads.az.e(s);
        if(com.admob.android.ads.bu.a("AdMobSDK", 4))
            android.util.Log.i("AdMobSDK", (new StringBuilder()).append("Interstitial Publisher ID set to ").append(s).toString());
        d = s;
    }

    public static java.lang.String d()
    {
        return l;
    }

    public static java.lang.String d(android.content.Context context)
    {
        if(c == null)
            com.admob.android.ads.az.a(context);
        if(c == null && com.admob.android.ads.bu.a("AdMobSDK", 6))
            android.util.Log.e("AdMobSDK", "getPublisherId returning null publisher id.  Please set the publisher id in AndroidManifest.xml or using AdManager.setPublisherId(String)");
        return c;
    }

    protected static java.lang.String d(java.lang.String s)
    {
        Object obj1 = null;
        java.lang.Object obj = obj1;
        if(s != null)
        {
            obj = obj1;
            if(s.length() > 0)
                try
                {
                    obj = java.security.MessageDigest.getInstance("MD5");
                    ((java.security.MessageDigest) (obj)).update(s.getBytes(), 0, s.length());
                    obj = java.lang.String.format("%032X", new java.lang.Object[] {
                        new BigInteger(1, ((java.security.MessageDigest) (obj)).digest())
                    });
                }
                catch(java.lang.Exception exception)
                {
                    if(com.admob.android.ads.bu.a("AdMobSDK", 3))
                        android.util.Log.d("AdMobSDK", (new StringBuilder()).append("Could not generate hash of ").append(s).toString(), exception);
                    return s.substring(0, 32);
                }
        }
        return ((java.lang.String) (obj));
    }

    public static java.lang.String e(android.content.Context context)
    {
        if(d == null)
            com.admob.android.ads.az.a(context);
        if(d == null && com.admob.android.ads.bu.a("AdMobSDK", 6))
            android.util.Log.e("AdMobSDK", "getInterstitialPublisherId returning null publisher id.  Please set the publisher id in AndroidManifest.xml or using AdManager.setPublisherId(String)");
        return d;
    }

    public static java.util.GregorianCalendar e()
    {
        return m;
    }

    private static void e(java.lang.String s)
    {
        if(s == null || s.length() != 15)
            com.admob.android.ads.az.a((new StringBuilder()).append("SETUP ERROR:  Incorrect AdMob publisher ID.  Should 15 [a-f,0-9] characters:  ").append(c).toString());
        if(a != null && s.equalsIgnoreCase("a1496ced2842262") && !"com.admob.android.ads".equals(a) && !"com.example.admob.lunarlander".equals(a))
            com.admob.android.ads.az.a("SETUP ERROR:  Cannot use the sample publisher ID (a1496ced2842262).  Yours is available on www.admob.com.");
    }

    static java.lang.String f()
    {
        java.lang.String s = null;
        java.util.GregorianCalendar gregoriancalendar = com.admob.android.ads.az.e();
        if(gregoriancalendar != null)
            s = java.lang.String.format("%04d%02d%02d", new java.lang.Object[] {
                java.lang.Integer.valueOf(gregoriancalendar.get(1)), java.lang.Integer.valueOf(gregoriancalendar.get(2) + 1), java.lang.Integer.valueOf(gregoriancalendar.get(5))
            });
        return s;
    }

    public static boolean f(android.content.Context context)
    {
        if(f != null)
        {
            java.lang.String s = com.admob.android.ads.az.g(context);
            context = s;
            if(s == null)
                context = "emulator";
            return java.util.Arrays.binarySearch(f, context) >= 0;
        } else
        {
            return false;
        }
    }

    static java.lang.String g()
    {
        if(n == com.admob.android.ads.bs.a)
            return "m";
        if(n == com.admob.android.ads.bs.b)
            return "f";
        else
            return null;
    }

    public static java.lang.String g(android.content.Context context)
    {
        if(g == null)
        {
            context = android.provider.Settings.Secure.getString(context.getContentResolver(), "android_id");
            if(context == null || com.admob.android.ads.az.b())
            {
                g = "emulator";
                android.util.Log.i("AdMobSDK", "To get test ads on the emulator use AdManager.setTestDevices( new String[] { AdManager.TEST_EMULATOR } )");
            } else
            {
                g = com.admob.android.ads.az.d(context);
                android.util.Log.i("AdMobSDK", (new StringBuilder()).append("To get test ads on this device use AdManager.setTestDevices( new String[] { \"").append(g).append("\" } )").toString());
            }
            if(com.admob.android.ads.bu.a("AdMobSDK", 3))
                android.util.Log.d("AdMobSDK", (new StringBuilder()).append("The user ID is ").append(g).toString());
        }
        if(g == "emulator")
            return null;
        else
            return g;
    }

    static android.location.Location h()
    {
        return h;
    }

    public static android.location.Location h(android.content.Context context)
    {
        if(com.admob.android.ads.az.b() && !i && com.admob.android.ads.bu.a("AdMobSDK", 4))
        {
            android.util.Log.i("AdMobSDK", "Location information is not being used for ad requests. Enable location");
            android.util.Log.i("AdMobSDK", "based ads with AdManager.setAllowUseOfLocation(true) or by setting ");
            android.util.Log.i("AdMobSDK", "meta-data ADMOB_ALLOW_LOCATION_FOR_ADS to true in AndroidManifest.xml");
        }
        if(!i || context == null || h != null && java.lang.System.currentTimeMillis() <= k + 0xdbba0L) goto _L2; else goto _L1
_L1:
        context;
        JVM INSTR monitorenter ;
        if(h != null && java.lang.System.currentTimeMillis() <= k + 0xdbba0L) goto _L4; else goto _L3
_L3:
        k = java.lang.System.currentTimeMillis();
        if(context.checkCallingOrSelfPermission("android.permission.ACCESS_COARSE_LOCATION") != 0) goto _L6; else goto _L5
_L5:
        android.location.LocationManager locationmanager;
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
            android.util.Log.d("AdMobSDK", "Trying to get locations from the network.");
        locationmanager = (android.location.LocationManager)context.getSystemService("location");
        if(locationmanager == null) goto _L8; else goto _L7
_L7:
        java.lang.Object obj;
        obj = new Criteria();
        ((android.location.Criteria) (obj)).setAccuracy(2);
        ((android.location.Criteria) (obj)).setCostAllowed(false);
        obj = locationmanager.getBestProvider(((android.location.Criteria) (obj)), true);
        boolean flag = true;
_L18:
        java.lang.Object obj1;
        android.location.LocationManager locationmanager1;
        boolean flag1;
        locationmanager1 = locationmanager;
        obj1 = obj;
        flag1 = flag;
        if(obj != null) goto _L10; else goto _L9
_L9:
        locationmanager1 = locationmanager;
        obj1 = obj;
        flag1 = flag;
        if(context.checkCallingOrSelfPermission("android.permission.ACCESS_FINE_LOCATION") != 0) goto _L10; else goto _L11
_L11:
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
            android.util.Log.d("AdMobSDK", "Trying to get locations from GPS.");
        locationmanager1 = (android.location.LocationManager)context.getSystemService("location");
        if(locationmanager1 == null) goto _L13; else goto _L12
_L12:
        obj = new Criteria();
        ((android.location.Criteria) (obj)).setAccuracy(1);
        ((android.location.Criteria) (obj)).setCostAllowed(false);
        obj1 = locationmanager1.getBestProvider(((android.location.Criteria) (obj)), true);
        flag1 = true;
_L10:
        if(flag1) goto _L15; else goto _L14
_L14:
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
            android.util.Log.d("AdMobSDK", "Cannot access user's location.  Permissions are not set.");
_L4:
        context;
        JVM INSTR monitorexit ;
_L2:
        return h;
_L15:
        if(obj1 != null)
            break MISSING_BLOCK_LABEL_332;
        if(!com.admob.android.ads.bu.a("AdMobSDK", 3)) goto _L4; else goto _L16
_L16:
        android.util.Log.d("AdMobSDK", "No location providers are available.  Ads will not be geotargeted.");
          goto _L4
        obj;
        throw obj;
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
            android.util.Log.d("AdMobSDK", "Location provider setup successfully.");
        locationmanager1.requestLocationUpdates(((java.lang.String) (obj1)), 0L, 0.0F, new ba(locationmanager1), context.getMainLooper());
          goto _L4
_L13:
        flag1 = true;
        obj1 = obj;
        if(true) goto _L10; else goto _L8
_L8:
        obj = null;
        flag = true;
        continue; /* Loop/switch isn't completed */
_L6:
        obj = null;
        locationmanager = null;
        flag = false;
        if(true) goto _L18; else goto _L17
_L17:
    }

    static long i()
    {
        return k;
    }

    static java.lang.String i(android.content.Context context)
    {
        Object obj = null;
        android.location.Location location = com.admob.android.ads.az.h(context);
        context = obj;
        if(location != null)
            context = (new StringBuilder()).append(location.getLatitude()).append(",").append(location.getLongitude()).toString();
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
            android.util.Log.d("AdMobSDK", (new StringBuilder()).append("User coordinates are ").append(context).toString());
        return context;
    }

    public static java.lang.String j(android.content.Context context)
    {
        java.lang.String s = "p";
        if(((android.view.WindowManager)context.getSystemService("window")).getDefaultDisplay().getOrientation() == 1)
            s = "l";
        return s;
    }

    private static java.lang.String a;
    private static int b;
    private static java.lang.String c;
    private static java.lang.String d;
    private static java.lang.String e;
    private static java.lang.String f[] = null;
    private static java.lang.String g;
    private static android.location.Location h;
    private static boolean i = false;
    private static boolean j = false;
    private static long k;
    private static java.lang.String l;
    private static java.util.GregorianCalendar m;
    private static com.admob.android.ads.bs n;
    private static boolean o = false;
    private static java.lang.Boolean p = null;

    static 
    {
        e = com.admob.android.ads.w.a.toString();
        if(com.admob.android.ads.bu.a("AdMobSDK", 4))
            android.util.Log.i("AdMobSDK", "AdMob SDK version is 20101109-ANDROID-3312276cc1406347");
    }
}
