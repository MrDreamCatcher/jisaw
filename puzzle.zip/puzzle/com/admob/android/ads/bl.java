// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.view.animation.Interpolator;

public final class bl
    implements android.view.animation.Interpolator
{

    public bl(android.view.animation.Interpolator interpolator, long l, long l1, long l2)
    {
        a = interpolator;
        b = (float)l / (float)l2;
        c = (float)l1 / (float)l2;
    }

    public final float getInterpolation(float f)
    {
        if(f <= b)
            return -1F;
        if(f <= b + c)
            return a.getInterpolation((f - b) / c);
        else
            return 2.0F;
    }

    private android.view.animation.Interpolator a;
    private float b;
    private float c;
}
