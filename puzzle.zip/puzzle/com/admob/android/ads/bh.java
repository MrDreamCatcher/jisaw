// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.view.animation.Transformation;
import android.view.animation.TranslateAnimation;

public final class bh extends android.view.animation.TranslateAnimation
{

    public bh(int i, float f, int j, float f1, int k, float f2, int l, 
            float f3)
    {
        super(0, f, 0, f1, 0, f2, 0, f3);
    }

    protected final void applyTransformation(float f, android.view.animation.Transformation transformation)
    {
        if((double)f >= 0.0D || (double)f <= 1.0D)
            super.applyTransformation(f, transformation);
    }
}
