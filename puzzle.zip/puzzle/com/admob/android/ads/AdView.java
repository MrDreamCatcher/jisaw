// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.content.Context;
import android.os.Handler;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.widget.RelativeLayout;
import android.widget.TextView;

// Referenced classes of package com.admob.android.ads:
//            c, ab, v, bu, 
//            ac, x, bd, r, 
//            f, i, ai, h, 
//            g, e

public class AdView extends android.widget.RelativeLayout
{

    public AdView(android.content.Context context, android.util.AttributeSet attributeset)
    {
        this(context, attributeset, 0);
    }

    public AdView(android.content.Context context, android.util.AttributeSet attributeset, int i1)
    {
        this(context, attributeset, i1, com.admob.android.ads.c.a);
    }

    public AdView(android.content.Context context, android.util.AttributeSet attributeset, int i1, com.admob.android.ads.c c1)
    {
        super(context, attributeset, i1);
        m = true;
        if(a == null)
            a = new Boolean(isInEditMode());
        if(s == null && !a.booleanValue())
        {
            android.os.Handler handler = new Handler();
            s = handler;
            com.admob.android.ads.ab.a(handler);
        }
        r = c1;
        if(c1 != com.admob.android.ads.c.a)
            q = com.admob.android.ads.v.a;
        setDescendantFocusability(0x40000);
        setClickable(true);
        setLongClickable(false);
        setGravity(17);
        int j1;
        int k1;
        int l1;
        if(attributeset != null)
        {
            c1 = (new StringBuilder()).append("http://schemas.android.com/apk/res/").append(context.getPackageName()).toString();
            if(attributeset.getAttributeBooleanValue(c1, "testing", false) && com.admob.android.ads.bu.a("AdMobSDK", 5))
                android.util.Log.w("AdMobSDK", "AdView's \"testing\" XML attribute has been deprecated and will be ignored.  Please delete it from your XML layout and use AdManager.setTestDevices instead.");
            l1 = attributeset.getAttributeUnsignedIntValue(c1, "backgroundColor", 0xff000000);
            j1 = attributeset.getAttributeUnsignedIntValue(c1, "textColor", -1);
            if(j1 >= 0)
                b(j1);
            k1 = attributeset.getAttributeUnsignedIntValue(c1, "primaryTextColor", -1);
            j1 = attributeset.getAttributeUnsignedIntValue(c1, "secondaryTextColor", -1);
            i = attributeset.getAttributeValue(c1, "keywords");
            a(attributeset.getAttributeIntValue(c1, "refreshInterval", 0));
            boolean flag = attributeset.getAttributeBooleanValue(c1, "isGoneWithoutAd", false);
            if(flag)
                a(flag);
        } else
        {
            j1 = -1;
            k1 = -1;
            l1 = 0xff000000;
        }
        setBackgroundColor(l1);
        c(k1);
        d(j1);
        b = null;
        p = null;
        if(a.booleanValue())
        {
            context = new TextView(context, attributeset, i1);
            context.setBackgroundColor(c());
            context.setTextColor(a());
            context.setPadding(10, 10, 10, 10);
            context.setTextSize(16F);
            context.setGravity(16);
            context.setText("Ads by AdMob");
            addView(context, new android.widget.RelativeLayout.LayoutParams(-1, -1));
            return;
        } else
        {
            f();
            return;
        }
    }

    static com.admob.android.ads.ac a(com.admob.android.ads.AdView adview)
    {
        return adview.b;
    }

    static void a(com.admob.android.ads.AdView adview, com.admob.android.ads.ab ab1)
    {
        if(adview.k == null)
            break MISSING_BLOCK_LABEL_34;
        if(adview.b != null && adview.b.getParent() != null)
            break MISSING_BLOCK_LABEL_46;
        adview.k.a(adview);
        return;
        adview;
        android.util.Log.w("AdMobSDK", "Unhandled exception raised in your AdListener.onReceiveAd.", adview);
        return;
        try
        {
            adview.k.c(adview);
            return;
        }
        // Misplaced declaration of an exception variable
        catch(com.admob.android.ads.AdView adview)
        {
            android.util.Log.w("AdMobSDK", "Unhandled exception raised in your AdListener.onReceiveRefreshedAd.", adview);
        }
        return;
    }

    static void a(com.admob.android.ads.AdView adview, com.admob.android.ads.ac ac1)
    {
        adview.a(ac1);
    }

    private void a(com.admob.android.ads.ac ac1)
    {
        b = ac1;
        if(l)
        {
            ac1 = new AlphaAnimation(0.0F, 1.0F);
            ac1.setDuration(233L);
            ac1.startNow();
            ac1.setFillAfter(true);
            ac1.setInterpolator(new AccelerateInterpolator());
            startAnimation(ac1);
        }
    }

    static boolean a(com.admob.android.ads.AdView adview, boolean flag)
    {
        adview.n = false;
        return false;
    }

    static com.admob.android.ads.x b(com.admob.android.ads.AdView adview)
    {
        return adview.k;
    }

    static void b(com.admob.android.ads.AdView adview, com.admob.android.ads.ac ac1)
    {
        ac1.setVisibility(8);
        com.admob.android.ads.bd bd1 = new bd(0.0F, -90F, (float)adview.getWidth() / 2.0F, (float)adview.getHeight() / 2.0F, -0.4F * (float)adview.getWidth(), true);
        bd1.setDuration(700L);
        bd1.setFillAfter(true);
        bd1.setInterpolator(new AccelerateInterpolator());
        bd1.setAnimationListener(new r(adview, ac1));
        adview.startAnimation(bd1);
    }

    static void b(com.admob.android.ads.AdView adview, boolean flag)
    {
        adview.b(true);
    }

    private void b(boolean flag)
    {
        this;
        JVM INSTR monitorenter ;
        if(!flag) goto _L2; else goto _L1
_L1:
        if(c <= 0 || getVisibility() != 0) goto _L2; else goto _L3
_L3:
        int i1 = c;
        g();
        if(h())
        {
            e = new f(this);
            s.postDelayed(e, i1);
            if(com.admob.android.ads.bu.a("AdMobSDK", 3))
                android.util.Log.d("AdMobSDK", (new StringBuilder()).append("Ad refresh scheduled for ").append(i1).append(" from now.").toString());
        }
_L6:
        this;
        JVM INSTR monitorexit ;
        return;
_L2:
        if(!flag) goto _L5; else goto _L4
_L4:
        if(c != 0) goto _L6; else goto _L5
_L5:
        g();
          goto _L6
        java.lang.Exception exception;
        exception;
        throw exception;
    }

    static com.admob.android.ads.ac c(com.admob.android.ads.AdView adview, com.admob.android.ads.ac ac1)
    {
        adview.b = ac1;
        return ac1;
    }

    static com.admob.android.ads.i c(com.admob.android.ads.AdView adview)
    {
        if(adview.p == null)
            adview.p = new i(adview);
        return adview.p;
    }

    static java.lang.String d(com.admob.android.ads.AdView adview)
    {
        return adview.i;
    }

    static java.lang.String e(com.admob.android.ads.AdView adview)
    {
        return adview.j;
    }

    private void f()
    {
        com.admob.android.ads.ai.a(getContext());
        if(!m && super.getVisibility() != 0)
        {
            if(com.admob.android.ads.bu.a("AdMobSDK", 5))
                android.util.Log.w("AdMobSDK", "Cannot requestFreshAd() when the AdView is not visible.  Call AdView.setVisibility(View.VISIBLE) first.");
        } else
        if(n)
        {
            if(com.admob.android.ads.bu.a("AdMobSDK", 5))
            {
                android.util.Log.w("AdMobSDK", "Ignoring requestFreshAd() because we are requesting an ad right now already.");
                return;
            }
        } else
        {
            n = true;
            o = android.os.SystemClock.uptimeMillis();
            (new h(this)).start();
            return;
        }
    }

    static void f(com.admob.android.ads.AdView adview)
    {
        if(adview.k != null)
            s.post(new g(adview));
    }

    static long g(com.admob.android.ads.AdView adview)
    {
        return adview.o;
    }

    private void g()
    {
        if(e != null)
        {
            e.a = true;
            e = null;
            if(com.admob.android.ads.bu.a("AdMobSDK", 2))
                android.util.Log.v("AdMobSDK", "Cancelled an ad refresh scheduled for the future.");
        }
    }

    static int h(com.admob.android.ads.AdView adview)
    {
        return adview.c;
    }

    private boolean h()
    {
        if(b != null)
        {
            com.admob.android.ads.ab ab1 = b.c();
            if(ab1 != null && ab1.f() && b.h() < 120L)
            {
                if(com.admob.android.ads.bu.a("AdMobSDK", 3))
                    android.util.Log.d("AdMobSDK", "Cannot refresh CPM ads.  Ignoring request to refresh the ad.");
                return false;
            }
        }
        return true;
    }

    static void i(com.admob.android.ads.AdView adview)
    {
        adview.f();
    }

    public int a()
    {
        return g;
    }

    public void a(int i1)
    {
        int k1 = i1 * 1000;
        if(c == k1) goto _L2; else goto _L1
_L1:
        int j1 = k1;
        if(i1 <= 0) goto _L4; else goto _L3
_L3:
        if(i1 >= 13) goto _L6; else goto _L5
_L5:
        if(com.admob.android.ads.bu.a("AdMobSDK", 5))
            android.util.Log.w("AdMobSDK", (new StringBuilder()).append("AdView.setRequestInterval(").append(i1).append(") seconds must be >= ").append(13).toString());
        j1 = 13000;
_L4:
        c = j1;
        if(i1 <= 0)
            g();
        if(com.admob.android.ads.bu.a("AdMobSDK", 4))
            android.util.Log.i("AdMobSDK", (new StringBuilder()).append("Requesting fresh ads every ").append(i1).append(" seconds.").toString());
_L2:
        return;
_L6:
        j1 = k1;
        if(i1 > 600)
        {
            if(com.admob.android.ads.bu.a("AdMobSDK", 5))
                android.util.Log.w("AdMobSDK", (new StringBuilder()).append("AdView.setRequestInterval(").append(i1).append(") seconds must be <= ").append(600).toString());
            j1 = 0x927c0;
        }
        if(true) goto _L4; else goto _L7
_L7:
    }

    final void a(com.admob.android.ads.ab ab1, com.admob.android.ads.ac ac1)
    {
        int i1 = super.getVisibility();
        double d1 = ab1.c();
        boolean flag;
        if(d1 >= 0.0D)
        {
            d = true;
            a((int)d1);
            b(true);
        } else
        {
            d = false;
        }
        flag = m;
        if(flag)
            m = false;
        ac1.a(ab1);
        ac1.setVisibility(i1);
        ac1.setGravity(17);
        ab1.a(ac1);
        ac1.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(ab1.a(ab1.g()), ab1.a(ab1.h())));
        s.post(new e(this, ac1, i1, flag));
    }

    public void a(boolean flag)
    {
        if(com.admob.android.ads.bu.a("AdMobSDK", 5))
            android.util.Log.w("AdMobSDK", "Deprecated method setGoneWithoutAd was called.  See JavaDoc for instructions to remove.");
    }

    public int b()
    {
        return h;
    }

    public void b(int i1)
    {
        if(com.admob.android.ads.bu.a("AdMobSDK", 5))
            android.util.Log.w("AdMobSDK", "Calling the deprecated method setTextColor!  Please use setPrimaryTextColor and setSecondaryTextColor instead.");
        c(i1);
        d(i1);
    }

    public int c()
    {
        return f;
    }

    public void c(int i1)
    {
        g = 0xff000000 | i1;
    }

    final com.admob.android.ads.v d()
    {
        return q;
    }

    public void d(int i1)
    {
        h = 0xff000000 | i1;
    }

    final com.admob.android.ads.c e()
    {
        return r;
    }

    protected void onAttachedToWindow()
    {
        l = true;
        b(true);
        super.onAttachedToWindow();
    }

    protected void onDetachedFromWindow()
    {
        l = false;
        b(false);
        super.onDetachedFromWindow();
    }

    protected void onMeasure(int i1, int j1)
    {
        super.onMeasure(i1, j1);
        i1 = getMeasuredWidth();
        j1 = getMeasuredHeight();
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
            android.util.Log.d("AdMobSDK", (new StringBuilder()).append("AdView size is ").append(i1).append(" by ").append(j1).toString());
        if(a.booleanValue()) goto _L2; else goto _L1
_L1:
        if((float)(int)((float)i1 / com.admob.android.ads.ac.d()) > 310F) goto _L4; else goto _L3
_L3:
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
            android.util.Log.d("AdMobSDK", "We need to have a minimum width of 320 device independent pixels to show an ad.");
        b.setVisibility(8);
_L2:
        return;
_L4:
        try
        {
            i1 = b.getVisibility();
            b.setVisibility(super.getVisibility());
        }
        catch(java.lang.NullPointerException nullpointerexception)
        {
            return;
        }
        if(i1 == 0) goto _L2; else goto _L5
_L5:
        if(b.getVisibility() != 0) goto _L2; else goto _L6
_L6:
        a(b);
        return;
        java.lang.NullPointerException nullpointerexception1;
        nullpointerexception1;
    }

    public void onWindowFocusChanged(boolean flag)
    {
        b(flag);
    }

    protected void onWindowVisibilityChanged(int i1)
    {
        boolean flag;
        if(i1 == 0)
            flag = true;
        else
            flag = false;
        b(flag);
    }

    public void setBackgroundColor(int i1)
    {
        f = 0xff000000 | i1;
        invalidate();
    }

    public void setEnabled(boolean flag)
    {
        super.setEnabled(flag);
        if(flag)
        {
            setVisibility(0);
            return;
        } else
        {
            setVisibility(8);
            return;
        }
    }

    public void setVisibility(int i1)
    {
        if(super.getVisibility() == i1) goto _L2; else goto _L1
_L1:
        this;
        JVM INSTR monitorenter ;
        int k1 = getChildCount();
        int j1 = 0;
_L4:
        if(j1 >= k1)
            break; /* Loop/switch isn't completed */
        getChildAt(j1).setVisibility(i1);
        j1++;
        if(true) goto _L4; else goto _L3
_L3:
        super.setVisibility(i1);
        invalidate();
        this;
        JVM INSTR monitorexit ;
_L2:
        java.lang.Exception exception;
        boolean flag;
        if(i1 == 0)
            flag = true;
        else
            flag = false;
        b(flag);
        return;
        exception;
        throw exception;
    }

    private static java.lang.Boolean a;
    private static android.os.Handler s = null;
    private com.admob.android.ads.ac b;
    private int c;
    private boolean d;
    private com.admob.android.ads.f e;
    private int f;
    private int g;
    private int h;
    private java.lang.String i;
    private java.lang.String j;
    private com.admob.android.ads.x k;
    private boolean l;
    private boolean m;
    private boolean n;
    private long o;
    private com.admob.android.ads.i p;
    private com.admob.android.ads.v q;
    private com.admob.android.ads.c r;

}
