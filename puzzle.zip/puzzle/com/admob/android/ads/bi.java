// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.graphics.Color;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Transformation;

public final class bi extends android.view.animation.Animation
{

    public bi(int i, int j, android.view.View view)
    {
        c = view;
        a = new int[4];
        b = new int[4];
        a[0] = android.graphics.Color.alpha(i);
        a[1] = android.graphics.Color.red(i);
        a[2] = android.graphics.Color.green(i);
        a[3] = android.graphics.Color.blue(i);
        b[0] = android.graphics.Color.alpha(j);
        b[1] = android.graphics.Color.red(j);
        b[2] = android.graphics.Color.green(j);
        b[3] = android.graphics.Color.blue(j);
    }

    protected final void applyTransformation(float f, android.view.animation.Transformation transformation)
    {
        transformation.setTransformationType(android.view.animation.Transformation.TYPE_IDENTITY);
        if((double)f < 0.0D || (double)f > 1.0D)
            return;
        transformation = new int[4];
        for(int i = 0; i < 4; i++)
            transformation[i] = (int)((float)a[i] + (float)(b[i] - a[i]) * f);

        int j = android.graphics.Color.argb(transformation[0], transformation[1], transformation[2], transformation[3]);
        c.setBackgroundColor(j);
    }

    private int a[];
    private int b[];
    private android.view.View c;
}
