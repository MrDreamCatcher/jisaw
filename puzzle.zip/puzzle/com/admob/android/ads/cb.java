// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import java.lang.ref.WeakReference;

// Referenced classes of package com.admob.android.ads:
//            ac

final class cb
    implements java.lang.Runnable
{

    public cb(com.admob.android.ads.ac ac1)
    {
        a = new WeakReference(ac1);
    }

    public final void run()
    {
        com.admob.android.ads.ac ac1;
        try
        {
            ac1 = (com.admob.android.ads.ac)a.get();
        }
        catch(java.lang.Exception exception)
        {
            return;
        }
        if(ac1 == null)
            break MISSING_BLOCK_LABEL_19;
        ac1.f();
    }

    private java.lang.ref.WeakReference a;
}
