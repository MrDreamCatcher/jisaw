// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;


// Referenced classes of package com.admob.android.ads:
//            w

final class j
{

    static final int a[];

    static 
    {
        a = new int[com.admob.android.ads.w.values().length];
        try
        {
            a[com.admob.android.ads.w.b.ordinal()] = 1;
        }
        catch(java.lang.NoSuchFieldError nosuchfielderror2) { }
        try
        {
            a[com.admob.android.ads.w.d.ordinal()] = 2;
        }
        catch(java.lang.NoSuchFieldError nosuchfielderror1) { }
        try
        {
            a[com.admob.android.ads.w.c.ordinal()] = 3;
        }
        catch(java.lang.NoSuchFieldError nosuchfielderror)
        {
            return;
        }
    }
}
