// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;


public final class v extends java.lang.Enum
{

    private v(java.lang.String s, int i, java.lang.String s1)
    {
        super(s, i);
        d = s1;
    }

    public static com.admob.android.ads.v valueOf(java.lang.String s)
    {
        return (com.admob.android.ads.v)java.lang.Enum.valueOf(com/admob/android/ads/v, s);
    }

    public static com.admob.android.ads.v[] values()
    {
        return (com.admob.android.ads.v[])e.clone();
    }

    public final java.lang.String toString()
    {
        return d;
    }

    public static final com.admob.android.ads.v a;
    public static final com.admob.android.ads.v b;
    public static final com.admob.android.ads.v c;
    private static final com.admob.android.ads.v e[];
    private java.lang.String d;

    static 
    {
        a = new v("VIEW", 0, "view");
        b = new v("INTERSTITIAL", 1, "full_screen");
        c = new v("BAR", 2, "bar");
        e = (new com.admob.android.ads.v[] {
            a, b, c
        });
    }
}
