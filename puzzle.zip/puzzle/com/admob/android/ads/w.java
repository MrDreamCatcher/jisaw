// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;


public final class w extends java.lang.Enum
{

    private w(java.lang.String s, int i1, java.lang.String s1)
    {
        super(s, i1);
        k = s1;
    }

    public static com.admob.android.ads.w a(java.lang.String s)
    {
        Object obj = null;
        com.admob.android.ads.w aw[] = com.admob.android.ads.w.values();
        int j1 = aw.length;
        int i1 = 0;
        do
        {
label0:
            {
                com.admob.android.ads.w w1 = obj;
                if(i1 < j1)
                {
                    w1 = aw[i1];
                    if(!w1.toString().equals(s))
                        break label0;
                }
                return w1;
            }
            i1++;
        } while(true);
    }

    public static com.admob.android.ads.w valueOf(java.lang.String s)
    {
        return (com.admob.android.ads.w)java.lang.Enum.valueOf(com/admob/android/ads/w, s);
    }

    public static com.admob.android.ads.w[] values()
    {
        return (com.admob.android.ads.w[])l.clone();
    }

    public final java.lang.String toString()
    {
        return k;
    }

    public static final com.admob.android.ads.w a;
    public static final com.admob.android.ads.w b;
    public static final com.admob.android.ads.w c;
    public static final com.admob.android.ads.w d;
    private static com.admob.android.ads.w e;
    private static com.admob.android.ads.w f;
    private static com.admob.android.ads.w g;
    private static com.admob.android.ads.w h;
    private static com.admob.android.ads.w i;
    private static com.admob.android.ads.w j;
    private static final com.admob.android.ads.w l[];
    private java.lang.String k;

    static 
    {
        e = new w("CLICK_TO_MAP", 0, "map");
        f = new w("CLICK_TO_VIDEO", 1, "video");
        g = new w("CLICK_TO_APP", 2, "app");
        a = new w("CLICK_TO_BROWSER", 3, "url");
        h = new w("CLICK_TO_CALL", 4, "call");
        i = new w("CLICK_TO_MUSIC", 5, "itunes");
        b = new w("CLICK_TO_CANVAS", 6, "canvas");
        j = new w("CLICK_TO_CONTACT", 7, "contact");
        c = new w("CLICK_TO_INTERACTIVE_VIDEO", 8, "movie");
        d = new w("CLICK_TO_FULLSCREEN_BROWSER", 9, "screen");
        l = (new com.admob.android.ads.w[] {
            e, f, g, a, h, i, b, j, c, d
        });
    }
}
