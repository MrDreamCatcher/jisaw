// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

// Referenced classes of package com.admob.android.ads:
//            ae, af, AdView, ac, 
//            ab, bu

public class i
    implements com.admob.android.ads.ae
{

    public i()
    {
    }

    public i(com.admob.android.ads.AdView adview)
    {
        a = new WeakReference(adview);
    }

    public static android.os.Bundle a(com.admob.android.ads.af af1)
    {
        if(af1 == null)
            return null;
        else
            return af1.a();
    }

    public static java.util.ArrayList a(java.util.Vector vector)
    {
        if(vector != null) goto _L2; else goto _L1
_L1:
        vector = null;
_L4:
        return vector;
_L2:
        java.util.ArrayList arraylist = new ArrayList();
        java.util.Iterator iterator = vector.iterator();
        do
        {
            vector = arraylist;
            if(!iterator.hasNext())
                continue;
            vector = (com.admob.android.ads.af)iterator.next();
            if(vector == null)
                arraylist.add(null);
            else
                arraylist.add(vector.a());
        } while(true);
        if(true) goto _L4; else goto _L3
_L3:
    }

    public final void a()
    {
        com.admob.android.ads.AdView adview = (com.admob.android.ads.AdView)a.get();
        if(adview != null)
            com.admob.android.ads.AdView.f(adview);
    }

    public final void a(com.admob.android.ads.ab ab1)
    {
        com.admob.android.ads.AdView adview;
        adview = (com.admob.android.ads.AdView)a.get();
        if(adview == null)
            break MISSING_BLOCK_LABEL_130;
        adview;
        JVM INSTR monitorenter ;
        if(com.admob.android.ads.AdView.a(adview) == null || !ab1.equals(com.admob.android.ads.AdView.a(adview).c()))
            break MISSING_BLOCK_LABEL_58;
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
            android.util.Log.d("AdMobSDK", "Received the same ad we already had.  Discarding it.");
_L2:
        adview;
        JVM INSTR monitorexit ;
        return;
        if(com.admob.android.ads.bu.a("AdMobSDK", 4))
            android.util.Log.i("AdMobSDK", (new StringBuilder()).append("Ad returned (").append(android.os.SystemClock.uptimeMillis() - com.admob.android.ads.AdView.g(adview)).append(" ms):  ").append(ab1).toString());
        adview.getContext();
        adview.a(ab1, ab1.d());
        if(true) goto _L2; else goto _L1
_L1:
        ab1;
        throw ab1;
    }

    private java.lang.ref.WeakReference a;
}
