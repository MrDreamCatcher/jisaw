// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;


final class c
{

    private c(int i, int j)
    {
        b = i;
        c = j;
    }

    public final java.lang.String toString()
    {
        java.lang.StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append(java.lang.String.valueOf(b));
        stringbuilder.append("x");
        stringbuilder.append(java.lang.String.valueOf(c));
        return stringbuilder.toString();
    }

    public static final com.admob.android.ads.c a = new c(320, 48);
    private int b;
    private int c;

    static 
    {
        new c(320, 270);
        new c(748, 110);
        new c(488, 80);
    }
}
