// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.view.animation.Animation;

// Referenced classes of package com.admob.android.ads:
//            b, AdView, ac

final class r
    implements android.view.animation.Animation.AnimationListener
{

    r(com.admob.android.ads.AdView adview, com.admob.android.ads.ac ac)
    {
        b = adview;
        a = ac;
        super();
    }

    public final void onAnimationEnd(android.view.animation.Animation animation)
    {
        b.post(new b(a, b));
    }

    public final void onAnimationRepeat(android.view.animation.Animation animation)
    {
    }

    public final void onAnimationStart(android.view.animation.Animation animation)
    {
    }

    private com.admob.android.ads.ac a;
    private com.admob.android.ads.AdView b;
}
