// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.graphics.PointF;
import android.view.View;

public final class bk
{

    public bk()
    {
        a = 0.0F;
        b = new PointF(0.5F, 0.5F);
    }

    public static float a(android.view.View view)
    {
        if(view != null)
            return com.admob.android.ads.bk.c(view).a;
        else
            return 0.0F;
    }

    public static android.graphics.PointF b(android.view.View view)
    {
        if(view != null)
            return com.admob.android.ads.bk.c(view).b;
        else
            return null;
    }

    public static com.admob.android.ads.bk c(android.view.View view)
    {
        view = ((android.view.View) (view.getTag()));
        if(view != null && (view instanceof com.admob.android.ads.bk))
            return (com.admob.android.ads.bk)view;
        else
            return new bk();
    }

    public float a;
    public android.graphics.PointF b;
}
