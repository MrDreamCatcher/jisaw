// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.graphics.BitmapFactory;
import android.util.Log;
import java.lang.ref.WeakReference;
import java.net.URL;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import org.json.JSONObject;

// Referenced classes of package com.admob.android.ads:
//            z, y, ak, av, 
//            m, bu

public final class ax
    implements com.admob.android.ads.z
{

    public ax(com.admob.android.ads.m m1)
    {
        a = new Hashtable();
        b = new HashSet();
        c = null;
        e = m1;
        d = null;
    }

    private void a(java.lang.String s, java.lang.String s1, java.lang.String s2, boolean flag)
    {
        s = com.admob.android.ads.y.a(s, s1, s2, this);
        if(flag)
            s.a(java.lang.Boolean.valueOf(true));
        b.add(s);
    }

    public final void a(com.admob.android.ads.ak ak1)
    {
        java.lang.String s = ak1.d();
        byte abyte0[] = ak1.c();
        if(abyte0 != null)
        {
            java.lang.Object obj1 = null;
            try
            {
                obj = android.graphics.BitmapFactory.decodeByteArray(abyte0, 0, abyte0.length);
            }
            catch(java.lang.Throwable throwable)
            {
                obj = obj1;
                if(com.admob.android.ads.bu.a("AdMobSDK", 6))
                {
                    android.util.Log.e("AdMobSDK", "couldn't create a Bitmap", throwable);
                    obj = obj1;
                }
            }
            if(obj != null)
            {
                obj1 = ak1.g();
                if((obj1 instanceof java.lang.Boolean) && ((java.lang.Boolean)obj1).booleanValue())
                    c.a(s, ((android.graphics.Bitmap) (obj)));
                a.put(s, obj);
                if(b != null)
                {
                    synchronized(b)
                    {
                        b.remove(ak1);
                    }
                    if(a() && e != null)
                        e.a();
                }
                return;
            }
            if(com.admob.android.ads.bu.a("AdMobSDK", 3))
                android.util.Log.d("AdMobSDK", (new StringBuilder()).append("Failed reading asset(").append(s).append(") as a bitmap.").toString());
            c();
            return;
        } else
        {
            if(com.admob.android.ads.bu.a("AdMobSDK", 3))
                android.util.Log.d("AdMobSDK", (new StringBuilder()).append("Failed reading asset(").append(s).append(") for ad").toString());
            c();
            return;
        }
    }

    public final void a(com.admob.android.ads.ak ak1, java.lang.Exception exception)
    {
label0:
        {
            {
                if(exception == null)
                    break label0;
                if(com.admob.android.ads.bu.a("AdMobSDK", 3))
                {
                    java.lang.String s;
                    if(ak1 != null)
                    {
                        s = ak1.d();
                        ak1 = ak1.e();
                        if(ak1 != null)
                            ak1 = ak1.toString();
                        else
                            ak1 = null;
                    } else
                    {
                        ak1 = null;
                        s = null;
                    }
                    android.util.Log.d("AdMobSDK", (new StringBuilder()).append("Failed downloading assets for ad: ").append(s).append(" ").append(ak1).toString(), exception);
                }
            }
            c();
            return;
        }
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
        {
            if(ak1 != null)
            {
                exception = ak1.d();
                ak1 = ak1.e();
                if(ak1 != null)
                    ak1 = ak1.toString();
                else
                    ak1 = null;
            } else
            {
                ak1 = null;
                exception = null;
            }
            android.util.Log.d("AdMobSDK", (new StringBuilder()).append("Failed downloading assets for ad: ").append(exception).append(" ").append(ak1).toString());
        }
        if(false)
            ;
        else
            break MISSING_BLOCK_LABEL_75;
    }

    public final void a(org.json.JSONObject jsonobject, java.lang.String s)
    {
        if(b == null) goto _L2; else goto _L1
_L1:
        java.util.HashSet hashset = b;
        hashset;
        JVM INSTR monitorenter ;
        if(jsonobject == null)
            break MISSING_BLOCK_LABEL_158;
        java.util.Iterator iterator = jsonobject.keys();
_L3:
        java.lang.String s1;
        java.lang.String s2;
        java.lang.Object obj;
        if(!iterator.hasNext())
            break MISSING_BLOCK_LABEL_158;
        s1 = (java.lang.String)iterator.next();
        obj = jsonobject.getJSONObject(s1);
        s2 = ((org.json.JSONObject) (obj)).getString("u");
        boolean flag;
        if(((org.json.JSONObject) (obj)).optInt("c", 0) == 1)
            flag = true;
        else
            flag = false;
        if(!flag)
            break MISSING_BLOCK_LABEL_145;
        if(c == null)
            break MISSING_BLOCK_LABEL_145;
        obj = c.a(s1);
        if(obj == null)
            break MISSING_BLOCK_LABEL_132;
        a.put(s1, obj);
          goto _L3
        jsonobject;
        throw jsonobject;
        a(s2, s1, s, true);
          goto _L3
        a(s2, s1, s, false);
          goto _L3
        hashset;
        JVM INSTR monitorexit ;
_L2:
    }

    public final boolean a()
    {
        return b == null || b.size() == 0;
    }

    public final void b()
    {
        if(b == null) goto _L2; else goto _L1
_L1:
        java.util.HashSet hashset = b;
        hashset;
        JVM INSTR monitorenter ;
        for(java.util.Iterator iterator = b.iterator(); iterator.hasNext(); ((com.admob.android.ads.ak)iterator.next()).f());
        break MISSING_BLOCK_LABEL_53;
        java.lang.Exception exception;
        exception;
        throw exception;
        hashset;
        JVM INSTR monitorexit ;
_L2:
    }

    public final void c()
    {
        if(b == null) goto _L2; else goto _L1
_L1:
        java.util.HashSet hashset = b;
        hashset;
        JVM INSTR monitorenter ;
        for(java.util.Iterator iterator = b.iterator(); iterator.hasNext(); ((com.admob.android.ads.ak)iterator.next()).b());
        break MISSING_BLOCK_LABEL_53;
        java.lang.Exception exception;
        exception;
        throw exception;
        b.clear();
        b = null;
        hashset;
        JVM INSTR monitorexit ;
_L2:
        d();
        if(e != null)
            e.b();
        return;
    }

    public final void d()
    {
        if(a != null)
        {
            a.clear();
            a = null;
        }
    }

    public java.util.Hashtable a;
    public java.util.HashSet b;
    public com.admob.android.ads.av c;
    public java.lang.ref.WeakReference d;
    private com.admob.android.ads.m e;
}
