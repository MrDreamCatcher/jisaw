// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import java.lang.ref.WeakReference;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.Vector;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.admob.android.ads:
//            m, as, ax, bu, 
//            an, a, y, ak, 
//            AdMobActivity, j, w, aq, 
//            ac, ap, ab, az

public final class at
    implements com.admob.android.ads.m
{

    public at()
    {
        a = new as();
        b = new Vector();
        c = new ax(this);
        d = null;
    }

    private static android.os.Bundle a(org.json.JSONObject jsonobject)
    {
        android.os.Bundle bundle = null;
        if(jsonobject != null)
        {
            java.util.Iterator iterator = jsonobject.keys();
            if(iterator.hasNext())
                bundle = new Bundle();
            else
                bundle = null;
            do
            {
                if(!iterator.hasNext())
                    break;
                java.lang.String s = (java.lang.String)iterator.next();
                java.lang.Object obj = jsonobject.opt(s);
                if(s != null && obj != null)
                    com.admob.android.ads.at.a(bundle, s, obj);
            } while(true);
        }
        return bundle;
    }

    private void a(android.content.Context context)
    {
        android.content.pm.PackageManager packagemanager;
        java.util.Iterator iterator;
        packagemanager = context.getPackageManager();
        iterator = b.iterator();
_L6:
        if(!iterator.hasNext()) goto _L2; else goto _L1
_L1:
        android.content.Intent intent;
        intent = (android.content.Intent)iterator.next();
        if(packagemanager.resolveActivity(intent, 0x10000) == null)
            continue; /* Loop/switch isn't completed */
        context.startActivity(intent);
_L4:
        return;
_L2:
        if(!com.admob.android.ads.bu.a("AdMobSDK", 6)) goto _L4; else goto _L3
_L3:
        android.util.Log.e("AdMobSDK", "Could not find a resolving intent on ad click");
        return;
        java.lang.Exception exception;
        exception;
        if(true) goto _L6; else goto _L5
_L5:
    }

    private void a(android.content.Context context, java.lang.String s)
    {
        a(b(context, s));
    }

    private void a(android.content.Intent intent)
    {
        if(intent != null)
            b.add(intent);
    }

    private static void a(android.os.Bundle bundle, java.lang.String s, java.lang.Object obj)
    {
        if(s != null && obj != null) goto _L2; else goto _L1
_L1:
        return;
_L2:
        if(obj instanceof java.lang.String)
        {
            bundle.putString(s, (java.lang.String)obj);
            return;
        }
        if(obj instanceof java.lang.Integer)
        {
            bundle.putInt(s, ((java.lang.Integer)obj).intValue());
            return;
        }
        if(obj instanceof java.lang.Boolean)
        {
            bundle.putBoolean(s, ((java.lang.Boolean)obj).booleanValue());
            return;
        }
        if(obj instanceof java.lang.Double)
        {
            bundle.putDouble(s, ((java.lang.Double)obj).doubleValue());
            return;
        }
        if(obj instanceof java.lang.Long)
        {
            bundle.putLong(s, ((java.lang.Long)obj).longValue());
            return;
        }
        if(obj instanceof org.json.JSONObject)
        {
            bundle.putBundle(s, com.admob.android.ads.at.a((org.json.JSONObject)obj));
            return;
        }
        if(!(obj instanceof org.json.JSONArray)) goto _L1; else goto _L3
_L3:
        org.json.JSONArray jsonarray = (org.json.JSONArray)obj;
        if(s == null || jsonarray == null) goto _L1; else goto _L4
_L4:
        int i;
        int k;
        obj = new Vector();
        k = jsonarray.length();
        i = 0;
_L6:
        if(i >= k)
            continue; /* Loop/switch isn't completed */
        ((java.util.Vector) (obj)).add(jsonarray.get(i));
        i++;
        if(true) goto _L6; else goto _L5
_L5:
        org.json.JSONException jsonexception;
        jsonexception;
        if(com.admob.android.ads.bu.a("AdMobSDK", 6))
            android.util.Log.e("AdMobSDK", "couldn't read bundle array while adding extras");
        if(k == 0) goto _L1; else goto _L7
_L7:
        long al[];
        al = ((long []) (((java.util.Vector) (obj)).get(0)));
        if(al instanceof java.lang.String)
        {
            bundle.putStringArray(s, (java.lang.String[])((java.util.Vector) (obj)).toArray(new java.lang.String[0]));
            return;
        }
          goto _L8
_L12:
        if(!com.admob.android.ads.bu.a("AdMobSDK", 6)) goto _L1; else goto _L9
_L9:
        android.util.Log.e("AdMobSDK", "Couldn't read in array when making extras");
        return;
_L8:
        if(!(al instanceof java.lang.Integer))
            break MISSING_BLOCK_LABEL_325;
        obj = (java.lang.Integer[])((java.util.Vector) (obj)).toArray(new java.lang.Integer[0]);
        al = new int[obj.length];
        i = 0;
_L11:
        if(i >= obj.length)
            break; /* Loop/switch isn't completed */
        al[i] = obj[i].intValue();
        i++;
        if(true) goto _L11; else goto _L10
_L10:
        try
        {
            bundle.putIntArray(s, al);
            return;
        }
        // Misplaced declaration of an exception variable
        catch(android.os.Bundle bundle) { }
          goto _L12
        if(!(al instanceof java.lang.Boolean))
            break MISSING_BLOCK_LABEL_386;
        obj = (java.lang.Boolean[])((java.util.Vector) (obj)).toArray(new java.lang.Boolean[0]);
        al = new boolean[obj.length];
        i = 0;
_L14:
        if(i >= al.length)
            break; /* Loop/switch isn't completed */
        al[i] = obj[i].booleanValue();
        i++;
        if(true) goto _L14; else goto _L13
_L13:
        bundle.putBooleanArray(s, al);
        return;
        if(!(al instanceof java.lang.Double))
            continue; /* Loop/switch isn't completed */
        obj = (java.lang.Double[])((java.util.Vector) (obj)).toArray(new java.lang.Double[0]);
        al = new double[obj.length];
        i = 0;
_L16:
        if(i >= al.length)
            break; /* Loop/switch isn't completed */
        al[i] = obj[i].doubleValue();
        i++;
        if(true) goto _L16; else goto _L15
_L15:
        bundle.putDoubleArray(s, al);
        return;
        if(!(al instanceof java.lang.Long)) goto _L1; else goto _L17
_L17:
        obj = (java.lang.Long[])((java.util.Vector) (obj)).toArray(new java.lang.Long[0]);
        al = new long[obj.length];
        i = 0;
_L19:
        if(i >= al.length)
            break; /* Loop/switch isn't completed */
        al[i] = obj[i].longValue();
        i++;
        if(true) goto _L19; else goto _L18
_L18:
        bundle.putLongArray(s, al);
        return;
    }

    private void a(java.lang.String s)
    {
        a.d = s;
    }

    public static void a(java.util.List list, org.json.JSONObject jsonobject, java.lang.String s)
    {
        if(list != null)
        {
            java.util.Iterator iterator = list.iterator();
            while(iterator.hasNext()) 
            {
                com.admob.android.ads.an an1 = (com.admob.android.ads.an)iterator.next();
                com.admob.android.ads.a a1 = new a();
                list = null;
                if(an1.b)
                    list = jsonobject;
                com.admob.android.ads.y.a(an1.a, "click_time_tracking", s, list, a1).f();
            }
        }
    }

    private static android.content.Intent b(android.content.Context context)
    {
        return new Intent(context, com/admob/android/ads/AdMobActivity);
    }

    private android.content.Intent b(android.content.Context context, java.lang.String s)
    {
        android.content.Intent intent;
        com.admob.android.ads.w w1;
        intent = null;
        w1 = a.a;
        if(w1 == null) goto _L2; else goto _L1
_L1:
        com.admob.android.ads.j.a[w1.ordinal()];
        JVM INSTR tableswitch 1 3: default 52
    //                   1 79
    //                   2 86
    //                   3 91;
           goto _L3 _L4 _L5 _L6
_L3:
        intent = new Intent();
        intent.setAction("android.intent.action.VIEW");
        intent.setData(android.net.Uri.parse(s));
_L2:
        return intent;
_L4:
        a(s);
        return null;
_L5:
        return com.admob.android.ads.at.b(context);
_L6:
        if(a.h != null && !a.h.b())
            return com.admob.android.ads.at.b(context);
        if(true) goto _L3; else goto _L7
_L7:
    }

    public final void a()
    {
        a(c.a);
        d();
        java.lang.Object obj = c;
        if(((com.admob.android.ads.ax) (obj)).d != null)
            obj = (android.content.Context)((com.admob.android.ads.ax) (obj)).d.get();
        else
            obj = null;
        if(obj != null)
            a(((android.content.Context) (obj)));
    }

    public final void a(android.app.Activity activity, android.view.View view)
    {
        if(a.a == com.admob.android.ads.w.b)
        {
            java.lang.String s = a.d;
            java.lang.Object obj = a.b;
            d = new PopupWindow(activity);
            android.graphics.Rect rect = new Rect();
            view.getWindowVisibleDisplayFrame(rect);
            double d1 = com.admob.android.ads.ac.d();
            android.widget.RelativeLayout relativelayout = new RelativeLayout(activity);
            relativelayout.setGravity(17);
            obj = new ap(activity, ((java.lang.String) (obj)), this);
            ((com.admob.android.ads.ap) (obj)).setBackgroundColor(-1);
            ((com.admob.android.ads.ap) (obj)).setId(1);
            android.widget.RelativeLayout.LayoutParams layoutparams1 = new android.widget.RelativeLayout.LayoutParams(com.admob.android.ads.ab.a(320, d1), com.admob.android.ads.ab.a(295, d1));
            layoutparams1.addRule(13);
            relativelayout.addView(((android.view.View) (obj)), layoutparams1);
            ((com.admob.android.ads.ap) (obj)).b(s);
            ((com.admob.android.ads.ap) (obj)).loadUrl("http://mm.admob.com/static/android/canvas.html");
            d.setBackgroundDrawable(null);
            d.setFocusable(true);
            d.setClippingEnabled(false);
            d.setWidth(rect.width());
            d.setHeight(rect.height());
            d.setContentView(relativelayout);
            view = view.getRootView();
            d.showAtLocation(view, 0, rect.left, rect.top);
            view = relativelayout.getLayoutParams();
            if(view instanceof android.view.WindowManager.LayoutParams)
            {
                android.view.WindowManager.LayoutParams layoutparams = (android.view.WindowManager.LayoutParams)view;
                layoutparams.flags = layoutparams.flags | 6;
                layoutparams.dimAmount = 0.5F;
                ((android.view.WindowManager)activity.getSystemService("window")).updateViewLayout(relativelayout, view);
            }
            return;
        }
        if(!c.a())
        {
            c.d = new WeakReference(activity);
            c.b();
            return;
        } else
        {
            a(((android.content.Context) (activity)));
            return;
        }
    }

    public final void a(android.content.Context context, org.json.JSONArray jsonarray)
    {
        int i = 0;
        do
        {
            if(i >= jsonarray.length())
                break;
            try
            {
                a(context, jsonarray.getJSONObject(i));
            }
            catch(org.json.JSONException jsonexception)
            {
                if(com.admob.android.ads.bu.a("AdMobSDK", 6))
                    android.util.Log.e("AdMobSDK", (new StringBuilder()).append("Could not form an intent from ad action response: ").append(jsonarray.toString()).toString());
            }
            i++;
        } while(true);
    }

    public final void a(android.content.Context context, org.json.JSONObject jsonobject)
    {
        java.lang.String s1;
        java.lang.String s2;
        int i;
label0:
        {
            if(jsonobject != null)
            {
                java.lang.String s = jsonobject.optString("u");
                if(s == null || s.equals(""))
                    break label0;
                a(context, s);
            }
            return;
        }
        s1 = jsonobject.optString("a", "android.intent.action.VIEW");
        s2 = jsonobject.optString("d", null);
        if(a.d == null)
            a(s2);
        i = jsonobject.optInt("f", 0);
        jsonobject = com.admob.android.ads.at.a(jsonobject.optJSONObject("b"));
        if(a.a == null) goto _L2; else goto _L1
_L1:
        com.admob.android.ads.j.a[a.a.ordinal()];
        JVM INSTR tableswitch 1 1: default 132
    //                   1 174;
           goto _L3 _L4
_L3:
        context = new Intent(s1, android.net.Uri.parse(s2));
        if(i != 0)
            context.addFlags(i);
        if(jsonobject != null)
            context.putExtras(jsonobject);
_L6:
        a(((android.content.Intent) (context)));
        return;
_L4:
        context = b(context, s2);
        continue; /* Loop/switch isn't completed */
_L2:
        context = null;
        if(true) goto _L6; else goto _L5
_L5:
    }

    public final void a(android.content.Context context, org.json.JSONObject jsonobject, com.admob.android.ads.ax ax1)
    {
        org.json.JSONObject jsonobject1;
        if(ax1 == null)
            ax1 = c;
        a.a(jsonobject, ax1, com.admob.android.ads.az.g(context));
        a.d = jsonobject.optString("u");
        ax1 = jsonobject.optJSONArray("ua");
        jsonobject1 = jsonobject.optJSONObject("ac");
        jsonobject = jsonobject.optJSONArray("ac");
        if(jsonobject == null) goto _L2; else goto _L1
_L1:
        a(context, ((org.json.JSONArray) (jsonobject)));
_L4:
        return;
_L2:
        if(jsonobject1 != null)
        {
            a(context, jsonobject1);
            return;
        }
        if(ax1 == null)
            break; /* Loop/switch isn't completed */
        int i = 0;
        while(i < ax1.length()) 
        {
            jsonobject = ax1.optString(i);
            if(jsonobject != null)
                a(context, ((java.lang.String) (jsonobject)));
            i++;
        }
        if(true) goto _L4; else goto _L3
_L3:
        if(a.d == null || a.d.length() <= 0) goto _L4; else goto _L5
_L5:
        a(context, a.d);
        return;
    }

    public final void a(java.util.Hashtable hashtable)
    {
        if(a != null)
        {
            com.admob.android.ads.as as1 = a;
            if(hashtable != null)
            {
                java.lang.String s;
                for(java.util.Iterator iterator = hashtable.keySet().iterator(); iterator.hasNext(); as1.k.putParcelable(s, (android.os.Parcelable)hashtable.get(s)))
                    s = (java.lang.String)iterator.next();

            }
        }
    }

    public final void b()
    {
    }

    public final void c()
    {
        if(d != null)
        {
            d.dismiss();
            d = null;
        }
    }

    public final void d()
    {
        if(a != null && e())
        {
            android.content.Intent intent = null;
            if(b.size() > 0)
                intent = (android.content.Intent)b.firstElement();
            if(intent != null)
                intent.putExtra("o", a.a());
        }
    }

    public final boolean e()
    {
        return a != null && (a.a == com.admob.android.ads.w.c && a.h != null && !a.h.b() || a.a == com.admob.android.ads.w.d);
    }

    public com.admob.android.ads.as a;
    public java.util.Vector b;
    private com.admob.android.ads.ax c;
    private android.widget.PopupWindow d;
}
