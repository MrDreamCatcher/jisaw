// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import java.lang.ref.WeakReference;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

// Referenced classes of package com.admob.android.ads:
//            br, ab, aq, au, 
//            as, ar, cd, am, 
//            ch, cg

public final class by
{

    public by()
    {
        c = null;
        d = null;
        a = null;
        e = null;
        b = false;
    }

    public final void a()
    {
        com.admob.android.ads.br.b(c);
        com.admob.android.ads.br.b(d);
        b = false;
    }

    public final void a(android.content.Context context, java.lang.String s, com.admob.android.ads.aq aq1, float f1, com.admob.android.ads.br br1, com.admob.android.ads.as as1, java.lang.ref.WeakReference weakreference)
    {
        f = weakreference;
        java.lang.Object obj1 = new Rect(0, 0, (int)(320F * f1), (int)(34F * f1));
        weakreference = android.graphics.Bitmap.createBitmap(((android.graphics.Rect) (obj1)).width(), ((android.graphics.Rect) (obj1)).height(), android.graphics.Bitmap.Config.ARGB_8888);
        if(weakreference != null)
        {
            android.graphics.Canvas canvas = new Canvas(weakreference);
            com.admob.android.ads.ab.a(canvas, ((android.graphics.Rect) (obj1)), 0xff000000, -1, 127, 0.5F);
            obj1 = new Paint();
            ((android.graphics.Paint) (obj1)).setColor(0xff888888);
            canvas.drawLines(new float[] {
                0.0F, 0.0F, 320F * f1, 0.0F, 0.0F, 34F * f1 - 1.0F, 320F * f1, 34F * f1 - 1.0F
            }, ((android.graphics.Paint) (obj1)));
            c = new RelativeLayout(context);
            weakreference = new BitmapDrawable(weakreference);
            weakreference.setAlpha(200);
            c.setBackgroundDrawable(weakreference);
        }
        weakreference = new TextView(context);
        weakreference.setText(aq1.b);
        aq1 = new android.widget.RelativeLayout.LayoutParams(-2, -2);
        weakreference.setTextSize(14F);
        weakreference.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        weakreference.setTextColor(-1);
        weakreference.setPadding((int)(3F * f1), 0, 0, 0);
        aq1.addRule(9);
        aq1.addRule(15);
        c.addView(weakreference, aq1);
        aq1 = new TextView(context);
        aq1.setText(com.admob.android.ads.au.a("Ads by AdMob"));
        weakreference = new android.widget.RelativeLayout.LayoutParams(-2, -2);
        aq1.setTextSize(11F);
        aq1.setTextColor(-1);
        aq1.setPadding(0, 0, (int)(3F * f1), 0);
        weakreference.addRule(11);
        weakreference.addRule(15);
        c.addView(aq1, weakreference);
        aq1 = new android.widget.RelativeLayout.LayoutParams(-1, (int)(34F * f1));
        aq1.addRule(10);
        c.setVisibility(4);
        br1.addView(c, aq1);
        java.lang.Object obj = new Rect(0, 0, (int)(320F * f1), (int)(50F * f1));
        aq1 = android.graphics.Bitmap.createBitmap(((android.graphics.Rect) (obj)).width(), ((android.graphics.Rect) (obj)).height(), android.graphics.Bitmap.Config.ARGB_8888);
        if(aq1 != null)
        {
            weakreference = new Canvas(aq1);
            com.admob.android.ads.ab.a(weakreference, ((android.graphics.Rect) (obj)), 0xff000000, -1, 127, 0.5F);
            obj = new Paint();
            ((android.graphics.Paint) (obj)).setColor(0xff888888);
            weakreference.drawLines(new float[] {
                0.0F, 0.0F, 320F * f1, 0.0F, 0.0F, 50F * f1 - 1.0F, 320F * f1, 50F * f1 - 1.0F
            }, ((android.graphics.Paint) (obj)));
            d = new RelativeLayout(context);
            aq1 = new BitmapDrawable(aq1);
            aq1.setAlpha(200);
            d.setBackgroundDrawable(aq1);
        }
        aq1 = as1.h.m;
        if(aq1 != null)
        {
            weakreference = new LinearLayout(context);
            weakreference.setOrientation(0);
            android.widget.LinearLayout.LayoutParams layoutparams = new android.widget.LinearLayout.LayoutParams(-2, -1);
            java.util.Iterator iterator = aq1.iterator();
            while(iterator.hasNext()) 
            {
                aq1 = (com.admob.android.ads.ar)iterator.next();
                java.lang.Object obj2 = new android.widget.LinearLayout.LayoutParams((int)(64F * f1), -2);
                android.widget.Button button = new Button(context);
                android.graphics.Bitmap bitmap = (android.graphics.Bitmap)as1.b().get(((com.admob.android.ads.ar) (aq1)).b);
                android.graphics.drawable.BitmapDrawable bitmapdrawable = new BitmapDrawable((android.graphics.Bitmap)as1.b().get(((com.admob.android.ads.ar) (aq1)).a));
                bitmapdrawable.setBounds(0, 0, (int)(28F * f1), (int)(28F * f1));
                button.setCompoundDrawables(null, bitmapdrawable, null, null);
                button.setBackgroundDrawable(null);
                button.setBackgroundColor(0);
                button.setTextSize(12F);
                button.setTextColor(-1);
                button.setText(((com.admob.android.ads.ar) (aq1)).c);
                button.setPadding(0, (int)(2.0F * f1), 0, (int)(2.0F * f1));
                button.setOnClickListener(new cd(br1, aq1, f));
                weakreference.addView(new am(context, button, (int)(64F * f1), (int)(50F * f1), bitmap), ((android.view.ViewGroup.LayoutParams) (obj2)));
                aq1 = new ImageView(context);
                obj2 = android.graphics.Bitmap.createBitmap(1, (int)(34F * f1), android.graphics.Bitmap.Config.ARGB_8888);
                if(obj2 == null)
                {
                    aq1 = null;
                } else
                {
                    android.graphics.Canvas canvas1 = new Canvas(((android.graphics.Bitmap) (obj2)));
                    android.graphics.Paint paint = new Paint();
                    paint.setColor(0xff888888);
                    canvas1.drawLines(new float[] {
                        0.0F, 0.0F, 0.0F, 34F * f1
                    }, paint);
                    aq1.setBackgroundDrawable(new BitmapDrawable(((android.graphics.Bitmap) (obj2))));
                }
                weakreference.addView(aq1, layoutparams);
            }
            aq1 = new android.widget.RelativeLayout.LayoutParams(-2, -2);
            aq1.addRule(15);
            d.addView(weakreference, aq1);
        }
        e = new Button(context);
        e.setOnClickListener(new ch(br1, false));
        e.setBackgroundResource(0x1080005);
        e.setTextSize(1, 13F);
        e.setText(s);
        context = new android.widget.RelativeLayout.LayoutParams((int)(54F * f1), (int)(36F * f1));
        context.addRule(11);
        context.addRule(15);
        context.setMargins(0, 0, (int)(2.0F * f1), 0);
        d.addView(e, context);
        context = new android.widget.RelativeLayout.LayoutParams(-1, (int)(50F * f1));
        context.addRule(12);
        d.setVisibility(4);
        br1.addView(d, context);
        br1.setOnTouchListener(new cg(br1));
    }

    public final void b()
    {
        d.bringToFront();
        c.bringToFront();
        com.admob.android.ads.br.a(d);
        com.admob.android.ads.br.a(c);
        b = true;
    }

    android.view.ViewGroup a;
    boolean b;
    private android.widget.RelativeLayout c;
    private android.widget.RelativeLayout d;
    private android.widget.Button e;
    private java.lang.ref.WeakReference f;
}
