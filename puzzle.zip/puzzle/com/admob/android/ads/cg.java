// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.view.MotionEvent;
import android.view.View;
import java.lang.ref.WeakReference;

// Referenced classes of package com.admob.android.ads:
//            br

public final class cg
    implements android.view.View.OnTouchListener
{

    public cg(com.admob.android.ads.br br1)
    {
        a = new WeakReference(br1);
    }

    public final boolean onTouch(android.view.View view, android.view.MotionEvent motionevent)
    {
        view = (com.admob.android.ads.br)a.get();
        if(view == null)
        {
            return false;
        } else
        {
            com.admob.android.ads.br.a(view, false);
            com.admob.android.ads.br.a(view, motionevent);
            return false;
        }
    }

    private java.lang.ref.WeakReference a;
}
