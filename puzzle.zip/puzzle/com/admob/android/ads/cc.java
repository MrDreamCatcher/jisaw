// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import java.util.TimerTask;

// Referenced classes of package com.admob.android.ads:
//            p, ab

final class cc extends java.util.TimerTask
{

    cc(com.admob.android.ads.p p1)
    {
        a = p1;
        super();
    }

    public final void run()
    {
        if(!a.a)
        {
            a.a = true;
            if(a.c != null)
                a.c.a(false);
        }
    }

    private com.admob.android.ads.p a;
}
