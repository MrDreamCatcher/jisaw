// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import java.util.Date;

// Referenced classes of package com.admob.android.ads:
//            az, bu

final class ba
    implements android.location.LocationListener
{

    ba(android.location.LocationManager locationmanager)
    {
        a = locationmanager;
        super();
    }

    public final void onLocationChanged(android.location.Location location)
    {
        com.admob.android.ads.az.a(location);
        com.admob.android.ads.az.a(java.lang.System.currentTimeMillis());
        a.removeUpdates(this);
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
            android.util.Log.d("AdMobSDK", (new StringBuilder()).append("Acquired location ").append(com.admob.android.ads.az.h().getLatitude()).append(",").append(com.admob.android.ads.az.h().getLongitude()).append(" at ").append((new Date(com.admob.android.ads.az.i())).toString()).append(".").toString());
    }

    public final void onProviderDisabled(java.lang.String s)
    {
    }

    public final void onProviderEnabled(java.lang.String s)
    {
    }

    public final void onStatusChanged(java.lang.String s, int i, android.os.Bundle bundle)
    {
    }

    private android.location.LocationManager a;
}
