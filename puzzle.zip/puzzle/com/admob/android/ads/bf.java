// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.graphics.Matrix;
import android.graphics.PointF;
import android.view.animation.Animation;
import android.view.animation.Transformation;

public final class bf extends android.view.animation.Animation
{

    public bf(float af[], float af1[], android.graphics.PointF pointf)
    {
        a = af;
        b = af1;
    }

    protected final void applyTransformation(float f, android.view.animation.Transformation transformation)
    {
        if((double)f < 0.0D || (double)f > 1.0D)
        {
            transformation.setTransformationType(android.view.animation.Transformation.TYPE_IDENTITY);
            return;
        }
        android.graphics.Matrix matrix = transformation.getMatrix();
        float af[] = new float[a.length];
        for(int i = 0; i < a.length; i++)
            af[i] = a[i] + (b[i] - a[i]) * f;

        matrix.setSkew(a[0], a[1]);
        transformation.setTransformationType(android.view.animation.Transformation.TYPE_MATRIX);
    }

    private float a[];
    private float b[];
}
