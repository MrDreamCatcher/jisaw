// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.media.MediaPlayer;
import android.util.Log;
import java.lang.ref.WeakReference;

// Referenced classes of package com.admob.android.ads:
//            br, bu

final class cm
    implements android.media.MediaPlayer.OnCompletionListener, android.media.MediaPlayer.OnErrorListener, android.media.MediaPlayer.OnPreparedListener
{

    public cm(com.admob.android.ads.br br1)
    {
        a = new WeakReference(br1);
    }

    public final void onCompletion(android.media.MediaPlayer mediaplayer)
    {
        mediaplayer = (com.admob.android.ads.br)a.get();
        if(mediaplayer != null)
        {
            mediaplayer.i = true;
            mediaplayer.f();
            mediaplayer.a(true);
        }
    }

    public final boolean onError(android.media.MediaPlayer mediaplayer, int i, int j)
    {
        if(com.admob.android.ads.bu.a("AdMobSDK", 6))
            android.util.Log.e("AdMobSDK", (new StringBuilder()).append("error playing video, what: ").append(i).append(", extra: ").append(j).toString());
        mediaplayer = (com.admob.android.ads.br)a.get();
        if(mediaplayer == null)
        {
            return false;
        } else
        {
            mediaplayer.c();
            return true;
        }
    }

    public final void onPrepared(android.media.MediaPlayer mediaplayer)
    {
        mediaplayer = (com.admob.android.ads.br)a.get();
        if(mediaplayer != null)
            mediaplayer.a();
    }

    private java.lang.ref.WeakReference a;
}
