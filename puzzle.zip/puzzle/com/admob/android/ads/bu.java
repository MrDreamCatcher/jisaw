// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.util.Log;

// Referenced classes of package com.admob.android.ads:
//            ae, n, ab

public class bu
    implements com.admob.android.ads.ae
{

    public bu()
    {
    }

    public static boolean a(java.lang.String s, int i)
    {
        boolean flag;
        if(i >= 5)
            flag = true;
        else
            flag = false;
        return flag || android.util.Log.isLoggable(s, i);
    }

    public final void a()
    {
        if(a != null)
            a.c();
    }

    public final void a(com.admob.android.ads.ab ab)
    {
        if(a != null)
        {
            com.admob.android.ads.n.a(a, ab);
            a.a();
        }
    }

    com.admob.android.ads.n a;
}
