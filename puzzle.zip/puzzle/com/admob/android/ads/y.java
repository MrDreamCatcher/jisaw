// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import java.util.Map;
import org.json.JSONObject;

// Referenced classes of package com.admob.android.ads:
//            ak, aa, z

public final class y
{

    public y()
    {
    }

    public static com.admob.android.ads.ak a(java.lang.String s, java.lang.String s1, java.lang.String s2)
    {
        return com.admob.android.ads.y.a(s, s1, s2, null);
    }

    public static com.admob.android.ads.ak a(java.lang.String s, java.lang.String s1, java.lang.String s2, com.admob.android.ads.z z)
    {
        return com.admob.android.ads.y.a(s, s1, s2, z, 5000, null, null);
    }

    public static com.admob.android.ads.ak a(java.lang.String s, java.lang.String s1, java.lang.String s2, com.admob.android.ads.z z, int i)
    {
        s = com.admob.android.ads.y.a(s, null, s2, z, 5000, null, null);
        if(s != null)
            s.a(1);
        return s;
    }

    public static com.admob.android.ads.ak a(java.lang.String s, java.lang.String s1, java.lang.String s2, com.admob.android.ads.z z, int i, java.util.Map map, java.lang.String s3)
    {
        return new aa(s, s1, s2, z, i, null, s3);
    }

    public static com.admob.android.ads.ak a(java.lang.String s, java.lang.String s1, java.lang.String s2, org.json.JSONObject jsonobject, com.admob.android.ads.z z)
    {
        if(jsonobject == null)
            jsonobject = null;
        else
            jsonobject = jsonobject.toString();
        s = com.admob.android.ads.y.a(s, s1, s2, z, 5000, null, ((java.lang.String) (jsonobject)));
        s.a("application/json");
        return s;
    }

    private static boolean a = false;

}
