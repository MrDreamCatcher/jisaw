// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads.a;

import android.app.Activity;
import android.content.Context;
import android.graphics.Point;
import android.util.Log;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import com.admob.android.ads.ab;
import com.admob.android.ads.al;
import com.admob.android.ads.bo;
import com.admob.android.ads.bu;
import java.lang.ref.WeakReference;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.json.JSONObject;

public class a extends android.webkit.WebView
    implements android.view.View.OnClickListener
{

    public a(android.content.Context context, boolean flag, java.lang.ref.WeakReference weakreference)
    {
        super(context);
        c = flag;
        d = weakreference;
        context = getSettings();
        context.setLoadsImagesAutomatically(true);
        context.setPluginsEnabled(true);
        context.setJavaScriptEnabled(true);
        context.setJavaScriptCanOpenWindowsAutomatically(true);
        context.setSaveFormData(false);
        context.setSavePassword(false);
        context.setUserAgentString(com.admob.android.ads.al.h());
        b = a(weakreference);
        setWebViewClient(b);
    }

    public static android.view.View a(android.content.Context context, java.lang.String s, boolean flag, boolean flag1, android.graphics.Point point, float f, java.lang.ref.WeakReference weakreference)
    {
        android.widget.RelativeLayout relativelayout = new RelativeLayout(context);
        relativelayout.setGravity(17);
        weakreference = new a(context, flag1, weakreference);
        weakreference.setBackgroundColor(0);
        relativelayout.addView(weakreference, new android.widget.RelativeLayout.LayoutParams(-1, -1));
        if(flag1)
        {
            context = new ImageButton(context);
            context.setImageResource(0x1080017);
            context.setBackgroundDrawable(null);
            context.setPadding(0, 0, 0, 0);
            context.setOnClickListener(weakreference);
            android.widget.RelativeLayout.LayoutParams layoutparams = new android.widget.RelativeLayout.LayoutParams(-2, -2);
            layoutparams.setMargins(com.admob.android.ads.ab.a(point.x, f), com.admob.android.ads.ab.a(point.y, f), 0, 0);
            relativelayout.addView(context, layoutparams);
        }
        weakreference.a = s;
        weakreference.loadUrl(s);
        return relativelayout;
    }

    private java.lang.String a(java.lang.Object obj)
    {
        if(obj == null)
            return "{}";
        if((obj instanceof java.lang.Integer) || (obj instanceof java.lang.Double))
            return obj.toString();
        if(obj instanceof java.lang.String)
        {
            obj = (java.lang.String)obj;
            return (new StringBuilder()).append("'").append(((java.lang.String) (obj))).append("'").toString();
        }
        if(obj instanceof java.util.Map)
        {
            java.util.Iterator iterator = ((java.util.Map)obj).entrySet().iterator();
            obj = "{";
            do
            {
                if(!iterator.hasNext())
                    break;
                java.lang.Object obj2 = (java.util.Map.Entry)iterator.next();
                java.lang.Object obj1 = ((java.util.Map.Entry) (obj2)).getKey();
                obj2 = ((java.util.Map.Entry) (obj2)).getValue();
                obj1 = a(obj1);
                obj2 = a(obj2);
                obj1 = ((java.lang.String) (obj)).concat((new StringBuilder()).append(((java.lang.String) (obj1))).append(":").append(((java.lang.String) (obj2))).toString());
                obj = obj1;
                if(iterator.hasNext())
                    obj = ((java.lang.String) (obj1)).concat(",");
            } while(true);
            return ((java.lang.String) (obj)).concat("}");
        }
        if(obj instanceof org.json.JSONObject)
            return ((org.json.JSONObject)obj).toString();
        if(com.admob.android.ads.bu.a("AdMobSDK", 5))
            android.util.Log.w("AdMobSDK", (new StringBuilder()).append("Unable to create JSON from object: ").append(obj).toString());
        return "";
    }

    protected com.admob.android.ads.bo a(java.lang.ref.WeakReference weakreference)
    {
        return new bo(this, weakreference);
    }

    public void a()
    {
        if(d != null)
        {
            android.app.Activity activity = (android.app.Activity)d.get();
            if(activity != null)
                activity.finish();
        }
    }

    public final void a(java.lang.String s)
    {
        a = s;
    }

    public final transient void a(java.lang.String s, java.lang.Object aobj[])
    {
        java.util.List list = java.util.Arrays.asList(aobj);
        aobj = "";
        java.util.Iterator iterator = list.iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            java.lang.String s1 = ((java.lang.String) (aobj)).concat(a(iterator.next()));
            aobj = s1;
            if(iterator.hasNext())
                aobj = s1.concat(",");
        } while(true);
        s = (new StringBuilder()).append("javascript:admob.".concat(s)).append("(").append(((java.lang.String) (aobj))).append(");").toString();
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
            android.util.Log.w("AdMobSDK", (new StringBuilder()).append("Sending url to webView: ").append(s).toString());
    }

    public void loadUrl(java.lang.String s)
    {
        if(c)
            s = (new StringBuilder()).append(s).append("#sdk_close").toString();
        super.loadUrl(s);
    }

    public void onClick(android.view.View view)
    {
        a();
    }

    public java.lang.String a;
    protected com.admob.android.ads.bo b;
    private boolean c;
    private java.lang.ref.WeakReference d;
}
