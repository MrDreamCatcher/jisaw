// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Hashtable;
import java.util.PriorityQueue;

// Referenced classes of package com.admob.android.ads:
//            be, bc, bu

public final class av
{

    private av(android.content.Context context, long l)
    {
        d = 0x80000L;
        c = 0L;
        e = null;
        f = null;
        context = new File(context.getCacheDir(), "admob_img_cache");
        if(context.exists()) goto _L2; else goto _L1
_L1:
        context.mkdir();
_L4:
        b = context;
        a(b);
        return;
_L2:
        if(!context.isDirectory())
        {
            context.delete();
            context.mkdir();
        }
        if(true) goto _L4; else goto _L3
_L3:
    }

    public static com.admob.android.ads.av a(android.content.Context context)
    {
        if(a == null)
            a = new av(context, 0x80000L);
        return a;
    }

    public static void a()
    {
        (new be(a)).start();
    }

    static void a(com.admob.android.ads.av av1)
    {
        av1.b();
    }

    private void a(java.io.File file)
    {
        file = file.listFiles();
        e = new PriorityQueue(20, new bc());
        f = new Hashtable();
        int j = file.length;
        for(int i = 0; i < j; i++)
        {
            java.io.File file1 = file[i];
            if(file1 != null && file1.canRead())
            {
                e.add(file1);
                f.put(file1.getName(), file1);
                c = c + file1.length();
            }
        }

    }

    private void b()
    {
        this;
        JVM INSTR monitorenter ;
        java.io.File file;
        for(; c > d && e.size() > 0; file.delete())
        {
            file = (java.io.File)e.peek();
            if(com.admob.android.ads.bu.a("AdMobSDK", 2))
                android.util.Log.v("AdMobSDK", (new StringBuilder()).append("cache: evicting bitmap ").append(file.getName()).append(" totalBytes ").append(c).toString());
            b(file);
        }

        break MISSING_BLOCK_LABEL_102;
        java.lang.Exception exception;
        exception;
        throw exception;
        this;
        JVM INSTR monitorexit ;
    }

    private void b(java.io.File file)
    {
        this;
        JVM INSTR monitorenter ;
        if(file == null)
            break MISSING_BLOCK_LABEL_99;
        boolean flag1 = e.remove(file);
        boolean flag;
        if(f.remove(file.getName()) != null)
            flag = true;
        else
            flag = false;
        if(!(flag1 & flag))
            break MISSING_BLOCK_LABEL_99;
        c = c - file.length();
        if(com.admob.android.ads.bu.a("AdMobSDK", 2))
            android.util.Log.v("AdMobSDK", (new StringBuilder()).append("Cache: removed file ").append(file.getName()).append(" totalBytes ").append(c).toString());
        this;
        JVM INSTR monitorexit ;
        return;
        file;
        throw file;
    }

    private void c(java.io.File file)
    {
        this;
        JVM INSTR monitorenter ;
        if(file == null)
            break MISSING_BLOCK_LABEL_137;
        if(e.contains(file) || f.get(file.getName()) != null)
        {
            if(com.admob.android.ads.bu.a("AdMobSDK", 2))
                android.util.Log.v("AdMobSDK", "Cache: trying to add a file that's already in index");
            b(file);
        }
        e.add(file);
        f.put(file.getName(), file);
        c = c + file.length();
        if(com.admob.android.ads.bu.a("AdMobSDK", 2))
            android.util.Log.v("AdMobSDK", (new StringBuilder()).append("cache: added file: ").append(file.getName()).append(" totalBytes ").append(c).toString());
        this;
        JVM INSTR monitorexit ;
        return;
        file;
        throw file;
    }

    public final android.graphics.Bitmap a(java.lang.String s)
    {
        this;
        JVM INSTR monitorenter ;
        java.io.File file = (java.io.File)f.get(s);
        if(file == null)
            break MISSING_BLOCK_LABEL_121;
        s = android.graphics.BitmapFactory.decodeFile(file.getAbsolutePath());
        if(s == null)
            break MISSING_BLOCK_LABEL_121;
        e.remove(file);
        file.setLastModified(java.lang.System.currentTimeMillis());
        e.add(file);
        if(com.admob.android.ads.bu.a("AdMobSDK", 2))
            android.util.Log.v("AdMobSDK", (new StringBuilder()).append("cache: found bitmap ").append(file.getName()).append(" totalBytes ").append(c).append(" new modified ").append(file.lastModified()).toString());
_L1:
        this;
        JVM INSTR monitorexit ;
        return s;
        s = null;
          goto _L1
        s;
        throw s;
    }

    public final void a(java.lang.String s, android.graphics.Bitmap bitmap)
    {
        this;
        JVM INSTR monitorenter ;
        java.io.File file;
        file = new File(b, s);
        s = (java.io.File)f.get(s);
        if(s == null)
            break MISSING_BLOCK_LABEL_78;
        if(com.admob.android.ads.bu.a("AdMobSDK", 2))
            android.util.Log.v("AdMobSDK", (new StringBuilder()).append("cache: found bitmap ").append(file.getName()).append(" and removing ").toString());
        b(s);
        if(file.exists())
            file.delete();
        try
        {
            s = new FileOutputStream(file);
            bitmap.compress(android.graphics.Bitmap.CompressFormat.PNG, 100, s);
            c(file);
            if(com.admob.android.ads.bu.a("AdMobSDK", 2))
                android.util.Log.v("AdMobSDK", (new StringBuilder()).append("cache: added bitmap ").append(file.getName()).append(" totalBytes ").append(c).append(" lastModified ").append(file.lastModified()).toString());
        }
        // Misplaced declaration of an exception variable
        catch(java.lang.String s) { }
        this;
        JVM INSTR monitorexit ;
        return;
        s;
        throw s;
    }

    private static com.admob.android.ads.av a = null;
    private java.io.File b;
    private long c;
    private long d;
    private java.util.PriorityQueue e;
    private java.util.Hashtable f;

}
