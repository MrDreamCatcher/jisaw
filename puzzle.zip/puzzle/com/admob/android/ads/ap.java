// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.app.Activity;
import android.view.KeyEvent;
import com.admob.android.ads.a.a;
import java.lang.ref.WeakReference;

// Referenced classes of package com.admob.android.ads:
//            o, at, bo

public final class ap extends com.admob.android.ads.a.a
{

    public ap(android.app.Activity activity, java.lang.String s, com.admob.android.ads.at at1)
    {
        super(activity, false, new WeakReference(activity));
        d = true;
        c = s;
        e = at1;
    }

    protected final com.admob.android.ads.bo a(java.lang.ref.WeakReference weakreference)
    {
        return new o(this, this, weakreference);
    }

    public final void a()
    {
        if(e != null)
            e.c();
    }

    public final void b(java.lang.String s)
    {
        a = (new StringBuilder()).append(s).append("#sdk").toString();
    }

    public final boolean onKeyDown(int i, android.view.KeyEvent keyevent)
    {
        if(i == 4)
        {
            a();
            return true;
        } else
        {
            return super.onKeyDown(i, keyevent);
        }
    }

    java.lang.String c;
    boolean d;
    private com.admob.android.ads.at e;
}
