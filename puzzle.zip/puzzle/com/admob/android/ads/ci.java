// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import java.lang.ref.WeakReference;

// Referenced classes of package com.admob.android.ads:
//            br

final class ci
    implements java.lang.Runnable
{

    public ci(com.admob.android.ads.br br1)
    {
        a = new WeakReference(br1);
    }

    public final void run()
    {
        com.admob.android.ads.br br1 = (com.admob.android.ads.br)a.get();
        if(br1 == null)
        {
            return;
        } else
        {
            br1.b();
            return;
        }
    }

    private java.lang.ref.WeakReference a;
}
