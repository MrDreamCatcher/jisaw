// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.view.View;
import android.view.animation.Animation;
import android.view.animation.Transformation;

// Referenced classes of package com.admob.android.ads:
//            bk, cn

public final class bb extends android.view.animation.Animation
{

    public bb(float f, float f1, android.view.View view)
    {
        b = f;
        c = f1;
        a = view;
    }

    protected final void applyTransformation(float f, android.view.animation.Transformation transformation)
    {
        transformation.setTransformationType(android.view.animation.Transformation.TYPE_IDENTITY);
        if((double)f >= 0.0D && (double)f <= 1.0D)
        {
            float f1 = b;
            float f2 = c;
            float f3 = b;
            transformation = a;
            if(transformation != null)
            {
                com.admob.android.ads.bk bk1 = com.admob.android.ads.bk.c(transformation);
                bk1.a = f1 + (f2 - f3) * f;
                transformation.setTag(bk1);
            }
            transformation = a.getParent();
            if(transformation instanceof com.admob.android.ads.cn)
            {
                ((com.admob.android.ads.cn)transformation).g();
                return;
            }
        }
    }

    private android.view.View a;
    private float b;
    private float c;
}
