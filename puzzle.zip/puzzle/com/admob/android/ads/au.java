// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.content.Context;
import android.util.Log;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Locale;
import java.util.Properties;

// Referenced classes of package com.admob.android.ads:
//            z, az, y, ak, 
//            bu

public final class au
    implements com.admob.android.ads.z
{

    private au(android.content.Context context)
    {
        f = context;
        e = null;
        d = com.admob.android.ads.au.a();
        if(a != null)
            a.e = null;
        if(!b() && c == null)
        {
            context = new StringBuilder();
            context.append("http://mm.admob.com/static/android/i18n/20101109");
            context.append("/");
            context.append(d);
            context.append(".properties");
            context = new Thread(com.admob.android.ads.y.a(context.toString(), null, com.admob.android.ads.az.g(f), this, 1));
            c = context;
            context.start();
        }
    }

    private static java.io.File a(android.content.Context context, java.lang.String s)
    {
        context = new File(context.getCacheDir(), "admob_cache");
        if(!context.exists())
            context.mkdir();
        context = new File(context, "20101109");
        if(!context.exists())
            context.mkdir();
        return new File(context, (new StringBuilder()).append(s).append(".properties").toString());
    }

    public static java.lang.String a()
    {
        if(d == null)
        {
            java.lang.String s = java.util.Locale.getDefault().getLanguage();
            d = s;
            if(s == null)
                d = "en";
        }
        return d;
    }

    public static java.lang.String a(java.lang.String s)
    {
label0:
        {
            java.lang.Object obj;
label1:
            {
                com.admob.android.ads.au.a(b);
                obj = a;
                ((com.admob.android.ads.au) (obj)).b();
                if(((com.admob.android.ads.au) (obj)).e == null)
                    break label0;
                java.lang.String s1 = ((com.admob.android.ads.au) (obj)).e.getProperty(s);
                if(s1 != null)
                {
                    obj = s1;
                    if(!s1.equals(""))
                        break label1;
                }
                obj = s;
            }
            return ((java.lang.String) (obj));
        }
        return s;
    }

    public static void a(android.content.Context context)
    {
        if(b == null && context != null)
            b = context.getApplicationContext();
        if(a == null)
            a = new au(b);
    }

    private boolean b()
    {
        if(e == null)
            try
            {
                java.util.Properties properties = new Properties();
                java.io.File file = com.admob.android.ads.au.a(f, d);
                if(file.exists())
                {
                    properties.load(new FileInputStream(file));
                    e = properties;
                }
            }
            catch(java.io.IOException ioexception)
            {
                e = null;
            }
        return e != null;
    }

    public final void a(com.admob.android.ads.ak ak1)
    {
        ak1 = ak1.c();
        if(ak1 == null)
            break MISSING_BLOCK_LABEL_38;
        java.io.FileOutputStream fileoutputstream = new FileOutputStream(com.admob.android.ads.au.a(f, d));
        fileoutputstream.write(ak1);
        fileoutputstream.close();
_L1:
        return;
        ak1;
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
        {
            android.util.Log.d("AdMobSDK", "Could not store localized strings to cache file.");
            return;
        }
          goto _L1
    }

    public final void a(com.admob.android.ads.ak ak1, java.lang.Exception exception)
    {
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
            android.util.Log.d("AdMobSDK", "Could not get localized strings from the AdMob servers.");
    }

    private static com.admob.android.ads.au a = null;
    private static android.content.Context b = null;
    private static java.lang.Thread c = null;
    private static java.lang.String d = null;
    private java.util.Properties e;
    private android.content.Context f;

}
