// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.content.Context;
import android.text.TextPaint;
import android.widget.TextView;

public final class bm extends android.widget.TextView
{

    public bm(android.content.Context context, float f)
    {
        super(context);
        a = -1F;
        b = false;
        setGravity(80);
        c = f;
    }

    protected final void onMeasure(int i, int j)
    {
        super.onMeasure(i, j);
        if(b)
        {
            i = getMeasuredWidth();
            android.graphics.Typeface typeface = getTypeface();
            float f1 = getTextSize();
            java.lang.CharSequence charsequence = getText();
            android.text.TextPaint textpaint = new TextPaint(getPaint());
            if(charsequence != null)
            {
                float f = f1;
                do
                {
                    if(f < a)
                        break;
                    textpaint.setTypeface(typeface);
                    textpaint.setTextSize(f);
                    if(textpaint.measureText(charsequence, 0, charsequence.length()) <= (float)i)
                        break;
                    f -= 0.5F;
                } while(true);
                if(f1 != f)
                    setTextSize(f / c);
            }
        }
    }

    public float a;
    public boolean b;
    public float c;
}
