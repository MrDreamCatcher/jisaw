// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.content.Context;
import android.util.Log;
import org.json.JSONObject;
import org.json.JSONTokener;

// Referenced classes of package com.admob.android.ads:
//            az, ah, y, ak, 
//            bu

final class ai
{

    ai()
    {
    }

    public static void a(android.content.Context context)
    {
        if(a)
            break MISSING_BLOCK_LABEL_134;
        a = true;
        if(!com.admob.android.ads.az.b())
            break MISSING_BLOCK_LABEL_134;
        java.lang.String s = com.admob.android.ads.ah.a(context, null, null, 0);
        java.lang.StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append("http://api.admob.com/v1/pubcode/android_sdk_emulator_notice");
        stringbuilder.append("?");
        stringbuilder.append(s);
        context = com.admob.android.ads.y.a(stringbuilder.toString(), "developer_message", com.admob.android.ads.az.g(context));
        if(!context.a())
            break MISSING_BLOCK_LABEL_134;
        context = context.c();
        if(context == null)
            break MISSING_BLOCK_LABEL_134;
        context = (new JSONObject(new JSONTokener(new String(context)))).getString("data");
        if(context == null)
            break MISSING_BLOCK_LABEL_134;
        if(!context.equals(""))
            android.util.Log.w("AdMobSDK", context);
_L1:
        return;
        context;
        if(com.admob.android.ads.bu.a("AdMobSDK", 2))
        {
            android.util.Log.v("AdMobSDK", "Unhandled exception retrieving developer message.", context);
            return;
        }
          goto _L1
    }

    private static boolean a = false;

}
