// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.view.View;
import java.util.Comparator;

// Referenced classes of package com.admob.android.ads:
//            bk

final class bx
    implements java.util.Comparator
{

    bx()
    {
    }

    public final volatile int compare(java.lang.Object obj, java.lang.Object obj1)
    {
        obj = (android.view.View)obj;
        obj1 = (android.view.View)obj1;
        float f = com.admob.android.ads.bk.a(((android.view.View) (obj)));
        float f1 = com.admob.android.ads.bk.a(((android.view.View) (obj1)));
        if(f < f1)
            return -1;
        return f <= f1 ? 0 : 1;
    }
}
