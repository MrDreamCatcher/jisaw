// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;


public final class q extends java.lang.Enum
{

    private q(java.lang.String s, int i)
    {
        super(s, i);
    }

    public static com.admob.android.ads.q valueOf(java.lang.String s)
    {
        return (com.admob.android.ads.q)java.lang.Enum.valueOf(com/admob/android/ads/q, s);
    }

    public static com.admob.android.ads.q[] values()
    {
        return (com.admob.android.ads.q[])f.clone();
    }

    public static final com.admob.android.ads.q a;
    public static final com.admob.android.ads.q b;
    public static final com.admob.android.ads.q c;
    public static final com.admob.android.ads.q d;
    public static final com.admob.android.ads.q e;
    private static final com.admob.android.ads.q f[];

    static 
    {
        a = new q("APP_START", 0);
        b = new q("SCREEN_CHANGE", 1);
        c = new q("PRE_ROLL", 2);
        d = new q("POST_ROLL", 3);
        e = new q("OTHER", 4);
        f = (new com.admob.android.ads.q[] {
            a, b, c, d, e
        });
    }
}
