// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.util.Log;
import java.lang.ref.WeakReference;

// Referenced classes of package com.admob.android.ads:
//            ac, bu

final class bz
    implements java.lang.Runnable
{

    public bz(com.admob.android.ads.ac ac1)
    {
        a = new WeakReference(ac1);
    }

    public final void run()
    {
        com.admob.android.ads.ac ac1 = (com.admob.android.ads.ac)a.get();
        if(ac1 == null)
            break MISSING_BLOCK_LABEL_23;
        ac1.addView(ac1.c);
_L1:
        return;
        java.lang.Exception exception;
        exception;
        if(com.admob.android.ads.bu.a("AdMobSDK", 6))
        {
            android.util.Log.e("AdMobSDK", (new StringBuilder()).append("exception caught in AdContainer post run(), ").append(exception.getMessage()).toString());
            return;
        }
          goto _L1
    }

    private java.lang.ref.WeakReference a;
}
