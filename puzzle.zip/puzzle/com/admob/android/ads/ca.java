// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.util.Log;
import java.lang.ref.WeakReference;
import org.json.JSONObject;

// Referenced classes of package com.admob.android.ads:
//            ac, ab, AdView, bu

public final class ca extends java.lang.Thread
{

    public ca(org.json.JSONObject jsonobject, com.admob.android.ads.ac ac1)
    {
        a = jsonobject;
        b = new WeakReference(ac1);
    }

    public final void run()
    {
        com.admob.android.ads.ac ac1 = (com.admob.android.ads.ac)b.get();
        if(ac1 == null)
            break MISSING_BLOCK_LABEL_48;
        if(ac1.a != null)
        {
            ac1.a.a(a);
            if(ac1.b != null)
                ac1.b.performClick();
        }
_L1:
        return;
        java.lang.Exception exception;
        exception;
        if(com.admob.android.ads.bu.a("AdMobSDK", 6))
        {
            android.util.Log.e("AdMobSDK", "exception caught in AdClickThread.run(), ", exception);
            return;
        }
          goto _L1
    }

    private org.json.JSONObject a;
    private java.lang.ref.WeakReference b;
}
