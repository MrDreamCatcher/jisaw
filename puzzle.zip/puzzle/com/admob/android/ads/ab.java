// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PaintFlagsDrawFilter;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;
import java.io.UnsupportedEncodingException;
import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.admob.android.ads:
//            m, ax, at, v, 
//            ac, bu, bk, bd, 
//            bf, bl, av, as, 
//            w, bb, bg, bh, 
//            bi, bj, az, bm, 
//            ao, AdView, ae, t, 
//            u, y, ak

public final class ab
    implements com.admob.android.ads.m
{

    protected ab()
    {
        m = new Vector();
        o = 0L;
        a(((com.admob.android.ads.ae) (null)));
        j = null;
        n = null;
        p = -1;
        q = -1;
        A = null;
        u = -1;
        t = -1;
        v = 0xff000000;
        x = new ax(this);
        y = 0;
        z = new Vector();
        B = -1D;
        C = -1D;
        D = new at();
        E = com.admob.android.ads.v.c;
        h = 5F;
        F = false;
        G = null;
    }

    private static float a(org.json.JSONObject jsonobject, java.lang.String s1, float f1)
    {
        return (float)jsonobject.optDouble(s1, f1);
    }

    public static int a(int i1, double d1)
    {
        double d3 = i1;
        double d2 = d3;
        if(d1 > 0.0D)
            d2 = d3 * d1;
        return (int)d2;
    }

    private static int a(org.json.JSONObject jsonobject, java.lang.String s1, int i1)
    {
        if(jsonobject != null && jsonobject.has(s1))
        {
            int j1;
            try
            {
                jsonobject = jsonobject.getJSONArray(s1);
                j1 = (int)(jsonobject.getDouble(0) * 255D);
                int k1 = (int)(jsonobject.getDouble(1) * 255D);
                int l1 = (int)(jsonobject.getDouble(2) * 255D);
                j1 = android.graphics.Color.argb((int)(jsonobject.getDouble(3) * 255D), j1, k1, l1);
            }
            // Misplaced declaration of an exception variable
            catch(org.json.JSONObject jsonobject)
            {
                return i1;
            }
            return j1;
        } else
        {
            return i1;
        }
    }

    private static android.graphics.Matrix a(org.json.JSONArray jsonarray)
    {
        Object obj = null;
        float af[] = com.admob.android.ads.ab.b(jsonarray);
        jsonarray = obj;
        if(af != null)
        {
            jsonarray = obj;
            if(af.length == 9)
            {
                jsonarray = new Matrix();
                jsonarray.setValues(af);
            }
        }
        return jsonarray;
    }

    private static android.graphics.Matrix a(org.json.JSONObject jsonobject, java.lang.String s1, android.graphics.Matrix matrix)
    {
        jsonobject = com.admob.android.ads.ab.b(jsonobject, s1);
        if(jsonobject != null && jsonobject.length == 9)
        {
            s1 = new Matrix();
            s1.setValues(jsonobject);
            return s1;
        } else
        {
            return matrix;
        }
    }

    private static android.graphics.PointF a(android.graphics.RectF rectf, android.graphics.PointF pointf)
    {
        float f1 = rectf.width();
        float f2 = rectf.height();
        float f3 = rectf.left;
        float f4 = pointf.x;
        float f5 = rectf.top;
        return new PointF(f1 * f4 + f3, f2 * pointf.y + f5);
    }

    private static android.graphics.PointF a(org.json.JSONObject jsonobject, java.lang.String s1, android.graphics.PointF pointf)
    {
        if(jsonobject != null && jsonobject.has(s1))
        {
            try
            {
                jsonobject = com.admob.android.ads.ab.e(jsonobject.getJSONArray(s1));
            }
            // Misplaced declaration of an exception variable
            catch(org.json.JSONObject jsonobject)
            {
                return pointf;
            }
            return jsonobject;
        } else
        {
            return pointf;
        }
    }

    private static android.graphics.Rect a(org.json.JSONObject jsonobject, java.lang.String s1, android.graphics.Rect rect)
    {
        if(jsonobject != null && jsonobject.has(s1))
        {
            try
            {
                jsonobject = jsonobject.getJSONArray(s1);
                int i1 = (int)jsonobject.getDouble(0);
                int j1 = (int)jsonobject.getDouble(1);
                jsonobject = new Rect(i1, j1, (int)jsonobject.getDouble(2) + i1, (int)jsonobject.getDouble(3) + j1);
            }
            // Misplaced declaration of an exception variable
            catch(org.json.JSONObject jsonobject)
            {
                return rect;
            }
            return jsonobject;
        } else
        {
            return rect;
        }
    }

    private static android.graphics.RectF a(org.json.JSONObject jsonobject, java.lang.String s1, android.graphics.RectF rectf)
    {
        if(jsonobject != null && jsonobject.has(s1))
        {
            try
            {
                jsonobject = com.admob.android.ads.ab.d(jsonobject.getJSONArray(s1));
            }
            // Misplaced declaration of an exception variable
            catch(org.json.JSONObject jsonobject)
            {
                return rectf;
            }
            return jsonobject;
        } else
        {
            return rectf;
        }
    }

    private android.view.View a(org.json.JSONObject jsonobject, android.graphics.Rect rect)
    {
        if(s == null)
            break MISSING_BLOCK_LABEL_123;
        float f1 = com.admob.android.ads.ab.a(jsonobject, "ia", 0.5F);
        float f2 = com.admob.android.ads.ab.a(jsonobject, "epy", 0.4375F);
        int i1 = com.admob.android.ads.ab.a(jsonobject, "bc", v);
        try
        {
            jsonobject = android.graphics.Bitmap.createBitmap(rect.width(), rect.height(), android.graphics.Bitmap.Config.ARGB_8888);
        }
        // Misplaced declaration of an exception variable
        catch(org.json.JSONObject jsonobject)
        {
            return null;
        }
        if(jsonobject == null)
            return null;
        z.add(jsonobject);
        com.admob.android.ads.ab.a(new Canvas(jsonobject), rect, i1, -1, (int)(f1 * 255F), f2);
        rect = new View(s.getContext());
        rect.setBackgroundDrawable(new BitmapDrawable(jsonobject));
        return rect;
        return null;
    }

    private static android.view.animation.Animation a(int i1, java.lang.String s1, java.lang.String s2, float af[], org.json.JSONArray jsonarray, java.lang.String as1[], long l1, 
            android.view.View view, android.graphics.Rect rect, org.json.JSONObject jsonobject, org.json.JSONArray jsonarray1)
    {
        float f1;
        float f2;
        int j1;
        j1 = i1 + 1;
        f1 = af[i1];
        f2 = af[j1];
        if(s1 != null && s2 != null) goto _L2; else goto _L1
_L1:
        if(!com.admob.android.ads.bu.a("AdMobSDK", 6)) goto _L4; else goto _L3
_L3:
        android.util.Log.e("AdMobSDK", (new StringBuilder()).append("Could not read keyframe animation: keyPath(").append(s1).append(") or valueType(").append(s2).append(") is null.").toString());
        s1 = null;
_L10:
        if(s1 != null)
        {
            j1 = (int)((float)l1 * f1);
            long l2 = (int)((f2 - f1) * (float)l1);
            s1.setDuration(l1);
            s2 = com.admob.android.ads.ab.a(as1[i1], j1, l2, l1);
            if(s2 != null)
                s1.setInterpolator(s2);
        }
        return s1;
_L2:
        if("position".equals(s1) && "P".equals(s2))
        {
            s1 = com.admob.android.ads.ab.a(com.admob.android.ads.ab.e(jsonarray.getJSONArray(i1)), com.admob.android.ads.ab.e(jsonarray.getJSONArray(j1)), view, rect);
            continue; /* Loop/switch isn't completed */
        }
        if("opacity".equals(s1) && "F".equals(s2))
        {
            s1 = com.admob.android.ads.ab.a((float)jsonarray.getDouble(i1), (float)jsonarray.getDouble(j1));
            continue; /* Loop/switch isn't completed */
        }
        if("bounds".equals(s1) && "R".equals(s2))
        {
            s1 = com.admob.android.ads.ab.a(com.admob.android.ads.ab.d(jsonarray.getJSONArray(i1)), com.admob.android.ads.ab.d(jsonarray.getJSONArray(j1)), view, rect);
            continue; /* Loop/switch isn't completed */
        }
        if("zPosition".equals(s1) && "F".equals(s2))
        {
            s1 = com.admob.android.ads.ab.a((float)jsonarray.getDouble(i1), (float)jsonarray.getDouble(j1), view);
            continue; /* Loop/switch isn't completed */
        }
        if("backgroundColor".equals(s1) && "C".equals(s2))
        {
            s1 = com.admob.android.ads.ab.a(com.admob.android.ads.ab.c(jsonarray.getJSONArray(i1)), com.admob.android.ads.ab.c(jsonarray.getJSONArray(j1)), view);
            continue; /* Loop/switch isn't completed */
        }
        if(!"transform".equals(s1) || !"AT".equals(s2)) goto _L6; else goto _L5
_L5:
        if(jsonarray1 == null) goto _L8; else goto _L7
_L7:
        try
        {
            com.admob.android.ads.ab.a(jsonarray.getJSONArray(i1));
            com.admob.android.ads.ab.a(jsonarray.getJSONArray(j1));
            s1 = com.admob.android.ads.ab.a(view, rect, jsonobject, jsonarray1.getJSONArray(i1), jsonarray1.getJSONArray(j1));
            continue; /* Loop/switch isn't completed */
        }
        // Misplaced declaration of an exception variable
        catch(java.lang.String s1) { }
          goto _L4
_L6:
        if(com.admob.android.ads.bu.a("AdMobSDK", 6))
            android.util.Log.e("AdMobSDK", (new StringBuilder()).append("Could not read keyframe animation: could not interpret keyPath(").append(s1).append(") and valueType(").append(s2).append(") combination.").toString());
_L8:
        s1 = null;
        continue; /* Loop/switch isn't completed */
_L4:
        s1 = null;
        if(true) goto _L10; else goto _L9
_L9:
    }

    private static android.view.animation.Animation a(android.view.View view, android.graphics.Rect rect, org.json.JSONObject jsonobject, org.json.JSONArray jsonarray, org.json.JSONArray jsonarray1)
    {
        jsonobject = jsonobject.optString("tt", null);
        if(jsonobject != null)
        {
            if("t".equals(jsonobject))
                return com.admob.android.ads.ab.a(com.admob.android.ads.ab.e(jsonarray), com.admob.android.ads.ab.e(jsonarray1), view, rect);
            if("r".equals(jsonobject))
            {
                jsonobject = com.admob.android.ads.ab.b(jsonarray);
                jsonarray = com.admob.android.ads.ab.b(jsonarray1);
                if(jsonobject != null && jsonarray != null && !java.util.Arrays.equals(jsonobject, jsonarray))
                {
                    view = com.admob.android.ads.bk.b(view);
                    view = com.admob.android.ads.ab.a(new RectF(rect), ((android.graphics.PointF) (view)));
                    return new bd(jsonobject, jsonarray, ((android.graphics.PointF) (view)).x, ((android.graphics.PointF) (view)).y, 0.0F, false);
                } else
                {
                    return null;
                }
            }
            if("sc".equals(jsonobject))
            {
                rect = com.admob.android.ads.ab.b(jsonarray);
                jsonobject = com.admob.android.ads.ab.b(jsonarray1);
                view = com.admob.android.ads.bk.b(view);
                return new ScaleAnimation(rect[0], jsonobject[0], rect[1], jsonobject[1], 1, ((android.graphics.PointF) (view)).x, 1, ((android.graphics.PointF) (view)).y);
            }
            if("sk".equals(jsonobject))
            {
                jsonobject = com.admob.android.ads.ab.b(jsonarray);
                jsonarray = com.admob.android.ads.ab.b(jsonarray1);
                if(jsonobject != null && jsonarray != null && !java.util.Arrays.equals(jsonobject, jsonarray))
                {
                    view = com.admob.android.ads.bk.b(view);
                    return new bf(jsonobject, jsonarray, com.admob.android.ads.ab.a(new RectF(rect), ((android.graphics.PointF) (view))));
                } else
                {
                    return null;
                }
            }
            "p".equals(jsonobject);
        }
        return null;
    }

    private android.view.animation.AnimationSet a(org.json.JSONArray jsonarray, org.json.JSONObject jsonobject, android.view.View view, android.graphics.Rect rect)
    {
        android.view.animation.AnimationSet animationset;
        int i1;
        animationset = new AnimationSet(false);
        i1 = 0;
_L8:
        java.lang.Object obj;
        java.lang.Object obj1;
        org.json.JSONObject jsonobject1;
        int j1;
        if(i1 >= jsonarray.length())
            break MISSING_BLOCK_LABEL_683;
        jsonobject1 = jsonarray.getJSONObject(i1);
        obj = null;
        obj1 = jsonobject1.optString("t", null);
        j1 = (int)((double)com.admob.android.ads.ab.a(jsonobject1, "d", 0.25F) * 1000D);
        if(!"B".equals(obj1))
            break MISSING_BLOCK_LABEL_655;
        obj = jsonobject1.optString("kp", null);
        obj1 = jsonobject1.optString("vt", null);
        if(obj != null && obj1 != null) goto _L2; else goto _L1
_L1:
        if(!com.admob.android.ads.bu.a("AdMobSDK", 6)) goto _L4; else goto _L3
_L3:
        android.util.Log.e("AdMobSDK", (new StringBuilder()).append("Could not read basic animation: keyPath(").append(((java.lang.String) (obj))).append(") or valueType(").append(((java.lang.String) (obj1))).append(") is null.").toString());
        obj = null;
_L5:
        if(obj != null)
        {
            android.view.animation.Interpolator interpolator = com.admob.android.ads.ab.a(jsonobject1.optString("tf", null), -1L, -1L, -1L);
            obj1 = interpolator;
            if(interpolator == null)
                obj1 = null;
            if(obj1 != null)
                ((android.view.animation.Animation) (obj)).setInterpolator(((android.view.animation.Interpolator) (obj1)));
        }
_L6:
        if(obj != null)
        {
            ((android.view.animation.Animation) (obj)).setDuration(j1);
            a(jsonobject1, ((android.view.animation.Animation) (obj)), animationset);
            animationset.addAnimation(((android.view.animation.Animation) (obj)));
            ((android.view.animation.Animation) (obj)).getDuration();
        }
        i1++;
        continue; /* Loop/switch isn't completed */
_L2:
        if("position".equals(obj) && "P".equals(obj1))
            obj = com.admob.android.ads.ab.a(com.admob.android.ads.ab.a(jsonobject1, "fv", c), com.admob.android.ads.ab.a(jsonobject1, "tv", d), view, rect);
        else
        if("opacity".equals(obj) && "F".equals(obj1))
            obj = com.admob.android.ads.ab.a(com.admob.android.ads.ab.a(jsonobject1, "fv", 0.0F), com.admob.android.ads.ab.a(jsonobject1, "tv", 0.0F));
        else
        if("transform".equals(obj) && "AT".equals(obj1))
        {
            com.admob.android.ads.ab.a(jsonobject1, "fv", f);
            com.admob.android.ads.ab.a(jsonobject1, "fv", f);
            obj = com.admob.android.ads.ab.a(view, rect, jsonobject1, jsonobject1.getJSONArray("tfv"), jsonobject1.getJSONArray("ttv"));
        } else
        if("bounds".equals(obj) && "R".equals(obj1))
            obj = com.admob.android.ads.ab.a(com.admob.android.ads.ab.a(jsonobject1, "fv", g), com.admob.android.ads.ab.a(jsonobject1, "tv", g), ((android.view.View) (null)), rect);
        else
        if("zPosition".equals(obj) && "F".equals(obj1))
        {
            obj = com.admob.android.ads.ab.a(com.admob.android.ads.ab.a(jsonobject1, "fv", 0.0F), com.admob.android.ads.ab.a(jsonobject1, "tv", 0.0F), view);
        } else
        {
label0:
            {
                if(!"backgroundColor".equals(obj) || !"C".equals(obj1))
                    break label0;
                obj = com.admob.android.ads.ab.a(com.admob.android.ads.ab.a(jsonobject1, "fv", 0), com.admob.android.ads.ab.a(jsonobject1, "tv", 0), view);
            }
        }
          goto _L5
        if(com.admob.android.ads.bu.a("AdMobSDK", 6))
            android.util.Log.e("AdMobSDK", (new StringBuilder()).append("Could not read basic animation: could not interpret keyPath(").append(((java.lang.String) (obj))).append(") and valueType(").append(((java.lang.String) (obj1))).append(") combination.").toString());
_L4:
        obj = null;
          goto _L5
        if("K".equals(obj1))
            obj = a(jsonobject1, view, rect, j1);
          goto _L6
        if(jsonobject != null)
            a(jsonobject, ((android.view.animation.Animation) (animationset)), ((android.view.animation.AnimationSet) (null)));
        return animationset;
        if(true) goto _L8; else goto _L7
_L7:
    }

    private android.view.animation.AnimationSet a(org.json.JSONObject jsonobject, android.view.View view, android.graphics.Rect rect, long l1)
    {
        java.lang.String s1 = jsonobject.getString("vt");
        float af[] = com.admob.android.ads.ab.b(jsonobject, "kt");
        org.json.JSONArray jsonarray = jsonobject.getJSONArray("vs");
        java.lang.String as1[] = com.admob.android.ads.ab.a(jsonobject, "tfs");
        org.json.JSONArray jsonarray1 = jsonobject.optJSONArray("ttvs");
        int k1 = af.length;
        int i1 = jsonarray.length();
        int i2 = as1.length;
        if((k1 != i1 || i1 != i2 + 1) && (double)af[0] == 0.0D && (double)af[k1 - 1] == 1.0D)
        {
            if(com.admob.android.ads.bu.a("AdMobSDK", 6))
                android.util.Log.e("AdMobSDK", (new StringBuilder()).append("keyframe animations were invalid: numKeyTimes=").append(k1).append(" numKeyValues=").append(i1).append(" numKeyFunctions=").append(i2).append(" keyTimes[0]=").append(af[0]).append(" keyTimes[").append(k1 - 1).append("]=").append(af[k1 - 1]).toString());
            return null;
        }
        android.view.animation.AnimationSet animationset = new AnimationSet(false);
        java.lang.String s2 = jsonobject.getString("kp");
        i2 = com.admob.android.ads.ab.c(jsonobject);
        for(int j1 = 0; j1 < k1 - 1; j1++)
        {
            android.view.animation.Animation animation = com.admob.android.ads.ab.a(j1, s2, s1, af, jsonarray, as1, l1, view, rect, jsonobject, jsonarray1);
            if(animation != null)
            {
                animation.setRepeatCount(i2);
                animationset.addAnimation(animation);
            }
        }

        com.admob.android.ads.ab.a(jsonobject.optString("fm", "r"), ((android.view.animation.Animation) (animationset)));
        return animationset;
    }

    private static android.view.animation.Interpolator a(java.lang.String s1, long l1, long l2, long l3)
    {
        if("i".equals(s1))
            s1 = new AccelerateInterpolator();
        else
        if("o".equals(s1))
            s1 = new DecelerateInterpolator();
        else
        if("io".equals(s1))
            s1 = new AccelerateDecelerateInterpolator();
        else
        if("l".equals(s1))
            s1 = new LinearInterpolator();
        else
            s1 = null;
        if(s1 != null && l1 != -1L && l2 != -1L && l3 != -1L)
            return new bl(s1, l1, l2, l3);
        else
            return s1;
    }

    public static com.admob.android.ads.ab a(com.admob.android.ads.ae ae1, android.content.Context context, org.json.JSONObject jsonobject, int i1, int j1, int k1, com.admob.android.ads.ac ac1, com.admob.android.ads.v v1)
    {
        if(jsonobject == null || jsonobject.length() == 0)
        {
            ae1 = null;
        } else
        {
            com.admob.android.ads.ab ab1 = new ab();
            ab1.E = v1;
            ab1.a(ae1);
            ab1.t = i1;
            ab1.u = j1;
            ab1.v = k1;
            ab1.s = ac1;
            ab1.G = com.admob.android.ads.av.a(context);
            ab1.x.c = ab1.G;
            boolean flag;
            if(ab1.E == com.admob.android.ads.v.b)
            {
                float f1 = com.admob.android.ads.ab.a(jsonobject, "timeout", 0.0F);
                if(f1 > 0.0F)
                {
                    h = f1;
                    ae1 = context.getSharedPreferences("admob_prefs", 2).edit();
                    ae1.putFloat("timeout", h);
                    ae1.commit();
                }
                ab1.D.a(context, jsonobject, ab1.x);
                ab1.D.a.l = true;
                ae1 = ab1.D.a.a;
                if(ae1 != com.admob.android.ads.w.d && ae1 != com.admob.android.ads.w.c)
                {
                    flag = false;
                } else
                {
                    ab1.x.b();
                    if(ab1.x.a())
                        ab1.a();
                    flag = true;
                }
            } else
            {
                flag = ab1.a(context, jsonobject);
            }
            ae1 = ab1;
            if(!flag)
                return null;
        }
        return ae1;
    }

    private static com.admob.android.ads.bb a(float f1, float f2, android.view.View view)
    {
        com.admob.android.ads.bb bb1 = null;
        if(f1 != f2)
            bb1 = new bb(f1, f2, view);
        return bb1;
    }

    private static com.admob.android.ads.bg a(android.graphics.RectF rectf, android.graphics.RectF rectf1, android.view.View view, android.graphics.Rect rect)
    {
        com.admob.android.ads.bg bg1 = null;
        if(!rectf.equals(rectf1))
        {
            view = com.admob.android.ads.ab.a(rectf, com.admob.android.ads.bk.b(view));
            float f1 = rect.width();
            float f2 = rect.height();
            float f3 = rectf.width() / f1;
            float f4 = rectf.height() / f2;
            bg1 = new bg(f3, rectf1.width() / f1, f4, rectf1.height() / f2, ((android.graphics.PointF) (view)).x, ((android.graphics.PointF) (view)).y);
        }
        return bg1;
    }

    private static com.admob.android.ads.bh a(android.graphics.PointF pointf, android.graphics.PointF pointf1, android.view.View view, android.graphics.Rect rect)
    {
        com.admob.android.ads.bh bh1 = null;
        if(!pointf.equals(pointf1))
        {
            view = com.admob.android.ads.bk.b(view);
            float f1 = (float)rect.width() * ((android.graphics.PointF) (view)).x + (float)rect.left;
            float f2 = rect.height();
            f2 = ((android.graphics.PointF) (view)).y * f2 + (float)rect.top;
            pointf.x = pointf.x - f1;
            pointf.y = pointf.y - f2;
            pointf1.x = pointf1.x - f1;
            pointf1.y = pointf1.y - f2;
            bh1 = new bh(0, pointf.x, 0, pointf1.x, 0, pointf.y, 0, pointf1.y);
        }
        return bh1;
    }

    private static com.admob.android.ads.bi a(int i1, int j1, android.view.View view)
    {
        com.admob.android.ads.bi bi1 = null;
        if(i1 != j1)
            bi1 = new bi(i1, j1, view);
        return bi1;
    }

    private static com.admob.android.ads.bj a(float f1, float f2)
    {
        com.admob.android.ads.bj bj1 = null;
        if(f1 != f2)
            bj1 = new bj(f1, f2);
        return bj1;
    }

    public static void a(android.graphics.Canvas canvas, android.graphics.Rect rect, int i1, int j1, int k1, float f1)
    {
        j1 = (int)((float)rect.height() * f1) + rect.top;
        java.lang.Object obj = new Rect(rect.left, rect.top, rect.right, j1);
        java.lang.Object obj1 = new Paint();
        ((android.graphics.Paint) (obj1)).setColor(-1);
        ((android.graphics.Paint) (obj1)).setStyle(android.graphics.Paint.Style.FILL);
        canvas.drawRect(((android.graphics.Rect) (obj)), ((android.graphics.Paint) (obj1)));
        k1 = android.graphics.Color.argb(k1, android.graphics.Color.red(i1), android.graphics.Color.green(i1), android.graphics.Color.blue(i1));
        obj1 = new GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, new int[] {
            k1, i1
        });
        ((android.graphics.drawable.GradientDrawable) (obj1)).setBounds(((android.graphics.Rect) (obj)));
        ((android.graphics.drawable.GradientDrawable) (obj1)).draw(canvas);
        rect = new Rect(rect.left, j1, rect.right, rect.bottom);
        obj = new Paint();
        ((android.graphics.Paint) (obj)).setColor(i1);
        ((android.graphics.Paint) (obj)).setStyle(android.graphics.Paint.Style.FILL);
        canvas.drawRect(rect, ((android.graphics.Paint) (obj)));
    }

    public static void a(android.os.Handler handler)
    {
        i = handler;
    }

    private static void a(android.view.animation.Animation animation, int i1, int j1, float f1, java.lang.String s1, boolean flag)
    {
        if(flag)
            animation.setRepeatMode(2);
        animation.setRepeatCount(i1);
        animation.setStartOffset(j1);
        animation.startNow();
        animation.scaleCurrentDuration(f1);
        com.admob.android.ads.ab.a(s1, animation);
    }

    private void a(android.widget.ImageView imageview, android.graphics.Bitmap bitmap, org.json.JSONObject jsonobject)
    {
        float f1;
        float f4;
        int i1;
        int j1;
        int k1;
        float f2 = com.admob.android.ads.ab.a(jsonobject, "bw", 0.5F);
        i1 = com.admob.android.ads.ab.a(jsonobject, "bdc", a);
        f4 = com.admob.android.ads.ab.a(jsonobject, "br", 6.5F);
        f1 = f2;
        if(f2 < 1.0F)
            f1 = 1.0F;
        j1 = bitmap.getWidth();
        k1 = bitmap.getHeight();
        jsonobject = android.graphics.Bitmap.createBitmap(j1, k1, android.graphics.Bitmap.Config.ARGB_8888);
        if(jsonobject == null)
            return;
        android.graphics.Canvas canvas;
        jsonobject.eraseColor(0);
        canvas = new Canvas(jsonobject);
        canvas.setDrawFilter(new PaintFlagsDrawFilter(0, 1));
        float f3 = f4 + f1;
        java.lang.Object obj = new Path();
        java.lang.Object obj1 = new RectF(0.0F, 0.0F, j1, k1);
        ((android.graphics.Path) (obj)).addRoundRect(((android.graphics.RectF) (obj1)), f3, f3, android.graphics.Path.Direction.CCW);
        canvas.clipPath(((android.graphics.Path) (obj)), android.graphics.Region.Op.REPLACE);
        canvas.drawBitmap(bitmap, 0.0F, 0.0F, new Paint(3));
        canvas.clipRect(((android.graphics.RectF) (obj1)), android.graphics.Region.Op.REPLACE);
        obj = new Paint(1);
        ((android.graphics.Paint) (obj)).setStrokeWidth(f1);
        ((android.graphics.Paint) (obj)).setColor(i1);
        ((android.graphics.Paint) (obj)).setStyle(android.graphics.Paint.Style.STROKE);
        obj1 = new Path();
        f1 /= 2.0F;
        ((android.graphics.Path) (obj1)).addRoundRect(new RectF(f1, f1, (float)j1 - f1, (float)k1 - f1), f4, f4, android.graphics.Path.Direction.CCW);
        canvas.drawPath(((android.graphics.Path) (obj1)), ((android.graphics.Paint) (obj)));
        if(bitmap == null)
            break MISSING_BLOCK_LABEL_290;
        bitmap.recycle();
        bitmap = jsonobject;
_L2:
        z.add(bitmap);
        imageview.setImageBitmap(bitmap);
        return;
        jsonobject;
        if(true) goto _L2; else goto _L1
_L1:
    }

    static void a(com.admob.android.ads.ab ab1)
    {
        ab1.p();
    }

    static void a(com.admob.android.ads.ab ab1, org.json.JSONArray jsonarray)
    {
        if(ab1.s == null)
            break MISSING_BLOCK_LABEL_190;
        java.util.ArrayList arraylist;
        ab1.s.setPadding(0, 0, 0, 0);
        arraylist = new ArrayList();
        int i1 = 0;
_L2:
        java.lang.Object obj;
        if(i1 >= jsonarray.length())
            break; /* Loop/switch isn't completed */
        obj = ab1.b(jsonarray.getJSONObject(i1));
        if(obj == null)
        {
            long l1;
            try
            {
                ab1.p();
                return;
            }
            // Misplaced declaration of an exception variable
            catch(org.json.JSONArray jsonarray)
            {
                ab1.p();
            }
            break MISSING_BLOCK_LABEL_190;
        }
        arraylist.add(obj);
        i1++;
        if(true) goto _L2; else goto _L1
_L1:
        l1 = android.view.animation.AnimationUtils.currentAnimationTimeMillis();
        i1 = 0;
_L4:
        if(i1 >= arraylist.size())
            break; /* Loop/switch isn't completed */
        jsonarray = (android.view.View)arraylist.get(i1);
        obj = jsonarray.getAnimation();
        if(obj == null)
            break MISSING_BLOCK_LABEL_121;
        ((android.view.animation.Animation) (obj)).setStartTime(l1);
        ab1.s.addView(jsonarray);
        i1++;
        if(true) goto _L4; else goto _L3
_L3:
        ab1.s.invalidate();
        ab1.s.requestLayout();
        if(!ab1.F)
            ab1.s.b();
        ab1.x.d();
        if(ab1.m())
        {
            ab1.o();
            return;
        }
    }

    private void a(com.admob.android.ads.ae ae1)
    {
        r = new WeakReference(ae1);
    }

    private void a(java.lang.String s1)
    {
        if(s1 != null && !"".equals(s1))
            m.add(s1);
    }

    private static void a(java.lang.String s1, android.view.animation.Animation animation)
    {
        java.lang.Object obj;
        if(s1 == null || animation == null)
            break MISSING_BLOCK_LABEL_72;
        obj = animation.getClass();
        obj = ((java.lang.Class) (obj)).getMethod("setFillEnabled", new java.lang.Class[] {
            java.lang.Boolean.TYPE
        });
        if(obj != null)
            try
            {
                ((java.lang.reflect.Method) (obj)).invoke(animation, new java.lang.Object[] {
                    java.lang.Boolean.valueOf(true)
                });
            }
            catch(java.lang.Exception exception) { }
        if("b".equals(s1))
        {
            animation.setFillBefore(true);
            animation.setFillAfter(false);
        } else
        {
            if("fb".equals(s1) || "r".equals(s1))
            {
                animation.setFillBefore(true);
                animation.setFillAfter(true);
                return;
            }
            if("f".equals(s1))
            {
                animation.setFillBefore(false);
                animation.setFillAfter(true);
                return;
            }
            if("r".equals(s1))
            {
                animation.setFillBefore(false);
                animation.setFillAfter(false);
                return;
            }
        }
    }

    private void a(org.json.JSONObject jsonobject, android.view.animation.Animation animation, android.view.animation.AnimationSet animationset)
    {
        float f1 = com.admob.android.ads.ab.a(jsonobject, "bt", 0.0F);
        float f2 = com.admob.android.ads.ab.a(jsonobject, "to", 0.0F);
        int i1 = com.admob.android.ads.ab.c(jsonobject);
        boolean flag = jsonobject.optBoolean("ar", false);
        java.lang.String s1 = jsonobject.optString("fm", "r");
        float f3 = com.admob.android.ads.ab.a(jsonobject, "s", 1.0F);
        int j1 = (int)((double)(f1 + 0.0F + f2) * 1000D);
        f1 = 1.0F / f3;
        com.admob.android.ads.ab.a(animation, i1, j1, f1, s1, flag);
        if(animationset != null)
            com.admob.android.ads.ab.a(((android.view.animation.Animation) (animationset)), i1, j1, f1, s1, flag);
    }

    private boolean a(android.content.Context context, org.json.JSONObject jsonobject)
    {
        java.lang.Object obj;
        obj = jsonobject.optJSONObject("o");
        if(obj != null)
        {
            D.a(context, ((org.json.JSONObject) (obj)), null);
        } else
        {
            j = jsonobject.optString("text", null);
            obj = jsonobject.optString("6", null);
            com.admob.android.ads.at at1 = D;
            java.lang.String s1 = jsonobject.optString("8", null);
            at1.a.b = s1;
            obj = com.admob.android.ads.w.a(((java.lang.String) (obj)));
            D.a.a = ((com.admob.android.ads.w) (obj));
            obj = jsonobject.optJSONArray("ac");
            if(obj != null)
                D.a(context, ((org.json.JSONArray) (obj)));
            obj = jsonobject.optJSONObject("ac");
            if(obj != null)
                D.a(context, ((org.json.JSONObject) (obj)));
        }
        context = jsonobject.optString("jsonp_url", null);
        obj = jsonobject.optString("tracking_url", null);
        D.a.a(context, true);
        D.a.a(((java.lang.String) (obj)), false);
        if(jsonobject.has("refreshInterval"))
            B = jsonobject.optDouble("refreshInterval");
        if(jsonobject.has("density"))
            C = jsonobject.optDouble("density");
        else
            C = com.admob.android.ads.ac.d();
        obj = com.admob.android.ads.ab.a(jsonobject, "d", ((android.graphics.PointF) (null)));
        context = ((android.content.Context) (obj));
        if(obj == null)
            context = new PointF(320F, 48F);
        if(((android.graphics.PointF) (context)).x < 0.0F || ((android.graphics.PointF) (context)).y < 0.0F)
            return false;
        int i1 = (int)((android.graphics.PointF) (context)).x;
        int j1 = (int)((android.graphics.PointF) (context)).y;
        p = i1;
        q = j1;
        context = jsonobject.optString("cpm_url", null);
        if(context != null)
        {
            k = true;
            a(((java.lang.String) (context)));
        }
        obj = jsonobject.optString("tracking_pixel", null);
        context = ((android.content.Context) (obj));
        if(obj == null)
            break MISSING_BLOCK_LABEL_372;
        new URL(((java.lang.String) (obj)));
        context = ((android.content.Context) (obj));
_L2:
        if(context != null)
            a(((java.lang.String) (context)));
        context = jsonobject.optJSONObject("markup");
        if(D.a.a == com.admob.android.ads.w.b && !(s.getContext() instanceof android.app.Activity))
        {
            p();
            return false;
        }
          goto _L1
        context;
        double d1;
        try
        {
            context = java.net.URLEncoder.encode(((java.lang.String) (obj)), "UTF-8");
        }
        // Misplaced declaration of an exception variable
        catch(android.content.Context context)
        {
            context = ((android.content.Context) (obj));
        }
        if(true) goto _L2; else goto _L1
_L1:
        if(context == null)
            return false;
        jsonobject = D;
        boolean flag;
        if(((com.admob.android.ads.at) (jsonobject)).a.c != null && ((com.admob.android.ads.at) (jsonobject)).a.c.size() > 0)
            flag = true;
        else
            flag = false;
        if(!flag)
        {
            if(com.admob.android.ads.bu.a("AdMobSDK", 6))
                android.util.Log.e("AdMobSDK", "Bad response:  didn't get clickURLString.  erroring out.");
            return false;
        }
        w = context;
        jsonobject = w.optJSONObject("$");
        if(s == null) goto _L4; else goto _L3
_L3:
        context = com.admob.android.ads.az.g(s.getContext());
_L6:
        x.a(jsonobject, context);
        n();
        d1 = w.optDouble("itid");
        if(d1 <= 0.0D)
            break MISSING_BLOCK_LABEL_582;
        o = (long)(d1 * 1000D);
_L5:
        x.b();
        if(x.a())
            a();
        return true;
        context;
        if(com.admob.android.ads.bu.a("AdMobSDK", 6))
            android.util.Log.e("AdMobSDK", "Could not read in the flex ad.", context);
        if(true) goto _L5; else goto _L4
_L4:
        context = null;
          goto _L6
    }

    private static java.lang.String[] a(org.json.JSONObject jsonobject, java.lang.String s1)
    {
        jsonobject = jsonobject.optJSONArray(s1);
        if(jsonobject == null)
            return null;
        int j1 = jsonobject.length();
        int i1;
        try
        {
            s1 = new java.lang.String[j1];
        }
        // Misplaced declaration of an exception variable
        catch(org.json.JSONObject jsonobject)
        {
            return null;
        }
        i1 = 0;
        if(i1 >= j1)
            break; /* Loop/switch isn't completed */
        s1[i1] = jsonobject.getString(i1);
        i1++;
        if(true) goto _L2; else goto _L1
_L2:
        break MISSING_BLOCK_LABEL_24;
_L1:
        return s1;
    }

    private android.view.View b(org.json.JSONObject jsonobject)
    {
        java.lang.Object obj;
        org.json.JSONArray jsonarray;
        jsonarray = null;
        obj = jsonarray;
        if(s == null) goto _L2; else goto _L1
_L1:
        obj = jsonarray;
        if(jsonobject == null) goto _L2; else goto _L3
_L3:
        android.graphics.Rect rect;
        obj = jsonobject.getString("t");
        rect = a(com.admob.android.ads.ab.a(jsonobject, "f", b));
        if(!"l".equals(obj)) goto _L5; else goto _L4
_L4:
        if(s == null) goto _L7; else goto _L6
_L6:
        float f1;
        java.lang.Object obj2;
        obj2 = jsonobject.getString("x");
        f1 = com.admob.android.ads.ab.a(jsonobject, "fs", 13F);
        jsonarray = jsonobject.optJSONArray("fa");
        obj = android.graphics.Typeface.DEFAULT;
        if(jsonarray == null) goto _L9; else goto _L8
_L8:
        int j1;
        int k1;
        k1 = 0;
        j1 = 0;
_L49:
        if(j1 >= jsonarray.length()) goto _L11; else goto _L10
_L10:
        java.lang.String s1 = jsonarray.getString(j1);
        if(!"b".equals(s1)) goto _L13; else goto _L12
_L12:
        int i1 = k1 | 1;
          goto _L14
_L13:
        if(!"i".equals(s1)) goto _L16; else goto _L15
_L15:
        i1 = k1 | 2;
          goto _L14
_L16:
        if(!"m".equals(s1)) goto _L18; else goto _L17
_L17:
        obj = android.graphics.Typeface.MONOSPACE;
        i1 = k1;
          goto _L14
_L18:
        if(!"s".equals(s1)) goto _L20; else goto _L19
_L19:
        obj = android.graphics.Typeface.SERIF;
        i1 = k1;
          goto _L14
_L20:
        i1 = k1;
        if(!"ss".equals(s1)) goto _L14; else goto _L21
_L21:
        obj = android.graphics.Typeface.SANS_SERIF;
        i1 = k1;
          goto _L14
_L11:
        obj = android.graphics.Typeface.create(((android.graphics.Typeface) (obj)), k1);
_L9:
        j1 = t;
        if(!jsonobject.has("fco")) goto _L23; else goto _L22
_L22:
        k1 = com.admob.android.ads.ab.a(jsonobject, "fco", j1);
        i1 = j1;
        if(k1 != j1)
            i1 = k1;
_L29:
        java.lang.Object obj1;
        org.json.JSONObject jsonobject1;
        try
        {
            boolean flag = jsonobject.optBoolean("afstfw", true);
            float f2 = com.admob.android.ads.ab.a(jsonobject, "mfs", 8F);
            j1 = jsonobject.optInt("nol", 1);
            obj1 = new bm(s.getContext(), com.admob.android.ads.ac.d());
            obj1.b = flag;
            obj1.a = ((com.admob.android.ads.bm) (obj1)).c * f2;
            ((com.admob.android.ads.bm) (obj1)).setBackgroundColor(0);
            ((com.admob.android.ads.bm) (obj1)).setText(((java.lang.CharSequence) (obj2)));
            ((com.admob.android.ads.bm) (obj1)).setTextColor(i1);
            ((com.admob.android.ads.bm) (obj1)).setTextSize(f1);
            ((com.admob.android.ads.bm) (obj1)).setTypeface(((android.graphics.Typeface) (obj)));
            ((com.admob.android.ads.bm) (obj1)).setLines(j1);
        }
        // Misplaced declaration of an exception variable
        catch(org.json.JSONObject jsonobject)
        {
            if(com.admob.android.ads.bu.a("AdMobSDK", 6))
                android.util.Log.e("AdMobSDK", "exception while trying to create a flex view.", jsonobject);
            return null;
        }
        obj = obj1;
          goto _L24
_L30:
        if(obj == null) goto _L26; else goto _L25
_L25:
        if(j1 == 0) goto _L28; else goto _L27
_L27:
        ((android.view.View) (obj)).setBackgroundColor(com.admob.android.ads.ab.a(jsonobject, "bgc", 0));
_L48:
        obj1 = com.admob.android.ads.ab.a(jsonobject, "ap", e);
        obj2 = com.admob.android.ads.bk.c(((android.view.View) (obj)));
        obj2.b = ((android.graphics.PointF) (obj1));
        ((android.view.View) (obj)).setTag(obj2);
        obj1 = null;
        obj2 = jsonobject.optJSONArray("a");
        jsonobject1 = jsonobject.optJSONObject("ag");
        if(obj2 == null)
            break MISSING_BLOCK_LABEL_505;
        obj1 = a(((org.json.JSONArray) (obj2)), jsonobject1, ((android.view.View) (obj)), rect);
        obj2 = jsonobject.optString("ut", null);
        if(obj == null || obj2 == null)
            break MISSING_BLOCK_LABEL_535;
        ((android.view.View) (obj)).setTag(com.admob.android.ads.bk.c(((android.view.View) (obj))));
        obj2 = new android.widget.RelativeLayout.LayoutParams(rect.width(), rect.height());
        ((android.widget.RelativeLayout.LayoutParams) (obj2)).addRule(9);
        ((android.widget.RelativeLayout.LayoutParams) (obj2)).addRule(10);
        ((android.widget.RelativeLayout.LayoutParams) (obj2)).setMargins(rect.left, rect.top, 0, 0);
        ((android.view.View) (obj)).setLayoutParams(((android.view.ViewGroup.LayoutParams) (obj2)));
        if(obj1 == null)
            break MISSING_BLOCK_LABEL_604;
        ((android.view.View) (obj)).setAnimation(((android.view.animation.Animation) (obj1)));
        if(jsonobject.optBoolean("cav") && s != null)
            s.a(((android.view.View) (obj)), ((android.widget.RelativeLayout.LayoutParams) (obj2)));
          goto _L2
_L23:
label0:
        {
            if(jsonobject.optInt("fc", 0) != 1)
                break label0;
            i1 = u;
        }
          goto _L29
        i1 = t;
          goto _L29
_L5:
        if(!"bg".equals(obj))
            break MISSING_BLOCK_LABEL_694;
        obj = a(jsonobject, rect);
        j1 = 0;
        i1 = 0;
          goto _L30
        if(!"i".equals(obj)) goto _L32; else goto _L31
_L31:
        obj = null;
        if(s == null) goto _L34; else goto _L33
_L33:
        obj1 = null;
        obj2 = jsonobject.getString("$");
        if(obj2 == null) goto _L36; else goto _L35
_L35:
        obj = x;
        if(((com.admob.android.ads.ax) (obj)).a == null) goto _L38; else goto _L37
_L37:
        obj = (android.graphics.Bitmap)((com.admob.android.ads.ax) (obj)).a.get(obj2);
_L50:
        if(obj == null) goto _L40; else goto _L39
_L39:
        obj1 = new ImageView(s.getContext());
        ((android.widget.ImageView) (obj1)).setScaleType(android.widget.ImageView.ScaleType.FIT_XY);
        if(!jsonobject.optBoolean("b", false)) goto _L42; else goto _L41
_L41:
        a(((android.widget.ImageView) (obj1)), ((android.graphics.Bitmap) (obj)), jsonobject);
        obj = obj1;
          goto _L34
_L42:
        z.add(obj);
        ((android.widget.ImageView) (obj1)).setImageBitmap(((android.graphics.Bitmap) (obj)));
        obj = obj1;
          goto _L34
_L40:
        if(com.admob.android.ads.bu.a("AdMobSDK", 6))
            android.util.Log.e("AdMobSDK", (new StringBuilder()).append("couldn't find Bitmap ").append(((java.lang.String) (obj2))).toString());
          goto _L43
_L36:
        obj = obj1;
        if(!com.admob.android.ads.bu.a("AdMobSDK", 3)) goto _L34; else goto _L44
_L44:
        android.util.Log.d("AdMobSDK", (new StringBuilder()).append("Could not find asset name ").append(jsonobject).toString());
        obj = obj1;
          goto _L34
_L32:
        if("P".equals(obj))
        {
            if(s == null)
                break MISSING_BLOCK_LABEL_1133;
            obj = new View(s.getContext());
            break MISSING_BLOCK_LABEL_1124;
        }
        if(!"wv".equals(obj)) goto _L46; else goto _L45
_L45:
        obj = d(jsonobject);
        j1 = 1;
        i1 = 1;
          goto _L30
_L28:
        if(i1 == 0) goto _L48; else goto _L47
_L47:
        ((android.view.View) (obj)).setBackgroundDrawable(null);
          goto _L48
_L26:
        if(com.admob.android.ads.bu.a("AdMobSDK", 6))
            android.util.Log.e("AdMobSDK", "created a null view.");
        return null;
_L46:
        i1 = 1;
        obj = null;
        j1 = 1;
          goto _L30
_L14:
        j1++;
        k1 = i1;
          goto _L49
_L24:
        j1 = 1;
        i1 = 1;
          goto _L30
_L2:
        return ((android.view.View) (obj));
_L7:
        obj = null;
          goto _L24
_L34:
        j1 = 1;
        i1 = 1;
          goto _L30
_L38:
        obj = null;
          goto _L50
_L43:
        obj = null;
          goto _L34
_L51:
        j1 = 1;
        i1 = 1;
          goto _L30
        obj = null;
          goto _L51
    }

    private static org.json.JSONArray b(int i1)
    {
        org.json.JSONArray jsonarray = new JSONArray();
        jsonarray.put(android.graphics.Color.red(i1));
        jsonarray.put(android.graphics.Color.green(i1));
        jsonarray.put(android.graphics.Color.blue(i1));
        jsonarray.put(android.graphics.Color.alpha(i1));
        return jsonarray;
    }

    private static float[] b(org.json.JSONArray jsonarray)
    {
        int j1 = jsonarray.length();
        float af[];
        int i1;
        try
        {
            af = new float[j1];
        }
        // Misplaced declaration of an exception variable
        catch(org.json.JSONArray jsonarray)
        {
            return null;
        }
        i1 = 0;
        if(i1 >= j1)
            break; /* Loop/switch isn't completed */
        af[i1] = (float)jsonarray.getDouble(i1);
        i1++;
        if(true) goto _L2; else goto _L1
_L2:
        break MISSING_BLOCK_LABEL_11;
_L1:
        return af;
    }

    private static float[] b(org.json.JSONObject jsonobject, java.lang.String s1)
    {
        jsonobject = jsonobject.optJSONArray(s1);
        if(jsonobject == null)
            return null;
        else
            return com.admob.android.ads.ab.b(((org.json.JSONArray) (jsonobject)));
    }

    private static int c(org.json.JSONArray jsonarray)
    {
        int i1 = (int)(jsonarray.getDouble(0) * 255D);
        int j1 = (int)(jsonarray.getDouble(1) * 255D);
        int k1 = (int)(jsonarray.getDouble(2) * 255D);
        return android.graphics.Color.argb((int)(jsonarray.getDouble(3) * 255D), i1, j1, k1);
    }

    private static int c(org.json.JSONObject jsonobject)
    {
        int j1 = (int)com.admob.android.ads.ab.a(jsonobject, "rc", 1.0F);
        int i1 = j1;
        if(j1 > 0)
            i1 = j1 - 1;
        return i1;
    }

    private static android.graphics.RectF d(org.json.JSONArray jsonarray)
    {
        float f1 = (float)jsonarray.getDouble(0);
        float f2 = (float)jsonarray.getDouble(1);
        return new RectF(f1, f2, (float)jsonarray.getDouble(2) + f1, (float)jsonarray.getDouble(3) + f2);
    }

    private android.view.View d(org.json.JSONObject jsonobject)
    {
        if(s != null)
        {
            java.lang.Object obj = jsonobject.optString("u");
            java.lang.String s1 = jsonobject.optString("html");
            java.lang.String s2 = jsonobject.optString("base");
            y = y + 1;
            com.admob.android.ads.ao ao1 = new ao(s.getContext(), this);
            if(obj != null && !((java.lang.String) (obj)).equals(""))
            {
                ao1.a(((java.lang.String) (obj)));
                ao1.loadUrl(((java.lang.String) (obj)));
            } else
            if(s1 != null && !s1.equals("") && s2 != null && !s2.equals(""))
            {
                ao1.loadDataWithBaseURL(s2, s1, null, null, null);
            } else
            {
                a(false);
                return null;
            }
            jsonobject = jsonobject.optJSONObject("d");
            if(jsonobject != null)
                ao1.c = jsonobject;
            obj = s.b;
            jsonobject = new JSONObject();
            try
            {
                jsonobject.put("ptc", com.admob.android.ads.ab.b(((com.admob.android.ads.AdView) (obj)).a()));
                jsonobject.put("stc", com.admob.android.ads.ab.b(((com.admob.android.ads.AdView) (obj)).b()));
                jsonobject.put("bgc", com.admob.android.ads.ab.b(((com.admob.android.ads.AdView) (obj)).c()));
            }
            catch(org.json.JSONException jsonexception) { }
            ao1.d = jsonobject;
            ao1.b();
            F = true;
            return ao1;
        } else
        {
            return null;
        }
    }

    private static android.graphics.PointF e(org.json.JSONArray jsonarray)
    {
        return new PointF((float)jsonarray.getDouble(0), (float)jsonarray.getDouble(1));
    }

    private boolean m()
    {
        return y <= 0;
    }

    private void n()
    {
        java.lang.Object obj;
        android.graphics.Rect rect;
        rect = new Rect(0, 0, p, q);
        obj = rect;
        if(!w.has("ta"))
            break MISSING_BLOCK_LABEL_120;
        android.graphics.Rect rect1;
        obj = w.getJSONArray("ta");
        int i1 = ((org.json.JSONArray) (obj)).getInt(0);
        int k1 = ((org.json.JSONArray) (obj)).getInt(1);
        rect1 = new Rect(i1, k1, ((org.json.JSONArray) (obj)).getInt(2) + i1, ((org.json.JSONArray) (obj)).getInt(3) + k1);
        obj = rect;
        int j1;
        if(java.lang.Math.abs(rect1.width()) < 44)
            break MISSING_BLOCK_LABEL_120;
        j1 = java.lang.Math.abs(rect1.height());
        obj = rect;
        if(j1 >= 44)
            obj = rect1;
_L2:
        n = ((android.graphics.Rect) (obj));
        return;
        org.json.JSONException jsonexception;
        jsonexception;
        jsonexception = rect;
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
        {
            android.util.Log.d("AdMobSDK", "could not read in the touchable area for the ad.");
            jsonexception = rect;
        }
        if(true) goto _L2; else goto _L1
_L1:
    }

    private void o()
    {
        com.admob.android.ads.ae ae1 = (com.admob.android.ads.ae)r.get();
        if(ae1 != null)
            ae1.a(this);
        if(G != null)
            com.admob.android.ads.av.a();
    }

    private void p()
    {
        com.admob.android.ads.ae ae1 = (com.admob.android.ads.ae)r.get();
        if(ae1 != null)
            ae1.a();
        if(G != null)
            com.admob.android.ads.av.a();
    }

    public final int a(int i1)
    {
        double d2 = i1;
        double d1 = d2;
        if(C > 0.0D)
            d1 = d2 * C;
        return (int)d1;
    }

    final android.graphics.Rect a(android.graphics.Rect rect)
    {
        android.graphics.Rect rect1 = new Rect(rect);
        if(C > 0.0D)
        {
            rect1.left = a(rect.left);
            rect1.top = a(rect.top);
            rect1.right = a(rect.right);
            rect1.bottom = a(rect.bottom);
        }
        return rect1;
    }

    public final void a()
    {
        java.lang.Object obj;
        if(D != null)
        {
            if(D.e())
                D.a(x.a);
            D.d();
        }
        if(w == null)
            break MISSING_BLOCK_LABEL_162;
        obj = w;
        w = null;
        obj = ((org.json.JSONObject) (obj)).optJSONArray("v");
        if(obj == null) goto _L2; else goto _L1
_L1:
        com.admob.android.ads.ax ax1;
        try
        {
            obj = new t(this, ((org.json.JSONArray) (obj)));
            if(i != null)
                i.post(((java.lang.Runnable) (obj)));
        }
        // Misplaced declaration of an exception variable
        catch(java.lang.Object obj1)
        {
            if(com.admob.android.ads.bu.a("AdMobSDK", 3))
                android.util.Log.d("AdMobSDK", "couldn't construct the views.", ((java.lang.Throwable) (obj1)));
        }
        ax1 = x;
        if(ax1.b != null)
            synchronized(ax1.b)
            {
                ax1.b.clear();
                ax1.b = null;
            }
_L4:
        return;
_L2:
        p();
        break MISSING_BLOCK_LABEL_91;
        if(m())
        {
            o();
            return;
        }
        if(true) goto _L4; else goto _L3
_L3:
    }

    public final void a(com.admob.android.ads.ac ac1)
    {
        s = ac1;
    }

    public final void a(com.admob.android.ads.u u1)
    {
        A = u1;
    }

    public final void a(org.json.JSONObject jsonobject)
    {
        if(l)
        {
            if(com.admob.android.ads.bu.a("AdMobSDK", 4))
                android.util.Log.i("AdMobSDK", "Ad clicked again.  Stats on admob.com will only reflect the first click.");
        } else
        {
            l = true;
            if(com.admob.android.ads.bu.a("AdMobSDK", 4))
                android.util.Log.i("AdMobSDK", "Ad clicked.");
            if(s != null)
            {
                java.lang.Object obj = s.getContext();
                com.admob.android.ads.at at1 = D;
                obj = com.admob.android.ads.az.g(((android.content.Context) (obj)));
                com.admob.android.ads.at.a(at1.a.c, jsonobject, ((java.lang.String) (obj)));
            }
        }
        if(s == null) goto _L2; else goto _L1
_L1:
        jsonobject = s.getContext();
        if(!(jsonobject instanceof android.app.Activity)) goto _L2; else goto _L3
_L3:
        jsonobject = (android.app.Activity)jsonobject;
_L5:
        if(jsonobject != null)
            D.a(jsonobject, s);
        else
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
            android.util.Log.d("AdMobSDK", "Context null, not able to finish click.");
        if(A != null)
            A.a();
        return;
_L2:
        jsonobject = null;
        if(true) goto _L5; else goto _L4
_L4:
    }

    public final void a(boolean flag)
    {
        y = y - 1;
        if(flag)
        {
            if(m())
                o();
            return;
        } else
        {
            x.c();
            return;
        }
    }

    public final void b()
    {
        w = null;
        if(com.admob.android.ads.bu.a("AdMobSDK", 4))
            android.util.Log.i("AdMobSDK", "assetsDidFailToLoad()");
        p();
    }

    public final double c()
    {
        return B;
    }

    public final com.admob.android.ads.ac d()
    {
        return s;
    }

    public final long e()
    {
        return o;
    }

    public final boolean equals(java.lang.Object obj)
    {
        if(obj instanceof com.admob.android.ads.ab)
        {
            obj = (com.admob.android.ads.ab)obj;
            return toString().equals(((com.admob.android.ads.ab) (obj)).toString());
        } else
        {
            return false;
        }
    }

    public final boolean f()
    {
        return k;
    }

    public final int g()
    {
        return p;
    }

    public final int h()
    {
        return q;
    }

    public final int hashCode()
    {
        return toString().hashCode();
    }

    public final android.graphics.Rect i()
    {
        if(n == null)
            n = new Rect(0, 0, p, q);
        return n;
    }

    final void j()
    {
        java.util.Iterator iterator = z.iterator();
        do
        {
            if(!iterator.hasNext())
                break;
            android.graphics.Bitmap bitmap = (android.graphics.Bitmap)iterator.next();
            if(bitmap != null)
                bitmap.recycle();
        } while(true);
        z.clear();
        if(D != null)
            D.c();
    }

    final void k()
    {
        if(s != null)
        {
            android.content.Context context = s.getContext();
            for(java.util.Iterator iterator = m.iterator(); iterator.hasNext(); com.admob.android.ads.y.a((java.lang.String)iterator.next(), "impression_request", com.admob.android.ads.az.g(context)).f());
        }
    }

    public final boolean l()
    {
        return F;
    }

    public final java.lang.String toString()
    {
        java.lang.String s2 = j;
        java.lang.String s1 = s2;
        if(s2 == null)
            s1 = "";
        return s1;
    }

    private static final int a = android.graphics.Color.rgb(102, 102, 102);
    private static final android.graphics.Rect b = new Rect(0, 0, 0, 0);
    private static final android.graphics.PointF c;
    private static final android.graphics.PointF d;
    private static final android.graphics.PointF e = new PointF(0.5F, 0.5F);
    private static final android.graphics.Matrix f = new Matrix();
    private static final android.graphics.RectF g = new RectF(0.0F, 0.0F, 0.0F, 0.0F);
    private static float h = -1F;
    private static android.os.Handler i = null;
    private com.admob.android.ads.u A;
    private double B;
    private double C;
    private com.admob.android.ads.at D;
    private com.admob.android.ads.v E;
    private boolean F;
    private com.admob.android.ads.av G;
    private java.lang.String j;
    private boolean k;
    private boolean l;
    private java.util.Vector m;
    private android.graphics.Rect n;
    private long o;
    private int p;
    private int q;
    private java.lang.ref.WeakReference r;
    private com.admob.android.ads.ac s;
    private int t;
    private int u;
    private int v;
    private org.json.JSONObject w;
    private com.admob.android.ads.ax x;
    private int y;
    private java.util.Vector z;

    static 
    {
        android.graphics.PointF pointf = new PointF(0.0F, 0.0F);
        c = pointf;
        d = pointf;
    }
}
