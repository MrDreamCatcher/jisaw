// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.os.Bundle;

// Referenced classes of package com.admob.android.ads:
//            af

public final class an
    implements com.admob.android.ads.af
{

    public an()
    {
        a = null;
        b = false;
    }

    public an(java.lang.String s, boolean flag)
    {
        a = s;
        b = flag;
    }

    public final android.os.Bundle a()
    {
        android.os.Bundle bundle = new Bundle();
        bundle.putString("u", a);
        bundle.putBoolean("p", b);
        return bundle;
    }

    public final boolean equals(java.lang.Object obj)
    {
        if(obj instanceof com.admob.android.ads.an)
        {
            obj = (com.admob.android.ads.an)obj;
            boolean flag;
            boolean flag1;
            boolean flag2;
            if(a == null && ((com.admob.android.ads.an) (obj)).a != null)
                flag = true;
            else
                flag = false;
            if(a != null && !a.equals(((com.admob.android.ads.an) (obj)).a))
                flag1 = true;
            else
                flag1 = false;
            if(b != ((com.admob.android.ads.an) (obj)).b)
                flag2 = true;
            else
                flag2 = false;
            return !flag && !flag1 && !flag2;
        } else
        {
            return false;
        }
    }

    public final int hashCode()
    {
        if(a != null)
            return a.hashCode();
        else
            return super.hashCode();
    }

    public java.lang.String a;
    public boolean b;
}
