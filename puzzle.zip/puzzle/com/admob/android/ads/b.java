// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.util.Log;
import android.view.animation.DecelerateInterpolator;
import java.lang.ref.WeakReference;

// Referenced classes of package com.admob.android.ads:
//            AdView, ac, bd, d, 
//            bu

final class b
    implements java.lang.Runnable
{

    public b(com.admob.android.ads.ac ac1, com.admob.android.ads.AdView adview)
    {
        b = new WeakReference(ac1);
        a = new WeakReference(adview);
    }

    public final void run()
    {
        com.admob.android.ads.AdView adview;
        com.admob.android.ads.ac ac1;
        adview = (com.admob.android.ads.AdView)a.get();
        ac1 = (com.admob.android.ads.ac)b.get();
        if(adview == null || ac1 == null)
            break MISSING_BLOCK_LABEL_133;
        com.admob.android.ads.ac ac2 = com.admob.android.ads.AdView.a(adview);
        if(ac2 == null)
            break MISSING_BLOCK_LABEL_45;
        ac2.setVisibility(8);
        ac1.setVisibility(0);
        com.admob.android.ads.bd bd1 = new bd(90F, 0.0F, (float)adview.getWidth() / 2.0F, (float)adview.getHeight() / 2.0F, -0.4F * (float)adview.getWidth(), false);
        bd1.setDuration(700L);
        bd1.setFillAfter(true);
        bd1.setInterpolator(new DecelerateInterpolator());
        bd1.setAnimationListener(new d(this, ac2, adview, ac1));
        adview.startAnimation(bd1);
_L1:
        return;
        java.lang.Exception exception;
        exception;
        if(com.admob.android.ads.bu.a("AdMobSDK", 6))
        {
            android.util.Log.e("AdMobSDK", (new StringBuilder()).append("exception caught in SwapViews.run(), ").append(exception.getMessage()).toString());
            return;
        }
          goto _L1
    }

    private java.lang.ref.WeakReference a;
    private java.lang.ref.WeakReference b;
}
