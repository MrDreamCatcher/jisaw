// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.VideoView;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.Vector;

// Referenced classes of package com.admob.android.ads:
//            bq, bp, cf, as, 
//            cm, aq, by, ab, 
//            ce, ci, cj, am, 
//            cl, aj, bu, az, 
//            au, ch

public final class br extends com.admob.android.ads.bq
    implements com.admob.android.ads.bp
{

    public br(android.content.Context context, java.lang.ref.WeakReference weakreference)
    {
        super(context);
        i = false;
        j = false;
        q = weakreference;
        n = new cf(this);
        h = false;
        i = false;
        j = false;
    }

    private void a(android.content.Context context)
    {
        com.admob.android.ads.aq aq1 = c.h;
        e = new VideoView(context);
        context = new cm(this);
        e.setOnPreparedListener(context);
        e.setOnCompletionListener(context);
        e.setVideoPath(aq1.a);
        e.setBackgroundDrawable(null);
        e.setOnErrorListener(context);
        context = new android.widget.RelativeLayout.LayoutParams(-1, -1);
        context.addRule(13);
        addView(e, context);
        if(k != null)
            k.b();
    }

    public static void a(android.view.View view)
    {
        android.view.animation.AlphaAnimation alphaanimation = new AlphaAnimation(0.0F, 1.0F);
        alphaanimation.setDuration(1000L);
        alphaanimation.setFillAfter(true);
        view.startAnimation(alphaanimation);
        view.invalidate();
    }

    static void a(com.admob.android.ads.br br1)
    {
        br1.g();
    }

    static void a(com.admob.android.ads.br br1, android.content.Context context)
    {
        br1.a(context);
    }

    static void a(com.admob.android.ads.br br1, android.view.MotionEvent motionevent)
    {
        android.util.Log.v("AdMobSDK", "fadeBars()");
        if(br1.e() && br1.k != null)
        {
            if(br1.g == 2)
            {
                br1.a.removeCallbacks(br1.n);
                if(!br1.k.b)
                    br1.k.b();
                br1.a.postDelayed(br1.n, 3000L);
                return;
            }
            if(motionevent.getAction() == 0)
                if(br1.k.b)
                {
                    br1.k.a();
                    return;
                } else
                {
                    br1.k.b();
                    return;
                }
        }
    }

    static void a(com.admob.android.ads.br br1, boolean flag)
    {
        br1.b(false);
    }

    public static void b(android.view.View view)
    {
        android.view.animation.AlphaAnimation alphaanimation = new AlphaAnimation(1.0F, 0.0F);
        alphaanimation.setDuration(1000L);
        alphaanimation.setFillAfter(true);
        view.startAnimation(alphaanimation);
        view.invalidate();
    }

    private void b(boolean flag)
    {
        o = flag;
        if(!flag)
            g();
    }

    private void g()
    {
        if(p != null)
        {
            a.removeCallbacks(p);
            p = null;
        }
    }

    private void h()
    {
        if(c.h.c())
        {
            java.lang.Object obj = getContext();
            d = new RelativeLayout(((android.content.Context) (obj)));
            obj = new ImageView(((android.content.Context) (obj)));
            java.lang.Object obj1 = c.b();
            if(obj1 != null)
            {
                obj1 = (android.graphics.Bitmap)((java.util.Hashtable) (obj1)).get(c.h.f);
                if(obj1 != null)
                {
                    android.graphics.drawable.BitmapDrawable bitmapdrawable = new BitmapDrawable(((android.graphics.Bitmap) (obj1)));
                    float f1 = getResources().getDisplayMetrics().density;
                    ((android.widget.ImageView) (obj)).setImageDrawable(bitmapdrawable);
                    obj1 = new android.widget.RelativeLayout.LayoutParams(com.admob.android.ads.ab.a(((android.graphics.Bitmap) (obj1)).getWidth(), f1), com.admob.android.ads.ab.a(((android.graphics.Bitmap) (obj1)).getHeight(), f1));
                    ((android.widget.RelativeLayout.LayoutParams) (obj1)).addRule(13);
                    d.addView(((android.view.View) (obj)), ((android.view.ViewGroup.LayoutParams) (obj1)));
                    d.setBackgroundColor(0);
                    d.setVisibility(4);
                    obj = new android.widget.RelativeLayout.LayoutParams(-1, -1);
                    addView(d, ((android.view.ViewGroup.LayoutParams) (obj)));
                }
            }
            l = java.lang.System.currentTimeMillis();
        }
    }

    public final void a()
    {
        if(h)
        {
            a.post(new ce(this));
            return;
        }
        com.admob.android.ads.ci ci1 = new ci(this);
        long l1 = java.lang.System.currentTimeMillis() - l;
        long l2 = (int)(c.h.g * 1000D);
        if(l2 > l1)
        {
            a.postDelayed(ci1, l2 - l1);
            return;
        } else
        {
            a.post(ci1);
            return;
        }
    }

    public final void a(android.content.res.Configuration configuration)
    {
        g = configuration.orientation;
        if(k == null || !e())
            break MISSING_BLOCK_LABEL_74;
        if(g != 2 || !k.b) goto _L2; else goto _L1
_L1:
        k.a();
_L4:
        return;
_L2:
        if(k.b || g != 1) goto _L4; else goto _L3
_L3:
        k.b();
        return;
        a.removeCallbacks(n);
        return;
    }

    public final void a(boolean flag)
    {
        a.removeCallbacks(n);
        if(d == null)
            h();
        if(d != null)
            com.admob.android.ads.br.a(((android.view.View) (d)));
        if(k != null)
        {
            com.admob.android.ads.by by1 = k;
            java.lang.Object obj = getContext();
            com.admob.android.ads.as as1 = c;
            float f1 = b;
            if(by1.a == null)
            {
                android.widget.RelativeLayout relativelayout = new RelativeLayout(((android.content.Context) (obj)));
                java.lang.Object obj1 = new Button(((android.content.Context) (obj)));
                ((android.widget.Button) (obj1)).setTextColor(-1);
                ((android.widget.Button) (obj1)).setOnClickListener(new cj(this));
                java.lang.Object obj2 = new BitmapDrawable((android.graphics.Bitmap)as1.b().get(as1.h.l));
                ((android.graphics.drawable.BitmapDrawable) (obj2)).setBounds(0, 0, (int)(134F * f1), (int)(134F * f1));
                ((android.widget.Button) (obj1)).setWidth((int)(134F * f1));
                ((android.widget.Button) (obj1)).setHeight(134);
                ((android.widget.Button) (obj1)).setBackgroundDrawable(((android.graphics.drawable.Drawable) (obj2)));
                obj2 = new android.widget.RelativeLayout.LayoutParams((int)(134F * f1), (int)(134F * f1));
                ((android.widget.RelativeLayout.LayoutParams) (obj2)).addRule(13);
                relativelayout.addView(((android.view.View) (obj1)), ((android.view.ViewGroup.LayoutParams) (obj2)));
                relativelayout.setOnClickListener(new cj(this));
                obj1 = new TextView(((android.content.Context) (obj)));
                ((android.widget.TextView) (obj1)).setTextColor(-1);
                ((android.widget.TextView) (obj1)).setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                ((android.widget.TextView) (obj1)).setText("Replay");
                ((android.widget.TextView) (obj1)).setPadding(0, 0, 0, (int)(14F * f1));
                obj2 = new android.widget.RelativeLayout.LayoutParams(-2, -2);
                ((android.widget.RelativeLayout.LayoutParams) (obj2)).addRule(12);
                ((android.widget.RelativeLayout.LayoutParams) (obj2)).addRule(14);
                relativelayout.addView(((android.view.View) (obj1)), ((android.view.ViewGroup.LayoutParams) (obj2)));
                by1.a = new am(((android.content.Context) (obj)), relativelayout, 134, 134, (android.graphics.Bitmap)as1.b().get(as1.h.k));
                by1.a.setOnClickListener(new cj(this));
                by1.a.setVisibility(4);
                obj = new android.widget.RelativeLayout.LayoutParams((int)(134F * f1), (int)(134F * f1));
                ((android.widget.RelativeLayout.LayoutParams) (obj)).addRule(13);
                addView(by1.a, ((android.view.ViewGroup.LayoutParams) (obj)));
            }
            if(flag)
            {
                com.admob.android.ads.by by2 = k;
                if(by2.a != null)
                {
                    by2.a.bringToFront();
                    com.admob.android.ads.br.a(((android.view.View) (by2.a)));
                }
            }
            if(!k.b)
                k.b();
        }
        if(o && p == null)
        {
            p = new cl(this);
            a.postDelayed(p, 7500L);
        }
    }

    public final void b()
    {
        if(d != null)
            com.admob.android.ads.br.b(((android.view.View) (d)));
        if(m != null)
            com.admob.android.ads.br.b(((android.view.View) (m)));
        if(k != null && !k.b)
            k.b();
        if(k != null)
        {
            com.admob.android.ads.by by1 = k;
            if(by1.a != null)
                com.admob.android.ads.br.b(((android.view.View) (by1.a)));
        }
        invalidate();
        if(g == 2 && k != null && k.b)
            a.postDelayed(n, 3000L);
        a.postDelayed(new ce(this), 1000L);
    }

    public final void c()
    {
        f();
        java.util.HashMap hashmap = null;
        if(i)
        {
            hashmap = new HashMap();
            hashmap.put("event", "completed");
        }
        f.a("done", hashmap);
        d();
    }

    void d()
    {
        if(q != null)
        {
            android.app.Activity activity = (android.app.Activity)q.get();
            if(activity != null)
                activity.finish();
        }
    }

    boolean e()
    {
        return e != null && e.isPlaying();
    }

    void f()
    {
        if(e != null)
        {
            e.stopPlayback();
            e.setVisibility(4);
            removeView(e);
            e = null;
        }
    }

    protected final void onAttachedToWindow()
    {
        p = null;
        if(c != null) goto _L2; else goto _L1
_L1:
        if(com.admob.android.ads.bu.a("AdMobSDK", 6))
            android.util.Log.e("AdMobSDK", "openerInfo is null");
_L4:
        return;
_L2:
        com.admob.android.ads.aq aq1;
        b(c.l);
        aq1 = c.h;
        if(aq1 != null)
            break; /* Loop/switch isn't completed */
        if(com.admob.android.ads.bu.a("AdMobSDK", 6))
        {
            android.util.Log.e("AdMobSDK", "movieInfo is null");
            return;
        }
        if(true) goto _L4; else goto _L3
_L3:
        android.content.Context context = getContext();
        java.lang.Object obj;
        if(com.admob.android.ads.az.j(context) == "l")
            g = 2;
        else
            g = 1;
        f = new aj(c.j, com.admob.android.ads.az.d(context), c.i, com.admob.android.ads.az.g(context));
        f.a("video", null);
        a(context);
        if(c.l)
            obj = "Skip";
        else
            obj = "Done";
        obj = com.admob.android.ads.au.a(((java.lang.String) (obj)));
        if(aq1.c())
        {
            h();
            if(d != null)
                com.admob.android.ads.br.a(d);
            if(!aq1.j || !aq1.c())
            {
                m = new Button(context);
                m.setOnClickListener(new ch(this, true));
                m.setBackgroundResource(0x1080005);
                m.setTextSize(13F);
                m.setText(((java.lang.CharSequence) (obj)));
                m.setVisibility(4);
                android.widget.RelativeLayout.LayoutParams layoutparams = new android.widget.RelativeLayout.LayoutParams((int)(54F * b), (int)(36F * b));
                layoutparams.addRule(11);
                layoutparams.addRule(12);
                layoutparams.setMargins(0, 0, (int)(2.0F * b), (int)(8F * b));
                addView(m, layoutparams);
                com.admob.android.ads.br.a(m);
            }
        }
        if(aq1.c == 2 && aq1.m != null && aq1.m.size() > 0)
        {
            k = new by();
            k.a(context, ((java.lang.String) (obj)), aq1, b, this, c, q);
            return;
        }
        boolean flag;
        if(aq1.c == 0)
            flag = true;
        else
            flag = false;
        obj = (android.app.Activity)q.get();
        if(obj != null && e != null)
        {
            r = new MediaController(((android.content.Context) (obj)), flag);
            r.setAnchorView(e);
            e.setMediaController(r);
            return;
        }
        if(true) goto _L4; else goto _L5
_L5:
    }

    android.view.ViewGroup d;
    android.widget.VideoView e;
    com.admob.android.ads.aj f;
    int g;
    boolean h;
    boolean i;
    boolean j;
    com.admob.android.ads.by k;
    private long l;
    private android.widget.Button m;
    private java.lang.Runnable n;
    private boolean o;
    private com.admob.android.ads.cl p;
    private java.lang.ref.WeakReference q;
    private android.widget.MediaController r;
}
