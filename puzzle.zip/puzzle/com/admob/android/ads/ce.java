// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.widget.VideoView;
import java.lang.ref.WeakReference;

// Referenced classes of package com.admob.android.ads:
//            br

final class ce
    implements java.lang.Runnable
{

    public ce(com.admob.android.ads.br br1)
    {
        a = new WeakReference(br1);
    }

    public final void run()
    {
        com.admob.android.ads.br br1;
        for(br1 = (com.admob.android.ads.br)a.get(); br1 == null || br1.e == null;)
            return;

        br1.e.setVisibility(0);
        br1.e.requestLayout();
        br1.e.requestFocus();
        br1.e.start();
    }

    private java.lang.ref.WeakReference a;
}
