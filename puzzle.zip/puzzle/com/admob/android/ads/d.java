// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.view.animation.Animation;

// Referenced classes of package com.admob.android.ads:
//            AdView, ac, b

final class d
    implements android.view.animation.Animation.AnimationListener
{

    d(com.admob.android.ads.b b1, com.admob.android.ads.ac ac1, com.admob.android.ads.AdView adview, com.admob.android.ads.ac ac2)
    {
        a = ac1;
        b = adview;
        c = ac2;
        super();
    }

    public final void onAnimationEnd(android.view.animation.Animation animation)
    {
        if(a != null)
            b.removeView(a);
        com.admob.android.ads.AdView.c(b, c);
        if(a != null)
            a.e();
    }

    public final void onAnimationRepeat(android.view.animation.Animation animation)
    {
    }

    public final void onAnimationStart(android.view.animation.Animation animation)
    {
    }

    private com.admob.android.ads.ac a;
    private com.admob.android.ads.AdView b;
    private com.admob.android.ads.ac c;
}
