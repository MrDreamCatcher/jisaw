// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.content.Context;
import android.media.AudioManager;

public class aw
{

    public aw(android.content.Context context)
    {
        a = (android.media.AudioManager)context.getSystemService("audio");
    }

    public int a()
    {
        return a.getMode();
    }

    public boolean b()
    {
        return a.isMusicActive();
    }

    public boolean c()
    {
        return a.isSpeakerphoneOn();
    }

    public int d()
    {
        return a.getRingerMode();
    }

    public android.media.AudioManager a;
}
