// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;

// Referenced classes of package com.admob.android.ads:
//            bu

public final class am extends android.widget.RelativeLayout
{

    public am(android.content.Context context, android.view.View view, int i, int j, android.graphics.Bitmap bitmap)
    {
        super(context);
        b = i;
        a = j;
        setClickable(true);
        setFocusable(true);
        d = getResources().getDisplayMetrics().density;
        c = new ImageView(context);
        context = new BitmapDrawable(bitmap);
        context.setBounds(0, 0, (int)((float)i * d), (int)((float)j * d));
        c.setImageDrawable(context);
        c.setVisibility(4);
        context = new android.widget.RelativeLayout.LayoutParams((int)((float)i * d), (int)((float)j * d));
        context.addRule(13);
        addView(view, context);
        addView(c, context);
    }

    private void a(boolean flag)
    {
        if(flag)
        {
            c.setVisibility(0);
            return;
        } else
        {
            c.setVisibility(4);
            return;
        }
    }

    public final boolean dispatchTouchEvent(android.view.MotionEvent motionevent)
    {
        int i;
        i = motionevent.getAction();
        if(com.admob.android.ads.bu.a("AdMobSDK", 2))
            android.util.Log.v("AdMobSDK", (new StringBuilder()).append("dispatchTouchEvent: action=").append(i).append(" x=").append(motionevent.getX()).append(" y=").append(motionevent.getY()).toString());
        if(i != 0) goto _L2; else goto _L1
_L1:
        a(true);
_L4:
        return super.dispatchTouchEvent(motionevent);
_L2:
        if(i == 2)
            a((new Rect(0, 0, (int)((float)b * d), (int)((float)a * d))).contains((int)motionevent.getX(), (int)motionevent.getY()));
        else
        if(i == 1)
            a(false);
        else
        if(i == 3)
            a(false);
        if(true) goto _L4; else goto _L3
_L3:
    }

    private int a;
    private int b;
    private android.widget.ImageView c;
    private float d;

}
