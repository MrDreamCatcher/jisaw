// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.util.Log;
import java.lang.ref.WeakReference;

// Referenced classes of package com.admob.android.ads:
//            AdView, ac, x

final class g
    implements java.lang.Runnable
{

    public g(com.admob.android.ads.AdView adview)
    {
        a = new WeakReference(adview);
    }

    public final void run()
    {
        java.lang.Object obj;
        obj = (com.admob.android.ads.AdView)a.get();
        if(obj == null)
            break MISSING_BLOCK_LABEL_49;
        if(com.admob.android.ads.AdView.a(((com.admob.android.ads.AdView) (obj))) != null && com.admob.android.ads.AdView.a(((com.admob.android.ads.AdView) (obj))).getParent() != null || com.admob.android.ads.AdView.b(((com.admob.android.ads.AdView) (obj))) == null)
            break MISSING_BLOCK_LABEL_61;
        com.admob.android.ads.AdView.b(((com.admob.android.ads.AdView) (obj))).b(((com.admob.android.ads.AdView) (obj)));
        return;
        obj;
        android.util.Log.w("AdMobSDK", "Unhandled exception raised in your AdListener.onFailedToReceiveAd.", ((java.lang.Throwable) (obj)));
        return;
        try
        {
            com.admob.android.ads.AdView.b(((com.admob.android.ads.AdView) (obj))).d(((com.admob.android.ads.AdView) (obj)));
            return;
        }
        catch(java.lang.Exception exception)
        {
            android.util.Log.w("AdMobSDK", "Unhandled exception raised in your AdListener.onFailedToReceiveRefreshedAd.", exception);
        }
        return;
    }

    private java.lang.ref.WeakReference a;
}
