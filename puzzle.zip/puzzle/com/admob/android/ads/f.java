// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.util.Log;
import java.lang.ref.WeakReference;

// Referenced classes of package com.admob.android.ads:
//            AdView, bu

final class f
    implements java.lang.Runnable
{

    public f(com.admob.android.ads.AdView adview)
    {
        b = new WeakReference(adview);
    }

    public final void run()
    {
        com.admob.android.ads.AdView adview = (com.admob.android.ads.AdView)b.get();
        if(a || adview == null)
            break MISSING_BLOCK_LABEL_83;
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
        {
            int i = com.admob.android.ads.AdView.h(adview) / 1000;
            if(com.admob.android.ads.bu.a("AdMobSDK", 3))
                android.util.Log.d("AdMobSDK", (new StringBuilder()).append("Requesting a fresh ad because a request interval passed (").append(i).append(" seconds).").toString());
        }
        com.admob.android.ads.AdView.i(adview);
_L1:
        return;
        java.lang.Exception exception;
        exception;
        if(com.admob.android.ads.bu.a("AdMobSDK", 6))
        {
            android.util.Log.e("AdMobSDK", (new StringBuilder()).append("exception caught in RefreshHandler.run(), ").append(exception.getMessage()).toString());
            return;
        }
          goto _L1
    }

    boolean a;
    private java.lang.ref.WeakReference b;
}
