// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;


public final class k extends java.lang.Enum
{

    private k(java.lang.String s, int i, java.lang.String s1)
    {
        super(s, i);
        d = s1;
    }

    public static com.admob.android.ads.k a(int i)
    {
        com.admob.android.ads.k k1 = c;
        com.admob.android.ads.k ak[] = com.admob.android.ads.k.values();
        int l = ak.length;
        for(int j = 0; j < l; j++)
        {
            com.admob.android.ads.k k2 = ak[j];
            if(k2.ordinal() == i)
                k1 = k2;
        }

        return k1;
    }

    public static com.admob.android.ads.k valueOf(java.lang.String s)
    {
        return (com.admob.android.ads.k)java.lang.Enum.valueOf(com/admob/android/ads/k, s);
    }

    public static com.admob.android.ads.k[] values()
    {
        return (com.admob.android.ads.k[])e.clone();
    }

    public final java.lang.String toString()
    {
        return d;
    }

    public static final com.admob.android.ads.k a;
    public static final com.admob.android.ads.k b;
    public static final com.admob.android.ads.k c;
    private static final com.admob.android.ads.k e[];
    private java.lang.String d;

    static 
    {
        a = new k("PORTRAIT", 0, "p");
        b = new k("LANDSCAPE", 1, "l");
        c = new k("ANY", 2, "a");
        e = (new com.admob.android.ads.k[] {
            a, b, c
        });
    }
}
