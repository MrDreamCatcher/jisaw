// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.util.Log;
import android.webkit.WebView;
import com.admob.android.ads.a.a;
import java.lang.ref.WeakReference;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.Hashtable;
import java.util.Timer;
import java.util.TimerTask;

// Referenced classes of package com.admob.android.ads:
//            bo, bu, ao, cc, 
//            ab

public final class p extends com.admob.android.ads.bo
{

    public p(com.admob.android.ads.ao ao1, com.admob.android.ads.a.a a1, com.admob.android.ads.ab ab1)
    {
        super(a1);
        c = ab1;
        a = false;
        b = false;
    }

    public final void onPageFinished(android.webkit.WebView webview, java.lang.String s)
    {
        com.admob.android.ads.a.a a1 = (com.admob.android.ads.a.a)d.get();
        if(a1 != null)
            if(s == null || !s.equals(a1.a))
            {
                if(com.admob.android.ads.bu.a("AdMobSDK", 4))
                {
                    android.util.Log.i("AdMobSDK", (new StringBuilder()).append("Unexpected page loaded, urlThatFinished: ").append(s).toString());
                    return;
                }
            } else
            {
                b = true;
                super.onPageFinished(webview, s);
                if(a1 instanceof com.admob.android.ads.ao)
                    ((com.admob.android.ads.ao)a1).b();
                if(com.admob.android.ads.bu.a("AdMobSDK", 3))
                    android.util.Log.d("AdMobSDK", "startResponseTimer()");
                f = new cc(this);
                e = new Timer();
                e.schedule(f, 10000L);
                return;
            }
    }

    public final boolean shouldOverrideUrlLoading(android.webkit.WebView webview, java.lang.String s)
    {
        if(com.admob.android.ads.bu.a("AdMobSDK", 2))
            android.util.Log.v("AdMobSDK", (new StringBuilder()).append("shouldOverrideUrlLoading, url: ").append(s).toString());
        java.lang.Object obj;
        java.lang.String s1;
        obj = new URI(s);
        if(!"admob".equals(((java.net.URI) (obj)).getScheme()))
            break MISSING_BLOCK_LABEL_326;
        s1 = ((java.net.URI) (obj)).getHost();
        if(!"ready".equals(s1))
            break MISSING_BLOCK_LABEL_193;
        if(a)
            return true;
        a = true;
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
            android.util.Log.d("AdMobSDK", "cancelResponseTimer()");
        if(e != null)
            e.cancel();
        obj = ((java.net.URI) (obj)).getQuery();
        if(obj == null)
            break MISSING_BLOCK_LABEL_175;
        obj = com.admob.android.ads.p.a(((java.lang.String) (obj)));
        if(obj == null)
            break MISSING_BLOCK_LABEL_175;
        obj = (java.lang.String)((java.util.Hashtable) (obj)).get("success");
        if(obj == null)
            break MISSING_BLOCK_LABEL_175;
        if("true".equalsIgnoreCase(((java.lang.String) (obj))))
        {
            if(c != null)
                c.a(true);
            break MISSING_BLOCK_LABEL_333;
        }
        try
        {
            if(c != null)
                c.a(false);
            break MISSING_BLOCK_LABEL_335;
        }
        catch(java.net.URISyntaxException urisyntaxexception)
        {
            android.util.Log.w("AdMobSDK", "Bad link URL in AdMob web view.", urisyntaxexception);
        }
        break MISSING_BLOCK_LABEL_326;
        if(!"movie".equals(s1))
            break MISSING_BLOCK_LABEL_326;
        obj = ((java.net.URI) (obj)).getQuery();
        if(obj == null)
            break MISSING_BLOCK_LABEL_314;
        obj = com.admob.android.ads.p.a(((java.lang.String) (obj)));
        if(obj == null)
            break MISSING_BLOCK_LABEL_314;
        obj = (java.lang.String)((java.util.Hashtable) (obj)).get("action");
        if(obj == null)
            break MISSING_BLOCK_LABEL_314;
        if(!"play".equalsIgnoreCase(((java.lang.String) (obj))) && !"pause".equalsIgnoreCase(((java.lang.String) (obj))) && !"stop".equalsIgnoreCase(((java.lang.String) (obj))) && !"remove".equalsIgnoreCase(((java.lang.String) (obj))) && !"replay".equalsIgnoreCase(((java.lang.String) (obj))) && com.admob.android.ads.bu.a("AdMobSDK", 5))
            android.util.Log.w("AdMobSDK", (new StringBuilder()).append("Unknown actionString, admob://movie?action=").append(((java.lang.String) (obj))).toString());
        return true;
        return super.shouldOverrideUrlLoading(webview, s);
        return true;
        return true;
    }

    boolean a;
    boolean b;
    com.admob.android.ads.ab c;
    private java.util.Timer e;
    private java.util.TimerTask f;
}
