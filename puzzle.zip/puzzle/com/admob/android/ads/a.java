// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.util.Log;

// Referenced classes of package com.admob.android.ads:
//            z, bu, ak

final class a
    implements com.admob.android.ads.z
{

    a()
    {
    }

    public final void a(com.admob.android.ads.ak ak1)
    {
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
            android.util.Log.d("AdMobSDK", (new StringBuilder()).append("Click processed at ").append(ak1.e()).toString());
    }

    public final void a(com.admob.android.ads.ak ak1, java.lang.Exception exception)
    {
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
            android.util.Log.d("AdMobSDK", (new StringBuilder()).append("Click processing failed at ").append(ak1.e()).toString(), exception);
    }
}
