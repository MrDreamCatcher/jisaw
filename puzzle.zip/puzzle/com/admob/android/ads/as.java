// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.graphics.Bitmap;
import android.graphics.Point;
import android.os.Bundle;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;
import java.util.Vector;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.admob.android.ads:
//            af, w, k, i, 
//            an, aq, ax, ar

public final class as
    implements com.admob.android.ads.af
{

    public as()
    {
        a = com.admob.android.ads.w.a;
        b = "";
        c = new Vector();
        d = null;
        e = com.admob.android.ads.k.c;
        m = false;
        g = new Point(4, 4);
        f = false;
        n = new Point(0, 0);
        h = null;
        i = null;
        j = null;
        o = null;
        k = new Bundle();
        l = false;
    }

    public static byte a(boolean flag)
    {
        return ((byte)(!flag ? 0 : 1));
    }

    private static android.graphics.Point a(int ai[])
    {
        if(ai == null || ai.length == 2)
            return null;
        else
            return new Point(ai[0], ai[1]);
    }

    public static boolean a(byte byte0)
    {
        return byte0 == 1;
    }

    private static int[] a(android.graphics.Point point)
    {
        if(point == null)
            return null;
        else
            return (new int[] {
                point.x, point.y
            });
    }

    public final android.os.Bundle a()
    {
        android.os.Bundle bundle = new Bundle();
        bundle.putString("a", a.toString());
        bundle.putString("t", b);
        bundle.putParcelableArrayList("c", com.admob.android.ads.i.a(c));
        bundle.putString("u", d);
        bundle.putInt("or", e.ordinal());
        bundle.putByte("tr", com.admob.android.ads.as.a(m));
        bundle.putByte("sc", com.admob.android.ads.as.a(f));
        bundle.putIntArray("cbo", com.admob.android.ads.as.a(g));
        bundle.putIntArray("cs", com.admob.android.ads.as.a(n));
        bundle.putBundle("mi", com.admob.android.ads.i.a(h));
        bundle.putString("su", i);
        bundle.putString("si", j);
        bundle.putString("json", o);
        bundle.putBundle("$", k);
        bundle.putByte("int", com.admob.android.ads.as.a(l));
        return bundle;
    }

    public final void a(java.lang.String s, boolean flag)
    {
        if(s != null && !"".equals(s))
            c.add(new an(s, flag));
    }

    public final void a(org.json.JSONObject jsonobject, com.admob.android.ads.ax ax1, java.lang.String s)
    {
        a = com.admob.android.ads.w.a(jsonobject.optString("a"));
        a(jsonobject.optString("au"), true);
        a(jsonobject.optString("tu"), false);
        java.lang.Object obj = jsonobject.optJSONObject("stats");
        if(obj != null)
        {
            i = ((org.json.JSONObject) (obj)).optString("url");
            j = ((org.json.JSONObject) (obj)).optString("id");
        }
        obj = jsonobject.optString("or");
        boolean flag;
        if(obj != null && !((java.lang.String) (obj)).equals(""))
            if("l".equals(obj))
                e = com.admob.android.ads.k.b;
            else
                e = com.admob.android.ads.k.a;
        if(jsonobject.opt("t") != null)
            flag = true;
        else
            flag = false;
        m = flag;
        b = jsonobject.optString("title");
        if(a == com.admob.android.ads.w.c)
        {
            h = new aq();
            java.lang.Object obj1 = jsonobject.optJSONObject("$");
            if(ax1 != null)
                try
                {
                    ax1.a(((org.json.JSONObject) (obj1)), s);
                }
                catch(org.json.JSONException jsonexception) { }
            h.a = jsonobject.optString("u");
            h.b = jsonobject.optString("title");
            h.c = jsonobject.optInt("mc", 2);
            h.d = jsonobject.optInt("msm", 0);
            h.e = jsonobject.optString("stats");
            h.f = jsonobject.optString("splash");
            h.g = jsonobject.optDouble("splash_duration", 1.5D);
            h.h = jsonobject.optString("skip_down");
            h.i = jsonobject.optString("skip_up");
            h.j = jsonobject.optBoolean("no_splash_skip");
            h.k = jsonobject.optString("replay_down");
            h.l = jsonobject.optString("replay_up");
            obj1 = jsonobject.optJSONArray("buttons");
            if(obj1 != null)
            {
                int j1 = ((org.json.JSONArray) (obj1)).length();
                for(int i1 = 0; i1 < j1; i1++)
                {
                    org.json.JSONObject jsonobject1 = ((org.json.JSONArray) (obj1)).optJSONObject(i1);
                    com.admob.android.ads.ar ar1 = new ar();
                    ar1.a = jsonobject1.optString("$");
                    ar1.b = jsonobject1.optString("h");
                    ar1.c = jsonobject1.optString("x");
                    ar1.e = jsonobject1.optString("analytics_page_name");
                    ar1.d.a(jsonobject1.optJSONObject("o"), ax1, s);
                    ar1.f = jsonobject1.optJSONObject("o").toString();
                    h.m.add(ar1);
                }

            }
        }
        if(jsonobject.optInt("sc", 0) != 0)
            flag = true;
        else
            flag = false;
        f = flag;
        ax1 = jsonobject.optJSONArray("co");
        if(ax1 != null && ax1.length() >= 2)
            g = new Point(ax1.optInt(0), ax1.optInt(1));
        o = jsonobject.toString();
    }

    public final boolean a(android.os.Bundle bundle)
    {
        if(bundle == null)
            return false;
        a = com.admob.android.ads.w.a(bundle.getString("a"));
        b = bundle.getString("t");
        c = new Vector();
        java.lang.Object obj = bundle.getParcelableArrayList("c");
        if(obj != null)
        {
            obj = ((java.util.ArrayList) (obj)).iterator();
            do
            {
                if(!((java.util.Iterator) (obj)).hasNext())
                    break;
                android.os.Bundle bundle1 = (android.os.Bundle)((java.util.Iterator) (obj)).next();
                if(bundle1 != null)
                {
                    com.admob.android.ads.an an1 = new an();
                    an1.a = bundle1.getString("u");
                    an1.b = bundle1.getBoolean("p", false);
                    c.add(an1);
                }
            } while(true);
        }
        d = bundle.getString("u");
        e = com.admob.android.ads.k.a(bundle.getInt("or"));
        m = com.admob.android.ads.as.a(bundle.getByte("tr"));
        f = com.admob.android.ads.as.a(bundle.getByte("sc"));
        g = com.admob.android.ads.as.a(bundle.getIntArray("cbo"));
        if(g == null)
            g = new Point(4, 4);
        n = com.admob.android.ads.as.a(bundle.getIntArray("cs"));
        obj = new aq();
        if(((com.admob.android.ads.aq) (obj)).a(bundle.getBundle("mi")))
            h = ((com.admob.android.ads.aq) (obj));
        else
            h = null;
        i = bundle.getString("su");
        j = bundle.getString("si");
        o = bundle.getString("json");
        k = bundle.getBundle("$");
        l = com.admob.android.ads.as.a(bundle.getByte("int"));
        return true;
    }

    public final java.util.Hashtable b()
    {
        java.lang.Object obj = k.keySet();
        java.util.Hashtable hashtable = new Hashtable();
        obj = ((java.util.Set) (obj)).iterator();
        do
        {
            if(!((java.util.Iterator) (obj)).hasNext())
                break;
            java.lang.String s = (java.lang.String)((java.util.Iterator) (obj)).next();
            android.os.Parcelable parcelable = k.getParcelable(s);
            if(parcelable instanceof android.graphics.Bitmap)
                hashtable.put(s, (android.graphics.Bitmap)parcelable);
        } while(true);
        return hashtable;
    }

    public com.admob.android.ads.w a;
    public java.lang.String b;
    public java.util.Vector c;
    public java.lang.String d;
    public com.admob.android.ads.k e;
    public boolean f;
    public android.graphics.Point g;
    public com.admob.android.ads.aq h;
    public java.lang.String i;
    public java.lang.String j;
    public android.os.Bundle k;
    public boolean l;
    private boolean m;
    private android.graphics.Point n;
    private java.lang.String o;
}
