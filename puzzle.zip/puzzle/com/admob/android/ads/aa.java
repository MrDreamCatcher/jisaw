// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.util.Log;
import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

// Referenced classes of package com.admob.android.ads:
//            al, z, bu

final class aa extends com.admob.android.ads.al
{

    public aa(java.lang.String s, java.lang.String s1, java.lang.String s2, com.admob.android.ads.z z1, int j, java.util.Map map, java.lang.String s3)
    {
        super(s1, s2, z1, j, map, s3);
        try
        {
            n = new URL(s);
            i = n;
        }
        // Misplaced declaration of an exception variable
        catch(java.lang.String s)
        {
            n = null;
            c = s;
        }
        m = null;
        e = 0;
    }

    private void i()
    {
        if(m != null)
        {
            m.disconnect();
            m = null;
        }
    }

    public final boolean a()
    {
        if(n != null) goto _L2; else goto _L1
_L1:
        boolean flag;
        if(h != null)
            h.a(this, new Exception("url was null"));
        flag = false;
_L6:
        if(!flag && h != null)
            h.a(this, c);
        return flag;
_L16:
        int j;
        if(j != 302) goto _L4; else goto _L3
_L3:
        java.lang.String s = m.getHeaderField("Location");
        if(com.admob.android.ads.bu.a("AdMobSDK", 3))
            android.util.Log.d("AdMobSDK", (new StringBuilder()).append("Got redirectUrl: ").append(s).toString());
        n = new URL(s);
        i();
_L14:
        if(e >= f || flag) goto _L6; else goto _L5
_L5:
        if(com.admob.android.ads.bu.a("AdMobSDK", 2))
            android.util.Log.v("AdMobSDK", (new StringBuilder()).append("attempt ").append(e).append(" to connect to url ").append(n).toString());
        i();
        m = (java.net.HttpURLConnection)n.openConnection();
        m.setUseCaches(true);
        m.setInstanceFollowRedirects(true);
        if(m == null) goto _L4; else goto _L7
_L7:
        m.setRequestProperty("User-Agent", com.admob.android.ads.aa.h());
        if(g != null)
            m.setRequestProperty("X-ADMOB-ISU", g);
        m.setConnectTimeout(b);
        m.setReadTimeout(b);
        m.setUseCaches(false);
        if(d == null) goto _L9; else goto _L8
_L8:
        java.lang.Object obj = d.keySet().iterator();
_L12:
        if(!((java.util.Iterator) (obj)).hasNext()) goto _L9; else goto _L10
_L10:
        java.lang.Object obj2 = (java.lang.String)((java.util.Iterator) (obj)).next();
        if(obj2 == null) goto _L12; else goto _L11
_L11:
        java.lang.Object obj3 = (java.lang.String)d.get(obj2);
        if(obj3 == null) goto _L12; else goto _L13
_L13:
        m.addRequestProperty(((java.lang.String) (obj2)), ((java.lang.String) (obj3)));
          goto _L12
        obj3;
        obj = null;
_L18:
        obj2 = obj;
        if(!com.admob.android.ads.bu.a("AdMobSDK", 3))
            break MISSING_BLOCK_LABEL_432;
        obj2 = obj;
        android.util.Log.d("AdMobSDK", (new StringBuilder()).append("connection attempt ").append(e).append(" failed, url ").append(n).toString());
        obj2 = obj;
        if(!com.admob.android.ads.bu.a("AdMobSDK", 2))
            break MISSING_BLOCK_LABEL_454;
        obj2 = obj;
        android.util.Log.v("AdMobSDK", "exception: ", ((java.lang.Throwable) (obj3)));
        obj2 = obj;
        c = ((java.lang.Exception) (obj3));
        java.lang.Object obj1;
        if(obj != null)
            try
            {
                ((java.io.BufferedWriter) (obj)).close();
            }
            // Misplaced declaration of an exception variable
            catch(java.lang.Object obj1) { }
        i();
        flag = false;
        e = e + 1;
          goto _L14
_L9:
        if(l == null)
            break MISSING_BLOCK_LABEL_742;
        m.setRequestMethod("POST");
        m.setDoOutput(true);
        m.setRequestProperty("Content-Type", a);
        m.setRequestProperty("Content-Length", java.lang.Integer.toString(l.length()));
        obj = new BufferedWriter(new OutputStreamWriter(m.getOutputStream()), 4096);
        obj2 = obj;
        ((java.io.BufferedWriter) (obj)).write(l);
        obj2 = obj;
        ((java.io.BufferedWriter) (obj)).close();
_L19:
        j = m.getResponseCode();
        if(!com.admob.android.ads.bu.a("AdMobSDK", 2))
            continue; /* Loop/switch isn't completed */
        obj = m.getHeaderField("X-AdMob-AdSrc");
        if(obj == null)
            continue; /* Loop/switch isn't completed */
        android.util.Log.v("AdMobSDK", (new StringBuilder()).append("Ad response came from server ").append(((java.lang.String) (obj))).toString());
        if(j < 200 || j >= 300) goto _L16; else goto _L15
_L15:
        i = m.getURL();
        if(!k)
            break MISSING_BLOCK_LABEL_760;
        obj = new BufferedInputStream(m.getInputStream(), 4096);
        obj2 = new byte[4096];
        obj3 = new ByteArrayOutputStream(4096);
_L17:
        j = ((java.io.BufferedInputStream) (obj)).read(((byte []) (obj2)));
        if(j == -1)
            break MISSING_BLOCK_LABEL_752;
        ((java.io.ByteArrayOutputStream) (obj3)).write(((byte []) (obj2)), 0, j);
          goto _L17
        obj3;
        obj = null;
          goto _L18
        m.connect();
          goto _L19
        this.j = ((java.io.ByteArrayOutputStream) (obj3)).toByteArray();
        if(h != null)
            h.a(this);
        break MISSING_BLOCK_LABEL_845;
_L4:
        i();
        i();
        break MISSING_BLOCK_LABEL_476;
        obj1;
        obj2 = null;
_L21:
        if(obj2 != null)
            try
            {
                ((java.io.BufferedWriter) (obj2)).close();
            }
            // Misplaced declaration of an exception variable
            catch(java.lang.Object obj2) { }
        i();
        throw obj1;
        obj1;
        continue; /* Loop/switch isn't completed */
        obj1;
        obj2 = null;
        if(true) goto _L21; else goto _L20
_L20:
        obj3;
          goto _L18
_L2:
        flag = false;
          goto _L14
        flag = true;
          goto _L4
    }

    public final void b()
    {
        i();
        h = null;
    }

    public final void run()
    {
        a();
_L1:
        return;
        java.lang.Exception exception;
        exception;
        if(com.admob.android.ads.bu.a("AdMobSDK", 6))
            android.util.Log.e("AdMobSDK", (new StringBuilder()).append("exception caught in AdMobURLConnector.run(), ").append(exception.getMessage()).toString());
        if(h != null)
        {
            h.a(this, c);
            return;
        }
          goto _L1
    }

    private java.net.HttpURLConnection m;
    private java.net.URL n;
}
