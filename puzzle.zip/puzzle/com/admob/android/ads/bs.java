// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;


public final class bs extends java.lang.Enum
{

    private bs(java.lang.String s, int i)
    {
        super(s, i);
    }

    public static com.admob.android.ads.bs valueOf(java.lang.String s)
    {
        return (com.admob.android.ads.bs)java.lang.Enum.valueOf(com/admob/android/ads/bs, s);
    }

    public static com.admob.android.ads.bs[] values()
    {
        return (com.admob.android.ads.bs[])c.clone();
    }

    public static final com.admob.android.ads.bs a;
    public static final com.admob.android.ads.bs b;
    private static final com.admob.android.ads.bs c[];

    static 
    {
        a = new bs("MALE", 0);
        b = new bs("FEMALE", 1);
        c = (new com.admob.android.ads.bs[] {
            a, b
        });
    }
}
