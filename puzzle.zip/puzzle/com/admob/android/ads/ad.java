// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import org.json.JSONObject;

interface ad
{

    public abstract java.lang.String i();

    public abstract org.json.JSONObject j();
}
