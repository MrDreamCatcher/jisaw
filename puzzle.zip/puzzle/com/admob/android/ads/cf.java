// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import java.lang.ref.WeakReference;

// Referenced classes of package com.admob.android.ads:
//            br, by

final class cf
    implements java.lang.Runnable
{

    public cf(com.admob.android.ads.br br1)
    {
        a = new WeakReference(br1);
    }

    public final void run()
    {
        com.admob.android.ads.br br1;
        for(br1 = (com.admob.android.ads.br)a.get(); br1 == null || !br1.e() || br1.g != 2 || br1.k == null;)
            return;

        br1.k.a();
    }

    private java.lang.ref.WeakReference a;
}
