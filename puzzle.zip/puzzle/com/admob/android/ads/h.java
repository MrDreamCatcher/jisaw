// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.util.Log;
import java.lang.ref.WeakReference;

// Referenced classes of package com.admob.android.ads:
//            AdView, ac, ah, bu

final class h extends java.lang.Thread
{

    public h(com.admob.android.ads.AdView adview)
    {
        a = new WeakReference(adview);
    }

    public final void run()
    {
        com.admob.android.ads.AdView adview;
        adview = (com.admob.android.ads.AdView)a.get();
        if(adview == null)
            break MISSING_BLOCK_LABEL_101;
        android.content.Context context = adview.getContext();
        com.admob.android.ads.ac ac1 = new ac(null, context, adview);
        int i = (int)((float)adview.getMeasuredWidth() / com.admob.android.ads.ac.d());
        if(com.admob.android.ads.ah.a(com.admob.android.ads.AdView.c(adview), context, com.admob.android.ads.AdView.d(adview), com.admob.android.ads.AdView.e(adview), adview.a(), adview.b(), adview.c(), ac1, i, adview.d(), null, adview.e()) == null)
            com.admob.android.ads.AdView.f(adview);
        com.admob.android.ads.AdView.a(adview, false);
        com.admob.android.ads.AdView.b(adview, true);
        return;
        java.lang.Object obj;
        obj;
        if(com.admob.android.ads.bu.a("AdMobSDK", 6))
            android.util.Log.e("AdMobSDK", "Unhandled exception requesting a fresh ad.", ((java.lang.Throwable) (obj)));
        com.admob.android.ads.AdView.f(adview);
        com.admob.android.ads.AdView.a(adview, false);
        com.admob.android.ads.AdView.b(adview, true);
        return;
        obj;
        com.admob.android.ads.AdView.a(adview, false);
        com.admob.android.ads.AdView.b(adview, true);
        throw obj;
    }

    private java.lang.ref.WeakReference a;
}
