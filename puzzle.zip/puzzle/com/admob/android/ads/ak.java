// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import java.net.URL;

// Referenced classes of package com.admob.android.ads:
//            z

public interface ak
    extends java.lang.Runnable
{

    public abstract void a(int i);

    public abstract void a(com.admob.android.ads.z z);

    public abstract void a(java.lang.Object obj);

    public abstract void a(java.lang.String s);

    public abstract boolean a();

    public abstract void b();

    public abstract byte[] c();

    public abstract java.lang.String d();

    public abstract java.net.URL e();

    public abstract void f();

    public abstract java.lang.Object g();
}
