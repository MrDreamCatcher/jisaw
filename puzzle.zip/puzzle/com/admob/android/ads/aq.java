// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.os.Bundle;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

// Referenced classes of package com.admob.android.ads:
//            af, as, i, ar

public final class aq
    implements com.admob.android.ads.af
{

    public aq()
    {
        j = false;
        m = new Vector();
    }

    public final android.os.Bundle a()
    {
        android.os.Bundle bundle = new Bundle();
        bundle.putString("u", a);
        bundle.putString("t", b);
        bundle.putInt("c", c);
        bundle.putInt("msm", d);
        bundle.putString("s", e);
        bundle.putString("sin", f);
        bundle.putDouble("sd", g);
        bundle.putString("skd", h);
        bundle.putString("sku", i);
        bundle.putByte("nosk", com.admob.android.ads.as.a(j));
        bundle.putString("rd", k);
        bundle.putString("ru", l);
        bundle.putParcelableArrayList("b", com.admob.android.ads.i.a(m));
        return bundle;
    }

    public final boolean a(android.os.Bundle bundle)
    {
        if(bundle == null)
            return false;
        a = bundle.getString("u");
        b = bundle.getString("t");
        c = bundle.getInt("c");
        d = bundle.getInt("msm");
        e = bundle.getString("s");
        f = bundle.getString("sin");
        g = bundle.getDouble("sd");
        h = bundle.getString("skd");
        i = bundle.getString("sku");
        j = com.admob.android.ads.as.a(bundle.getByte("nosk"));
        k = bundle.getString("rd");
        l = bundle.getString("ru");
        m = null;
        java.lang.Object obj = bundle.getParcelableArrayList("b");
        if(obj != null)
        {
            bundle = new Vector();
            obj = ((java.util.ArrayList) (obj)).iterator();
            do
            {
                if(!((java.util.Iterator) (obj)).hasNext())
                    break;
                android.os.Bundle bundle1 = (android.os.Bundle)((java.util.Iterator) (obj)).next();
                if(bundle1 != null)
                {
                    com.admob.android.ads.ar ar1 = new ar();
                    if(ar1.a(bundle1))
                        bundle.add(ar1);
                }
            } while(true);
            m = bundle;
        }
        return true;
    }

    public final boolean b()
    {
        return c == 0 || m == null || m.size() == 0;
    }

    public final boolean c()
    {
        return f != null && f.length() > 0 && g > 0.0D;
    }

    public java.lang.String a;
    public java.lang.String b;
    public int c;
    public int d;
    public java.lang.String e;
    public java.lang.String f;
    public double g;
    public java.lang.String h;
    public java.lang.String i;
    public boolean j;
    public java.lang.String k;
    public java.lang.String l;
    public java.util.Vector m;
}
