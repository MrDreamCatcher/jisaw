// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.os.Build;
import android.util.Log;
import java.net.URL;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

// Referenced classes of package com.admob.android.ads:
//            ak, bu, z

public abstract class al
    implements com.admob.android.ads.ak
{

    protected al(java.lang.String s, java.lang.String s1, com.admob.android.ads.z z, int i1, java.util.Map map, java.lang.String s2)
    {
        c = null;
        o = s;
        g = s1;
        h = z;
        b = i1;
        d = map;
        k = true;
        e = 0;
        f = 3;
        if(s2 != null)
        {
            l = s2;
            a = "application/x-www-form-urlencoded";
            return;
        } else
        {
            l = null;
            a = null;
            return;
        }
    }

    public static java.lang.String h()
    {
        if(n == null)
        {
            java.lang.StringBuffer stringbuffer = new StringBuffer();
            java.lang.Object obj = android.os.Build.VERSION.RELEASE;
            java.lang.String s;
            if(((java.lang.String) (obj)).length() > 0)
                stringbuffer.append(((java.lang.String) (obj)));
            else
                stringbuffer.append("1.0");
            stringbuffer.append("; ");
            obj = java.util.Locale.getDefault();
            s = ((java.util.Locale) (obj)).getLanguage();
            if(s != null)
            {
                stringbuffer.append(s.toLowerCase());
                obj = ((java.util.Locale) (obj)).getCountry();
                if(obj != null)
                {
                    stringbuffer.append("-");
                    stringbuffer.append(((java.lang.String) (obj)).toLowerCase());
                }
            } else
            {
                stringbuffer.append("en");
            }
            obj = android.os.Build.MODEL;
            if(((java.lang.String) (obj)).length() > 0)
            {
                stringbuffer.append("; ");
                stringbuffer.append(((java.lang.String) (obj)));
            }
            obj = android.os.Build.ID;
            if(((java.lang.String) (obj)).length() > 0)
            {
                stringbuffer.append(" Build/");
                stringbuffer.append(((java.lang.String) (obj)));
            }
            n = java.lang.String.format("Mozilla/5.0 (Linux; U; Android %s) AppleWebKit/525.10+ (KHTML, like Gecko) Version/3.0.4 Mobile Safari/523.12.2 (AdMob-ANDROID-%s)", new java.lang.Object[] {
                stringbuffer, "20101109"
            });
            if(com.admob.android.ads.bu.a("AdMobSDK", 3))
                android.util.Log.d("AdMobSDK", (new StringBuilder()).append("Phone's user-agent is:  ").append(n).toString());
        }
        return n;
    }

    public final void a(int i1)
    {
        f = i1;
    }

    public void a(com.admob.android.ads.z z)
    {
        h = z;
    }

    public final void a(java.lang.Object obj)
    {
        p = obj;
    }

    public final void a(java.lang.String s)
    {
        a = s;
    }

    public final byte[] c()
    {
        return j;
    }

    public final java.lang.String d()
    {
        return o;
    }

    public final java.net.URL e()
    {
        return i;
    }

    public final void f()
    {
        if(m == null)
            m = java.util.concurrent.Executors.newCachedThreadPool();
        m.execute(this);
    }

    public final java.lang.Object g()
    {
        return p;
    }

    private static java.util.concurrent.Executor m = null;
    private static java.lang.String n;
    protected java.lang.String a;
    protected int b;
    protected java.lang.Exception c;
    protected java.util.Map d;
    protected int e;
    protected int f;
    protected java.lang.String g;
    protected com.admob.android.ads.z h;
    protected java.net.URL i;
    protected byte j[];
    protected boolean k;
    protected java.lang.String l;
    private java.lang.String o;
    private java.lang.Object p;

}
