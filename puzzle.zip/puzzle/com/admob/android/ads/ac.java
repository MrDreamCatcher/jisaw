// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import java.util.Collections;
import java.util.Vector;
import org.json.JSONArray;
import org.json.JSONObject;

// Referenced classes of package com.admob.android.ads:
//            ad, cn, u, bu, 
//            ab, ca, AdView, cb, 
//            bz, bx

public final class ac extends android.widget.RelativeLayout
    implements android.view.animation.Animation.AnimationListener, com.admob.android.ads.ad, com.admob.android.ads.cn, com.admob.android.ads.u
{

    public ac(com.admob.android.ads.ab ab1, android.content.Context context, com.admob.android.ads.AdView adview)
    {
        super(context);
        f = -1L;
        b = adview;
        setId(1);
        com.admob.android.ads.ac.b(context);
        e = null;
        a(((com.admob.android.ads.ab) (null)));
    }

    public static float a(android.content.Context context)
    {
        com.admob.android.ads.ac.b(context);
        return i;
    }

    private static java.util.Vector a(int i1, int j1, int k1, long l1, java.util.Vector vector)
    {
        if(vector == null)
            vector = new Vector();
        float f1 = (float)l1 / 1000F;
        java.lang.String s;
        if(j1 != -1 && k1 != -1)
            s = java.lang.String.format("{%d,%d,%d,%f}", new java.lang.Object[] {
                java.lang.Integer.valueOf(i1), java.lang.Integer.valueOf(j1), java.lang.Integer.valueOf(k1), java.lang.Float.valueOf(f1)
            });
        else
            s = java.lang.String.format("{%d,%f}", new java.lang.Object[] {
                java.lang.Integer.valueOf(i1), java.lang.Float.valueOf(f1)
            });
        vector.add(s);
        if(com.admob.android.ads.bu.a("AdMobSDK", 2))
            android.util.Log.v("AdMobSDK", (new StringBuilder()).append("recordEvent:").append(s).toString());
        return vector;
    }

    private java.util.Vector a(android.view.KeyEvent keyevent, java.util.Vector vector)
    {
        int i1 = keyevent.getAction();
        long l1 = keyevent.getEventTime();
        long l2 = f;
        if(i1 == 0 || i1 == 1)
        {
            if(i1 == 1)
                i1 = 1;
            else
                i1 = 0;
            return com.admob.android.ads.ac.a(i1, -1, -1, l1 - l2, vector);
        } else
        {
            return vector;
        }
    }

    private java.util.Vector a(android.view.MotionEvent motionevent, boolean flag, java.util.Vector vector)
    {
        int i1 = motionevent.getAction();
        long l1 = motionevent.getEventTime();
        long l2 = f;
        if(i1 == 0 || i1 == 1)
        {
            if(i1 == 1)
                i1 = 1;
            else
                i1 = 0;
            return com.admob.android.ads.ac.a(i1, (int)motionevent.getX(), (int)motionevent.getY(), l1 - l2, vector);
        } else
        {
            return vector;
        }
    }

    private static void a(android.view.View view, org.json.JSONObject jsonobject)
    {
        if(view instanceof com.admob.android.ads.ad)
        {
            java.lang.Object obj = (com.admob.android.ads.ad)view;
            org.json.JSONObject jsonobject1 = ((com.admob.android.ads.ad) (obj)).j();
            obj = ((com.admob.android.ads.ad) (obj)).i();
            int i1;
            if(jsonobject1 != null && obj != null)
                try
                {
                    jsonobject.put(((java.lang.String) (obj)), jsonobject1);
                }
                catch(java.lang.Exception exception) { }
        }
        if(view instanceof android.view.ViewGroup)
        {
            view = (android.view.ViewGroup)view;
            for(i1 = 0; i1 < view.getChildCount(); i1++)
                com.admob.android.ads.ac.a(view.getChildAt(i1), jsonobject);

        }
    }

    private static void b(android.content.Context context)
    {
        if(i < 0.0F)
            i = context.getResources().getDisplayMetrics().density;
    }

    public static float d()
    {
        return i;
    }

    private boolean k()
    {
        return a == null || !a.l();
    }

    private boolean l()
    {
        return a != null && android.os.SystemClock.uptimeMillis() - f > a.e();
    }

    private void m()
    {
        if(a != null && isPressed())
        {
            setPressed(false);
            if(!g)
            {
                g = true;
                org.json.JSONObject jsonobject = n();
                boolean flag;
                if(h != null)
                    flag = true;
                else
                    flag = false;
                if(flag)
                {
                    android.view.animation.AnimationSet animationset = new AnimationSet(true);
                    float f1 = (float)h.getWidth() / 2.0F;
                    float f2 = (float)h.getHeight() / 2.0F;
                    android.view.animation.ScaleAnimation scaleanimation = new ScaleAnimation(1.0F, 1.2F, 1.0F, 1.2F, f1, f2);
                    scaleanimation.setDuration(200L);
                    animationset.addAnimation(scaleanimation);
                    scaleanimation = new ScaleAnimation(1.2F, 0.001F, 1.2F, 0.001F, f1, f2);
                    scaleanimation.setDuration(299L);
                    scaleanimation.setStartOffset(200L);
                    scaleanimation.setAnimationListener(this);
                    animationset.addAnimation(scaleanimation);
                    postDelayed(new ca(jsonobject, this), 500L);
                    h.startAnimation(animationset);
                } else
                {
                    a.a(jsonobject);
                    if(b != null)
                    {
                        b.performClick();
                        return;
                    }
                }
            }
        }
    }

    private org.json.JSONObject n()
    {
        org.json.JSONObject jsonobject;
        org.json.JSONObject jsonobject1;
        jsonobject = new JSONObject();
        com.admob.android.ads.ac.a(this, jsonobject);
        jsonobject1 = new JSONObject();
        jsonobject1.put("interactions", jsonobject);
        return jsonobject1;
        java.lang.Exception exception;
        exception;
        jsonobject1 = null;
_L2:
        android.util.Log.w("AdMobSDK", "Exception while processing interaction history.", exception);
        return jsonobject1;
        exception;
        if(true) goto _L2; else goto _L1
_L1:
    }

    public final void a()
    {
        post(new cb(this));
    }

    public final void a(android.view.View view, android.widget.RelativeLayout.LayoutParams layoutparams)
    {
        if(view != null && view != h)
        {
            h = view;
            c = new ProgressBar(getContext());
            c.setIndeterminate(true);
            c.setId(2);
            if(layoutparams != null)
                c.setLayoutParams(layoutparams);
            c.setVisibility(4);
            post(new bz(this));
        }
    }

    public final void a(com.admob.android.ads.ab ab1)
    {
        a = ab1;
        if(ab1 == null)
        {
            setFocusable(false);
            setClickable(false);
            return;
        } else
        {
            ab1.a(this);
            setFocusable(true);
            setClickable(true);
            return;
        }
    }

    public final void b()
    {
        android.content.Context context = getContext();
        setBackgroundDrawable(context.getResources().getDrawable(0x1080062));
        android.graphics.drawable.Drawable drawable = context.getResources().getDrawable(0x1080062);
        drawable.setAlpha(128);
        e = new View(context);
        e.setBackgroundDrawable(drawable);
        e.setVisibility(4);
        addView(e, new android.widget.RelativeLayout.LayoutParams(-1, -1));
    }

    public final com.admob.android.ads.ab c()
    {
        return a;
    }

    public final boolean dispatchTouchEvent(android.view.MotionEvent motionevent)
    {
        if(!k()) goto _L2; else goto _L1
_L1:
        int i1;
        i1 = motionevent.getAction();
        if(com.admob.android.ads.bu.a("AdMobSDK", 2))
            android.util.Log.v("AdMobSDK", (new StringBuilder()).append("dispatchTouchEvent: action=").append(i1).append(" x=").append(motionevent.getX()).append(" y=").append(motionevent.getY()).toString());
        if(!l()) goto _L4; else goto _L3
_L3:
        if(a == null) goto _L6; else goto _L5
_L5:
        android.graphics.Rect rect = a.i();
        if(a.a(rect).contains((int)motionevent.getX(), (int)motionevent.getY())) goto _L6; else goto _L7
_L7:
        boolean flag = false;
_L11:
        if(flag)
            d = a(motionevent, true, d);
        if(i1 != 0 && i1 != 2) goto _L9; else goto _L8
_L8:
        setPressed(flag);
_L4:
        return true;
_L9:
        if(i1 == 1)
        {
            if(isPressed() && flag)
                m();
            setPressed(false);
        } else
        if(i1 == 3)
            setPressed(false);
        if(true) goto _L4; else goto _L2
_L2:
        return super.dispatchTouchEvent(motionevent);
_L6:
        flag = true;
        if(true) goto _L11; else goto _L10
_L10:
    }

    public final boolean dispatchTrackballEvent(android.view.MotionEvent motionevent)
    {
        if(!k()) goto _L2; else goto _L1
_L1:
        if(com.admob.android.ads.bu.a("AdMobSDK", 2))
            android.util.Log.v("AdMobSDK", (new StringBuilder()).append("dispatchTrackballEvent: action=").append(motionevent.getAction()).toString());
        if(!l()) goto _L2; else goto _L3
_L3:
        d = a(motionevent, true, d);
        if(motionevent.getAction() != 0) goto _L5; else goto _L4
_L4:
        setPressed(true);
_L2:
        return super.onTrackballEvent(motionevent);
_L5:
        if(motionevent.getAction() == 1)
        {
            if(hasFocus())
                m();
            setPressed(false);
        }
        if(true) goto _L2; else goto _L6
_L6:
    }

    public final void e()
    {
        if(a != null)
        {
            a.j();
            a = null;
        }
    }

    protected final void f()
    {
        g = false;
        if(c != null)
            c.setVisibility(4);
        if(h != null)
            h.setVisibility(0);
    }

    public final void g()
    {
        java.util.Vector vector = new Vector();
        for(int i1 = 0; i1 < getChildCount(); i1++)
            vector.add(getChildAt(i1));

        if(j == null)
            j = new bx();
        java.util.Collections.sort(vector, j);
        for(int j1 = vector.size() - 1; j1 >= 0; j1--)
            if(indexOfChild((android.view.View)vector.elementAt(j1)) != j1)
                bringChildToFront((android.view.View)vector.elementAt(j1));

        if(e != null)
            e.bringToFront();
    }

    public final long h()
    {
        long l1;
label0:
        {
            long l2 = android.os.SystemClock.uptimeMillis() - f;
            if(f >= 0L && l2 >= 0L)
            {
                l1 = l2;
                if(l2 <= 0x989680L)
                    break label0;
            }
            l1 = 0L;
        }
        return l1;
    }

    public final java.lang.String i()
    {
        return "container";
    }

    public final org.json.JSONObject j()
    {
        org.json.JSONObject jsonobject = null;
        if(d != null)
        {
            jsonobject = new JSONObject();
            try
            {
                jsonobject.put("touches", new JSONArray(d));
            }
            catch(java.lang.Exception exception)
            {
                return jsonobject;
            }
        }
        return jsonobject;
    }

    public final void onAnimationEnd(android.view.animation.Animation animation)
    {
    }

    public final void onAnimationRepeat(android.view.animation.Animation animation)
    {
    }

    public final void onAnimationStart(android.view.animation.Animation animation)
    {
    }

    protected final void onDraw(android.graphics.Canvas canvas)
    {
        if(isPressed() || isFocused())
            canvas.clipRect(3, 3, getWidth() - 3, getHeight() - 3);
        super.onDraw(canvas);
        if(f == -1L)
        {
            f = android.os.SystemClock.uptimeMillis();
            if(a != null)
                a.k();
        }
    }

    public final boolean onKeyDown(int i1, android.view.KeyEvent keyevent)
    {
        if(k())
        {
            if(com.admob.android.ads.bu.a("AdMobSDK", 2))
                android.util.Log.v("AdMobSDK", (new StringBuilder()).append("onKeyDown: keyCode=").append(i1).toString());
            if(i1 == 66 || i1 == 23)
            {
                d = a(keyevent, d);
                setPressed(true);
            }
        }
        return super.onKeyDown(i1, keyevent);
    }

    public final boolean onKeyUp(int i1, android.view.KeyEvent keyevent)
    {
        if(k())
        {
            if(com.admob.android.ads.bu.a("AdMobSDK", 2))
                android.util.Log.v("AdMobSDK", (new StringBuilder()).append("onKeyUp: keyCode=").append(i1).toString());
            if(l() && (i1 == 66 || i1 == 23))
            {
                d = a(keyevent, d);
                m();
            }
            setPressed(false);
        }
        return super.onKeyUp(i1, keyevent);
    }

    public final void setPressed(boolean flag)
    {
        while(!k() || g && flag || isPressed() == flag) 
            return;
        if(e != null)
            if(flag)
            {
                e.bringToFront();
                e.setVisibility(0);
            } else
            {
                e.setVisibility(4);
            }
        super.setPressed(flag);
        invalidate();
    }

    private static float i = -1F;
    private static com.admob.android.ads.bx j = null;
    protected com.admob.android.ads.ab a;
    final com.admob.android.ads.AdView b;
    protected android.widget.ProgressBar c;
    private java.util.Vector d;
    private android.view.View e;
    private long f;
    private boolean g;
    private android.view.View h;

}
