// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;


// Referenced classes of package com.admob.android.ads:
//            ab

public interface ae
{

    public abstract void a();

    public abstract void a(com.admob.android.ads.ab ab);
}
