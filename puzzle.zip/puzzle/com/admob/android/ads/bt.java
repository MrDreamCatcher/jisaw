// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.content.Context;
import android.util.Log;
import java.lang.ref.WeakReference;

// Referenced classes of package com.admob.android.ads:
//            n, ah, bu

final class bt extends java.lang.Thread
{

    public final void run()
    {
        java.lang.Object obj;
        obj = (android.content.Context)c.get();
        if(obj == null)
            break MISSING_BLOCK_LABEL_105;
        obj = com.admob.android.ads.ah.a(b.h(), ((android.content.Context) (obj)), b.f(), b.g(), b.e());
        if(a || obj != null)
            break MISSING_BLOCK_LABEL_66;
        b.c();
_L2:
        return;
        java.lang.Object obj1;
        obj1;
        if(com.admob.android.ads.bu.a("AdMobSDK", 6))
            android.util.Log.e("AdMobSDK", "Unhandled exception requesting a fresh ad.", ((java.lang.Throwable) (obj1)));
        if(a) goto _L2; else goto _L1
_L1:
        b.c();
        return;
        obj1;
        throw obj1;
        if(!a)
        {
            b.c();
            return;
        }
          goto _L2
    }

    boolean a;
    private com.admob.android.ads.n b;
    private java.lang.ref.WeakReference c;
}
