// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import java.lang.ref.WeakReference;
import java.util.Timer;

// Referenced classes of package com.admob.android.ads:
//            bw, bu, l, bv, 
//            bt, q, ab

public class n
{

    static void a(com.admob.android.ads.n n1, com.admob.android.ads.ab ab)
    {
        n1.g = ab;
    }

    private static void i()
    {
        if(b != null)
        {
            b.cancel();
            b = null;
        }
    }

    final void a()
    {
        if(a != null)
            a.post(new bw(this));
    }

    final void b()
    {
        com.admob.android.ads.l l1;
        com.admob.android.ads.n.i();
        if(k != -1L && com.admob.android.ads.bu.a("AdMobSDK", 2))
        {
            long l2 = android.os.SystemClock.uptimeMillis();
            long l3 = k;
            android.util.Log.v("AdMobSDK", (new StringBuilder()).append("total request time: ").append(l2 - l3).toString());
        }
        f = true;
        c = null;
        l1 = (com.admob.android.ads.l)e.get();
        if(l1 == null)
            break MISSING_BLOCK_LABEL_92;
        l1.a(this);
        return;
        java.lang.Exception exception;
        exception;
        android.util.Log.w("AdMobSDK", "Unhandled exception raised in your InterstitialAdListener.onReceiveInterstitial.", exception);
        return;
    }

    final void c()
    {
        if(a != null)
            a.post(new bv(this));
    }

    final void d()
    {
        com.admob.android.ads.l l1;
        c = null;
        l1 = (com.admob.android.ads.l)e.get();
        if(l1 == null)
            break MISSING_BLOCK_LABEL_26;
        l1.b(this);
        return;
        java.lang.Exception exception;
        exception;
        android.util.Log.w("AdMobSDK", "Unhandled exception raised in your InterstitialAdListener.onFailedToReceiveInterstitial.", exception);
        return;
    }

    final com.admob.android.ads.q e()
    {
        return d;
    }

    public java.lang.String f()
    {
        return i;
    }

    public java.lang.String g()
    {
        return h;
    }

    final com.admob.android.ads.bu h()
    {
        return j;
    }

    private static android.os.Handler a = null;
    private static java.util.Timer b = null;
    private static com.admob.android.ads.bt c = null;
    private com.admob.android.ads.q d;
    private java.lang.ref.WeakReference e;
    private boolean f;
    private com.admob.android.ads.ab g;
    private java.lang.String h;
    private java.lang.String i;
    private com.admob.android.ads.bu j;
    private long k;

}
