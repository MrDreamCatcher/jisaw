// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.view.View;
import java.lang.ref.WeakReference;

// Referenced classes of package com.admob.android.ads:
//            br, aj

public final class ch
    implements android.view.View.OnClickListener
{

    public ch(com.admob.android.ads.br br1, boolean flag)
    {
        a = new WeakReference(br1);
        b = flag;
    }

    public final void onClick(android.view.View view)
    {
        view = (com.admob.android.ads.br)a.get();
        if(view == null)
            return;
        if(b)
            ((com.admob.android.ads.br) (view)).f.a("skip", null);
        view.c();
    }

    private java.lang.ref.WeakReference a;
    private boolean b;
}
