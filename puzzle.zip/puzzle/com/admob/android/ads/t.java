// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.util.Log;
import java.lang.ref.WeakReference;
import org.json.JSONArray;

// Referenced classes of package com.admob.android.ads:
//            ab, bu

final class t
    implements java.lang.Runnable
{

    public t(com.admob.android.ads.ab ab1, org.json.JSONArray jsonarray)
    {
        a = new WeakReference(ab1);
        b = jsonarray;
    }

    public final void run()
    {
        com.admob.android.ads.ab ab1 = (com.admob.android.ads.ab)a.get();
        if(ab1 == null)
            break MISSING_BLOCK_LABEL_23;
        com.admob.android.ads.ab.a(ab1, b);
_L1:
        return;
        java.lang.Exception exception;
        exception;
        if(com.admob.android.ads.bu.a("AdMobSDK", 6))
        {
            android.util.Log.e("AdMobSDK", (new StringBuilder()).append("exception caught in Ad$ViewAdd.run(), ").append(exception.getMessage()).toString());
            exception.printStackTrace();
        }
        com.admob.android.ads.ab ab2 = (com.admob.android.ads.ab)a.get();
        if(ab2 != null)
        {
            com.admob.android.ads.ab.a(ab2);
            return;
        }
          goto _L1
    }

    private java.lang.ref.WeakReference a;
    private org.json.JSONArray b;
}
