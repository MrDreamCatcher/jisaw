// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.webkit.WebView;
import java.lang.ref.WeakReference;

// Referenced classes of package com.admob.android.ads:
//            bo, ap

public final class o extends com.admob.android.ads.bo
{

    public o(com.admob.android.ads.ap ap1, com.admob.android.ads.ap ap2, java.lang.ref.WeakReference weakreference)
    {
        a = ap1;
        super(ap2, weakreference);
    }

    public final void onPageFinished(android.webkit.WebView webview, java.lang.String s)
    {
        if("http://mm.admob.com/static/android/canvas.html".equals(s) && a.d)
        {
            webview = new StringBuilder();
            webview.append("javascript:cb('");
            webview.append(a.a);
            webview.append("','");
            webview.append(a.c);
            webview.append("')");
            a.d = false;
            a.loadUrl(webview.toString());
        }
    }

    private com.admob.android.ads.ap a;
}
