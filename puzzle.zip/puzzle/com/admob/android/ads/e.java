// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.util.Log;
import java.lang.ref.WeakReference;

// Referenced classes of package com.admob.android.ads:
//            AdView, ac, bu

final class e
    implements java.lang.Runnable
{

    public e(com.admob.android.ads.AdView adview, com.admob.android.ads.ac ac1, int i, boolean flag)
    {
        a = new WeakReference(adview);
        b = new WeakReference(ac1);
        c = i;
        d = flag;
    }

    public final void run()
    {
        java.lang.Object obj;
        com.admob.android.ads.ac ac1;
        obj = (com.admob.android.ads.AdView)a.get();
        ac1 = (com.admob.android.ads.ac)b.get();
        if(obj == null || ac1 == null)
            break MISSING_BLOCK_LABEL_96;
        ((com.admob.android.ads.AdView) (obj)).addView(ac1);
        com.admob.android.ads.AdView.a(((com.admob.android.ads.AdView) (obj)), ac1.c());
        if(c != 0)
            break MISSING_BLOCK_LABEL_90;
        if(d)
        {
            com.admob.android.ads.AdView.a(((com.admob.android.ads.AdView) (obj)), ac1);
            return;
        }
        try
        {
            com.admob.android.ads.AdView.b(((com.admob.android.ads.AdView) (obj)), ac1);
            return;
        }
        // Misplaced declaration of an exception variable
        catch(java.lang.Object obj) { }
        if(com.admob.android.ads.bu.a("AdMobSDK", 6))
        {
            android.util.Log.e("AdMobSDK", "Unhandled exception placing AdContainer into AdView.", ((java.lang.Throwable) (obj)));
            return;
        }
        break MISSING_BLOCK_LABEL_96;
        com.admob.android.ads.AdView.c(((com.admob.android.ads.AdView) (obj)), ac1);
    }

    private java.lang.ref.WeakReference a;
    private java.lang.ref.WeakReference b;
    private int c;
    private boolean d;
}
