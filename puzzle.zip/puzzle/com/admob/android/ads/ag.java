// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;


final class ag extends java.lang.Enum
{

    private ag(java.lang.String s, int i)
    {
        super(s, i);
    }

    public static com.admob.android.ads.ag valueOf(java.lang.String s)
    {
        return (com.admob.android.ads.ag)java.lang.Enum.valueOf(com/admob/android/ads/ag, s);
    }

    public static com.admob.android.ads.ag[] values()
    {
        return (com.admob.android.ads.ag[])f.clone();
    }

    public static final com.admob.android.ads.ag a;
    public static final com.admob.android.ads.ag b;
    public static final com.admob.android.ads.ag c;
    public static final com.admob.android.ads.ag d;
    private static com.admob.android.ads.ag e;
    private static final com.admob.android.ads.ag f[];

    static 
    {
        a = new ag("SPEAKER", 0);
        e = new ag("HEADPHONES", 1);
        b = new ag("VIBRATE", 2);
        c = new ag("EMULATOR", 3);
        d = new ag("OTHER", 4);
        f = (new com.admob.android.ads.ag[] {
            a, e, b, c, d
        });
    }
}
