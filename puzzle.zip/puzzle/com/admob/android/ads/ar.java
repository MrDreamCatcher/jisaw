// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.os.Bundle;

// Referenced classes of package com.admob.android.ads:
//            af, as, i

public final class ar
    implements com.admob.android.ads.af
{

    public ar()
    {
        d = new as();
    }

    public final android.os.Bundle a()
    {
        android.os.Bundle bundle = new Bundle();
        bundle.putString("ad", a);
        bundle.putString("au", b);
        bundle.putString("t", c);
        bundle.putBundle("oi", com.admob.android.ads.i.a(d));
        bundle.putString("ap", e);
        bundle.putString("json", f);
        return bundle;
    }

    public final boolean a(android.os.Bundle bundle)
    {
        if(bundle == null)
            return false;
        a = bundle.getString("ad");
        b = bundle.getString("au");
        c = bundle.getString("t");
        if(!d.a(bundle.getBundle("oi")))
        {
            return false;
        } else
        {
            e = bundle.getString("ap");
            f = bundle.getString("json");
            return true;
        }
    }

    public java.lang.String a;
    public java.lang.String b;
    public java.lang.String c;
    public com.admob.android.ads.as d;
    public java.lang.String e;
    public java.lang.String f;
}
