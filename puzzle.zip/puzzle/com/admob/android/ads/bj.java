// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.view.animation.AlphaAnimation;
import android.view.animation.Transformation;

public final class bj extends android.view.animation.AlphaAnimation
{

    public bj(float f, float f1)
    {
        super(f, f1);
    }

    protected final void applyTransformation(float f, android.view.animation.Transformation transformation)
    {
        if((double)f >= 0.0D || (double)f <= 1.0D)
            super.applyTransformation(f, transformation);
    }
}
