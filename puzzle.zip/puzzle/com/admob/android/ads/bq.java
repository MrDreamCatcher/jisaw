// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.content.Context;
import android.content.res.Resources;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.widget.RelativeLayout;

// Referenced classes of package com.admob.android.ads:
//            as

public abstract class bq extends android.widget.RelativeLayout
{

    public bq(android.content.Context context)
    {
        super(context);
        a = new Handler();
        b = getResources().getDisplayMetrics().density;
    }

    public final void a(com.admob.android.ads.as as)
    {
        c = as;
    }

    protected android.os.Handler a;
    protected float b;
    protected com.admob.android.ads.as c;
}
