// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.view.View;
import java.lang.ref.WeakReference;

// Referenced classes of package com.admob.android.ads:
//            br, aj

public final class cj
    implements android.view.View.OnClickListener
{

    public cj(com.admob.android.ads.br br1)
    {
        a = new WeakReference(br1);
    }

    public final void onClick(android.view.View view)
    {
        view = (com.admob.android.ads.br)a.get();
        if(view == null)
            return;
        ((com.admob.android.ads.br) (view)).f.a("replay", null);
        if(((com.admob.android.ads.br) (view)).d != null)
            com.admob.android.ads.br.b(((com.admob.android.ads.br) (view)).d);
        com.admob.android.ads.br.a(view, false);
        view.h = true;
        com.admob.android.ads.br.a(view, view.getContext());
    }

    private java.lang.ref.WeakReference a;
}
