// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.app.Activity;
import java.lang.ref.WeakReference;

public final class bn
{

    public bn(android.app.Activity activity, java.lang.ref.WeakReference weakreference)
    {
    }
}
