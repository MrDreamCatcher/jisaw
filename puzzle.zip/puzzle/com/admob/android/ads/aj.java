// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.admob.android.ads;

import android.util.Log;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

// Referenced classes of package com.admob.android.ads:
//            z, bu, ak, y, 
//            ay

public final class aj
    implements com.admob.android.ads.z
{

    public aj(java.lang.String s, java.lang.String s1, java.lang.String s2, java.lang.String s3)
    {
        a = s;
        b = s1;
        c = s2;
        d = s3;
        e = null;
        f = new HashSet();
        g = 0;
    }

    private java.lang.String a(java.lang.String s, java.util.Map map, boolean flag)
    {
        java.lang.StringBuilder stringbuilder;
        stringbuilder = new StringBuilder();
        java.lang.String s1;
        try
        {
            stringbuilder.append("rt=1&ex=1");
            stringbuilder.append("&a=").append(a);
            stringbuilder.append("&p=").append(java.net.URLEncoder.encode(s, "UTF-8"));
            stringbuilder.append("&o=").append(d);
            stringbuilder.append("&v=").append("20101109-ANDROID-3312276cc1406347");
            long l = java.lang.System.currentTimeMillis();
            stringbuilder.append("&z").append("=").append(l / 1000L).append(".").append(l % 1000L);
            stringbuilder.append("&h%5BHTTP_HOST%5D=").append(java.net.URLEncoder.encode(c, "UTF-8"));
            stringbuilder.append("&h%5BHTTP_REFERER%5D=http%3A%2F%2F").append(b);
        }
        // Misplaced declaration of an exception variable
        catch(java.lang.String s)
        {
            return null;
        }
        if(!flag)
            break MISSING_BLOCK_LABEL_165;
        stringbuilder.append("&startvisit=1");
        if(map == null)
            break MISSING_BLOCK_LABEL_248;
        s = map.keySet();
        if(s == null)
            break MISSING_BLOCK_LABEL_248;
        for(s = s.iterator(); s.hasNext(); stringbuilder.append("&").append(s1).append("=").append(java.net.URLEncoder.encode((java.lang.String)map.get(s1))))
            s1 = (java.lang.String)s.next();

        return stringbuilder.toString();
    }

    private void b(com.admob.android.ads.ak ak1)
    {
        f.remove(ak1);
    }

    public final void a(com.admob.android.ads.ak ak1)
    {
        if(com.admob.android.ads.bu.a("AdMobSDK", 2))
        {
            android.util.Log.v("AdMobSDK", (new StringBuilder()).append("Analytics event ").append(ak1.d()).append(" has been recorded.").toString());
            int i = f.size();
            if(i > 0)
                android.util.Log.v("AdMobSDK", (new StringBuilder()).append("Pending Analytics requests: ").append(i).toString());
        }
        b(ak1);
    }

    public final void a(com.admob.android.ads.ak ak1, java.lang.Exception exception)
    {
        if(com.admob.android.ads.bu.a("AdMobSDK", 5))
            android.util.Log.w("AdMobSDK", (new StringBuilder()).append("analytics request failed for ").append(ak1.d()).toString(), exception);
        b(ak1);
    }

    public final void a(java.lang.String s, java.util.Map map)
    {
_L2:
        return;
        if(c == null || s == null) goto _L2; else goto _L1
_L1:
        g = g + 1;
        boolean flag;
        if(g == 1)
            flag = true;
        else
            flag = false;
        map = a(s, map, flag);
        if(map == null)
            continue; /* Loop/switch isn't completed */
        if(f != null)
        {
            com.admob.android.ads.ak ak1 = com.admob.android.ads.y.a("http://r.admob.com/ad_source.php", "AnalyticsData", d, this, 5000, null, map);
            f.add(ak1);
            ak1.f();
        }
        if(!com.admob.android.ads.bu.a("AdMobSDK", 3)) goto _L2; else goto _L3
_L3:
        android.util.Log.d("AdMobSDK", (new StringBuilder()).append("Analytics event ").append(c).append("/").append(s).append(" data:").append(map).append(" has been recorded.").toString());
        return;
        if(!com.admob.android.ads.bu.a("AdMobSDK", 6)) goto _L2; else goto _L4
_L4:
        android.util.Log.e("AdMobSDK", "Could not create analytics URL.  Analytics data not tracked.");
        return;
    }

    private final java.lang.String a;
    private final java.lang.String b;
    private final java.lang.String c;
    private java.lang.String d;
    private com.admob.android.ads.ay e;
    private java.util.HashSet f;
    private int g;
}
