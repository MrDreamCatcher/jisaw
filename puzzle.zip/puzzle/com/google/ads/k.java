// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;

import android.content.Context;
import java.util.List;

public interface k
{

    public abstract java.util.List a(android.content.Context context);

    public abstract boolean a();

    public abstract int b();

    public abstract int c();

    public abstract java.lang.String d();
}
