// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;

import java.util.Map;

// Referenced classes of package com.google.ads:
//            r, GoogleAdView

class ac
    implements com.google.ads.r
{

    ac()
    {
    }

    private static boolean a(int i, int j, int k, int l)
    {
        return (i > 0 || j > 0 || k > 0 || l > 0) && i >= 0 && j >= 0 && k >= 0 && l >= 0;
    }

    public void a(java.util.Map map, com.google.ads.GoogleAdView googleadview)
    {
        java.lang.String s;
        java.lang.String s1;
        java.lang.String s2;
        java.lang.String s3;
        java.lang.String s4;
        s = (java.lang.String)map.get("width");
        s1 = (java.lang.String)map.get("height");
        s2 = (java.lang.String)map.get("left");
        s3 = (java.lang.String)map.get("right");
        s4 = (java.lang.String)map.get("top");
        map = (java.lang.String)map.get("bottom");
        if(s == null) goto _L2; else goto _L1
_L1:
        int i;
        int j;
        int k;
        int l;
        int i1;
        int j1;
        try
        {
            i = java.lang.Integer.parseInt(s);
        }
        // Misplaced declaration of an exception variable
        catch(java.util.Map map)
        {
            return;
        }
        if(s == null) goto _L4; else goto _L3
_L3:
        j = java.lang.Integer.parseInt(s1);
_L24:
        if(s2 == null) goto _L6; else goto _L5
_L5:
        k = java.lang.Integer.parseInt(s2);
_L15:
        if(s3 == null) goto _L8; else goto _L7
_L7:
        l = java.lang.Integer.parseInt(s3);
_L16:
        if(s4 == null) goto _L10; else goto _L9
_L9:
        i1 = java.lang.Integer.parseInt(s4);
_L17:
        if(map == null) goto _L12; else goto _L11
_L11:
        j1 = java.lang.Integer.parseInt(map);
_L18:
        if(i == googleadview.e() && j == googleadview.f()) goto _L14; else goto _L13
_L13:
        if(googleadview.d())
            googleadview.b();
        googleadview.a(i, j);
_L20:
        return;
_L2:
        i = googleadview.e();
        continue; /* Loop/switch isn't completed */
_L4:
        j = googleadview.f();
        continue; /* Loop/switch isn't completed */
_L6:
        k = 0;
          goto _L15
_L8:
        l = 0;
          goto _L16
_L10:
        i1 = 0;
          goto _L17
_L12:
        j1 = 0;
          goto _L18
_L14:
        if(googleadview.d() && k == 0 && l == 0 && i1 == 0 && j1 == 0)
        {
            googleadview.a();
            return;
        }
        if(googleadview.d() || !com.google.ads.ac.a(i1, j1, k, l)) goto _L20; else goto _L19
_L19:
        googleadview.a(i1, j1, k, l);
        return;
        if(true) goto _L22; else goto _L21
_L22:
        break MISSING_BLOCK_LABEL_86;
_L21:
        if(true) goto _L24; else goto _L23
_L23:
    }
}
