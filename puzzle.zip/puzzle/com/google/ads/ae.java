// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;


public final class ae extends java.lang.Enum
{

    private ae(java.lang.String s, int i, java.lang.String s1)
    {
        super(s, i);
        c = s1;
    }

    public static com.google.ads.ae valueOf(java.lang.String s)
    {
        return (com.google.ads.ae)java.lang.Enum.valueOf(com/google/ads/ae, s);
    }

    public static com.google.ads.ae[] values()
    {
        return (com.google.ads.ae[])d.clone();
    }

    java.lang.String a()
    {
        return c;
    }

    public static final com.google.ads.ae a;
    public static final com.google.ads.ae b;
    private static final com.google.ads.ae d[];
    private java.lang.String c;

    static 
    {
        a = new ae("TOP", 0, "t");
        b = new ae("BOTTOM", 1, "b");
        d = (new com.google.ads.ae[] {
            a, b
        });
    }
}
