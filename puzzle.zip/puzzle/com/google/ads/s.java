// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;


public final class s extends java.lang.Enum
{

    private s(java.lang.String s1, int i, java.lang.String s2)
    {
        super(s1, i);
        c = s2;
    }

    public static com.google.ads.s valueOf(java.lang.String s1)
    {
        return (com.google.ads.s)java.lang.Enum.valueOf(com/google/ads/s, s1);
    }

    public static com.google.ads.s[] values()
    {
        return (com.google.ads.s[])d.clone();
    }

    public java.lang.String a()
    {
        return c;
    }

    public static final com.google.ads.s a;
    public static final com.google.ads.s b;
    private static final com.google.ads.s d[];
    private java.lang.String c;

    static 
    {
        a = new s("JS_OUTSIDE_CLICK_MESSAGE", 0, "click_outside_ad");
        b = new s("JS_REPORT_INSTALL_STATE", 1, "report_application_installation_state");
        d = (new com.google.ads.s[] {
            a, b
        });
    }
}
