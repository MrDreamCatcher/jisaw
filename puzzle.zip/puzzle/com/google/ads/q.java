// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;


public final class q extends java.lang.Enum
{

    private q(java.lang.String s, int i, java.lang.String s1, int j, int k)
    {
        super(s, i);
        c = s1;
        d = j;
        e = k;
    }

    public static com.google.ads.q valueOf(java.lang.String s)
    {
        return (com.google.ads.q)java.lang.Enum.valueOf(com/google/ads/q, s);
    }

    public static com.google.ads.q[] values()
    {
        return (com.google.ads.q[])f.clone();
    }

    public java.lang.String a()
    {
        return c;
    }

    public int b()
    {
        return d;
    }

    public int c()
    {
        return e;
    }

    public static final com.google.ads.q a;
    public static final com.google.ads.q b;
    private static final com.google.ads.q f[];
    private java.lang.String c;
    private int d;
    private int e;

    static 
    {
        a = new q("FORMAT_320x50", 0, "320x50_mb", 320, 50);
        b = new q("FORMAT_300x250", 1, "300x250_as", 300, 250);
        f = (new com.google.ads.q[] {
            a, b
        });
    }
}
