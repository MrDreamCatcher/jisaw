// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;

import android.content.Context;
import android.content.SharedPreferences;

// Referenced classes of package com.google.ads:
//            aa, h

class d
{

    private d(com.google.ads.aa aa, android.content.Context context)
    {
        a = aa;
        super();
        b = -1;
        c = -1;
        d = null;
        e = context.getSharedPreferences("google_ads.xml", 0);
    }

    d(com.google.ads.aa aa, android.content.Context context, com.google.ads.h h)
    {
        this(aa, context);
    }

    static int a(com.google.ads.d d1, int i)
    {
        d1.b = i;
        return i;
    }

    static java.lang.String a(com.google.ads.d d1, java.lang.String s)
    {
        d1.d = s;
        return s;
    }

    private void a()
    {
        if(e == null)
        {
            return;
        } else
        {
            android.content.SharedPreferences.Editor editor = e.edit();
            editor.putInt("fetch_latency", b);
            editor.putInt("click_latency", c);
            editor.putString("click_string", d);
            editor.commit();
            return;
        }
    }

    static void a(com.google.ads.d d1)
    {
        d1.b();
    }

    static int b(com.google.ads.d d1, int i)
    {
        d1.c = i;
        return i;
    }

    private void b()
    {
        if(e == null)
        {
            return;
        } else
        {
            b = e.getInt("fetch_latency", -1);
            c = e.getInt("click_latency", -1);
            d = e.getString("click_string", null);
            return;
        }
    }

    static void b(com.google.ads.d d1)
    {
        d1.a();
    }

    static int c(com.google.ads.d d1)
    {
        return d1.b;
    }

    private void c()
    {
        b = -1;
        c = -1;
        d = null;
        a();
    }

    static int d(com.google.ads.d d1)
    {
        return d1.c;
    }

    static java.lang.String e(com.google.ads.d d1)
    {
        return d1.d;
    }

    static void f(com.google.ads.d d1)
    {
        d1.c();
    }

    final com.google.ads.aa a;
    private int b;
    private int c;
    private java.lang.String d;
    private android.content.SharedPreferences e;
}
