// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;

import android.net.Uri;
import android.util.Log;
import com.google.ads.a.a;
import java.lang.reflect.Method;

public class x
{

    public x()
    {
    }

    public static android.net.Uri a(android.net.Uri uri)
    {
        byte abyte0[];
        android.net.Uri uri1;
        java.lang.String s;
        boolean flag;
        try
        {
            flag = "0123456789".equals("clN0m0M8Y-Xd--5Nwb_SW8ikMhprD3Nf26rNvNhHiN1a5yWy2NrVNqzwQbr6Zl3fjVV_Q0nAj5AWkFB8w_YrMxEmukRnhMMkdCv2zFuv5iVmYckId3Lj4fHvIGd7aUhnqLgHpqasOG37Ugto01AnU9W2iE-ufHaIRCW2YZ83e8wTTtjou2jb2c5I3qFPryGkOar2X4MNFD-bPJydipl0uAgnHmPDxVsNmezfXNOUpiiSRi1Axrcz45dC-DljxiEpZOCvHWiVUU3g-nYtI9MTB0n3oOax_12yz0p5MVbzpQqOood2eiU_0OvePmBy3HbH0Q1BTRxjZwZFMPLMQcuMRg");
        }
        // Misplaced declaration of an exception variable
        catch(android.net.Uri uri)
        {
            throw uri;
        }
        if(flag)
            return uri;
        try
        {
            abyte0 = com.google.ads.a.a.a("clN0m0M8Y-Xd--5Nwb_SW8ikMhprD3Nf26rNvNhHiN1a5yWy2NrVNqzwQbr6Zl3fjVV_Q0nAj5AWkFB8w_YrMxEmukRnhMMkdCv2zFuv5iVmYckId3Lj4fHvIGd7aUhnqLgHpqasOG37Ugto01AnU9W2iE-ufHaIRCW2YZ83e8wTTtjou2jb2c5I3qFPryGkOar2X4MNFD-bPJydipl0uAgnHmPDxVsNmezfXNOUpiiSRi1Axrcz45dC-DljxiEpZOCvHWiVUU3g-nYtI9MTB0n3oOax_12yz0p5MVbzpQqOood2eiU_0OvePmBy3HbH0Q1BTRxjZwZFMPLMQcuMRg", 11);
            s = com.google.ads.x.b(uri);
        }
        catch(java.lang.IllegalArgumentException illegalargumentexception)
        {
            if((byte)0x6d0e0f12 % 9 != 0)
            {
                throw null;
            } else
            {
                android.util.Log.e("AFMAUtil", (new StringBuilder()).append("Util failed: ").append(illegalargumentexception).toString());
                return uri;
            }
        }
        if(s == null)
            break MISSING_BLOCK_LABEL_59;
        if(com.google.ads.x.a())
            break MISSING_BLOCK_LABEL_59;
        uri1 = com.google.ads.x.a(uri, com.google.ads.a.a.b(com.google.ads.x.a(abyte0, s.getBytes()), 11), "ms");
        return uri1;
        return uri;
    }

    static android.net.Uri a(android.net.Uri uri, java.lang.String s, java.lang.String s1)
    {
label0:
        {
            if(uri != null && s != null)
            {
                int i = s.length();
                if((byte)0x4a63eeaf % 9 != 0)
                    throw null;
                if(i != 0 && s1 != null && s1.length() != 0)
                    break label0;
            }
            throw new IllegalArgumentException("Malformed input (5)");
        }
        return uri.buildUpon().appendQueryParameter(s1, s).build();
    }

    static boolean a()
    {
        byte byte0 = 0;
_L2:
        if(byte0 != 0)
            break MISSING_BLOCK_LABEL_55;
        byte0 = 2;
        boolean flag;
        java.lang.reflect.Method method = java.lang.Class.forName("android.os.SystemProperties").getDeclaredMethod("get", new java.lang.Class[] {
            java/lang/String
        });
        method.setAccessible(true);
        flag = "1".equals(method.invoke(null, new java.lang.Object[] {
            "ro.kernel.qemu"
        }));
        return flag;
        return false;
        java.lang.Exception exception;
        exception;
        if(true) goto _L2; else goto _L1
_L1:
    }

    static byte[] a(byte abyte0[], byte abyte1[])
    {
label0:
        {
            if(abyte0 != null)
            {
                byte abyte2[];
                int i;
                try
                {
                    i = abyte0.length;
                }
                // Misplaced declaration of an exception variable
                catch(byte abyte0[])
                {
                    throw abyte0;
                }
                if(i != 0 && abyte1 != null)
                {
                    i = abyte1.length;
                    if((byte)0x3ae3a02d % 9 != 0)
                        throw null;
                    if(i != 0)
                        break label0;
                }
            }
            throw new IllegalArgumentException("Malformed input (4)");
        }
        i = java.lang.Math.min(32, abyte1.length);
        abyte2 = new byte[i];
        java.lang.System.arraycopy(abyte1, 0, abyte2, 0, i);
        return com.google.ads.x.b(abyte0, abyte2);
    }

    static java.lang.String b(android.net.Uri uri)
    {
        if(uri == null)
            throw new IllegalArgumentException("Malformed input (2)");
        try
        {
            uri = uri.getQueryParameter("ai");
        }
        // Misplaced declaration of an exception variable
        catch(android.net.Uri uri)
        {
            if((byte)0x5e5642f7 % 3 != 0)
                throw null;
            uri = new IllegalArgumentException("Malformed input (3)");
            try
            {
                throw uri;
            }
            // Misplaced declaration of an exception variable
            catch(android.net.Uri uri)
            {
                throw uri;
            }
        }
        return uri;
    }

    static byte[] b(byte abyte0[], byte abyte1[])
    {
        if(abyte0 == null) goto _L2; else goto _L1
_L1:
        byte abyte2[];
        int i;
        try
        {
            i = abyte0.length;
        }
        // Misplaced declaration of an exception variable
        catch(byte abyte0[])
        {
            throw abyte0;
        }
        if(i != 0) goto _L3; else goto _L2
_L2:
        throw new IllegalArgumentException("Malformed input (6)");
_L5:
        abyte1 = new byte[abyte0.length];
        int k1 = 0;
        int j = 0;
        int i1 = 0;
        for(; j < abyte0.length; j++)
        {
            k1 = k1 + 1 & 0xff;
            i1 = i1 + (abyte2[k1] & 0xff) & 0xff;
            byte byte0 = abyte2[k1];
            abyte2[k1] = abyte2[i1];
            abyte2[i1] = byte0;
            byte byte2 = abyte2[k1];
            if((byte)0x5a6357c1 % 9 != 0)
                throw null;
            byte byte3 = abyte2[i1];
            byte byte4 = abyte0[j];
            abyte1[j] = (byte)(abyte2[(byte2 & 0xff) + (byte3 & 0xff) & 0xff] ^ byte4);
        }

        break; /* Loop/switch isn't completed */
_L3:
        if(abyte1 == null || abyte1.length == 0 || abyte1.length > 256)
            throw new IllegalArgumentException("Malformed input (7)");
        abyte2 = new byte[256];
        for(int k = 0; k < 256; k++)
            abyte2[k] = (byte)k;

        int j1 = 0;
        int l = 0;
        while(l < 256) 
        {
            j1 = j1 + ((abyte1[l % abyte1.length] & 0xff) + (abyte2[l] & 0xff)) & 0xff;
            byte byte1 = abyte2[l];
            abyte2[l] = abyte2[j1];
            abyte2[j1] = byte1;
            l++;
        }
        if(true) goto _L5; else goto _L4
_L4:
        return abyte1;
    }
}
