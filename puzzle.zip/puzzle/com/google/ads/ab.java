// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;


public class ab
{

    public ab(java.lang.String s, java.lang.String s1)
    {
        if(s == null)
            throw new NullPointerException("Parameter name cannot be null.");
        if(s1 == null)
        {
            throw new NullPointerException("Parameter value cannot be null.");
        } else
        {
            a = s;
            b = s1;
            return;
        }
    }

    public java.lang.String a()
    {
        return a;
    }

    public java.lang.String b()
    {
        return b;
    }

    public boolean equals(java.lang.Object obj)
    {
        if(this == obj)
            return true;
        if(!(obj instanceof com.google.ads.ab))
            return false;
        obj = (com.google.ads.ab)obj;
        return a.equals(((com.google.ads.ab) (obj)).a) && b.equals(((com.google.ads.ab) (obj)).b);
    }

    public int hashCode()
    {
        return a.hashCode() * 4999 + b.hashCode();
    }

    public java.lang.String toString()
    {
        return (new StringBuilder()).append("Parameter(").append(a).append(",").append(b).append(")").toString();
    }

    private final java.lang.String a;
    private final java.lang.String b;
}
