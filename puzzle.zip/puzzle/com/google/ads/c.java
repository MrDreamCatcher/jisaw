// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

// Referenced classes of package com.google.ads:
//            k, q, ab, w, 
//            ae

public class c
    implements com.google.ads.k
{

    public c(java.lang.String s)
    {
        a(s, "ClientId");
        a = s;
        b = true;
        n = com.google.ads.q.a;
    }

    private void a(java.lang.String s, java.lang.String s1)
    {
        if(s == null)
            throw new NullPointerException((new StringBuilder()).append(s1).append(" cannot be null.").toString());
        if(s.length() <= 0)
            throw new IllegalArgumentException((new StringBuilder()).append(s1).append(" cannot be empty.").toString());
        else
            return;
    }

    private java.lang.String b(android.content.Context context)
    {
        java.lang.String s = context.getPackageName();
        try
        {
            int i1 = context.getPackageManager().getPackageInfo(s, 0).versionCode;
            context = (new StringBuilder()).append(i1).append(".android.").append(s).toString();
        }
        // Misplaced declaration of an exception variable
        catch(android.content.Context context)
        {
            return (new StringBuilder()).append(".android.").append(s).toString();
        }
        return context;
    }

    private void b(java.lang.String s, java.lang.String s1)
    {
        if(s != null && s.length() <= 0)
            throw new IllegalArgumentException((new StringBuilder()).append(s1).append(" cannot be empty.").toString());
        else
            return;
    }

    public com.google.ads.c a(com.google.ads.w w1)
    {
        c = w1;
        return this;
    }

    public com.google.ads.c a(java.lang.String s)
    {
        a(s, "AppName");
        f = s;
        return this;
    }

    public com.google.ads.c a(boolean flag)
    {
        b = flag;
        return this;
    }

    public java.util.List a(android.content.Context context)
    {
        if(f == null)
            throw new IllegalStateException("AppName must be set before calling generateParameters().");
        if(m == null)
            throw new IllegalStateException("CompanyName must be set before calling generateParameters().");
        java.util.ArrayList arraylist = new ArrayList();
        arraylist.add(new ab("client", a));
        arraylist.add(new ab("app_name", b(context)));
        arraylist.add(new ab("msid", context.getPackageName()));
        arraylist.add(new ab("js", "afma-sdk-a-v3.1"));
        arraylist.add(new ab("platform", "Android"));
        arraylist.add(new ab("an", f));
        arraylist.add(new ab("cn", m));
        arraylist.add(new ab("hl", java.util.Locale.getDefault().getLanguage().trim().toLowerCase()));
        if(!b)
            arraylist.add(new ab("adtest", "off"));
        if(c != null)
            arraylist.add(new ab("ad_type", com.google.ads.w.a(c)));
        if(d != null)
            arraylist.add(new ab("alternate_ad_url", d));
        if(e != null)
            arraylist.add(new ab("alt_color", e));
        if(g != null)
            arraylist.add(new ab("channel", g));
        if(h != null)
            arraylist.add(new ab("color_bg", h));
        if(i != null)
            arraylist.add(new ab("color_border", i));
        if(j != null)
            arraylist.add(new ab("color_link", j));
        if(k != null)
            arraylist.add(new ab("color_text", k));
        if(l != null)
            arraylist.add(new ab("color_url", l));
        if(n != null)
            arraylist.add(new ab("format", n.a()));
        if(o != null)
            arraylist.add(new ab("kw", o));
        if(p != null)
            arraylist.add(new ab("q", p));
        if(q != null)
            arraylist.add(new ab("url", q));
        if(r != null)
            arraylist.add(new ab("xdir", r.a()));
        return arraylist;
    }

    public boolean a()
    {
        return b;
    }

    public int b()
    {
        return e().b();
    }

    public com.google.ads.c b(java.lang.String s)
    {
        b(s, "Channel");
        g = s;
        return this;
    }

    public int c()
    {
        return e().c();
    }

    public com.google.ads.c c(java.lang.String s)
    {
        a(s, "CompanyName");
        m = s;
        return this;
    }

    public com.google.ads.c d(java.lang.String s)
    {
        b(s, "Keywords");
        o = s;
        return this;
    }

    public java.lang.String d()
    {
        if(p == null || p.length() == 0)
            return "http://pagead2.googlesyndication.com/pagead/afma_load_ads.js";
        else
            return "http://www.gstatic.com/mobile/ads/safma_load_ads.js";
    }

    public com.google.ads.q e()
    {
        if(n == null)
            return com.google.ads.q.a;
        else
            return n;
    }

    private java.lang.String a;
    private boolean b;
    private com.google.ads.w c;
    private java.lang.String d;
    private java.lang.String e;
    private java.lang.String f;
    private java.lang.String g;
    private java.lang.String h;
    private java.lang.String i;
    private java.lang.String j;
    private java.lang.String k;
    private java.lang.String l;
    private java.lang.String m;
    private com.google.ads.q n;
    private java.lang.String o;
    private java.lang.String p;
    private java.lang.String q;
    private com.google.ads.ae r;
}
