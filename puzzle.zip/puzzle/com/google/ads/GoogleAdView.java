// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ViewSwitcher;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.List;

// Referenced classes of package com.google.ads:
//            y, j, g, i, 
//            z, m, aa, p, 
//            t, u, ac, l, 
//            k, ab, af, ad, 
//            v

public class GoogleAdView extends android.widget.ViewSwitcher
{

    public GoogleAdView(android.content.Context context)
    {
        super(context);
        a(context, new WebView(context), 320, 50);
    }

    public GoogleAdView(android.content.Context context, android.util.AttributeSet attributeset)
    {
        super(context, attributeset);
        a(context, new WebView(context), 320, 50);
    }

    static com.google.ads.aa a(com.google.ads.GoogleAdView googleadview)
    {
        return googleadview.l;
    }

    private void a(android.content.Context context, android.webkit.WebView webview, int i1, int j1)
    {
        i = new y(context.getPackageManager());
        android.widget.ProgressBar progressbar = new ProgressBar(context, null, 0x1010079);
        progressbar.setIndeterminate(true);
        n = new LinearLayout(context);
        n.setGravity(17);
        n.addView(progressbar);
        addView(n, com.google.ads.j.b(context, i1), com.google.ads.j.b(context, j1));
        h = new g(this);
        h();
        d = webview;
        g = new i(this);
        d.setBackgroundColor(0);
        d.setWebViewClient(g);
        d.setInitialScale(com.google.ads.j.b(context, 100));
        e = new FrameLayout(context);
        e.setBackgroundColor(0);
        e.setBackgroundDrawable(null);
        e.addView(d);
        addView(e, com.google.ads.j.b(context, i1), com.google.ads.j.b(context, j1));
        f = new z(context, this, webview);
        r = new m(this, context);
        d.setVerticalScrollBarEnabled(false);
        d.setHorizontalScrollBarEnabled(false);
        webview = d.getLayoutParams();
        webview.width = -1;
        webview.height = -1;
        webview = d.getSettings();
        webview.setJavaScriptEnabled(true);
        webview.setPluginsEnabled(true);
        webview.setSupportZoom(false);
        webview.setCacheMode(0);
        l = new aa(context);
        m = new p(context);
        o = false;
        setOutAnimation(context, 0x10a0001);
        setInAnimation(context, 0x10a0000);
        j = false;
        s = -1;
        u = new t(this, null);
    }

    static void a(com.google.ads.GoogleAdView googleadview, com.google.ads.k k1, boolean flag)
    {
        googleadview.b(k1, flag);
    }

    static boolean a(com.google.ads.GoogleAdView googleadview, boolean flag)
    {
        googleadview.o = flag;
        return flag;
    }

    static com.google.ads.v b(com.google.ads.GoogleAdView googleadview)
    {
        return googleadview.c;
    }

    private void b(com.google.ads.k k1, boolean flag)
    {
        a(k1, flag, hasWindowFocus());
    }

    static com.google.ads.g c(com.google.ads.GoogleAdView googleadview)
    {
        return googleadview.h;
    }

    static android.webkit.WebView d(com.google.ads.GoogleAdView googleadview)
    {
        return googleadview.d;
    }

    static boolean e(com.google.ads.GoogleAdView googleadview)
    {
        return googleadview.o;
    }

    static com.google.ads.z f(com.google.ads.GoogleAdView googleadview)
    {
        return googleadview.f;
    }

    static com.google.ads.k g(com.google.ads.GoogleAdView googleadview)
    {
        return googleadview.t;
    }

    static java.lang.String[] g()
    {
        return b;
    }

    static int h(com.google.ads.GoogleAdView googleadview)
    {
        return googleadview.s;
    }

    private void h()
    {
        h.a("/loadAdURL", new u());
        h.a("/resize", new ac());
        h.a("/requestApplications", new l(i, h));
    }

    private void i()
    {
        removeCallbacks(u);
        if(t != null && s > 0 && hasWindowFocus())
            postDelayed(u, s * 1000);
    }

    private android.graphics.drawable.Drawable j()
    {
        if(k != null)
            break MISSING_BLOCK_LABEL_111;
        android.graphics.Bitmap bitmap = android.graphics.BitmapFactory.decodeStream(getContext().getAssets().open("test_ad.png"));
        try
        {
            android/graphics/Bitmap.getMethod("setDensity", new java.lang.Class[] {
                java.lang.Integer.TYPE
            }).invoke(bitmap, new java.lang.Object[] {
                java.lang.Integer.valueOf(160)
            });
            k = (android.graphics.drawable.Drawable)android/graphics/drawable/BitmapDrawable.getConstructor(new java.lang.Class[] {
                android/content/res/Resources, android/graphics/Bitmap
            }).newInstance(new java.lang.Object[] {
                getContext().getResources(), bitmap
            });
        }
        catch(java.lang.Exception exception)
        {
            try
            {
                k = new BitmapDrawable(bitmap);
            }
            catch(java.io.IOException ioexception)
            {
                android.util.Log.e("GoogleAdView", "Error loading debug watermark", ioexception);
            }
        }
        return k;
    }

    private void k()
    {
        android.graphics.Picture picture = d.capturePicture();
        r.a(d.getWidth(), d.getHeight());
        r.a(picture);
    }

    java.lang.String a(com.google.ads.k k1, boolean flag)
    {
        java.util.List list = k1.a(getContext());
        java.lang.Object obj = getContext();
        int ai[] = new int[2];
        d.getLocationOnScreen(ai);
        android.graphics.Rect rect = new Rect();
        getWindowVisibleDisplayFrame(rect);
        int i1 = ai[0];
        int j1 = ai[1];
        int l1 = rect.height();
        int i2 = d.getHeight();
        int j2 = rect.width();
        int k2 = d.getWidth();
        list.add(new ab("tsp", java.lang.Integer.toString(com.google.ads.j.a(((android.content.Context) (obj)), j1))));
        list.add(new ab("lsp", java.lang.Integer.toString(com.google.ads.j.a(((android.content.Context) (obj)), i1))));
        list.add(new ab("bsp", java.lang.Integer.toString(com.google.ads.j.a(((android.content.Context) (obj)), l1 - i2 - j1))));
        list.add(new ab("rsp", java.lang.Integer.toString(com.google.ads.j.a(((android.content.Context) (obj)), j2 - k2 - i1))));
        if(flag)
            list.add(new ab("ar", java.lang.Integer.toString(s)));
        list.addAll(i.a());
        if(l.d())
            list.add(new ab("prl", java.lang.Integer.toString(l.e())));
        if(l.f())
            list.add(new ab("pcl", java.lang.Integer.toString(l.g())));
        if(l.h())
            list.add(new ab("pai", l.i()));
        l.j();
        obj = m.a();
        if(obj != null && ((java.lang.String) (obj)).length() > 0)
            list.add(new ab("uule", ((java.lang.String) (obj))));
        k1 = (new StringBuilder()).append(";\n</script>\n<script type='text/javascript' src='").append(k1.d()).append("'></script>\n</body>\n</html>").toString();
        return (new StringBuilder("<html>\n<body marginwidth='0' marginheight='0'>\n<script type='text/javascript'>\nwindow.google_afma_request = ")).append(com.google.ads.j.a(list)).append(k1).toString();
    }

    void a()
    {
        if(!o)
        {
            return;
        } else
        {
            k();
            e.removeAllViews();
            f.b();
            e.addView(d);
            f.a(r);
            a(p, q);
            postDelayed(new af(this, null), 400L);
            return;
        }
    }

    public void a(int i1)
    {
        char c1 = '\264';
        if(i1 <= 0)
        {
            s = -1;
            return;
        }
        if(i1 < 180)
            i1 = c1;
        s = i1;
        i();
    }

    void a(int i1, int j1)
    {
        p = i1;
        q = j1;
        int l1 = getChildCount();
        for(int k1 = 0; k1 < l1; k1++)
        {
            android.view.ViewGroup.LayoutParams layoutparams = getChildAt(k1).getLayoutParams();
            layoutparams.width = com.google.ads.j.b(getContext(), i1);
            layoutparams.height = com.google.ads.j.b(getContext(), j1);
        }

        requestLayout();
    }

    void a(int i1, int j1, int k1, int l1)
    {
        if(o)
        {
            return;
        } else
        {
            o = true;
            android.content.Context context = getContext();
            int i2 = p;
            int j2 = q;
            k();
            int ai[] = new int[2];
            d.getLocationOnScreen(ai);
            int k2 = com.google.ads.j.a(context, ai[0]);
            int l2 = com.google.ads.j.a(context, ai[1]);
            f.a(i2 + (k1 + l1), j2 + (i1 + j1));
            e.removeAllViews();
            e.addView(r);
            d.setVisibility(4);
            f.b(com.google.ads.j.b(context, k2 - k1), com.google.ads.j.b(context, l2 - i1));
            postDelayed(new ad(this, null), 150L);
            return;
        }
    }

    public void a(com.google.ads.k k1)
    {
        b(k1, false);
    }

    void a(com.google.ads.k k1, boolean flag, boolean flag1)
    {
        v = false;
        t = k1;
        if(!flag1)
        {
            v = true;
            return;
        }
        if(o)
            b();
        a(k1.b(), k1.c());
        j = k1.a();
        k1 = a(k1, flag);
        if(j)
        {
            android.util.Log.i("GoogleAdView", (new StringBuilder()).append("Fetching ad: ").append(k1).toString());
            j();
            d.setWebChromeClient(new WebChromeClient());
        } else
        {
            d.setWebChromeClient(null);
        }
        d.loadData(k1, "text/html", "utf8");
        i();
    }

    void a(java.lang.String s1)
    {
        d.loadUrl(s1);
    }

    void b()
    {
        if(!o)
        {
            return;
        } else
        {
            e.removeAllViews();
            f.a();
            e.addView(d);
            a(p, q);
            o = false;
            return;
        }
    }

    android.webkit.WebView c()
    {
        return d;
    }

    boolean d()
    {
        return o;
    }

    int e()
    {
        return p;
    }

    int f()
    {
        return q;
    }

    protected void onAttachedToWindow()
    {
        onWindowFocusChanged(hasWindowFocus());
    }

    protected void onDetachedFromWindow()
    {
        if(o)
            b();
        super.onDetachedFromWindow();
    }

    protected void onRestoreInstanceState(android.os.Parcelable parcelable)
    {
        parcelable = (android.os.Bundle)parcelable;
        l.b(parcelable);
        parcelable = parcelable.getParcelable("google_ad_view_parent_state");
        if(parcelable != null)
            super.onRestoreInstanceState(parcelable);
    }

    protected android.os.Parcelable onSaveInstanceState()
    {
        android.os.Bundle bundle = new Bundle();
        android.os.Parcelable parcelable = super.onSaveInstanceState();
        if(parcelable != null)
            bundle.putParcelable("google_ad_view_parent_state", parcelable);
        l.a(bundle);
        return bundle;
    }

    public void onWindowFocusChanged(boolean flag)
    {
        super.onWindowFocusChanged(flag);
        if(v && flag && t != null && !o)
            b(t, false);
        if(flag)
            l.c();
        i();
    }

    public void reset()
    {
        setDisplayedChild(0);
        d.stopLoading();
        d.clearView();
        com.google.ads.i.a(g);
    }

    public void setDisplayedChild(int i1)
    {
        super.setDisplayedChild(i1);
        if(j && i1 == 1)
        {
            setForeground(j());
            return;
        } else
        {
            setForeground(null);
            return;
        }
    }

    private static final java.lang.String a[] = {
        "googleads.g.doubleclick.net", "googleadservices.com"
    };
    private static final java.lang.String b[] = {
        "about:blank"
    };
    private com.google.ads.v c;
    private android.webkit.WebView d;
    private android.widget.FrameLayout e;
    private com.google.ads.z f;
    private com.google.ads.i g;
    private com.google.ads.g h;
    private com.google.ads.y i;
    private boolean j;
    private android.graphics.drawable.Drawable k;
    private com.google.ads.aa l;
    private com.google.ads.p m;
    private android.widget.LinearLayout n;
    private boolean o;
    private int p;
    private int q;
    private com.google.ads.m r;
    private int s;
    private com.google.ads.k t;
    private java.lang.Runnable u;
    private boolean v;

}
