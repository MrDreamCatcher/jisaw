// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;

import java.util.Map;

// Referenced classes of package com.google.ads:
//            r, y, GoogleAdView, s, 
//            g

public class l
    implements com.google.ads.r
{

    public l(com.google.ads.y y1, com.google.ads.g g1)
    {
        a = y1;
        b = g1;
    }

    public void a(java.util.Map map, com.google.ads.GoogleAdView googleadview)
    {
        map = a.a();
        com.google.ads.g.a(googleadview.c(), com.google.ads.s.b, map);
    }

    private final com.google.ads.y a;
    private final com.google.ads.g b;
}
