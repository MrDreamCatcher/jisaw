// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;


// Referenced classes of package com.google.ads:
//            GoogleAdView, a

class t
    implements java.lang.Runnable
{

    private t(com.google.ads.GoogleAdView googleadview)
    {
        a = googleadview;
        super();
    }

    t(com.google.ads.GoogleAdView googleadview, com.google.ads.a a1)
    {
        this(googleadview);
    }

    public void run()
    {
        if(com.google.ads.GoogleAdView.g(a) != null && a.hasWindowFocus())
        {
            if(!com.google.ads.GoogleAdView.e(a))
                com.google.ads.GoogleAdView.a(a, com.google.ads.GoogleAdView.g(a), true);
            if(com.google.ads.GoogleAdView.h(a) > 0)
            {
                a.postDelayed(this, com.google.ads.GoogleAdView.h(a) * 1000);
                return;
            }
        }
    }

    final com.google.ads.GoogleAdView a;
}
