// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;


public final class w extends java.lang.Enum
{

    private w(java.lang.String s, int i, java.lang.String s1)
    {
        super(s, i);
        d = s1;
    }

    private java.lang.String a()
    {
        return d;
    }

    static java.lang.String a(com.google.ads.w w1)
    {
        return w1.a();
    }

    public static com.google.ads.w valueOf(java.lang.String s)
    {
        return (com.google.ads.w)java.lang.Enum.valueOf(com/google/ads/w, s);
    }

    public static com.google.ads.w[] values()
    {
        return (com.google.ads.w[])e.clone();
    }

    public static final com.google.ads.w a;
    public static final com.google.ads.w b;
    public static final com.google.ads.w c;
    private static final com.google.ads.w e[];
    private java.lang.String d;

    static 
    {
        a = new w("TEXT", 0, "text");
        b = new w("IMAGE", 1, "image");
        c = new w("TEXT_IMAGE", 2, "text_image");
        e = (new com.google.ads.w[] {
            a, b, c
        });
    }
}
