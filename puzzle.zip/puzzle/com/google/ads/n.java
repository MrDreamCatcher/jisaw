// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;

import android.os.Bundle;

// Referenced classes of package com.google.ads:
//            aa, h

class n
{

    private n(com.google.ads.aa aa)
    {
        a = aa;
        super();
        b = -1L;
        c = -1L;
        d = null;
    }

    n(com.google.ads.aa aa, com.google.ads.h h)
    {
        this(aa);
    }

    static long a(com.google.ads.n n1)
    {
        return n1.b;
    }

    static long a(com.google.ads.n n1, long l)
    {
        n1.b = l;
        return l;
    }

    static java.lang.String a(com.google.ads.n n1, java.lang.String s)
    {
        n1.d = s;
        return s;
    }

    private void a(android.os.Bundle bundle)
    {
        bundle.putLong("fetch_start", b);
        bundle.putLong("click_start", c);
        bundle.putString("current_click_string", d);
    }

    static void a(com.google.ads.n n1, android.os.Bundle bundle)
    {
        n1.a(bundle);
    }

    static long b(com.google.ads.n n1)
    {
        return n1.c;
    }

    static long b(com.google.ads.n n1, long l)
    {
        n1.c = l;
        return l;
    }

    private void b(android.os.Bundle bundle)
    {
        b = bundle.getLong("fetch_start");
        c = bundle.getLong("click_start");
        d = bundle.getString("current_click_string");
    }

    static void b(com.google.ads.n n1, android.os.Bundle bundle)
    {
        n1.b(bundle);
    }

    static java.lang.String c(com.google.ads.n n1)
    {
        return n1.d;
    }

    final com.google.ads.aa a;
    private long b;
    private long c;
    private java.lang.String d;
}
