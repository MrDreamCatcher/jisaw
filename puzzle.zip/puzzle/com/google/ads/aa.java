// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;

import android.content.Context;
import android.os.Bundle;

// Referenced classes of package com.google.ads:
//            b, n, d, o

class aa
{

    public aa(android.content.Context context)
    {
        c = new b(this, null);
        a = new n(this, null);
        b = new d(this, context, null);
        com.google.ads.d.a(b);
    }

    public void a()
    {
        com.google.ads.n.a(a, c.a());
    }

    public void a(android.os.Bundle bundle)
    {
        com.google.ads.n.a(a, bundle);
    }

    public void a(java.lang.String s)
    {
        com.google.ads.n.b(a, c.a());
        com.google.ads.n.a(a, s);
    }

    public void b()
    {
        if(com.google.ads.n.a(a) == -1L)
        {
            return;
        } else
        {
            com.google.ads.d.a(b, (int)(c.a() - com.google.ads.n.a(a)));
            com.google.ads.n.a(a, -1L);
            com.google.ads.d.b(b);
            return;
        }
    }

    public void b(android.os.Bundle bundle)
    {
        com.google.ads.n.b(a, bundle);
    }

    public void c()
    {
        if(com.google.ads.n.b(a) == -1L)
        {
            return;
        } else
        {
            com.google.ads.d.b(b, (int)(c.a() - com.google.ads.n.b(a)));
            com.google.ads.d.a(b, com.google.ads.n.c(a));
            com.google.ads.n.b(a, -1L);
            com.google.ads.d.b(b);
            return;
        }
    }

    public boolean d()
    {
        return com.google.ads.d.c(b) != -1;
    }

    public int e()
    {
        return com.google.ads.d.c(b);
    }

    public boolean f()
    {
        return com.google.ads.d.d(b) != -1;
    }

    public int g()
    {
        return com.google.ads.d.d(b);
    }

    public boolean h()
    {
        return com.google.ads.d.e(b) != null && com.google.ads.d.e(b).length() > 0;
    }

    public java.lang.String i()
    {
        return com.google.ads.d.e(b);
    }

    public void j()
    {
        com.google.ads.d.f(b);
    }

    public java.lang.String toString()
    {
        return (new StringBuilder()).append("Latency[fstart=").append(com.google.ads.n.a(a)).append(", ").append("cstart=").append(com.google.ads.n.b(a)).append(", ").append("ccstr=").append(com.google.ads.n.c(a)).append(", ").append("flat=").append(com.google.ads.d.c(b)).append(", ").append("clat=").append(com.google.ads.d.d(b)).append(", ").append("cstr=").append(com.google.ads.d.e(b)).append("]").toString();
    }

    private com.google.ads.n a;
    private com.google.ads.d b;
    private com.google.ads.o c;
}
