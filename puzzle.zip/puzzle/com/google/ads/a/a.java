// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads.a;

import java.io.UnsupportedEncodingException;

// Referenced classes of package com.google.ads.a:
//            d, b

public class a
{

    private a()
    {
    }

    public static byte[] a(java.lang.String s, int i)
    {
        return com.google.ads.a.a.a(s.getBytes(), i);
    }

    public static byte[] a(byte abyte0[], int i)
    {
        return com.google.ads.a.a.a(abyte0, 0, abyte0.length, i);
    }

    public static byte[] a(byte abyte0[], int i, int j, int k)
    {
        com.google.ads.a.d d1 = new d(k, new byte[(j * 3) / 4]);
        if(!d1.a(abyte0, i, j, true))
            throw new IllegalArgumentException("bad base-64");
        if(d1.g == d1.f.length)
        {
            return d1.f;
        } else
        {
            abyte0 = new byte[d1.g];
            java.lang.System.arraycopy(d1.f, 0, abyte0, 0, d1.g);
            return abyte0;
        }
    }

    public static java.lang.String b(byte abyte0[], int i)
    {
        try
        {
            abyte0 = new String(com.google.ads.a.a.c(abyte0, i), "US-ASCII");
        }
        // Misplaced declaration of an exception variable
        catch(byte abyte0[])
        {
            throw new AssertionError(abyte0);
        }
        return abyte0;
    }

    public static byte[] b(byte abyte0[], int i, int j, int k)
    {
        com.google.ads.a.b b1;
        int l;
        b1 = new b(k, null);
        l = (j / 3) * 4;
        if(!b1.b) goto _L2; else goto _L1
_L1:
        k = l;
        if(j % 3 > 0)
            k = l + 4;
_L4:
        l = k;
        if(b1.c)
        {
            l = k;
            if(j > 0)
            {
                int i1 = (j - 1) / 57;
                if(b1.d)
                    l = 2;
                else
                    l = 1;
                l = k + (i1 + 1) * l;
            }
        }
        b1.f = new byte[l];
        b1.a(abyte0, i, j, true);
        if(!a && b1.g != l)
            throw new AssertionError();
        else
            return b1.f;
_L2:
        k = l;
        switch(j % 3)
        {
        default:
            k = l;
            break;

        case 1: // '\001'
            k = l + 2;
            break;

        case 2: // '\002'
            k = l + 3;
            break;

        case 0: // '\0'
            break;
        }
        if(true) goto _L4; else goto _L3
_L3:
    }

    public static byte[] c(byte abyte0[], int i)
    {
        return com.google.ads.a.a.b(abyte0, 0, abyte0.length, i);
    }

    static final boolean a;

    static 
    {
        boolean flag;
        if(!com/google/ads/a/a.desiredAssertionStatus())
            flag = true;
        else
            flag = false;
        a = flag;
    }
}
