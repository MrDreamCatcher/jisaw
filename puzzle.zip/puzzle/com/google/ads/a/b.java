// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads.a;


// Referenced classes of package com.google.ads.a:
//            c, a

public class b extends com.google.ads.a.c
{

    public b(int i1, byte abyte0[])
    {
        f = abyte0;
        boolean flag;
        if((i1 & 1) == 0)
            flag = true;
        else
            flag = false;
        b = flag;
        if((i1 & 2) == 0)
            flag = true;
        else
            flag = false;
        c = flag;
        if((i1 & 4) != 0)
            flag = true;
        else
            flag = false;
        d = flag;
        if((i1 & 8) == 0)
            abyte0 = h;
        else
            abyte0 = i;
        l = abyte0;
        a = 0;
        if(c)
            i1 = 19;
        else
            i1 = -1;
        k = i1;
    }

    public boolean a(byte abyte0[], int i1, int j1, boolean flag)
    {
        byte abyte1[];
        byte abyte2[];
        int l1;
        int k2;
        int k3;
        abyte1 = l;
        abyte2 = f;
        l1 = 0;
        k2 = k;
        k3 = j1 + i1;
        j1 = -1;
        a;
        JVM INSTR tableswitch 0 2: default 60
    //                   0 386
    //                   1 389
    //                   2 451;
           goto _L1 _L1 _L2 _L3
_L1:
        int k1 = k2;
        if(j1 == -1) goto _L5; else goto _L4
_L4:
        int i2;
        l1 = 0 + 1;
        abyte2[0] = abyte1[j1 >> 18 & 0x3f];
        k1 = l1 + 1;
        abyte2[l1] = abyte1[j1 >> 12 & 0x3f];
        l1 = k1 + 1;
        abyte2[k1] = abyte1[j1 >> 6 & 0x3f];
        i2 = l1 + 1;
        abyte2[l1] = abyte1[j1 & 0x3f];
        j1 = k2 - 1;
        l1 = i2;
        k1 = j1;
        if(j1 != 0) goto _L5; else goto _L6
_L6:
        j1 = i2;
        if(d)
        {
            abyte2[i2] = 13;
            j1 = i2 + 1;
        }
        abyte2[j1] = 10;
        l1 = j1 + 1;
        k1 = 19;
        j1 = i1;
        i1 = l1;
_L13:
        while(j1 + 3 <= k3) 
        {
            l1 = (abyte0[j1] & 0xff) << 16 | (abyte0[j1 + 1] & 0xff) << 8 | abyte0[j1 + 2] & 0xff;
            abyte2[i1] = abyte1[l1 >> 18 & 0x3f];
            abyte2[i1 + 1] = abyte1[l1 >> 12 & 0x3f];
            abyte2[i1 + 2] = abyte1[l1 >> 6 & 0x3f];
            abyte2[i1 + 3] = abyte1[l1 & 0x3f];
            int j2 = j1 + 3;
            l1 = i1 + 4;
            int l2 = k1 - 1;
            j1 = j2;
            k1 = l2;
            i1 = l1;
            if(l2 == 0)
            {
                int i3;
                int j3;
                if(d)
                {
                    i1 = l1 + 1;
                    abyte2[l1] = 13;
                } else
                {
                    i1 = l1;
                }
                l1 = i1 + 1;
                abyte2[i1] = 10;
                k1 = 19;
                j1 = j2;
                i1 = l1;
            }
        }
          goto _L7
_L2:
        if(i1 + 2 <= k3)
        {
            j1 = j[0];
            k1 = i1 + 1;
            j1 = (j1 & 0xff) << 16 | (abyte0[i1] & 0xff) << 8 | abyte0[k1] & 0xff;
            a = 0;
            i1 = k1 + 1;
        }
          goto _L1
_L3:
        if(i1 + 1 <= k3)
        {
            j1 = j[0];
            j2 = j[1];
            k1 = i1 + 1;
            j1 = (j1 & 0xff) << 16 | (j2 & 0xff) << 8 | abyte0[i1] & 0xff;
            a = 0;
            i1 = k1;
        }
          goto _L1
_L7:
        if(!flag) goto _L9; else goto _L8
_L8:
        if(j1 - a == k3 - 1)
        {
            l1 = 0;
            if(a > 0)
            {
                j2 = j[0];
                l1 = 0 + 1;
            } else
            {
                i3 = j1 + 1;
                j2 = abyte0[j1];
                j1 = i3;
            }
            j2 = (j2 & 0xff) << 4;
            a = a - l1;
            l1 = i1 + 1;
            abyte2[i1] = abyte1[j2 >> 6 & 0x3f];
            i1 = l1 + 1;
            abyte2[l1] = abyte1[j2 & 0x3f];
            if(b)
            {
                l1 = i1 + 1;
                abyte2[i1] = 61;
                abyte2[l1] = 61;
                i1 = l1 + 1;
            }
            l1 = i1;
            if(c)
            {
                l1 = i1;
                if(d)
                {
                    abyte2[i1] = 13;
                    l1 = i1 + 1;
                }
                abyte2[l1] = 10;
                l1++;
            }
            i1 = l1;
        } else
        if(j1 - a == k3 - 2)
        {
            i3 = 0;
            if(a > 1)
            {
                j2 = j[0];
                i3 = 0 + 1;
                l1 = j1;
                j1 = i3;
            } else
            {
                l1 = j1 + 1;
                j2 = abyte0[j1];
                j1 = i3;
            }
            if(a > 0)
            {
                i3 = j[j1];
                j3 = j1 + 1;
                j1 = l1;
                l1 = j3;
            } else
            {
                j3 = l1 + 1;
                i3 = abyte0[l1];
                l1 = j1;
                j1 = j3;
            }
            j2 = (j2 & 0xff) << 10 | (i3 & 0xff) << 2;
            a = a - l1;
            l1 = i1 + 1;
            abyte2[i1] = abyte1[j2 >> 12 & 0x3f];
            i3 = l1 + 1;
            abyte2[l1] = abyte1[j2 >> 6 & 0x3f];
            i1 = i3 + 1;
            abyte2[i3] = abyte1[j2 & 0x3f];
            if(b)
            {
                l1 = i1 + 1;
                abyte2[i1] = 61;
                i1 = l1;
            }
            l1 = i1;
            if(c)
            {
                l1 = i1;
                if(d)
                {
                    abyte2[i1] = 13;
                    l1 = i1 + 1;
                }
                abyte2[l1] = 10;
                l1++;
            }
            i1 = l1;
        } else
        {
            l1 = i1;
            if(c)
            {
                l1 = i1;
                if(i1 > 0)
                {
                    l1 = i1;
                    if(k1 != 19)
                    {
                        if(d)
                        {
                            l1 = i1 + 1;
                            abyte2[i1] = 13;
                            i1 = l1;
                        }
                        l1 = i1 + 1;
                        abyte2[i1] = 10;
                    }
                }
            }
            i1 = l1;
        }
        if(!e && a != 0)
            throw new AssertionError();
        if(!e && j1 != k3)
            throw new AssertionError();
          goto _L10
_L9:
        if(j1 != k3 - 1) goto _L12; else goto _L11
_L11:
        abyte1 = j;
        l1 = a;
        a = l1 + 1;
        abyte1[l1] = abyte0[j1];
_L10:
        g = i1;
        k = k1;
        return true;
_L12:
        if(j1 == k3 - 2)
        {
            abyte1 = j;
            l1 = a;
            a = l1 + 1;
            abyte1[l1] = abyte0[j1];
            abyte1 = j;
            l1 = a;
            a = l1 + 1;
            abyte1[l1] = abyte0[j1 + 1];
        }
        if(true) goto _L10; else goto _L5
_L5:
        j1 = i1;
        i1 = l1;
          goto _L13
    }

    static final boolean e;
    private static final byte h[] = {
        65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 
        75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 
        85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 
        101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 
        111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 
        121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 
        56, 57, 43, 47
    };
    private static final byte i[] = {
        65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 
        75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 
        85, 86, 87, 88, 89, 90, 97, 98, 99, 100, 
        101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 
        111, 112, 113, 114, 115, 116, 117, 118, 119, 120, 
        121, 122, 48, 49, 50, 51, 52, 53, 54, 55, 
        56, 57, 45, 95
    };
    public int a;
    public final boolean b;
    public final boolean c;
    public final boolean d;
    private final byte j[] = new byte[2];
    private int k;
    private final byte l[];

    static 
    {
        boolean flag;
        if(!com/google/ads/a/a.desiredAssertionStatus())
            flag = true;
        else
            flag = false;
        e = flag;
    }
}
