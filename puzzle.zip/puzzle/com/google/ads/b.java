// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;

import android.os.SystemClock;

// Referenced classes of package com.google.ads:
//            o, aa, h

class b
    implements com.google.ads.o
{

    private b(com.google.ads.aa aa)
    {
        a = aa;
        super();
    }

    b(com.google.ads.aa aa, com.google.ads.h h)
    {
        this(aa);
    }

    public long a()
    {
        return android.os.SystemClock.elapsedRealtime();
    }

    final com.google.ads.aa a;
}
