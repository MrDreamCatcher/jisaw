// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;

import android.content.pm.PackageManager;
import java.util.LinkedList;
import java.util.List;

// Referenced classes of package com.google.ads:
//            f, ab

public class y
{

    public y(android.content.pm.PackageManager packagemanager)
    {
        a = packagemanager;
    }

    public java.util.List a()
    {
        java.util.LinkedList linkedlist = new LinkedList();
        com.google.ads.f af[] = com.google.ads.f.values();
        int j = af.length;
        for(int i = 0; i < j; i++)
        {
            com.google.ads.f f1 = af[i];
            linkedlist.add(new ab(com.google.ads.f.a(f1), (new StringBuilder()).append("").append(com.google.ads.f.a(f1, a)).toString()));
        }

        return linkedlist;
    }

    private final android.content.pm.PackageManager a;
}
