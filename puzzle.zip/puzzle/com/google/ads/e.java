// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;

import android.content.Context;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.widget.FrameLayout;

// Referenced classes of package com.google.ads:
//            z

class e extends android.widget.FrameLayout
{

    public e(com.google.ads.z z1, android.content.Context context)
    {
        a = z1;
        super(context);
    }

    public boolean dispatchKeyEvent(android.view.KeyEvent keyevent)
    {
        if(keyevent.getKeyCode() == 4 && keyevent.getAction() == 0)
        {
            com.google.ads.z.a(a);
            return true;
        } else
        {
            return super.dispatchKeyEvent(keyevent);
        }
    }

    public boolean onTouchEvent(android.view.MotionEvent motionevent)
    {
        int i = (int)motionevent.getX();
        int j = (int)motionevent.getY();
        if(motionevent.getAction() == 0 && (i < 0 || i >= getWidth() || j < 0 || j >= getHeight()))
        {
            com.google.ads.z.a(a, i, j);
            return true;
        }
        if(motionevent.getAction() == 4)
        {
            com.google.ads.z.a(a, i, j);
            return true;
        } else
        {
            return super.onTouchEvent(motionevent);
        }
    }

    final com.google.ads.z a;
}
