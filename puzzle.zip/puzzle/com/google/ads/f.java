// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;

import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;

final class f extends java.lang.Enum
{

    private f(java.lang.String s, int i, java.lang.String s1, java.lang.String s2)
    {
        super(s, i);
        b = s1;
        c = s2;
    }

    private int a(android.content.pm.PackageManager packagemanager)
    {
        int i;
        try
        {
            packagemanager = packagemanager.getPackageInfo(c, 0);
        }
        // Misplaced declaration of an exception variable
        catch(android.content.pm.PackageManager packagemanager)
        {
            return 0;
        }
        if(packagemanager == null)
            return 0;
        i = ((android.content.pm.PackageInfo) (packagemanager)).versionCode;
        return i;
    }

    static int a(com.google.ads.f f1, android.content.pm.PackageManager packagemanager)
    {
        return f1.a(packagemanager);
    }

    private java.lang.String a()
    {
        return b;
    }

    static java.lang.String a(com.google.ads.f f1)
    {
        return f1.a();
    }

    public static com.google.ads.f valueOf(java.lang.String s)
    {
        return (com.google.ads.f)java.lang.Enum.valueOf(com/google/ads/f, s);
    }

    public static com.google.ads.f[] values()
    {
        return (com.google.ads.f[])d.clone();
    }

    public static final com.google.ads.f a;
    private static final com.google.ads.f d[];
    private java.lang.String b;
    private java.lang.String c;

    static 
    {
        a = new f("YOUTUBE", 0, "app_youtube", "com.google.android.youtube");
        d = (new com.google.ads.f[] {
            a
        });
    }
}
