// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Picture;
import android.graphics.Rect;
import android.view.View;

// Referenced classes of package com.google.ads:
//            GoogleAdView

class m extends android.view.View
{

    public m(com.google.ads.GoogleAdView googleadview, android.content.Context context)
    {
        a = googleadview;
        super(context);
    }

    public void a(int i, int j)
    {
        c = i;
        d = j;
    }

    public void a(android.graphics.Picture picture)
    {
        b = picture;
    }

    public void onDraw(android.graphics.Canvas canvas)
    {
        super.onDraw(canvas);
        canvas.drawPicture(b, new Rect(0, 0, c, d));
    }

    final com.google.ads.GoogleAdView a;
    private android.graphics.Picture b;
    private int c;
    private int d;
}
