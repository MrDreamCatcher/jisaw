// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;

import android.content.Context;
import android.content.res.Resources;
import android.util.DisplayMetrics;
import android.util.Log;
import java.util.Iterator;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.google.ads:
//            ab

final class j
{

    private j()
    {
    }

    static int a(android.content.Context context, int i)
    {
        if(a < 0.0F)
            a = context.getResources().getDisplayMetrics().density;
        return (int)((float)i / a);
    }

    static java.lang.String a(java.util.List list)
    {
        java.util.Iterator iterator;
        org.json.JSONObject jsonobject = new JSONObject();
        iterator = list.iterator();
        list = jsonobject;
_L2:
        java.lang.String s;
        java.lang.String s1;
        if(!iterator.hasNext())
            break; /* Loop/switch isn't completed */
        com.google.ads.ab ab1 = (com.google.ads.ab)iterator.next();
        s = ab1.a();
        s1 = ab1.b();
        org.json.JSONObject jsonobject1 = list.put(s, s1);
        list = jsonobject1;
        continue; /* Loop/switch isn't completed */
        org.json.JSONException jsonexception;
        jsonexception;
        android.util.Log.w("Google.AdUtil", (new StringBuilder()).append("Error encoding JSON: ").append(s).append("=").append(s1).toString());
        if(true) goto _L2; else goto _L1
_L1:
        return list.toString();
    }

    static int b(android.content.Context context, int i)
    {
        if(a < 0.0F)
            a = context.getResources().getDisplayMetrics().density;
        return (int)((float)i * a);
    }

    private static float a = -1F;

}
