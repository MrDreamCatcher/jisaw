// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;


// Referenced classes of package com.google.ads:
//            GoogleAdView, z, a

class af
    implements java.lang.Runnable
{

    private af(com.google.ads.GoogleAdView googleadview)
    {
        a = googleadview;
        super();
    }

    af(com.google.ads.GoogleAdView googleadview, com.google.ads.a a1)
    {
        this(googleadview);
    }

    public void run()
    {
        if(!com.google.ads.GoogleAdView.e(a))
        {
            return;
        } else
        {
            com.google.ads.GoogleAdView.f(a).a();
            com.google.ads.GoogleAdView.a(a, false);
            return;
        }
    }

    final com.google.ads.GoogleAdView a;
}
