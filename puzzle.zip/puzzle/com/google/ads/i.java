// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.util.Log;
import android.webkit.URLUtil;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import java.util.Random;

// Referenced classes of package com.google.ads:
//            GoogleAdView, aa, v, g, 
//            x

class i extends android.webkit.WebViewClient
{

    i(com.google.ads.GoogleAdView googleadview)
    {
        a = googleadview;
        super();
        c = new Random();
    }

    private void a()
    {
        b = false;
    }

    static void a(com.google.ads.i j)
    {
        j.a();
    }

    private boolean a(android.net.Uri uri)
    {
        uri = uri.toString();
        for(int j = 0; j < com.google.ads.GoogleAdView.g().length; j++)
            if(uri.equals(com.google.ads.GoogleAdView.g()[j]))
                return true;

        return false;
    }

    private boolean a(java.lang.String s, android.net.Uri uri)
    {
        if(s.startsWith("http://__NO_MATCHING_AD__"))
        {
            android.util.Log.w("GoogleAdView", "DoubleClick could not fill the ad request.");
            return true;
        } else
        {
            return false;
        }
    }

    private java.lang.String b(android.net.Uri uri)
    {
        if(!uri.isHierarchical())
            return null;
        else
            return uri.getQueryParameter("ai");
    }

    private void b()
    {
        com.google.ads.GoogleAdView.d(a).loadUrl("javascript: document.body.style.margin = 0;");
    }

    public void onPageFinished(android.webkit.WebView webview, java.lang.String s)
    {
        b();
        super.onPageFinished(webview, s);
        if(b && !android.webkit.URLUtil.isDataUrl(s))
        {
            b = false;
            a.setDisplayedChild(1);
            com.google.ads.GoogleAdView.a(a).b();
            if(com.google.ads.GoogleAdView.b(a) != null)
                com.google.ads.GoogleAdView.b(a).b();
        }
    }

    public void onPageStarted(android.webkit.WebView webview, java.lang.String s, android.graphics.Bitmap bitmap)
    {
        super.onPageStarted(webview, s, bitmap);
        if(android.webkit.URLUtil.isDataUrl(s))
        {
            b = true;
            com.google.ads.GoogleAdView.a(a).a();
            if(com.google.ads.GoogleAdView.b(a) != null)
                com.google.ads.GoogleAdView.b(a).a();
        }
    }

    public boolean shouldOverrideUrlLoading(android.webkit.WebView webview, java.lang.String s)
    {
        webview = android.net.Uri.parse(s);
        if(com.google.ads.g.b(webview))
        {
            com.google.ads.GoogleAdView.c(a).a(webview);
            return true;
        }
        if(a(webview))
            return false;
        if(a(s, webview))
        {
            if(com.google.ads.GoogleAdView.b(a) != null)
                com.google.ads.GoogleAdView.b(a).d();
            return true;
        }
        if(com.google.ads.GoogleAdView.b(a) != null)
            com.google.ads.GoogleAdView.b(a).c();
        com.google.ads.GoogleAdView.a(a).a(b(webview));
        webview = new Intent("android.intent.action.VIEW", com.google.ads.x.a(webview));
        webview.addCategory("android.intent.category.BROWSABLE");
        try
        {
            a.getContext().startActivity(webview);
        }
        // Misplaced declaration of an exception variable
        catch(android.webkit.WebView webview)
        {
            android.util.Log.e("GoogleAdView", webview.getMessage(), webview);
        }
        return true;
    }

    final com.google.ads.GoogleAdView a;
    private boolean b;
    private java.util.Random c;
}
