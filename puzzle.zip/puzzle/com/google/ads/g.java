// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;

import android.net.Uri;
import android.webkit.WebView;
import java.net.URLDecoder;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// Referenced classes of package com.google.ads:
//            j, s, r, GoogleAdView

class g
{

    public g(com.google.ads.GoogleAdView googleadview)
    {
        b = new HashMap();
        a = googleadview;
    }

    public static void a(android.webkit.WebView webview, com.google.ads.s s1, java.util.List list)
    {
        if(list == null || webview == null)
        {
            throw new NullPointerException();
        } else
        {
            list = com.google.ads.j.a(list);
            s1 = (new StringBuilder()).append("adsense.mobileads.afmanotify.receiveMessage(\"").append(s1.a()).append("\", ").append(list).append(");").toString();
            webview.loadUrl((new StringBuilder()).append("javascript: ").append(s1).toString());
            return;
        }
    }

    public static boolean b(android.net.Uri uri)
    {
        if(uri == null || !uri.isHierarchical() || uri.getScheme() == null || !uri.getScheme().equals("gmsg"))
            return false;
        uri = uri.getAuthority();
        return uri != null && uri.equals("afma.google.com");
    }

    private static java.util.Map c(android.net.Uri uri)
    {
        if(uri == null)
        {
            uri = null;
        } else
        {
            java.util.HashMap hashmap = new HashMap();
            java.lang.String s1 = uri.getEncodedQuery();
            uri = hashmap;
            if(s1 != null)
            {
                uri = s1.split("&");
                for(int i = 0; i < uri.length; i++)
                {
                    int k = uri[i].indexOf('=');
                    if(k == -1)
                        return null;
                    if(uri[i].indexOf('=', k + 1) != -1)
                        return null;
                    java.lang.String s2 = uri[i].substring(0, k);
                    java.lang.String s3 = uri[i].substring(k + 1);
                    hashmap.put(java.net.URLDecoder.decode(s2), java.net.URLDecoder.decode(s3));
                }

                return java.util.Collections.unmodifiableMap(hashmap);
            }
        }
        return uri;
    }

    public com.google.ads.r a(java.lang.String s1, com.google.ads.r r1)
    {
        return (com.google.ads.r)b.put(s1, r1);
    }

    public boolean a(android.net.Uri uri)
    {
        if(!com.google.ads.g.b(uri))
            throw new IllegalArgumentException((new StringBuilder()).append("Invalid syntax in forwarded message: ").append(uri).toString());
        java.lang.Object obj = uri.getPath();
        obj = (com.google.ads.r)b.get(obj);
        if(obj == null)
            return false;
        uri = com.google.ads.g.c(uri);
        if(uri == null)
        {
            return false;
        } else
        {
            ((com.google.ads.r) (obj)).a(uri, a);
            return true;
        }
    }

    private com.google.ads.GoogleAdView a;
    private java.util.Map b;
}
