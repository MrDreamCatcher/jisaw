// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;

import android.content.Context;
import android.graphics.Rect;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import java.util.ArrayList;
import java.util.List;

// Referenced classes of package com.google.ads:
//            e, ab, j, s, 
//            g

class z extends android.widget.PopupWindow
{

    public z(android.content.Context context, android.view.View view, android.webkit.WebView webview)
    {
        super(context);
        c = view;
        b = webview;
        a(context);
    }

    private void a(android.content.Context context)
    {
        setBackgroundDrawable(null);
        setFocusable(true);
        a = new e(this, context);
        a.setBackgroundDrawable(null);
        setContentView(a);
    }

    static void a(com.google.ads.z z1)
    {
        z1.d();
    }

    static void a(com.google.ads.z z1, int i, int k)
    {
        z1.c(i, k);
    }

    private void c(int i, int k)
    {
        int ai[] = new int[2];
        b.getLocationInWindow(ai);
        int l = ai[0];
        int i1 = ai[1];
        android.graphics.Rect rect = new Rect();
        c.getWindowVisibleDisplayFrame(rect);
        android.content.Context context = b.getContext();
        java.util.ArrayList arraylist = new ArrayList();
        arraylist.add(new ab("click_x", java.lang.Integer.toString(com.google.ads.j.a(context, i + l))));
        arraylist.add(new ab("click_y", java.lang.Integer.toString(com.google.ads.j.a(context, k + i1))));
        arraylist.add(new ab("ad_x", java.lang.Integer.toString(com.google.ads.j.a(context, l))));
        arraylist.add(new ab("ad_y", java.lang.Integer.toString(com.google.ads.j.a(context, i1))));
        arraylist.add(new ab("ad_width", java.lang.Integer.toString(com.google.ads.j.a(context, b.getWidth()))));
        arraylist.add(new ab("ad_height", java.lang.Integer.toString(com.google.ads.j.a(context, b.getHeight()))));
        arraylist.add(new ab("screen_width", java.lang.Integer.toString(com.google.ads.j.a(context, rect.width()))));
        arraylist.add(new ab("screen_height", java.lang.Integer.toString(com.google.ads.j.a(context, rect.height()))));
        com.google.ads.g.a(b, com.google.ads.s.a, arraylist);
    }

    private void d()
    {
        c(-1, -1);
    }

    public void a()
    {
        a.removeAllViews();
        dismiss();
    }

    public void a(int i, int k)
    {
        setWidth(com.google.ads.j.b(c.getContext(), i));
        setHeight(com.google.ads.j.b(c.getContext(), k));
    }

    public void a(android.view.View view)
    {
        b();
        a.addView(view);
    }

    public void b()
    {
        a.removeAllViews();
    }

    public void b(int i, int k)
    {
        b();
        a.addView(b);
        showAtLocation(c, 0, i, k);
    }

    public void c()
    {
        android.view.WindowManager.LayoutParams layoutparams = (android.view.WindowManager.LayoutParams)a.getLayoutParams();
        if(layoutparams == null)
        {
            return;
        } else
        {
            layoutparams.flags = layoutparams.flags | 2;
            layoutparams.dimAmount = 0.5F;
            ((android.view.WindowManager)b.getContext().getSystemService("window")).updateViewLayout(a, a.getLayoutParams());
            return;
        }
    }

    private android.widget.FrameLayout a;
    private android.webkit.WebView b;
    private android.view.View c;
}
