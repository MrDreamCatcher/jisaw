// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import com.google.ads.a.a;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

class p
{

    p(android.content.Context context)
    {
        b = context;
    }

    private java.util.List b()
    {
        android.location.LocationManager locationmanager = (android.location.LocationManager)b.getSystemService("location");
        java.lang.Object obj = locationmanager.getProviders(false);
        java.util.ArrayList arraylist = new ArrayList(((java.util.List) (obj)).size());
        obj = ((java.util.List) (obj)).iterator();
        do
        {
            if(!((java.util.Iterator) (obj)).hasNext())
                break;
            android.location.Location location = locationmanager.getLastKnownLocation((java.lang.String)((java.util.Iterator) (obj)).next());
            if(location != null && location.hasAccuracy())
                arraylist.add(location);
        } while(true);
        return arraylist;
    }

    java.lang.String a()
    {
        java.util.List list = b();
        java.lang.StringBuilder stringbuilder = new StringBuilder();
        int i = 0;
        while(i < list.size()) 
        {
            java.lang.String s = a(a((android.location.Location)list.get(i)));
            if(s != null)
            {
                if(i == 0)
                    stringbuilder.append("e1+");
                else
                    stringbuilder.append("+e1+");
                stringbuilder.append(s);
            }
            i++;
        }
        return stringbuilder.toString();
    }

    java.lang.String a(android.location.Location location)
    {
        return java.lang.String.format(a, new java.lang.Object[] {
            java.lang.Long.valueOf(location.getTime() * 1000L), java.lang.Long.valueOf((long)(location.getLatitude() * 10000000D)), java.lang.Long.valueOf((long)(location.getLongitude() * 10000000D)), java.lang.Long.valueOf((long)(location.getAccuracy() * 1000F))
        });
    }

    java.lang.String a(java.lang.String s)
    {
        try
        {
            javax.crypto.Cipher cipher = javax.crypto.Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(1, new SecretKeySpec(new byte[] {
                10, 55, -112, -47, -6, 7, 11, 75, -7, -121, 
                121, 69, 80, -61, 15, 5
            }, "AES"));
            byte abyte0[] = cipher.getIV();
            s = cipher.doFinal(s.getBytes());
            byte abyte1[] = new byte[abyte0.length + s.length];
            java.lang.System.arraycopy(abyte0, 0, abyte1, 0, abyte0.length);
            java.lang.System.arraycopy(s, 0, abyte1, abyte0.length, s.length);
            s = com.google.ads.a.a.b(abyte1, 11);
        }
        // Misplaced declaration of an exception variable
        catch(java.lang.String s)
        {
            return null;
        }
        return s;
    }

    static java.lang.String a = "desc < role: 6 producer: 24 historical_role: 1 historical_producer: 12 timestamp: %d latlng < latitude_e7: %d longitude_e7: %d> radius: %d>";
    private android.content.Context b;

}
