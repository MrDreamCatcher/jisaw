// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.google.ads;

import android.webkit.WebView;

// Referenced classes of package com.google.ads:
//            GoogleAdView, z, a

class ad
    implements java.lang.Runnable
{

    private ad(com.google.ads.GoogleAdView googleadview)
    {
        a = googleadview;
        super();
    }

    ad(com.google.ads.GoogleAdView googleadview, com.google.ads.a a1)
    {
        this(googleadview);
    }

    public void run()
    {
        if(!com.google.ads.GoogleAdView.e(a))
        {
            return;
        } else
        {
            com.google.ads.GoogleAdView.d(a).setVisibility(0);
            com.google.ads.GoogleAdView.f(a).c();
            return;
        }
    }

    final com.google.ads.GoogleAdView a;
}
