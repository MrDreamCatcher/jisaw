// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class k extends android.widget.BaseAdapter
{

    public k(android.content.Context context, int ai[])
    {
        b = context;
        context = (android.view.WindowManager)b.getSystemService("window");
        android.util.DisplayMetrics displaymetrics = new DisplayMetrics();
        context.getDefaultDisplay().getMetrics(displaymetrics);
        g = displaymetrics.scaledDensity;
        a = new int[ai.length];
        int j = ai.length;
        for(int i = 0; i < j; i++)
            a[i] = ai[i];

        c = (int)(64F * g);
        d = (int)(96F * g);
        e = android.widget.ImageView.ScaleType.FIT_XY;
    }

    private void a()
    {
        if(f != null)
        {
            f.setLayoutParams(new android.widget.Gallery.LayoutParams(-2, d));
            f.setGravity(17);
            f.setTextColor(-1);
            f.setBackgroundResource(0x7f020017);
        }
    }

    public void a(int i)
    {
        f = new TextView(b);
        f.setText(i);
        a();
    }

    public void a(int i, int j)
    {
        c = (int)((float)i * g);
        d = (int)((float)j * g);
    }

    public int getCount()
    {
        int j = a.length;
        int i = j;
        if(f != null)
            i = j + 1;
        return i;
    }

    public java.lang.Object getItem(int i)
    {
        return java.lang.Integer.valueOf(i);
    }

    public long getItemId(int i)
    {
        return (long)i;
    }

    public android.view.View getView(int i, android.view.View view, android.view.ViewGroup viewgroup)
    {
        if(f != null)
        {
            if(i == 0)
                return f;
            i--;
        }
        view = new ImageView(b);
        view.setImageResource(a[i]);
        view.setLayoutParams(new android.widget.Gallery.LayoutParams(c, d));
        view.setScaleType(e);
        view.setBackgroundResource(0x7f020017);
        return view;
    }

    final int a[];
    private android.content.Context b;
    private int c;
    private int d;
    private android.widget.ImageView.ScaleType e;
    private android.widget.TextView f;
    private float g;
}
