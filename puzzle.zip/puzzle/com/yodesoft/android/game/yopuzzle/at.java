// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.view.View;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            n, ah

class at
    implements android.view.View.OnClickListener
{

    at(com.yodesoft.android.game.yopuzzle.n n1)
    {
        a = n1;
        super();
    }

    public void onClick(android.view.View view)
    {
        com.yodesoft.android.game.yopuzzle.n.j(a).b();
        com.yodesoft.android.game.yopuzzle.n.G(a);
    }

    final com.yodesoft.android.game.yopuzzle.n a;
}
