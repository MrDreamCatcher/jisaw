// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.view.View;
import android.widget.ViewFlipper;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            YoPuzzle, ah, a

class f
    implements android.view.View.OnClickListener
{

    f(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        a = yopuzzle;
        super();
    }

    public void onClick(android.view.View view)
    {
        a.a.b();
        switch(view.getId())
        {
        default:
            return;

        case 2131296326: 
            com.yodesoft.android.game.yopuzzle.YoPuzzle.b(a).showNext();
            return;

        case 2131296327: 
            if(a.c.f() && !com.yodesoft.android.game.yopuzzle.YoPuzzle.j(a))
            {
                com.yodesoft.android.game.yopuzzle.YoPuzzle.k(a);
                return;
            } else
            {
                com.yodesoft.android.game.yopuzzle.YoPuzzle.c(a, a.c.h());
                com.yodesoft.android.game.yopuzzle.YoPuzzle.a(a, false);
                return;
            }

        case 2131296270: 
            com.yodesoft.android.game.yopuzzle.YoPuzzle.b(a).showPrevious();
            return;

        case 2131296268: 
            if(com.yodesoft.android.game.yopuzzle.YoPuzzle.l(a) == 2)
            {
                com.yodesoft.android.game.yopuzzle.YoPuzzle.m(a);
                return;
            } else
            {
                com.yodesoft.android.game.yopuzzle.YoPuzzle.a(a, true);
                return;
            }

        case 2131296269: 
            com.yodesoft.android.game.yopuzzle.YoPuzzle.m(a);
            return;

        case 2131296259: 
            com.yodesoft.android.game.yopuzzle.YoPuzzle.o(com.yodesoft.android.game.yopuzzle.YoPuzzle.n(a));
            return;

        case 2131296328: 
            a.openOptionsMenu();
            return;

        case 2131296264: 
            com.yodesoft.android.game.yopuzzle.YoPuzzle.d(a, 0);
            return;

        case 2131296266: 
            com.yodesoft.android.game.yopuzzle.YoPuzzle.d(a, 1);
            return;

        case 2131296267: 
            com.yodesoft.android.game.yopuzzle.YoPuzzle.d(a, 2);
            return;

        case 2131296329: 
            com.yodesoft.android.game.yopuzzle.YoPuzzle.p(a);
            return;

        case 2131296262: 
            com.yodesoft.android.game.yopuzzle.YoPuzzle.a(a, com.yodesoft.android.game.yopuzzle.YoPuzzle.q(a), true);
            return;

        case 2131296260: 
            com.yodesoft.android.game.yopuzzle.YoPuzzle.a(a, com.yodesoft.android.game.yopuzzle.YoPuzzle.q(a), false);
            return;
        }
    }

    final com.yodesoft.android.game.yopuzzle.YoPuzzle a;
}
