// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.view.View;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            u, ai

class ba
    implements android.view.View.OnClickListener
{

    ba(com.yodesoft.android.game.yopuzzle.u u1, com.yodesoft.android.game.yopuzzle.ai ai1)
    {
        b = u1;
        a = ai1;
        super();
    }

    public void onClick(android.view.View view)
    {
        com.yodesoft.android.game.yopuzzle.u.b(b).onClick(a, -2);
        a.dismiss();
    }

    final com.yodesoft.android.game.yopuzzle.ai a;
    final com.yodesoft.android.game.yopuzzle.u b;
}
