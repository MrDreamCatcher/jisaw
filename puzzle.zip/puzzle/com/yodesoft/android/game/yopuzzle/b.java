// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.os.Handler;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            bb, w, a, av

final class b
    implements java.lang.Runnable
{

    b(com.yodesoft.android.game.yopuzzle.w w1, android.os.Handler handler)
    {
        a = w1;
        super();
        b = handler;
    }

    public void run()
    {
        android.os.Handler handler = b;
        com.yodesoft.android.game.yopuzzle.bb bb1 = new bb();
        boolean flag = false;
        int i = 0;
        do
        {
label0:
            {
                if(i < 3)
                {
                    flag = bb1.a(com.yodesoft.android.game.yopuzzle.w.a(a).j(), com.yodesoft.android.game.yopuzzle.w.b(a), a.g, com.yodesoft.android.game.yopuzzle.w.c(a), com.yodesoft.android.game.yopuzzle.w.d(a), com.yodesoft.android.game.yopuzzle.w.e(a).t, a.a, a.b, a.j, a.e, a.k, a.i);
                    if(!flag)
                        break label0;
                }
                if(flag)
                {
                    com.yodesoft.android.game.yopuzzle.w.a(a, a.g, a.h, a.j, 0, 0);
                    com.yodesoft.android.game.yopuzzle.w.a(a, 3);
                    com.yodesoft.android.game.yopuzzle.w.a(a, false);
                    handler.sendEmptyMessage(8);
                    return;
                } else
                {
                    com.yodesoft.android.game.yopuzzle.w.a(a, 1);
                    handler.sendEmptyMessage(9);
                    return;
                }
            }
            i++;
        } while(true);
    }

    final com.yodesoft.android.game.yopuzzle.w a;
    private android.os.Handler b;
}
