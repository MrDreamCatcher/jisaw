// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.ImageSwitcher;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            bj

class be
    implements android.view.View.OnClickListener
{

    be(com.yodesoft.android.game.yopuzzle.bj bj1)
    {
        a = bj1;
        super();
    }

    public void onClick(android.view.View view)
    {
        view = (android.widget.ImageSwitcher)view;
        com.yodesoft.android.game.yopuzzle.bj.a(a);
        if(com.yodesoft.android.game.yopuzzle.bj.b(a) < com.yodesoft.android.game.yopuzzle.bj.c(a).length)
        {
            view.setImageResource(com.yodesoft.android.game.yopuzzle.bj.c(a)[com.yodesoft.android.game.yopuzzle.bj.b(a)]);
            return;
        } else
        {
            view = new Message();
            view.what = 2;
            com.yodesoft.android.game.yopuzzle.bj.d(a).sendMessage(view);
            return;
        }
    }

    final com.yodesoft.android.game.yopuzzle.bj a;
}
