// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.net.Uri;
import android.webkit.CookieManager;
import com.yodesoft.android.game.yopuzzle.a.b;
import java.util.ArrayList;
import java.util.List;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.apache.http.HttpResponse;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

public class bb
{

    bb()
    {
        c = null;
    }

    public static java.lang.String a()
    {
        return com.yodesoft.android.game.yopuzzle.bb.f("name");
    }

    private void a(java.util.List list)
    {
        list.add(new BasicNameValuePair("ver", "1"));
    }

    public static void b()
    {
        java.lang.String s = com.yodesoft.android.game.yopuzzle.bb.f("ver");
        if(s == null || s.compareTo("1") != 0)
            com.yodesoft.android.game.yopuzzle.bb.b("ver", "1");
    }

    public static void b(java.lang.String s, java.lang.String s1)
    {
        android.webkit.CookieManager cookiemanager;
        java.lang.String s2;
        java.lang.StringBuilder stringbuilder;
        java.lang.String as[];
        int i;
        cookiemanager = android.webkit.CookieManager.getInstance();
        if(cookiemanager == null)
            return;
        s = (new StringBuilder()).append(s).append("=").toString();
        s1 = (new StringBuilder()).append(s).append(android.net.Uri.encode(s1)).toString();
        s2 = cookiemanager.getCookie("http://www.yopuzzle.com");
        stringbuilder = new StringBuilder();
        if(s2 == null)
        {
            cookiemanager.setCookie("http://www.yopuzzle.com", s1);
            return;
        }
        as = s2.split("; ");
        i = 0;
_L7:
        if(i >= as.length) goto _L2; else goto _L1
_L1:
        if(!as[i].startsWith(s)) goto _L4; else goto _L3
_L3:
        if(i <= -1) goto _L6; else goto _L5
_L4:
        i++;
          goto _L7
_L5:
        as[i] = s1;
        stringbuilder.delete(0, stringbuilder.length() - 1);
        for(i = 0; i < as.length; i++)
        {
            stringbuilder.append(as[i]);
            if(i < as.length - 1)
                stringbuilder.append("; ");
        }

        s = stringbuilder.toString();
_L8:
        cookiemanager.setCookie("http://www.yopuzzle.com", s);
        return;
_L6:
        s = (new StringBuilder()).append(s2).append("; ").append(s1).toString();
        if(true) goto _L8; else goto _L2
_L2:
        i = -1;
          goto _L3
    }

    public static java.lang.String f(java.lang.String s)
    {
        java.lang.Object obj = android.webkit.CookieManager.getInstance();
        if(obj == null)
            return null;
        obj = ((android.webkit.CookieManager) (obj)).getCookie("http://www.yopuzzle.com");
        if(obj == null)
            return null;
        java.lang.String as[] = ((java.lang.String) (obj)).split("; ");
        s = (new StringBuilder()).append(s).append("=").toString();
        int j = as.length;
        for(int i = 0; i < j; i++)
        {
            java.lang.String s1 = as[i];
            if(s1.startsWith(s))
                return android.net.Uri.decode(s1.substring(s1.indexOf("=") + 1));
        }

        return null;
    }

    public java.lang.String a(java.lang.String s)
    {
        if(b((new StringBuilder()).append("{\"module\":\"bottle\",\"action\":\"read\",\"id\":\"").append(s).append("\"}").toString()))
        {
            if(c.indexOf("(") == 0)
                c = c.substring(1, c.length() - 1);
            return c;
        } else
        {
            return null;
        }
    }

    public java.lang.String a(java.lang.String s, java.lang.String s1)
    {
        if(b((new StringBuilder()).append("{\"module\":\"update\",\"action\":\"check\",\"pkg\":\"").append(s).append("\",\"code\":\"").append(s1).append("\"}").toString()))
        {
            if(c.indexOf("(") == 0)
                c = c.substring(1, c.length() - 1);
            return c;
        } else
        {
            return null;
        }
    }

    public boolean a(java.lang.String s, int i, int j, int k, int l, java.lang.String s1, int i1, 
            int j1, int k1, int l1, int i2, int j2)
    {
        return b(java.lang.String.format("{\"module\":\"master\",\"action\":\"add\", \"authToken\":\"0\", \"album\":\"%s\", \"game\":\"%d\", \"mode\":\"%d\", \"score\":\"%d\", \"time\":\"%d\", \"name\":\"%s\", \"row\":\"%d\", \"col\":\"%d\", \"shape\":\"%d\", \"rotation\":\"%d\", \"style\":\"%d\", \"distortion\":\"%d\"}", new java.lang.Object[] {
            s, java.lang.Integer.valueOf(i), java.lang.Integer.valueOf(j), java.lang.Integer.valueOf(k), java.lang.Integer.valueOf(l), s1, java.lang.Integer.valueOf(i1), java.lang.Integer.valueOf(j1), java.lang.Integer.valueOf(k1), java.lang.Integer.valueOf(l1), 
            java.lang.Integer.valueOf(i2), java.lang.Integer.valueOf(j2)
        }));
    }

    public boolean b(java.lang.String s)
    {
        s = c(s);
        if(s == null)
            return false;
        else
            return s.contains("200 OK");
    }

    public java.lang.String c(java.lang.String s)
    {
        s = d(s);
        if(s == null)
            return null;
        org.apache.http.impl.client.DefaultHttpClient defaulthttpclient = new DefaultHttpClient();
        org.apache.http.client.methods.HttpPost httppost = new HttpPost("http://www.yopuzzle.com/api/request/");
        java.lang.Object obj = android.webkit.CookieManager.getInstance();
        if(obj != null)
            httppost.setHeader("Cookie", ((android.webkit.CookieManager) (obj)).getCookie("http://www.yopuzzle.com"));
        obj = new ArrayList();
        a(((java.util.List) (obj)));
        ((java.util.List) (obj)).add(new BasicNameValuePair("data", s));
        try
        {
            httppost.setEntity(new UrlEncodedFormEntity(((java.util.List) (obj)), "UTF-8"));
            s = defaulthttpclient.execute(httppost);
            c = org.apache.http.util.EntityUtils.toString(s.getEntity());
        }
        // Misplaced declaration of an exception variable
        catch(java.lang.String s)
        {
            s.printStackTrace();
            return null;
        }
        return s.getStatusLine().toString();
    }

    public java.lang.String d(java.lang.String s)
    {
        try
        {
            javax.crypto.Cipher cipher = javax.crypto.Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(1, new SecretKeySpec(b, "AES"), new IvParameterSpec(a));
            s = com.yodesoft.android.game.yopuzzle.a.b.a(cipher.doFinal(s.getBytes("utf-8")));
        }
        // Misplaced declaration of an exception variable
        catch(java.lang.String s)
        {
            s.printStackTrace();
            return null;
        }
        return s;
    }

    public java.lang.String e(java.lang.String s)
    {
        try
        {
            javax.crypto.Cipher cipher = javax.crypto.Cipher.getInstance("AES/CBC/PKCS5Padding");
            cipher.init(2, new SecretKeySpec(b, "AES"), new IvParameterSpec(a));
            s = new String(cipher.doFinal(com.yodesoft.android.game.yopuzzle.a.b.a(s)));
        }
        // Misplaced declaration of an exception variable
        catch(java.lang.String s)
        {
            s.printStackTrace();
            return null;
        }
        return s;
    }

    private static final byte a[] = {
        16, 74, 71, -80, 32, 101, -47, 72, 117, -14, 
        0, -29, 70, 65, -12, 74
    };
    private static final byte b[] = {
        -19, 83, 8, 60, 19, -89, -22, -100, 75, -33, 
        87, 72, 6, -80, -7, 55
    };
    private java.lang.String c;

}
