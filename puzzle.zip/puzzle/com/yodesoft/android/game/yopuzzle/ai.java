// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.app.Dialog;
import android.content.Context;

public class ai extends android.app.Dialog
{

    public ai(android.content.Context context)
    {
        super(context);
    }

    public ai(android.content.Context context, int i)
    {
        super(context, i);
    }
}
