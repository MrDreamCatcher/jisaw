// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            n, bk, av, a

class ao extends android.os.Handler
{

    ao(com.yodesoft.android.game.yopuzzle.n n1)
    {
        a = n1;
        super();
    }

    public void handleMessage(android.os.Message message)
    {
        message.what;
        JVM INSTR tableswitch 0 11: default 68
    //                   0 69
    //                   1 120
    //                   2 139
    //                   3 148
    //                   4 157
    //                   5 166
    //                   6 183
    //                   7 200
    //                   8 210
    //                   9 265
    //                   10 365
    //                   11 401;
           goto _L1 _L2 _L3 _L4 _L5 _L6 _L7 _L8 _L9 _L10 _L11 _L12 _L13
_L1:
        return;
_L2:
        if(com.yodesoft.android.game.yopuzzle.n.a(a) == 2)
        {
            com.yodesoft.android.game.yopuzzle.n.a(a, 0);
            return;
        } else
        {
            com.yodesoft.android.game.yopuzzle.n.b(a, 0);
            com.yodesoft.android.game.yopuzzle.n.c(a).postDelayed(com.yodesoft.android.game.yopuzzle.n.b(a), 350L);
            return;
        }
_L3:
        com.yodesoft.android.game.yopuzzle.n.a(a, 1);
        com.yodesoft.android.game.yopuzzle.n.d(a).b();
        return;
_L4:
        com.yodesoft.android.game.yopuzzle.n.a(a, 2);
        return;
_L5:
        a.b(true);
        return;
_L6:
        a.b(false);
        return;
_L7:
        android.widget.Toast.makeText(com.yodesoft.android.game.yopuzzle.n.e(a), 0x7f07003d, 0).show();
        return;
_L8:
        android.widget.Toast.makeText(com.yodesoft.android.game.yopuzzle.n.e(a), 0x7f07003e, 0).show();
        return;
_L9:
        com.yodesoft.android.game.yopuzzle.n.a(a, 7);
        return;
_L10:
        message = (android.widget.ViewFlipper)com.yodesoft.android.game.yopuzzle.n.f(a).findViewById(0x7f090031);
        if(message.getDisplayedChild() != 0)
            message.setDisplayedChild(0);
        if(com.yodesoft.android.game.yopuzzle.n.g(a))
        {
            android.widget.Toast.makeText(com.yodesoft.android.game.yopuzzle.n.e(a), 0x7f07002f, 0).show();
            return;
        }
        continue; /* Loop/switch isn't completed */
_L11:
        if(com.yodesoft.android.game.yopuzzle.n.g(a))
        {
            message = (android.widget.ViewFlipper)com.yodesoft.android.game.yopuzzle.n.f(a).findViewById(0x7f090031);
            android.widget.Toast.makeText(com.yodesoft.android.game.yopuzzle.n.e(a), 0x7f070030, 0).show();
            com.yodesoft.android.game.yopuzzle.n.f(a).findViewById(0x7f090038).setEnabled(true);
            if(message.getDisplayedChild() != 1)
            {
                ((android.widget.EditText)com.yodesoft.android.game.yopuzzle.n.f(a).findViewById(0x7f090037)).setText(com.yodesoft.android.game.yopuzzle.n.h(a).t);
                message.setDisplayedChild(1);
                return;
            }
        }
        if(true) goto _L1; else goto _L12
_L12:
        ((android.widget.TextView)com.yodesoft.android.game.yopuzzle.n.f(a).findViewById(0x7f09003b)).setText((java.lang.String)message.obj);
        com.yodesoft.android.game.yopuzzle.n.i(a).o();
        return;
_L13:
        if(com.yodesoft.android.game.yopuzzle.n.g(a))
        {
            android.widget.Toast.makeText(com.yodesoft.android.game.yopuzzle.n.e(a), 0x7f070073, 0).show();
            return;
        }
        if(true) goto _L1; else goto _L14
_L14:
    }

    final com.yodesoft.android.game.yopuzzle.n a;
}
