// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Random;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            j, ax, d, af, 
//            av, a, w, bg, 
//            ad, ah, n, o

class bk extends android.view.View
{

    bk(android.content.Context context)
    {
        super(context);
        w = 0;
        x = 0;
        r = true;
        C = true;
        o = new Path();
        l = new Paint();
        l.setStrokeWidth(0.0F);
        l.setStyle(android.graphics.Paint.Style.FILL);
        e = new d();
        f = new af();
        k = 0;
        h = com.yodesoft.android.game.yopuzzle.av.a(context);
        j = com.yodesoft.android.game.yopuzzle.a.a(context);
        s = new BlurMaskFilter(1.0F, android.graphics.BlurMaskFilter.Blur.INNER);
    }

    public android.graphics.Bitmap a(android.graphics.Bitmap bitmap)
    {
        int i1 = bitmap.getHeight();
        android.graphics.Bitmap bitmap1 = android.graphics.Bitmap.createBitmap(bitmap.getWidth(), i1, android.graphics.Bitmap.Config.RGB_565);
        android.graphics.Canvas canvas = new Canvas(bitmap1);
        android.graphics.Paint paint = new Paint();
        android.graphics.ColorMatrix colormatrix = new ColorMatrix();
        colormatrix.setSaturation(0.0F);
        paint.setColorFilter(new ColorMatrixColorFilter(colormatrix));
        canvas.drawBitmap(bitmap, 0.0F, 0.0F, paint);
        return bitmap1;
    }

    public void a()
    {
        b();
    }

    public void a(int i1, int j1)
    {
        o.reset();
        e.c();
        m = j.a();
        if(a)
            f.a(e.a, w, i.k, m, i.a, i.b, i.e, x);
        else
            f.a(e.a, i.j, i.k, m, i.a, i.b, i.e, i.i);
        p = (i1 - m.getWidth()) / 2;
        q = (j1 - m.getHeight()) / 2;
    }

    protected void a(android.graphics.Canvas canvas, android.graphics.Paint paint, java.util.ArrayList arraylist)
    {
        paint.setStyle(android.graphics.Paint.Style.STROKE);
        paint.setStrokeWidth(4F);
        paint.setAntiAlias(true);
        paint.setColor(0xccffffff);
        paint.setMaskFilter(s);
        if(o.isEmpty())
        {
            int j1 = arraylist.size();
            for(int i1 = 0; i1 < j1; i1++)
            {
                com.yodesoft.android.game.yopuzzle.bg bg1 = (com.yodesoft.android.game.yopuzzle.bg)arraylist.get(i1);
                o.moveTo(bg1.s.a, bg1.s.b);
                f.a(o, i.j, bg1.s.a, bg1.s.b, bg1.t.a, bg1.t.b, -bg1.s.c, bg1.s.e, bg1.f);
                f.a(o, i.j, bg1.t.a, bg1.t.b, bg1.u.a, bg1.u.b, -bg1.t.d, bg1.t.f, bg1.g);
                f.a(o, i.j, bg1.u.a, bg1.u.b, bg1.v.a, bg1.v.b, bg1.v.c, bg1.v.e, bg1.f);
                f.a(o, i.j, bg1.v.a, bg1.v.b, bg1.s.a, bg1.s.b, bg1.s.d, bg1.s.f, bg1.g);
                o.close();
            }

        }
        canvas.drawPath(o, paint);
        paint.setMaskFilter(null);
    }

    public void a(boolean flag, int i1, com.yodesoft.android.game.yopuzzle.n n1)
    {
        y = n1;
        g = com.yodesoft.android.game.yopuzzle.ah.a(getContext());
        j.l();
        j.c(k);
        if(i == null)
            i = new w(getContext(), k);
        if(flag)
        {
            i.a(i1);
            if(j.f() && !h.u)
                h.d();
        } else
        {
            i.a();
            if(i.e())
            {
                i.f();
                return;
            }
        }
    }

    protected boolean a(int i1, android.view.KeyEvent keyevent)
    {
        if(i1 != 22) goto _L2; else goto _L1
_L1:
        w = w + 1;
        if(w > 40)
            w = 0;
_L4:
        android.util.Log.d("-----", (new StringBuilder()).append("shape:").append(w).toString());
        android.util.Log.d("-----", (new StringBuilder()).append("distortion:").append(x).toString());
        android.util.Log.d("-----", "-----");
        a(b, c);
        return true;
_L2:
        if(i1 == 21)
        {
            w = w - 1;
            if(w < 0)
                w = 40;
            continue; /* Loop/switch isn't completed */
        }
        if(i1 == 19)
        {
            x = x + 1;
            if(x > 7)
                x = 0;
            continue; /* Loop/switch isn't completed */
        }
        if(i1 != 20)
            break; /* Loop/switch isn't completed */
        x = x - 1;
        if(x < 0)
            x = 7;
        if(true) goto _L4; else goto _L3
_L3:
        if(i1 == 8)
        {
            boolean flag;
            if(!t)
                flag = true;
            else
                flag = false;
            t = flag;
            invalidate();
            return true;
        }
        if(i1 == 9)
        {
            boolean flag1;
            if(!v)
                flag1 = true;
            else
                flag1 = false;
            v = flag1;
            invalidate();
            return true;
        }
        if(i1 == 10)
        {
            boolean flag2;
            if(!u)
                flag2 = true;
            else
                flag2 = false;
            u = flag2;
            invalidate();
            return true;
        } else
        {
            return false;
        }
    }

    public int[] a(int i1)
    {
        java.util.Random random = new Random();
        int ai[] = new int[i1];
        for(int j1 = 0; j1 < i1; j1++)
            ai[j1] = j1;

        for(int k1 = 0; k1 < i1; k1++)
        {
            int l1 = random.nextInt(i1);
            int i2 = random.nextInt(i1);
            int j2 = ai[l1];
            ai[l1] = ai[i2];
            ai[i2] = j2;
        }

        return ai;
    }

    protected void b()
    {
        a(b, c);
        g.a();
        g();
        if(y != null)
            y.c();
    }

    protected void b(android.graphics.Canvas canvas, android.graphics.Paint paint, java.util.ArrayList arraylist)
    {
        paint.setStyle(android.graphics.Paint.Style.STROKE);
        paint.setStrokeWidth(1.0F);
        paint.setAntiAlias(true);
        int j1 = arraylist.size();
        if(t)
            a(canvas, paint, arraylist);
        if(v)
        {
            for(int i1 = 0; i1 < j1; i1++)
            {
                com.yodesoft.android.game.yopuzzle.bg bg1 = (com.yodesoft.android.game.yopuzzle.bg)arraylist.get(i1);
                paint.setColor(0xff0000ff);
                canvas.drawRect(bg1.A, paint);
            }

        }
        if(d != null && u)
        {
            l.setColor(0xff00ff00);
            float f1 = d.m;
            float f2 = d.n;
            float f3 = d.m;
            float f4 = d.o;
            float f5 = d.n;
            canvas.drawRect(f1, f2, f4 + f3, (float)d.p + f5, paint);
            paint.setColor(0xff0000ff);
            canvas.drawRect(d.A, paint);
            paint.setColor(0xff00ffff);
            canvas.drawRect(d.B, paint);
            l.setColor(-256);
            paint.setStrokeWidth(2.0F);
            canvas.drawPoint(d.m + (float)d.q, d.n + (float)d.r, paint);
        }
        paint.setTextSize(16F);
        paint.setStyle(android.graphics.Paint.Style.FILL);
        canvas.drawText((new StringBuilder()).append("shape:").append(w).append(" distortion:").append(x).toString(), 0.0F, 16F, paint);
    }

    public void c()
    {
        if(y != null)
            y.i();
    }

    public void d()
    {
        g.c();
        if(y != null)
            y.d();
    }

    public void e()
    {
        e.c();
        if(n != null)
        {
            n.recycle();
            n = null;
        }
    }

    public void f()
    {
        java.util.Random random;
        java.util.ArrayList arraylist;
        java.lang.Object obj;
        int ai[];
        int j1;
        int k1;
        int i3;
        int j3;
        int i6;
        random = new Random();
        java.util.ArrayList arraylist1 = e.a;
        k1 = arraylist1.size();
        if(C)
        {
            int l1 = b / 2;
            int i1 = c / 2;
            if(c > b)
                i1 = c;
            else
                i1 = b;
            i1 /= 2;
            for(java.util.Iterator iterator = e.a.iterator(); iterator.hasNext();)
            {
                com.yodesoft.android.game.yopuzzle.bg bg1 = (com.yodesoft.android.game.yopuzzle.bg)iterator.next();
                float f1 = (float)java.lang.Math.toRadians(random.nextInt(180));
                bg1.m = (int)(java.lang.Math.cos(f1) * (double)b) + l1;
                bg1.n = 0 - (int)(java.lang.Math.sin(f1) * (double)i1);
            }

            B.a(2000);
            C = false;
        } else
        {
            B.a(600);
        }
        java.util.Collections.sort(arraylist1, A);
        arraylist = z;
        arraylist.clear();
        obj = B;
        obj = com.yodesoft.android.game.yopuzzle.ax.a;
        ((java.util.ArrayList) (obj)).clear();
        B.a(this);
        j1 = 0;
        while(j1 < k1) 
        {
            com.yodesoft.android.game.yopuzzle.bg bg2 = (com.yodesoft.android.game.yopuzzle.bg)arraylist1.get(j1);
            if(bg2.j.size() <= 0)
            {
                arraylist.add(bg2);
                com.yodesoft.android.game.yopuzzle.o o1 = new o();
                o1.a = bg2;
                o1.b = bg2.m;
                o1.d = bg2.n;
                ((java.util.ArrayList) (obj)).add(o1);
            }
            j1++;
        }
        ai = a(arraylist.size());
        i6 = i.b;
        i3 = i.a;
        j1 = m.getWidth();
        k1 = m.getHeight();
        j3 = j1 / i6;
        k1 /= i3;
        if(h.n) goto _L2; else goto _L1
_L1:
        int k4;
        int l4;
        k4 = c;
        l4 = h.p;
        j1 = 0;
        k1 = 0;
_L7:
        if(k1 < i3)
        {
            int i2 = 0;
            do
            {
                if(i2 >= i6 || j1 >= ai.length)
                {
                    k1++;
                    continue; /* Loop/switch isn't completed */
                }
                int k2 = ai[j1];
                com.yodesoft.android.game.yopuzzle.bg bg3 = (com.yodesoft.android.game.yopuzzle.bg)arraylist.get(k2);
                com.yodesoft.android.game.yopuzzle.o o2 = (com.yodesoft.android.game.yopuzzle.o)((java.util.ArrayList) (obj)).get(k2);
                int i5 = bg3.o / 4;
                k2 = (i2 * j3 + random.nextInt(i5)) - i5;
                if(k2 < 0)
                    k2 = random.nextInt(i5);
                o2.c = k2;
                o2.e = k4 - l4 - (bg3.p / 2) * (k1 + 2);
                o2.a();
                o2.b();
                i2++;
                j1++;
            } while(true);
        } else
        {
            arraylist.clear();
            B.a();
            return;
        }
_L2:
        int j2;
        int l2;
        int j5;
        int j6;
        k4 = (b - j1) / 2;
        l4 = c - h.p - k1;
        l2 = b;
        j6 = ai.length / 2;
        j5 = i3 - 1;
        k1 = j1 + k4;
        j2 = 0;
        i3 = l4;
        j1 = l2;
_L4:
        int k5;
        if(j5 < 0)
            break MISSING_BLOCK_LABEL_952;
        int k3 = j1;
        k5 = i6 - 1;
        j1 = k1;
        k1 = k3;
_L5:
label0:
        {
            if(k5 >= 0 && j2 < ai.length)
                break label0;
            j5--;
            int l3 = j1;
            j1 = k1;
            k1 = l3;
        }
        if(true) goto _L4; else goto _L3
_L3:
        com.yodesoft.android.game.yopuzzle.bg bg4;
        com.yodesoft.android.game.yopuzzle.o o3;
        int i4;
        int l5;
        if(j2 == j6)
        {
            l2 = l4;
            i3 = k4;
            j1 = k4;
            k1 = 0;
        } else
        {
            int j4 = j1;
            j1 = l2;
            l2 = i3;
            i3 = j1;
            j1 = k1;
            k1 = j4;
        }
        i4 = ai[j2];
        bg4 = (com.yodesoft.android.game.yopuzzle.bg)arraylist.get(i4);
        o3 = (com.yodesoft.android.game.yopuzzle.o)((java.util.ArrayList) (obj)).get(i4);
        l5 = i3 - bg4.o;
        i3 = l2;
        i4 = l5;
        if(l5 < k1)
        {
            i4 = j1 - bg4.o;
            i3 = l2 - bg4.p;
        }
        if(i3 < 0)
        {
            l5 = j1 - k1 - bg4.o;
            l2 = l5;
            if(l5 <= 10)
                l2 = 10;
            o3.c = random.nextInt(l2) + k1;
            o3.e = l4 - (bg4.p / 2) * (random.nextInt(j5 + 1) + 2);
        } else
        {
            o3.c = i4;
            o3.e = i3;
        }
        o3.a();
        o3.b();
        k5--;
        l5 = j2 + 1;
        l2 = i4;
        j2 = k1;
        k1 = j1;
        j1 = j2;
        j2 = l5;
          goto _L5
          goto _L4
        arraylist.clear();
        B.a();
        return;
        if(true) goto _L7; else goto _L6
_L6:
    }

    public void g()
    {
        if(r)
        {
            C = true;
            f();
            return;
        }
        java.util.Random random = new Random();
        java.lang.Object obj1 = e.a;
        java.lang.Object obj = B;
        obj = com.yodesoft.android.game.yopuzzle.ax.a;
        ((java.util.ArrayList) (obj)).clear();
        int j1 = b / 2;
        int i1 = c / 2;
        if(c > b)
            i1 = c;
        else
            i1 = b;
        i1 /= 2;
        obj1 = ((java.util.ArrayList) (obj1)).iterator();
        do
        {
            if(!((java.util.Iterator) (obj1)).hasNext())
                break;
            com.yodesoft.android.game.yopuzzle.bg bg1 = (com.yodesoft.android.game.yopuzzle.bg)((java.util.Iterator) (obj1)).next();
            if(bg1 != null)
            {
                com.yodesoft.android.game.yopuzzle.o o1 = new o();
                float f1 = (float)java.lang.Math.toRadians(random.nextInt(180));
                o1.a = bg1;
                o1.b = (int)(java.lang.Math.cos(f1) * (double)b) + j1;
                o1.d = 0 - (int)(java.lang.Math.sin(f1) * (double)i1);
                o1.c = bg1.m;
                o1.e = bg1.n;
                o1.a();
                o1.b();
                ((java.util.ArrayList) (obj)).add(o1);
            }
        } while(true);
        B.a(2000);
        C = false;
        B.a(this);
        B.a();
    }

    public boolean onKeyDown(int i1, android.view.KeyEvent keyevent)
    {
        if(f != null)
        {
            if(i1 == 32)
            {
                boolean flag;
                if(!a)
                    flag = true;
                else
                    flag = false;
                a = flag;
                invalidate();
                return true;
            }
            if(a)
                a(i1, keyevent);
        }
        if(y != null)
            return y.a(i1, keyevent);
        else
            return false;
    }

    public void onSizeChanged(int i1, int j1, int k1, int l1)
    {
        b = i1;
        c = j1;
    }

    public boolean onTouchEvent(android.view.MotionEvent motionevent)
    {
        if(y != null)
            return y.a(motionevent);
        else
            return false;
    }

    private final java.util.Comparator A = new j();
    private final com.yodesoft.android.game.yopuzzle.ax B = new ax();
    private boolean C;
    protected boolean a;
    protected int b;
    protected int c;
    protected com.yodesoft.android.game.yopuzzle.bg d;
    protected com.yodesoft.android.game.yopuzzle.d e;
    protected com.yodesoft.android.game.yopuzzle.af f;
    protected com.yodesoft.android.game.yopuzzle.ah g;
    protected com.yodesoft.android.game.yopuzzle.av h;
    protected com.yodesoft.android.game.yopuzzle.w i;
    protected com.yodesoft.android.game.yopuzzle.a j;
    protected int k;
    protected android.graphics.Paint l;
    protected android.graphics.Bitmap m;
    protected android.graphics.Bitmap n;
    protected android.graphics.Path o;
    protected int p;
    protected int q;
    protected boolean r;
    protected android.graphics.BlurMaskFilter s;
    private boolean t;
    private boolean u;
    private boolean v;
    private int w;
    private int x;
    private com.yodesoft.android.game.yopuzzle.n y;
    private final java.util.ArrayList z = new ArrayList();
}
