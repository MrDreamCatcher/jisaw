// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.webkit.WebView;
import android.webkit.WebViewClient;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            al

public class am extends android.webkit.WebViewClient
{

    public am(com.yodesoft.android.game.yopuzzle.al al1)
    {
        a = al1;
        super();
    }

    public void onPageFinished(android.webkit.WebView webview, java.lang.String s)
    {
        if(com.yodesoft.android.game.yopuzzle.al.a(a) != com.yodesoft.android.game.yopuzzle.al.b(a))
        {
            com.yodesoft.android.game.yopuzzle.al.c(a).clearHistory();
            com.yodesoft.android.game.yopuzzle.al.a(a, com.yodesoft.android.game.yopuzzle.al.b(a));
        }
    }

    public boolean shouldOverrideUrlLoading(android.webkit.WebView webview, java.lang.String s)
    {
        return false;
    }

    final com.yodesoft.android.game.yopuzzle.al a;
}
