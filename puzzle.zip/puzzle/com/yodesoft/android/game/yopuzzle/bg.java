// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.graphics.Bitmap;
import android.graphics.Matrix;
import android.graphics.Rect;
import java.util.ArrayList;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            ad

public class bg
{

    bg(int i1, int j1)
    {
        j = new ArrayList();
        k = 0;
        l = 0;
        b = i1;
        c = j1;
        B = new Rect();
    }

    void a()
    {
        C = m;
        D = n;
        int i1 = j.size();
        if(i1 > 0)
        {
            i1--;
            do
            {
                if(i1 < 0)
                    break;
                com.yodesoft.android.game.yopuzzle.bg bg1 = (com.yodesoft.android.game.yopuzzle.bg)j.get(i1);
                a(bg1);
                int j1 = i1 - 1;
                if(bg1.m < C)
                    C = bg1.m;
                i1 = j1;
                if(bg1.n < D)
                {
                    D = bg1.n;
                    i1 = j1;
                }
            } while(true);
        }
    }

    void a(int i1)
    {
        b(i1);
        int j1 = j.size();
        if(j1 > 0)
            for(j1--; j1 >= 0; j1--)
            {
                com.yodesoft.android.game.yopuzzle.bg bg1 = (com.yodesoft.android.game.yopuzzle.bg)j.get(j1);
                bg1.b(i1);
                a(bg1);
            }

    }

    void a(com.yodesoft.android.game.yopuzzle.bg bg1)
    {
        float f1 = m + (float)q;
        float f2 = n + (float)r;
        if(d > bg1.d)
            bg1.m = f1 - (float)(d - bg1.d) - (float)bg1.q;
        else
            bg1.m = (f1 + (float)(bg1.d - d)) - (float)bg1.q;
        if(e > bg1.e)
            bg1.n = f2 - (float)(e - bg1.e) - (float)bg1.r;
        else
            bg1.n = ((float)(bg1.e - e) + f2) - (float)bg1.r;
        B.union(bg1.A);
    }

    public void b()
    {
        B.set(A);
    }

    public void b(int i1)
    {
        while(h == null || k == i1) 
            return;
        java.lang.Object obj;
        if(i1 == 90 || i1 == 270)
        {
            int j1 = A.width() / 2;
            int l1 = A.height() / 2;
            float f1 = m;
            m = (float)j1 + f1;
            n = n + (float)l1;
            j1 = A.height() / 2;
            l1 = A.width() / 2;
            m = m - (float)j1;
            n = n - (float)l1;
        } else
        {
            int k1 = A.height() / 2;
            int i2 = A.width() / 2;
            float f2 = m;
            m = (float)k1 + f2;
            n = n + (float)i2;
            k1 = A.width() / 2;
            i2 = A.height() / 2;
            m = m - (float)k1;
            n = n - (float)i2;
        }
        if(i1 != 0) goto _L2; else goto _L1
_L1:
        o = A.width();
        p = A.height();
        d = s.a;
        e = s.b;
        q = d - A.left;
        r = e - A.top;
_L4:
        obj = new Matrix();
        ((android.graphics.Matrix) (obj)).postRotate(i1);
        obj = android.graphics.Bitmap.createBitmap(i, 0, 0, i.getWidth(), i.getHeight(), ((android.graphics.Matrix) (obj)), true);
        h.recycle();
        h = ((android.graphics.Bitmap) (obj));
        k = i1;
        return;
_L2:
        if(i1 == 90)
        {
            o = A.height();
            p = A.width();
            d = F - v.b;
            e = v.a;
            q = d - (F - A.bottom);
            r = e - A.left;
        } else
        if(i1 == 180)
        {
            o = A.width();
            p = A.height();
            d = E - u.a;
            e = F - u.b;
            q = d - (E - A.right);
            r = e - (F - A.bottom);
        } else
        if(i1 == 270)
        {
            o = A.height();
            p = A.width();
            d = t.b;
            e = E - t.a;
            q = d - A.top;
            r = e - (E - A.right);
        }
        if(true) goto _L4; else goto _L3
_L3:
    }

    void b(com.yodesoft.android.game.yopuzzle.bg bg1)
    {
        int i1 = bg1.j.size();
        if(i1 > 0)
            for(i1--; i1 >= 0; i1--)
            {
                com.yodesoft.android.game.yopuzzle.bg bg2 = (com.yodesoft.android.game.yopuzzle.bg)bg1.j.get(i1);
                a(bg2);
                j.add(bg2);
            }

        a(bg1);
        j.add(bg1);
    }

    public android.graphics.Rect A;
    public android.graphics.Rect B;
    public float C;
    public float D;
    public int E;
    public int F;
    public int a;
    public int b;
    public int c;
    public int d;
    public int e;
    public int f;
    public int g;
    public android.graphics.Bitmap h;
    public android.graphics.Bitmap i;
    public java.util.ArrayList j;
    public int k;
    public int l;
    public float m;
    public float n;
    public int o;
    public int p;
    public int q;
    public int r;
    public com.yodesoft.android.game.yopuzzle.ad s;
    public com.yodesoft.android.game.yopuzzle.ad t;
    public com.yodesoft.android.game.yopuzzle.ad u;
    public com.yodesoft.android.game.yopuzzle.ad v;
    public boolean w;
    public boolean x;
    public boolean y;
    public boolean z;
}
