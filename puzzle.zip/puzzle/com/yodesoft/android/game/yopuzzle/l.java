// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.graphics.Bitmap;
import android.os.Handler;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            a

final class l
    implements java.lang.Runnable
{

    l(com.yodesoft.android.game.yopuzzle.a a1, int i)
    {
        b = a1;
        super();
        a = i;
    }

    public void run()
    {
        int i = a;
        android.os.Handler handler = com.yodesoft.android.game.yopuzzle.a.a(b);
        handler.sendMessage(handler.obtainMessage(0));
        if(com.yodesoft.android.game.yopuzzle.a.b(b) != null)
        {
            com.yodesoft.android.game.yopuzzle.a.b(b).recycle();
            com.yodesoft.android.game.yopuzzle.a.a(b, null);
        }
        android.graphics.Bitmap bitmap;
        if(com.yodesoft.android.game.yopuzzle.a.c(b))
            bitmap = com.yodesoft.android.game.yopuzzle.a.d(b);
        else
        if(com.yodesoft.android.game.yopuzzle.a.e(b) == 0)
            bitmap = com.yodesoft.android.game.yopuzzle.a.a(b, i);
        else
        if(com.yodesoft.android.game.yopuzzle.a.e(b) == 1)
            bitmap = com.yodesoft.android.game.yopuzzle.a.b(b, i);
        else
            bitmap = com.yodesoft.android.game.yopuzzle.a.c(b, i);
        if(bitmap == null)
        {
            handler.sendMessage(handler.obtainMessage(2));
            return;
        }
        if(bitmap.getWidth() != com.yodesoft.android.game.yopuzzle.a.f(b))
        {
            com.yodesoft.android.game.yopuzzle.a.a(b, android.graphics.Bitmap.createScaledBitmap(bitmap, com.yodesoft.android.game.yopuzzle.a.f(b), com.yodesoft.android.game.yopuzzle.a.g(b), true));
            bitmap.recycle();
        } else
        {
            com.yodesoft.android.game.yopuzzle.a.a(b, bitmap);
        }
        handler.sendMessage(handler.obtainMessage(1));
    }

    final int a;
    final com.yodesoft.android.game.yopuzzle.a b;
}
