// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import java.util.ArrayList;
import java.util.Comparator;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            bg

public class j
    implements java.util.Comparator
{

    public j()
    {
    }

    public int compare(java.lang.Object obj, java.lang.Object obj1)
    {
        obj = (com.yodesoft.android.game.yopuzzle.bg)obj;
        obj1 = (com.yodesoft.android.game.yopuzzle.bg)obj1;
        int i = ((com.yodesoft.android.game.yopuzzle.bg) (obj)).j.size();
        int k = ((com.yodesoft.android.game.yopuzzle.bg) (obj1)).j.size();
        if(i < k)
            return 1;
        return i <= k ? 0 : -1;
    }
}
