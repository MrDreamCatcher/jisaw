// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ViewFlipper;

public class FixedViewFlipper extends android.widget.ViewFlipper
{

    public FixedViewFlipper(android.content.Context context)
    {
        super(context);
    }

    public FixedViewFlipper(android.content.Context context, android.util.AttributeSet attributeset)
    {
        super(context, attributeset);
    }

    public void onDetachedFromWindow()
    {
        try
        {
            super.onDetachedFromWindow();
            return;
        }
        catch(java.lang.Exception exception)
        {
            stopFlipping();
        }
    }
}
