// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.view.View;
import android.widget.ImageView;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            bj

class bd
    implements android.widget.ViewSwitcher.ViewFactory
{

    bd(com.yodesoft.android.game.yopuzzle.bj bj1)
    {
        a = bj1;
        super();
    }

    public android.view.View makeView()
    {
        android.widget.ImageView imageview = new ImageView(com.yodesoft.android.game.yopuzzle.bj.e(a));
        imageview.setBackgroundColor(0);
        imageview.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
        imageview.setLayoutParams(new android.widget.FrameLayout.LayoutParams(-1, -1));
        return imageview;
    }

    final com.yodesoft.android.game.yopuzzle.bj a;
}
