// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;


public final class p
{

    p()
    {
        l = null;
        m = null;
    }

    p(java.lang.String s, java.lang.String s1, int i1, int j1, int k1, int l1, int i2, 
            int j2, int k2, int l2, int i3)
    {
        a = s;
        b = s1;
        c = i1;
        d = j1;
        e = k1;
        i = l1;
        j = i2;
        f = j2;
        g = k2;
        h = l2;
        k = i3;
        l = null;
        m = null;
    }

    public java.lang.String a;
    public java.lang.String b;
    public int c;
    public int d;
    public int e;
    public int f;
    public int g;
    public int h;
    public int i;
    public int j;
    public int k;
    public java.lang.String l;
    public java.lang.String m;
}
