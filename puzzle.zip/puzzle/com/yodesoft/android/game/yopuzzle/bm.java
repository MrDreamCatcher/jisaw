// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import java.util.ArrayList;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            bk, bg, d, w, 
//            ah, af

class bm extends com.yodesoft.android.game.yopuzzle.bk
{

    bm(android.content.Context context)
    {
        super(context);
        w = new ArrayList();
        k = 1;
    }

    private void c(android.graphics.Canvas canvas, android.graphics.Paint paint, java.util.ArrayList arraylist)
    {
        int k = w.size();
        for(int i = 0; i < k; i++)
        {
            paint = (com.yodesoft.android.game.yopuzzle.bg)w.get(i);
            canvas.drawBitmap(((com.yodesoft.android.game.yopuzzle.bg) (paint)).h, ((com.yodesoft.android.game.yopuzzle.bg) (paint)).m, ((com.yodesoft.android.game.yopuzzle.bg) (paint)).n, null);
        }

        k = arraylist.size();
        for(int j = 0; j < k; j++)
        {
            paint = (com.yodesoft.android.game.yopuzzle.bg)arraylist.get(j);
            canvas.drawBitmap(((com.yodesoft.android.game.yopuzzle.bg) (paint)).h, ((com.yodesoft.android.game.yopuzzle.bg) (paint)).m, ((com.yodesoft.android.game.yopuzzle.bg) (paint)).n, null);
        }

    }

    public void a(int i, int j)
    {
        w.clear();
        super.a(i, j);
        f();
    }

    public void onDraw(android.graphics.Canvas canvas)
    {
        canvas.save();
        canvas.translate(p, q);
        a(canvas, l, e.a);
        canvas.restore();
        c(canvas, null, e.a);
        if(a)
            b(canvas, l, e.a);
    }

    public boolean onTouchEvent(android.view.MotionEvent motionevent)
    {
        float f;
        float f1;
        if(super.onTouchEvent(motionevent))
            return true;
        f = motionevent.getX();
        f1 = motionevent.getY();
        motionevent.getAction();
        JVM INSTR tableswitch 0 2: default 52
    //                   0 58
    //                   1 138
    //                   2 546;
           goto _L1 _L2 _L3 _L4
_L1:
        invalidate();
        return true;
_L2:
        d = e.a(f, f1);
        if(d != null)
        {
            t = true;
            u = f - d.m;
            v = f1 - d.n;
            d.m = f - u;
            d.n = f1 - v;
        }
        continue; /* Loop/switch isn't completed */
_L3:
        if(d != null)
        {
            d.m = f - u;
            d.n = f1 - v;
            if(this.i.e != 0 && motionevent.getEventTime() - motionevent.getDownTime() <= 150L)
            {
                int k = d.k + 90;
                int i = k;
                if(k > 270)
                    i = 0;
                g.e();
                d.b(i);
                this.f.a(d, this.i.k);
            }
            f = d.m;
            f1 = d.n;
            d.m = d.m - (float)p;
            d.n = d.n - (float)q;
            motionevent = e.a(d, this.i.f);
            if(motionevent != null)
            {
                d.m = d.m + (float)p;
                d.n = d.n + (float)q;
                w.add(motionevent);
                g.d();
                if(e.b())
                {
                    int l = m.getWidth();
                    int j = m.getHeight();
                    l = (b - l) / 2;
                    j = (c - j) / 2;
                    d.m = l + (d.d - d.q);
                    d.n = j + (d.e - d.r);
                    d.a();
                    d();
                }
                invalidate();
            } else
            {
                d.m = f;
                d.n = f1;
            }
            c();
            d = null;
            t = false;
        }
        continue; /* Loop/switch isn't completed */
_L4:
        if(t && d != null)
        {
            d.m = f - u;
            d.n = f1 - v;
        }
        if(true) goto _L1; else goto _L5
_L5:
    }

    private boolean t;
    private float u;
    private float v;
    private java.util.ArrayList w;
}
