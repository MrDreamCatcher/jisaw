// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Handler;
import android.preference.PreferenceManager;
import java.util.Random;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            v

class av
{

    private av(android.content.Context context)
    {
        A = android.preference.PreferenceManager.getDefaultSharedPreferences(context);
        B = context;
        C = B.getResources();
        D = new Random();
    }

    static android.content.Context a(com.yodesoft.android.game.yopuzzle.av av1)
    {
        return av1.B;
    }

    public static com.yodesoft.android.game.yopuzzle.av a(android.content.Context context)
    {
        if(w == null)
            w = new av(context);
        return w;
    }

    static void a(com.yodesoft.android.game.yopuzzle.av av1, java.lang.String s1)
    {
        av1.b(s1);
    }

    public static boolean a(int i1)
    {
        return i1 > 0 && i1 < 8;
    }

    private void b(java.lang.String s1)
    {
        if(s1 == null)
        {
            return;
        } else
        {
            y = s1;
            s1 = A.edit();
            s1.putLong("cu_lasttime", java.lang.System.currentTimeMillis());
            s1.commit();
            return;
        }
    }

    private void i()
    {
        switch(j)
        {
        default:
            return;

        case 0: // '\0'
            l = 3;
            k = 3;
            return;

        case 1: // '\001'
            l = 3;
            k = 4;
            return;

        case 2: // '\002'
            l = 4;
            k = 4;
            return;

        case 3: // '\003'
            l = 4;
            k = 5;
            return;

        case 4: // '\004'
            l = 5;
            k = 5;
            return;

        case 5: // '\005'
            l = 5;
            k = 6;
            return;

        case 6: // '\006'
            l = 6;
            k = 6;
            return;

        case 7: // '\007'
            l = 6;
            k = 7;
            // fall through

        case 8: // '\b'
            l = 7;
            break;
        }
        k = 7;
    }

    private boolean j()
    {
        return java.lang.System.currentTimeMillis() - z >= 0x5265c00L;
    }

    public void a()
    {
        d = A.getBoolean("show_toolbar", true);
        e = A.getBoolean("show_time", true);
        b = A.getBoolean("enable_sound", true);
        c = A.getBoolean("enable_vibrate", true);
        f = A.getInt("game_bg", 0);
        u = A.getBoolean("played_online", false);
        v = A.getBoolean("rated_game", false);
        x = A.getInt("yopu_tc", 0);
        t = A.getString("master_name", "");
        y = "";
        z = A.getLong("cu_lasttime", 0L);
        b();
    }

    public void a(int i1, int j1, int k1, int l1)
    {
        g = i1;
        h = j1;
        i = k1;
        j = l1;
        i();
        android.content.SharedPreferences.Editor editor = A.edit();
        editor.putInt("custom_shape", g);
        editor.putInt("custom_rotation", h);
        editor.putInt("custom_style", i);
        editor.putInt("custom_rows", k);
        editor.putInt("custom_cols", l);
        editor.commit();
    }

    public void a(int i1, int j1, int k1, int l1, int i2, int j2)
    {
        g = k1;
        h = l1;
        i = i2;
        k = i1;
        l = j1;
        m = j2;
        android.content.SharedPreferences.Editor editor = A.edit();
        editor.putInt("custom_shape", g);
        editor.putInt("custom_rotation", h);
        editor.putInt("custom_style", i);
        editor.putInt("custom_rows", k);
        editor.putInt("custom_cols", l);
        editor.putInt("custom_dist", m);
        editor.commit();
    }

    public void a(android.os.Handler handler)
    {
        if(j())
            (new Thread(new v(this, handler))).start();
    }

    public void a(java.lang.String s1)
    {
        t = s1;
        s1 = A.edit();
        s1.putString("master_name", t);
        s1.commit();
    }

    public void a(boolean flag)
    {
        android.content.SharedPreferences.Editor editor = A.edit();
        editor.putBoolean("enable_sound", flag);
        editor.commit();
        b = flag;
    }

    public void b()
    {
        g = A.getInt("custom_shape", 0);
        h = A.getInt("custom_rotation", 0);
        i = A.getInt("custom_style", 0);
        j = A.getInt("custom_pieces", 0);
        k = A.getInt("custom_rows", 3);
        l = A.getInt("custom_cols", 3);
    }

    public void b(boolean flag)
    {
        android.content.SharedPreferences.Editor editor = A.edit();
        editor.putBoolean("enable_vibrate", flag);
        editor.commit();
        c = flag;
    }

    public int c()
    {
        switch(D.nextInt(3) + 1)
        {
        default:
            return 0x7f020000;

        case 1: // '\001'
            return 0x7f020000;

        case 2: // '\002'
            return 0x7f020001;

        case 3: // '\003'
            return 0x7f020002;
        }
    }

    public void c(boolean flag)
    {
        android.content.SharedPreferences.Editor editor = A.edit();
        editor.putBoolean("show_toolbar", flag);
        editor.commit();
        d = flag;
    }

    public void d()
    {
        if(u)
        {
            return;
        } else
        {
            android.content.SharedPreferences.Editor editor = A.edit();
            editor.putBoolean("played_online", true);
            editor.commit();
            u = true;
            return;
        }
    }

    public void e()
    {
        if(v)
        {
            return;
        } else
        {
            android.content.SharedPreferences.Editor editor = A.edit();
            editor.putBoolean("rated_game", true);
            editor.commit();
            v = true;
            return;
        }
    }

    public boolean f()
    {
        if(x > 15)
            return false;
        if(x > 7 && !D.nextBoolean())
        {
            return false;
        } else
        {
            android.content.SharedPreferences.Editor editor = A.edit();
            int i1 = x + 1;
            x = i1;
            editor.putInt("yopu_tc", i1);
            editor.commit();
            return true;
        }
    }

    public java.lang.String g()
    {
        return y;
    }

    public boolean h()
    {
        return y != null && y.length() > 4;
    }

    public static final int a[] = {
        6, 1, 2, 3, 4, 5, 7
    };
    private static com.yodesoft.android.game.yopuzzle.av w = null;
    private android.content.SharedPreferences A;
    private android.content.Context B;
    private android.content.res.Resources C;
    private java.util.Random D;
    public boolean b;
    public boolean c;
    public boolean d;
    public boolean e;
    public int f;
    public int g;
    public int h;
    public int i;
    public int j;
    public int k;
    public int l;
    public int m;
    public boolean n;
    public int o;
    public int p;
    public int q;
    public int r;
    public float s;
    public java.lang.String t;
    public boolean u;
    public boolean v;
    private int x;
    private java.lang.String y;
    private long z;

}
