// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Message;
import android.widget.ViewFlipper;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            YoPuzzle, n, av, p

class s extends android.os.Handler
{

    s(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        a = yopuzzle;
        super();
    }

    public void handleMessage(android.os.Message message)
    {
        switch(message.what)
        {
        default:
            return;

        case 0: // '\0'
            com.yodesoft.android.game.yopuzzle.YoPuzzle.a(a, true);
            return;

        case 1: // '\001'
            if(com.yodesoft.android.game.yopuzzle.YoPuzzle.a(a) != null)
                com.yodesoft.android.game.yopuzzle.YoPuzzle.a(a).g();
            com.yodesoft.android.game.yopuzzle.YoPuzzle.b(a).setDisplayedChild(0);
            com.yodesoft.android.game.yopuzzle.YoPuzzle.a(a, 0);
            com.yodesoft.android.game.yopuzzle.YoPuzzle.c(a);
            return;

        case 2: // '\002'
            com.yodesoft.android.game.yopuzzle.YoPuzzle.b(a).setDisplayedChild(1);
            com.yodesoft.android.game.yopuzzle.YoPuzzle.a(a, 0);
            com.yodesoft.android.game.yopuzzle.YoPuzzle.c(a);
            return;

        case 3: // '\003'
            a.a();
            return;

        case 4: // '\004'
            com.yodesoft.android.game.yopuzzle.YoPuzzle.d(a);
            com.yodesoft.android.game.yopuzzle.YoPuzzle.a(a, true);
            return;

        case 5: // '\005'
            com.yodesoft.android.game.yopuzzle.YoPuzzle.a(a).b();
            return;

        case 6: // '\006'
            com.yodesoft.android.game.yopuzzle.YoPuzzle.b(a, 2);
            return;

        case 7: // '\007'
            message = new Intent("android.intent.action.VIEW", android.net.Uri.parse((new StringBuilder()).append("market://details?id=").append(a.getPackageName()).toString()));
            try
            {
                a.startActivity(message);
            }
            // Misplaced declaration of an exception variable
            catch(android.os.Message message)
            {
                return;
            }
            a.b.e();
            return;

        case 8: // '\b'
            com.yodesoft.android.game.yopuzzle.YoPuzzle.e(a);
            return;

        case 9: // '\t'
            com.yodesoft.android.game.yopuzzle.YoPuzzle.f(a);
            return;

        case 10: // '\n'
            message = (com.yodesoft.android.game.yopuzzle.p)message.obj;
            if(!com.yodesoft.android.game.yopuzzle.av.a(((com.yodesoft.android.game.yopuzzle.p) (message)).d))
            {
                com.yodesoft.android.game.yopuzzle.YoPuzzle.g(a);
                return;
            } else
            {
                com.yodesoft.android.game.yopuzzle.YoPuzzle.a(a, message);
                com.yodesoft.android.game.yopuzzle.YoPuzzle.h(a);
                return;
            }

        case 11: // '\013'
            message = (com.yodesoft.android.game.yopuzzle.p)message.obj;
            break;
        }
        if(!com.yodesoft.android.game.yopuzzle.av.a(((com.yodesoft.android.game.yopuzzle.p) (message)).d))
        {
            com.yodesoft.android.game.yopuzzle.YoPuzzle.g(a);
            return;
        } else
        {
            com.yodesoft.android.game.yopuzzle.YoPuzzle.a(a, message);
            com.yodesoft.android.game.yopuzzle.YoPuzzle.i(a);
            return;
        }
    }

    final com.yodesoft.android.game.yopuzzle.YoPuzzle a;
}
