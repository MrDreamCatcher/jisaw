// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.app.Dialog;
import android.content.Context;
import android.content.res.Resources;
import android.os.Handler;
import android.text.format.Time;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;
import java.util.Random;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            ao, ap, aq, ar, 
//            as, an, av, a, 
//            ah, FixedViewFlipper, u, w, 
//            bk, bb, ay, at, 
//            bf, bm, y, m, 
//            t, ab, ae

public class n
{

    public n(android.content.Context context, android.os.Handler handler)
    {
        J = new ao(this);
        K = new ap(this);
        M = new Time();
        N = new aq(this);
        O = new ar(this);
        P = new as(this);
        R = -1;
        S = new an(this);
        z = context;
        A = handler;
        B = com.yodesoft.android.game.yopuzzle.av.a(context);
        E = com.yodesoft.android.game.yopuzzle.a.a(context);
        F = com.yodesoft.android.game.yopuzzle.ah.a(context);
        C = null;
        y = 0;
        x = -1;
        j();
    }

    static int A(com.yodesoft.android.game.yopuzzle.n n1)
    {
        return n1.x;
    }

    static int B(com.yodesoft.android.game.yopuzzle.n n1)
    {
        int i1 = n1.L - 1;
        n1.L = i1;
        return i1;
    }

    static int C(com.yodesoft.android.game.yopuzzle.n n1)
    {
        int i1 = n1.L + 1;
        n1.L = i1;
        return i1;
    }

    static java.lang.Runnable D(com.yodesoft.android.game.yopuzzle.n n1)
    {
        return n1.N;
    }

    static boolean E(com.yodesoft.android.game.yopuzzle.n n1)
    {
        return n1.u();
    }

    static void F(com.yodesoft.android.game.yopuzzle.n n1)
    {
        n1.n();
    }

    static void G(com.yodesoft.android.game.yopuzzle.n n1)
    {
        n1.q();
    }

    static int H(com.yodesoft.android.game.yopuzzle.n n1)
    {
        return n1.R;
    }

    static int a(com.yodesoft.android.game.yopuzzle.n n1)
    {
        return n1.G;
    }

    private void a(int i1)
    {
        d(true);
        g.setVisibility(8);
        l.setVisibility(8);
        b.setDisplayedChild(i1);
        b.setVisibility(0);
        b.requestFocus();
    }

    private void a(android.view.View view)
    {
        if(n.getContentView() == view)
        {
            if(n.isShowing())
            {
                return;
            } else
            {
                n.showAtLocation(a, 17, 0, 0);
                return;
            }
        } else
        {
            n.dismiss();
            n.setContentView(view);
            n.update();
            n.showAtLocation(a, 17, 0, 0);
            return;
        }
    }

    private void a(android.widget.ViewFlipper viewflipper)
    {
        android.content.Context context = z;
        if((new Random()).nextBoolean())
        {
            viewflipper.setInAnimation(android.view.animation.AnimationUtils.loadAnimation(context, 0x10a0000));
            viewflipper.setOutAnimation(android.view.animation.AnimationUtils.loadAnimation(context, 0x10a0001));
            return;
        } else
        {
            viewflipper.setInAnimation(android.view.animation.AnimationUtils.loadAnimation(context, 0x10a0002));
            viewflipper.setOutAnimation(android.view.animation.AnimationUtils.loadAnimation(context, 0x10a0003));
            return;
        }
    }

    static void a(com.yodesoft.android.game.yopuzzle.n n1, int i1)
    {
        n1.b(i1);
    }

    static int b(com.yodesoft.android.game.yopuzzle.n n1, int i1)
    {
        n1.G = i1;
        return i1;
    }

    static java.lang.Runnable b(com.yodesoft.android.game.yopuzzle.n n1)
    {
        return n1.O;
    }

    private void b(int i1)
    {
        if(i1 == G && u())
            return;
        int j1;
        if(i1 == 0)
            j1 = 0;
        else
        if(i1 == 2)
        {
            ((android.widget.TextView)h.findViewById(0x7f090042)).setText(0x7f070059);
            h.findViewById(0x7f090043).setVisibility(0);
            j1 = 1;
        } else
        if(i1 == 7)
        {
            ((android.widget.TextView)h.findViewById(0x7f090042)).setText(0x7f07005b);
            h.findViewById(0x7f090043).setVisibility(8);
            j1 = 1;
        } else
        {
            j1 = 0;
        }
        G = i1;
        if(i1 == 1)
        {
            g.setVisibility(8);
            return;
        } else
        {
            h.setDisplayedChild(j1);
            l();
            g.setVisibility(0);
            return;
        }
    }

    static android.os.Handler c(com.yodesoft.android.game.yopuzzle.n n1)
    {
        return n1.J;
    }

    private void c(int i1)
    {
        int l1 = 0x7f070000;
        if(Q == null || R != i1) goto _L2; else goto _L1
_L1:
        Q.show();
_L10:
        return;
_L2:
        i1;
        JVM INSTR tableswitch 0 4: default 64
    //                   0 161
    //                   1 176
    //                   2 191
    //                   3 206
    //                   4 221;
           goto _L3 _L4 _L5 _L6 _L7 _L8
_L8:
        break MISSING_BLOCK_LABEL_221;
_L4:
        break; /* Loop/switch isn't completed */
_L3:
        boolean flag;
        int j1;
        int k1;
        flag = false;
        j1 = 0;
        l1 = 0;
        k1 = 0;
_L11:
        if(k1 > 0)
        {
            com.yodesoft.android.game.yopuzzle.u u1 = new u(z);
            u1.c(k1).b(l1).a(j1).a(0x1040013, S).a(false);
            if(flag)
                u1.b(0x1040009, S);
            Q = u1.a();
            Q.show();
            R = i1;
            return;
        }
        if(true) goto _L10; else goto _L9
_L9:
        k1 = 0x1080027;
        j1 = 0x7f070011;
        flag = true;
          goto _L11
_L5:
        k1 = 0x1080027;
        j1 = 0x7f070041;
        flag = true;
          goto _L11
_L6:
        k1 = 0x1080027;
        j1 = 0x7f070042;
        flag = true;
          goto _L11
_L7:
        k1 = 0x1080027;
        j1 = 0x7f070043;
        flag = true;
          goto _L11
        k1 = 0x1080027;
        j1 = 0x7f070074;
        flag = true;
          goto _L11
    }

    private void c(boolean flag)
    {
        if(flag)
        {
            J.removeCallbacks(N);
            J.postDelayed(N, 1000L);
            return;
        } else
        {
            J.removeCallbacks(N);
            return;
        }
    }

    static com.yodesoft.android.game.yopuzzle.bk d(com.yodesoft.android.game.yopuzzle.n n1)
    {
        return n1.C;
    }

    private void d(boolean flag)
    {
        if(flag)
            o.setDisplayedChild(1);
        else
            o.setDisplayedChild(0);
        if(!flag)
            flag = true;
        else
            flag = false;
        c(flag);
    }

    static android.content.Context e(com.yodesoft.android.game.yopuzzle.n n1)
    {
        return n1.z;
    }

    static android.view.View f(com.yodesoft.android.game.yopuzzle.n n1)
    {
        return n1.d;
    }

    static boolean g(com.yodesoft.android.game.yopuzzle.n n1)
    {
        return n1.t();
    }

    static com.yodesoft.android.game.yopuzzle.av h(com.yodesoft.android.game.yopuzzle.n n1)
    {
        return n1.B;
    }

    static com.yodesoft.android.game.yopuzzle.a i(com.yodesoft.android.game.yopuzzle.n n1)
    {
        return n1.E;
    }

    static com.yodesoft.android.game.yopuzzle.ah j(com.yodesoft.android.game.yopuzzle.n n1)
    {
        return n1.F;
    }

    private void j()
    {
        a = new FrameLayout(z);
        b = new FixedViewFlipper(z);
        i = new android.widget.FrameLayout.LayoutParams(-2, -2, 17);
        k = new android.widget.FrameLayout.LayoutParams(-1, -1, 17);
        int i1;
        if(B.n)
            i1 = B.q - B.o;
        else
            i1 = -1;
        j = new android.widget.FrameLayout.LayoutParams(i1, -2, 80);
        v();
        a.addView(f, j);
        a(B.d);
        a.addView(b, i);
        b.setVisibility(8);
        a.addView(l, i);
        l.setVisibility(8);
        a.addView(g, k);
        g.setVisibility(8);
    }

    static com.yodesoft.android.game.yopuzzle.w k(com.yodesoft.android.game.yopuzzle.n n1)
    {
        return n1.D;
    }

    private void k()
    {
        if(C == null)
        {
            return;
        } else
        {
            E.a(D.b(), J);
            l.setImageBitmap(null);
            return;
        }
    }

    private void l()
    {
        b.setVisibility(8);
        d(false);
    }

    static void l(com.yodesoft.android.game.yopuzzle.n n1)
    {
        n1.x();
    }

    private void m()
    {
        if(!s())
        {
            android.widget.Button button = (android.widget.Button)c.findViewById(0x7f09002e);
            if(C.r)
                button.setVisibility(0);
            else
                button.setVisibility(8);
            a(0);
            return;
        } else
        {
            l();
            return;
        }
    }

    static void m(com.yodesoft.android.game.yopuzzle.n n1)
    {
        n1.l();
    }

    private void n()
    {
        a(1);
        if(D.h())
            D.a(J);
    }

    static void n(com.yodesoft.android.game.yopuzzle.n n1)
    {
        n1.k();
    }

    private void o()
    {
        a(2);
        F.f();
    }

    static void o(com.yodesoft.android.game.yopuzzle.n n1)
    {
        n1.m();
    }

    private void p()
    {
        l();
        android.view.animation.Animation animation = android.view.animation.AnimationUtils.loadAnimation(z, 0x10a0000);
        animation.setDuration(500L);
        l.setAnimation(animation);
        l.setImageBitmap(E.a());
        l.setVisibility(0);
    }

    static void p(com.yodesoft.android.game.yopuzzle.n n1)
    {
        n1.w();
    }

    private void q()
    {
        android.view.animation.Animation animation = android.view.animation.AnimationUtils.loadAnimation(z, 0x10a0001);
        animation.setDuration(1000L);
        l.setAnimation(animation);
        l.setVisibility(8);
    }

    static void q(com.yodesoft.android.game.yopuzzle.n n1)
    {
        n1.p();
    }

    private void r()
    {
        c(false);
        if(!H)
            D.a(L, s);
        boolean flag = D.e();
        boolean flag1 = v;
        java.lang.Object obj1 = (android.widget.TextView)d.findViewById(0x7f09002f);
        java.lang.Object obj = (android.widget.ViewFlipper)d.findViewById(0x7f090031);
        if(!flag1)
        {
            if(java.lang.Boolean.valueOf(flag).booleanValue())
            {
                ((android.widget.TextView) (obj1)).setText(0x7f070024);
                ((android.widget.TextView) (obj1)).setTextSize(18F);
                d.findViewById(0x7f090032).setVisibility(0);
                d.findViewById(0x7f090035).setVisibility(8);
                d.findViewById(0x7f09002b).setVisibility(0);
                d.findViewById(0x7f090038).setEnabled(true);
                obj1 = (android.widget.EditText)d.findViewById(0x7f090037);
                java.lang.String s1 = com.yodesoft.android.game.yopuzzle.bb.a();
                int i1;
                int j1;
                if(s1 != null)
                {
                    ((android.widget.ViewFlipper) (obj)).setDisplayedChild(0);
                    B.a(s1);
                    D.a(s1);
                } else
                {
                    ((android.widget.EditText) (obj1)).setText(B.t);
                    if(D.i())
                        ((android.widget.ViewFlipper) (obj)).setDisplayedChild(1);
                    else
                        ((android.widget.ViewFlipper) (obj)).setDisplayedChild(0);
                }
            } else
            {
                ((android.widget.ViewFlipper) (obj)).setDisplayedChild(0);
                ((android.widget.TextView) (obj1)).setText(0x7f070023);
                d.findViewById(0x7f090032).setVisibility(8);
                d.findViewById(0x7f090035).setVisibility(0);
                d.findViewById(0x7f09002b).setVisibility(8);
            }
            obj = (android.widget.TextView)d.findViewById(0x7f090030);
            obj1 = z.getString(0x7f070029);
            s1 = z.getString(0x7f07002a);
            i1 = D.c();
            j1 = D.g();
            ((android.widget.TextView) (obj)).setText((new StringBuilder()).append(((java.lang.String) (obj1))).append(i1).append("\n").append(s1).append(j1).toString());
        } else
        {
            ((android.widget.ViewFlipper) (obj)).setDisplayedChild(2);
            ((android.widget.TextView)d.findViewById(0x7f09002f)).setText(0x7f070023);
            ((android.widget.TextView)d.findViewById(0x7f090030)).setText(0x7f070072);
            ((android.widget.TextView)d.findViewById(0x7f09003b)).setText(0x7f070071);
            D.b(J);
        }
        a(false);
        a(m);
        m.a();
        J.postDelayed(P, 5000L);
    }

    static boolean r(com.yodesoft.android.game.yopuzzle.n n1)
    {
        return n1.v;
    }

    static void s(com.yodesoft.android.game.yopuzzle.n n1)
    {
        n1.z();
    }

    private boolean s()
    {
        return b.isShown() && b.getCurrentView() == c;
    }

    static android.os.Handler t(com.yodesoft.android.game.yopuzzle.n n1)
    {
        return n1.A;
    }

    private boolean t()
    {
        return b.isShown() && b.getCurrentView() == d;
    }

    private boolean u()
    {
        return g.isShown();
    }

    static boolean u(com.yodesoft.android.game.yopuzzle.n n1)
    {
        return n1.H;
    }

    private void v()
    {
        android.view.LayoutInflater layoutinflater = (android.view.LayoutInflater)z.getSystemService("layout_inflater");
        c = layoutinflater.inflate(0x7f030005, null, false);
        c.setClickable(true);
        b.addView(c, 0, i);
        ((android.widget.Button)c.findViewById(0x7f09002c)).setOnClickListener(K);
        ((android.widget.Button)c.findViewById(0x7f09002a)).setOnClickListener(K);
        ((android.widget.Button)c.findViewById(0x7f09002b)).setOnClickListener(K);
        ((android.widget.Button)c.findViewById(0x7f09002d)).setOnClickListener(K);
        ((android.widget.Button)c.findViewById(0x7f09002e)).setOnClickListener(K);
        d = layoutinflater.inflate(0x7f030006, null, false);
        d.setFocusable(true);
        d.setFocusableInTouchMode(true);
        d.setClickable(true);
        b.addView(d, 1, i);
        ((android.widget.Button)d.findViewById(0x7f090033)).setOnClickListener(K);
        ((android.widget.Button)d.findViewById(0x7f090034)).setOnClickListener(K);
        ((android.widget.Button)d.findViewById(0x7f090035)).setOnClickListener(K);
        ((android.widget.Button)d.findViewById(0x7f09002b)).setOnClickListener(K);
        ((android.widget.Button)d.findViewById(0x7f090032)).setOnClickListener(K);
        ((android.widget.Button)d.findViewById(0x7f090038)).setOnClickListener(K);
        ((android.widget.Button)d.findViewById(0x7f090039)).setOnClickListener(K);
        ((android.widget.Button)d.findViewById(0x7f09003c)).setOnClickListener(K);
        a((android.widget.ViewFlipper)d.findViewById(0x7f090031));
        e = layoutinflater.inflate(0x7f030007, null, false);
        e.setFocusable(true);
        e.setFocusableInTouchMode(true);
        e.setClickable(true);
        b.addView(e, 2, i);
        ((android.widget.Button)e.findViewById(0x7f09003d)).setOnClickListener(K);
        ((android.widget.Button)e.findViewById(0x7f09002b)).setOnClickListener(K);
        g = layoutinflater.inflate(0x7f030008, null, false);
        g.setFocusable(true);
        g.setFocusableInTouchMode(true);
        g.setClickable(true);
        ((android.widget.Button)g.findViewById(0x7f090043)).setOnClickListener(K);
        ((android.widget.Button)g.findViewById(0x7f09002b)).setOnClickListener(K);
        h = (com.yodesoft.android.game.yopuzzle.FixedViewFlipper)g.findViewById(0x7f09003e);
        a(h);
        l = new ImageView(z);
        l.setLayoutParams(new android.view.ViewGroup.LayoutParams(-2, -2));
        l.setAdjustViewBounds(true);
        l.setOnClickListener(new at(this));
        f = layoutinflater.inflate(0x7f03000a, null, false);
        p = (android.widget.TextView)f.findViewById(0x7f09004f);
        q = (android.widget.TextView)f.findViewById(0x7f09004e);
        r = (android.widget.TextView)f.findViewById(0x7f09004d);
        ((android.widget.Button)f.findViewById(0x7f09004a)).setOnClickListener(K);
        o = (android.widget.ViewFlipper)f.findViewById(0x7f09004b);
        a(o);
        m = new ay(z);
        n = new PopupWindow(m, -1, -1, false);
        n.setTouchable(false);
    }

    static boolean v(com.yodesoft.android.game.yopuzzle.n n1)
    {
        return n1.w;
    }

    private void w()
    {
        c(0);
    }

    static void w(com.yodesoft.android.game.yopuzzle.n n1)
    {
        n1.y();
    }

    static int x(com.yodesoft.android.game.yopuzzle.n n1)
    {
        return n1.L;
    }

    private void x()
    {
        c(1);
    }

    static android.text.format.Time y(com.yodesoft.android.game.yopuzzle.n n1)
    {
        return n1.M;
    }

    private void y()
    {
        c(3);
    }

    static android.widget.TextView z(com.yodesoft.android.game.yopuzzle.n n1)
    {
        return n1.q;
    }

    private void z()
    {
        c(4);
    }

    public android.widget.FrameLayout a()
    {
        return a;
    }

    public void a(boolean flag)
    {
        if(flag)
        {
            p.setText(java.lang.String.valueOf(s));
            java.lang.String s1 = java.lang.String.format("%d/%d", new java.lang.Object[] {
                java.lang.Integer.valueOf(t), java.lang.Integer.valueOf(u)
            });
            r.setText(s1);
            M.set(L * 1000);
            q.setText(M.format("%M:%S"));
            c(true);
            f.setVisibility(0);
            return;
        } else
        {
            f.setVisibility(8);
            return;
        }
    }

    public void a(boolean flag, int i1, int j1)
    {
        if(!flag && C != null && y == i1 && !D.e() && !D.j() && !E.g())
        {
            f();
            return;
        }
        if(C != null)
        {
            C.e();
            if(D.j())
                E.o();
            a.removeView(C);
            l.setImageBitmap(null);
            l();
            q();
        }
        if(i1 != 6) goto _L2; else goto _L1
_L1:
        C = new bf(z);
_L4:
        C.a(flag, j1, this);
        if(E.k() == 0)
        {
            J.sendEmptyMessage(7);
            G = 7;
        }
        a.addView(C, 0);
        a.requestChildFocus(C, null);
        D = C.i;
        y = i1;
        x = D.g;
        v = D.j();
        w = D.k();
        s = 0;
        t = D.h;
        u = D.d();
        E.a(J);
        k();
        return;
_L2:
        if(i1 == 1)
            C = new bm(z);
        else
        if(i1 == 3)
            C = new y(z);
        else
        if(i1 == 4)
            C = new m(z);
        else
        if(i1 == 5)
            C = new t(z);
        else
        if(i1 == 2)
            C = new ab(z);
        else
        if(i1 == 7)
            C = new ae(z);
        if(true) goto _L4; else goto _L3
_L3:
    }

    public boolean a(int i1, android.view.KeyEvent keyevent)
    {
        if(i1 == 4)
        {
            g();
            if(s())
            {
                l();
                return true;
            }
            if(v && !D.e())
            {
                z();
                return true;
            }
        }
        return false;
    }

    public boolean a(android.view.MotionEvent motionevent)
    {
        if(h())
        {
            if(H && motionevent.getAction() == 1)
            {
                J.removeCallbacks(P);
                if(t())
                    return true;
                J.postDelayed(P, 50L);
            }
            return true;
        }
        if(s())
            l();
        return false;
    }

    public void b()
    {
        a.setBackgroundResource(B.c());
    }

    public void b(boolean flag)
    {
        java.lang.String s1 = E.b();
        if(flag)
            s1 = (new StringBuilder()).append(z.getResources().getString(0x7f07003f)).append(s1).toString();
        else
            s1 = z.getResources().getString(0x7f070040);
        android.widget.Toast.makeText(z, s1, 1).show();
    }

    public void c()
    {
        A.sendEmptyMessage(5);
        s = 0;
        if(x == 0)
            L = D.d;
        else
            L = 0;
        d(false);
        a(B.d);
        l();
        q();
        I = false;
        H = false;
    }

    public void d()
    {
        r();
        t = D.h;
        I = false;
        H = true;
    }

    public void e()
    {
        a(false);
        I = true;
        H = false;
        o();
    }

    public void f()
    {
        c(true);
        a.requestChildFocus(C, null);
    }

    public void g()
    {
        c(false);
    }

    public boolean h()
    {
        return I || H;
    }

    public void i()
    {
        s = s + 1;
        if(p != null)
            p.setText(java.lang.String.valueOf(s));
    }

    private android.os.Handler A;
    private com.yodesoft.android.game.yopuzzle.av B;
    private com.yodesoft.android.game.yopuzzle.bk C;
    private com.yodesoft.android.game.yopuzzle.w D;
    private com.yodesoft.android.game.yopuzzle.a E;
    private com.yodesoft.android.game.yopuzzle.ah F;
    private int G;
    private boolean H;
    private boolean I;
    private android.os.Handler J;
    private android.view.View.OnClickListener K;
    private int L;
    private android.text.format.Time M;
    private java.lang.Runnable N;
    private java.lang.Runnable O;
    private java.lang.Runnable P;
    private android.app.Dialog Q;
    private int R;
    private android.content.DialogInterface.OnClickListener S;
    private android.widget.FrameLayout a;
    private com.yodesoft.android.game.yopuzzle.FixedViewFlipper b;
    private android.view.View c;
    private android.view.View d;
    private android.view.View e;
    private android.view.View f;
    private android.view.View g;
    private com.yodesoft.android.game.yopuzzle.FixedViewFlipper h;
    private android.view.ViewGroup.LayoutParams i;
    private android.view.ViewGroup.LayoutParams j;
    private android.view.ViewGroup.LayoutParams k;
    private android.widget.ImageView l;
    private com.yodesoft.android.game.yopuzzle.ay m;
    private android.widget.PopupWindow n;
    private android.widget.ViewFlipper o;
    private android.widget.TextView p;
    private android.widget.TextView q;
    private android.widget.TextView r;
    private int s;
    private int t;
    private int u;
    private boolean v;
    private boolean w;
    private int x;
    private int y;
    private android.content.Context z;
}
