// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            a, bc

final class z
    implements java.lang.Runnable
{

    z(com.yodesoft.android.game.yopuzzle.a a1, java.lang.String s, int i)
    {
        a = a1;
        super();
        b = s;
        c = i;
    }

    public void run()
    {
        java.lang.Object obj1 = new StringBuilder();
        java.lang.Object obj = com.yodesoft.android.game.yopuzzle.a.m(a);
        ((java.lang.StringBuilder) (obj1)).delete(0, ((java.lang.StringBuilder) (obj1)).length());
        ((java.lang.StringBuilder) (obj1)).append(com.yodesoft.android.game.yopuzzle.a.n(a));
        ((java.lang.StringBuilder) (obj1)).append(b);
        ((java.lang.StringBuilder) (obj1)).append("/");
        java.io.File file = new File(((java.lang.StringBuilder) (obj1)).toString());
        if(!file.exists())
            file.mkdirs();
        ((java.lang.StringBuilder) (obj1)).append(c);
        ((java.lang.StringBuilder) (obj1)).append(".jpg");
        obj1 = ((java.lang.StringBuilder) (obj1)).toString();
        try
        {
            obj = new FileInputStream(((java.lang.String) (obj)));
            com.yodesoft.android.game.yopuzzle.bc.a(((java.io.InputStream) (obj)), new FileOutputStream(((java.lang.String) (obj1))));
            ((java.io.InputStream) (obj)).close();
            return;
        }
        catch(java.lang.Exception exception)
        {
            exception.printStackTrace();
        }
    }

    final com.yodesoft.android.game.yopuzzle.a a;
    private java.lang.String b;
    private int c;
}
