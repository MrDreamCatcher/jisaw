// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.WebSettings;
import android.webkit.WebView;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            am, bh

public class al
{

    al(android.content.Context context, com.yodesoft.android.game.yopuzzle.YoPuzzle.JSHandler jshandler)
    {
        a = context;
        c = jshandler;
        e = "about:blank";
        g = -1;
        h = -1;
        b = ((android.view.LayoutInflater)a.getSystemService("layout_inflater")).inflate(0x7f030000, null, false);
        d = (android.webkit.WebView)b.findViewById(0x7f090000);
        d.setWebViewClient(new am(this));
        d.getSettings().setJavaScriptEnabled(true);
        d.clearCache(true);
        d.addJavascriptInterface(c, "yopuzzle");
        d.setOnTouchListener(new bh(this));
    }

    static int a(com.yodesoft.android.game.yopuzzle.al al1)
    {
        return al1.h;
    }

    static int a(com.yodesoft.android.game.yopuzzle.al al1, int i)
    {
        al1.h = i;
        return i;
    }

    static int b(com.yodesoft.android.game.yopuzzle.al al1)
    {
        return al1.g;
    }

    static android.webkit.WebView c(com.yodesoft.android.game.yopuzzle.al al1)
    {
        return al1.d;
    }

    public android.view.View a()
    {
        return b;
    }

    public void a(int i)
    {
        java.lang.String s;
        if(h != i)
            d.clearView();
        g = i;
        s = null;
        g;
        JVM INSTR lookupswitch 6: default 84
    //                   0: 102
    //                   1: 108
    //                   2: 114
    //                   3: 120
    //                   4: 126
    //                   21: 132;
           goto _L1 _L2 _L3 _L4 _L5 _L6 _L7
_L1:
        if(s != null)
        {
            e = s;
            d.loadUrl(s);
        }
        return;
_L2:
        s = "http://www.yopuzzle.com/m/albums/hot/1";
        continue; /* Loop/switch isn't completed */
_L3:
        s = "http://www.yopuzzle.com/m/masters/hot";
        continue; /* Loop/switch isn't completed */
_L4:
        s = "http://www.yopuzzle.com/m/account/info";
        continue; /* Loop/switch isn't completed */
_L5:
        s = "http://www.yopuzzle.com/m/bottles/hot";
        continue; /* Loop/switch isn't completed */
_L6:
        s = "http://www.yopuzzle.com/m/";
        continue; /* Loop/switch isn't completed */
_L7:
        s = "file:///android_asset/hot.html";
        if(true) goto _L1; else goto _L8
_L8:
    }

    public int b()
    {
        return g;
    }

    public void b(int i)
    {
        f = i;
    }

    public void c()
    {
        if(g < 0)
        {
            return;
        } else
        {
            d.reload();
            return;
        }
    }

    public int d()
    {
        return f;
    }

    private android.content.Context a;
    private android.view.View b;
    private com.yodesoft.android.game.yopuzzle.YoPuzzle.JSHandler c;
    private android.webkit.WebView d;
    private java.lang.String e;
    private int f;
    private int g;
    private int h;
}
