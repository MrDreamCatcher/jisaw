// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.TextSwitcher;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            av, YoPuzzle

class c
    implements android.widget.AdapterView.OnItemSelectedListener
{

    c(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        a = yopuzzle;
        super();
    }

    public void onItemSelected(android.widget.AdapterView adapterview, android.view.View view, int i, long l)
    {
        com.yodesoft.android.game.yopuzzle.YoPuzzle.c(a, com.yodesoft.android.game.yopuzzle.av.a[i]);
        com.yodesoft.android.game.yopuzzle.YoPuzzle.t(a).setText(com.yodesoft.android.game.yopuzzle.YoPuzzle.r(a)[com.yodesoft.android.game.yopuzzle.YoPuzzle.s(a) - 1]);
        if(i < 1)
        {
            com.yodesoft.android.game.yopuzzle.YoPuzzle.u(a).setEnabled(false);
            return;
        }
        if(i > com.yodesoft.android.game.yopuzzle.av.a.length - 2)
        {
            com.yodesoft.android.game.yopuzzle.YoPuzzle.v(a).setEnabled(false);
            return;
        } else
        {
            com.yodesoft.android.game.yopuzzle.YoPuzzle.u(a).setEnabled(true);
            com.yodesoft.android.game.yopuzzle.YoPuzzle.v(a).setEnabled(true);
            return;
        }
    }

    public void onNothingSelected(android.widget.AdapterView adapterview)
    {
    }

    final com.yodesoft.android.game.yopuzzle.YoPuzzle a;
}
