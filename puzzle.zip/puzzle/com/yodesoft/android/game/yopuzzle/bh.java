// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.view.MotionEvent;
import android.view.View;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            al

class bh
    implements android.view.View.OnTouchListener
{

    bh(com.yodesoft.android.game.yopuzzle.al al)
    {
        a = al;
        super();
    }

    public boolean onTouch(android.view.View view, android.view.MotionEvent motionevent)
    {
        motionevent.getAction();
        JVM INSTR tableswitch 0 0: default 24
    //                   0 26;
           goto _L1 _L2
_L1:
        return false;
_L2:
        if(!view.hasFocus())
            view.requestFocus();
        if(true) goto _L1; else goto _L3
_L3:
    }

    final com.yodesoft.android.game.yopuzzle.al a;
}
