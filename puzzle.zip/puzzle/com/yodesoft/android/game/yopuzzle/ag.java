// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.graphics.Bitmap;
import android.os.Handler;
import java.io.FileOutputStream;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            a

final class ag
    implements java.lang.Runnable
{

    ag(com.yodesoft.android.game.yopuzzle.a a1, int i)
    {
        b = a1;
        super();
        a = i - 1;
    }

    public void run()
    {
        android.os.Handler handler;
        java.lang.String s;
        int i;
        i = a;
        handler = com.yodesoft.android.game.yopuzzle.a.a(b);
        if(!com.yodesoft.android.game.yopuzzle.a.h(b))
        {
            handler.sendMessage(handler.obtainMessage(4));
            return;
        }
        s = com.yodesoft.android.game.yopuzzle.a.i(b);
        com.yodesoft.android.game.yopuzzle.a.e(b);
        JVM INSTR tableswitch 0 2: default 268
    //                   0 160
    //                   1 185
    //                   2 196;
           goto _L1 _L2 _L3 _L4
_L1:
        break MISSING_BLOCK_LABEL_268;
_L6:
        java.lang.Object obj;
        if(com.yodesoft.android.game.yopuzzle.a.c(b))
            obj = java.lang.String.format("%s/bottle_%s.jpg", new java.lang.Object[] {
                s, com.yodesoft.android.game.yopuzzle.a.k(b)
            });
        if(com.yodesoft.android.game.yopuzzle.a.b(b) == null || com.yodesoft.android.game.yopuzzle.a.b(b).isRecycled())
        {
            handler.sendMessage(handler.obtainMessage(4));
            return;
        }
          goto _L5
_L2:
        try
        {
            obj = java.lang.String.format("%s/classic_%03d.jpg", new java.lang.Object[] {
                s, java.lang.Integer.valueOf(i)
            });
        }
        // Misplaced declaration of an exception variable
        catch(java.lang.Object obj)
        {
            handler.sendMessage(handler.obtainMessage(4));
            ((java.lang.Exception) (obj)).printStackTrace();
            return;
        }
          goto _L6
_L3:
        handler.sendMessage(handler.obtainMessage(3));
        return;
_L4:
        obj = java.lang.String.format("%s/%s_%03d.jpg", new java.lang.Object[] {
            s, com.yodesoft.android.game.yopuzzle.a.j(b), java.lang.Integer.valueOf(i)
        });
          goto _L6
_L5:
        obj = new FileOutputStream(((java.lang.String) (obj)));
        com.yodesoft.android.game.yopuzzle.a.b(b).compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, ((java.io.OutputStream) (obj)));
        handler.sendMessage(handler.obtainMessage(3));
        return;
        obj = null;
          goto _L6
    }

    final int a;
    final com.yodesoft.android.game.yopuzzle.a b;
}
