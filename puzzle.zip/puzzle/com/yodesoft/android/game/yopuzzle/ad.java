// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;


class ad
{

    ad()
    {
        e = (float)java.lang.Math.random();
        f = (float)java.lang.Math.random();
        c = 0;
        d = 0;
    }

    public int a;
    public int b;
    public int c;
    public int d;
    public float e;
    public float f;
}
