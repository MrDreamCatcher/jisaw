// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.view.View;
import android.widget.AdapterView;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            YoPuzzle, ah

class e
    implements android.widget.AdapterView.OnItemClickListener
{

    e(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        a = yopuzzle;
        super();
    }

    public void onItemClick(android.widget.AdapterView adapterview, android.view.View view, int i, long l)
    {
        a.a.b();
    }

    final com.yodesoft.android.game.yopuzzle.YoPuzzle a;
}
