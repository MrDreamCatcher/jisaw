// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.view.View;
import android.widget.AdapterView;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            bl

class r
    implements android.widget.AdapterView.OnItemSelectedListener
{

    r(com.yodesoft.android.game.yopuzzle.bl bl1)
    {
        a = bl1;
        super();
    }

    public void onItemSelected(android.widget.AdapterView adapterview, android.view.View view, int i, long l)
    {
        com.yodesoft.android.game.yopuzzle.bl.b(a, i);
    }

    public void onNothingSelected(android.widget.AdapterView adapterview)
    {
    }

    final com.yodesoft.android.game.yopuzzle.bl a;
}
