// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.os.CountDownTimer;
import android.view.View;
import java.util.ArrayList;
import java.util.Iterator;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            ax, o, bg

final class au extends android.os.CountDownTimer
{

    public au(com.yodesoft.android.game.yopuzzle.ax ax1, int i)
    {
        a = ax1;
        super(i + 1000, 30L);
        c = i;
        d = i + 1000;
        b = d;
        com.yodesoft.android.game.yopuzzle.ax.a(ax1, 0L);
    }

    public void onFinish()
    {
        com.yodesoft.android.game.yopuzzle.ax.a(a, 0L);
        b = d;
        for(java.util.Iterator iterator = com.yodesoft.android.game.yopuzzle.ax.a.iterator(); iterator.hasNext();)
        {
            com.yodesoft.android.game.yopuzzle.o o1 = (com.yodesoft.android.game.yopuzzle.o)iterator.next();
            o1.a.m = o1.c;
            o1.a.n = o1.e;
        }

        if(com.yodesoft.android.game.yopuzzle.ax.c() != null)
            com.yodesoft.android.game.yopuzzle.ax.c().postInvalidate();
    }

    public void onTick(long l)
    {
        long l1 = b - l;
        b = l;
        com.yodesoft.android.game.yopuzzle.ax.b(a, l1);
        if(com.yodesoft.android.game.yopuzzle.ax.a(a) >= c)
            com.yodesoft.android.game.yopuzzle.ax.a(a, c);
        com.yodesoft.android.game.yopuzzle.ax.a((float)com.yodesoft.android.game.yopuzzle.ax.a(a) / (float)c);
        com.yodesoft.android.game.yopuzzle.ax.c(a, l1);
    }

    final com.yodesoft.android.game.yopuzzle.ax a;
    private long b;
    private final long c;
    private final long d;
}
