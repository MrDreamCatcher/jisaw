// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;


// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            n

class as
    implements java.lang.Runnable
{

    as(com.yodesoft.android.game.yopuzzle.n n1)
    {
        a = n1;
        super();
    }

    public void run()
    {
        if(com.yodesoft.android.game.yopuzzle.n.g(a))
        {
            return;
        } else
        {
            com.yodesoft.android.game.yopuzzle.n.F(a);
            return;
        }
    }

    final com.yodesoft.android.game.yopuzzle.n a;
}
