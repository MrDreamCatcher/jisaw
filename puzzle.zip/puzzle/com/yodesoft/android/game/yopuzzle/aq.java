// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.os.Handler;
import android.text.format.Time;
import android.widget.TextView;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            n

class aq
    implements java.lang.Runnable
{

    aq(com.yodesoft.android.game.yopuzzle.n n1)
    {
        a = n1;
        super();
    }

    public void run()
    {
        com.yodesoft.android.game.yopuzzle.n.y(a).set(com.yodesoft.android.game.yopuzzle.n.x(a) * 1000);
        com.yodesoft.android.game.yopuzzle.n.z(a).setText(com.yodesoft.android.game.yopuzzle.n.y(a).format("%M:%S"));
        if(com.yodesoft.android.game.yopuzzle.n.A(a) == 0)
        {
            com.yodesoft.android.game.yopuzzle.n.B(a);
            if(com.yodesoft.android.game.yopuzzle.n.x(a) < 0)
            {
                a.e();
                return;
            }
        } else
        {
            com.yodesoft.android.game.yopuzzle.n.C(a);
        }
        com.yodesoft.android.game.yopuzzle.n.c(a).postDelayed(com.yodesoft.android.game.yopuzzle.n.D(a), 1000L);
    }

    final com.yodesoft.android.game.yopuzzle.n a;
}
