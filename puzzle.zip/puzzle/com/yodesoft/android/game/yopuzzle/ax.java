// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Interpolator;
import java.util.ArrayList;
import java.util.Random;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            au, o, bg

public class ax
{

    ax()
    {
        d = 0L;
        if(a == null)
            a = new ArrayList();
        if(b == null)
            b = new AccelerateDecelerateInterpolator();
        if(e == null)
            e = new au(this, h);
        if(g == null)
            g = new Random();
    }

    static float a(float f1)
    {
        c = f1;
        return f1;
    }

    public static float a(float f1, float f2, float f3, float f4)
    {
        f1 -= f3;
        f2 -= f4;
        return (float)java.lang.Math.sqrt(f1 * f1 + f2 * f2);
    }

    static long a(com.yodesoft.android.game.yopuzzle.ax ax1)
    {
        return ax1.d;
    }

    static long a(com.yodesoft.android.game.yopuzzle.ax ax1, long l)
    {
        ax1.d = l;
        return l;
    }

    private void a(long l)
    {
        int i = a.size();
        if(i <= 0)
        {
            e.cancel();
        } else
        {
            i--;
            while(i >= 0) 
            {
                com.yodesoft.android.game.yopuzzle.o o1 = (com.yodesoft.android.game.yopuzzle.o)a.get(i);
                float f2 = b.getInterpolation(c) * com.yodesoft.android.game.yopuzzle.o.a(o1);
                float f1 = f2;
                if(f2 - 1.0F > 0.0F)
                    f1 = 1.0F;
                f1 *= o1.f;
                f2 = o1.b;
                float f3 = (int)(java.lang.Math.cos(o1.g) * (double)f1);
                float f4 = o1.d;
                float f5 = (int)(java.lang.Math.sin(o1.g) * (double)f1);
                if(f1 >= o1.f)
                {
                    o1.a.m = o1.c;
                    o1.a.n = o1.e;
                    a.remove(i);
                } else
                {
                    o1.a.m = f2 + f3;
                    o1.a.n = f4 + f5;
                }
                i--;
            }
            if(f != null)
            {
                f.postInvalidate();
                return;
            }
        }
    }

    public static float b(float f1, float f2, float f3, float f4)
    {
        return (float)((java.lang.Math.atan2(f4 - f2, f3 - f1) * 180D) / 3.1415926535897931D);
    }

    static long b(com.yodesoft.android.game.yopuzzle.ax ax1, long l)
    {
        l = ax1.d + l;
        ax1.d = l;
        return l;
    }

    static java.util.Random b()
    {
        return g;
    }

    static android.view.View c()
    {
        return f;
    }

    static void c(com.yodesoft.android.game.yopuzzle.ax ax1, long l)
    {
        ax1.a(l);
    }

    public void a()
    {
        d = 0L;
        e.cancel();
        e.start();
    }

    public void a(int i)
    {
        if(h == i)
        {
            return;
        } else
        {
            h = i;
            e.cancel();
            e = new au(this, h);
            return;
        }
    }

    public void a(android.view.View view)
    {
        f = view;
    }

    public static java.util.ArrayList a = null;
    private static android.view.animation.Interpolator b = null;
    private static float c;
    private static com.yodesoft.android.game.yopuzzle.au e;
    private static android.view.View f;
    private static java.util.Random g;
    private static int h = 2000;
    private long d;

}
