// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;


// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            ay, ak

final class aa
{

    private aa(com.yodesoft.android.game.yopuzzle.ay ay)
    {
        n = ay;
        super();
    }

    aa(com.yodesoft.android.game.yopuzzle.ay ay, com.yodesoft.android.game.yopuzzle.ak ak)
    {
        this(ay);
    }

    protected int a;
    protected int b;
    protected int c;
    protected int d;
    protected int e;
    protected int f;
    protected int g;
    protected float h;
    protected float i;
    protected int j;
    protected int k;
    protected int l;
    protected java.lang.String m;
    final com.yodesoft.android.game.yopuzzle.ay n;
}
