// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.os.Handler;
import android.os.Message;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            bb, w

final class aj
    implements java.lang.Runnable
{

    aj(com.yodesoft.android.game.yopuzzle.w w1, java.lang.String s, android.os.Handler handler)
    {
        a = w1;
        super();
        c = s;
        b = handler;
    }

    public void run()
    {
        android.os.Handler handler;
        handler = b;
        java.lang.Object obj = (new bb()).a(c);
        if(obj == null || ((java.lang.String) (obj)).length() <= 4)
            break MISSING_BLOCK_LABEL_138;
        android.os.Message message;
        int i;
        try
        {
            obj = new JSONObject(((java.lang.String) (obj)));
            i = ((org.json.JSONObject) (obj)).getInt("err");
            obj = ((org.json.JSONObject) (obj)).getString("msg");
            message = new Message();
            message.what = 10;
            message.arg1 = i;
            message.obj = obj;
        }
        catch(org.json.JSONException jsonexception)
        {
            com.yodesoft.android.game.yopuzzle.w.b(a, false);
            handler.sendMessage(handler.obtainMessage(11));
            return;
        }
        if(i < 0)
            break MISSING_BLOCK_LABEL_102;
        handler.sendMessage(message);
_L2:
        com.yodesoft.android.game.yopuzzle.w.b(a, true);
        return;
        handler.sendMessage(handler.obtainMessage(11));
        if(true) goto _L2; else goto _L1
_L1:
        com.yodesoft.android.game.yopuzzle.w.b(a, false);
        handler.sendMessage(handler.obtainMessage(11));
        return;
    }

    final com.yodesoft.android.game.yopuzzle.w a;
    private android.os.Handler b;
    private java.lang.String c;
}
