// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.webkit.CookieManager;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

class bc
{

    bc()
    {
    }

    public static final void a(java.io.InputStream inputstream, java.io.OutputStream outputstream)
    {
        byte abyte0[] = new byte[1024];
        do
        {
            int i = inputstream.read(abyte0);
            if(i >= 0)
            {
                outputstream.write(abyte0, 0, i);
            } else
            {
                outputstream.flush();
                outputstream.close();
                return;
            }
        } while(true);
    }

    public static boolean a(java.lang.String s, java.lang.String s1)
    {
        java.lang.Object obj;
        java.lang.Object obj1;
        byte abyte0[];
        int i;
        try
        {
            obj = new DefaultHttpClient();
            s = new HttpPost(s);
            obj1 = android.webkit.CookieManager.getInstance();
        }
        // Misplaced declaration of an exception variable
        catch(java.lang.String s)
        {
            s.printStackTrace();
            return false;
        }
        if(obj1 == null)
            break MISSING_BLOCK_LABEL_37;
        s.setHeader("Cookie", ((android.webkit.CookieManager) (obj1)).getCookie("http://www.yopuzzle.com"));
        s = ((org.apache.http.impl.client.DefaultHttpClient) (obj)).execute(s).getEntity().getContent();
        obj = (new StringBuilder()).append(s1).append(".tmp").toString();
        obj1 = new FileOutputStream(((java.lang.String) (obj)));
        abyte0 = new byte[1024];
_L1:
        i = s.read(abyte0);
        if(i > 0)
            break MISSING_BLOCK_LABEL_134;
        ((java.io.FileOutputStream) (obj1)).flush();
        s.close();
        ((java.io.FileOutputStream) (obj1)).close();
        return (new File(((java.lang.String) (obj)))).renameTo(new File(s1));
        ((java.io.FileOutputStream) (obj1)).write(abyte0, 0, i);
          goto _L1
    }
}
