// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.content.Context;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageSwitcher;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            bd, be

public class bj
{

    bj(android.content.Context context, android.os.Handler handler, int i)
    {
        g = new bd(this);
        a = context;
        f = handler;
        b = ((android.view.LayoutInflater)a.getSystemService("layout_inflater")).inflate(0x7f030004, null, false);
        c = (android.widget.ImageSwitcher)b.findViewById(0x7f090029);
        c.setFactory(g);
        c.setOnClickListener(new be(this));
        a(i);
    }

    static int a(com.yodesoft.android.game.yopuzzle.bj bj1)
    {
        int i = bj1.e;
        bj1.e = i + 1;
        return i;
    }

    static int b(com.yodesoft.android.game.yopuzzle.bj bj1)
    {
        return bj1.e;
    }

    static int[] c(com.yodesoft.android.game.yopuzzle.bj bj1)
    {
        return bj1.d;
    }

    static android.os.Handler d(com.yodesoft.android.game.yopuzzle.bj bj1)
    {
        return bj1.f;
    }

    static android.content.Context e(com.yodesoft.android.game.yopuzzle.bj bj1)
    {
        return bj1.a;
    }

    public android.view.View a()
    {
        return b;
    }

    public void a(int i)
    {
        d = null;
        i;
        JVM INSTR tableswitch 1 7: default 48
    //                   1 90
    //                   2 98
    //                   3 106
    //                   4 114
    //                   5 122
    //                   6 82
    //                   7 130;
           goto _L1 _L2 _L3 _L4 _L5 _L6 _L7 _L8
_L1:
        int j;
        i = 0;
        j = 0;
_L10:
        d = new int[i];
        for(int k = 0; k < i; k++)
            d[k] = j + k;

        break; /* Loop/switch isn't completed */
_L7:
        j = 0x7f020088;
        i = 4;
        continue; /* Loop/switch isn't completed */
_L2:
        j = 0x7f020081;
        i = 4;
        continue; /* Loop/switch isn't completed */
_L3:
        j = 0x7f02008f;
        i = 4;
        continue; /* Loop/switch isn't completed */
_L4:
        j = 0x7f020085;
        i = 3;
        continue; /* Loop/switch isn't completed */
_L5:
        j = 0x7f02007c;
        i = 4;
        continue; /* Loop/switch isn't completed */
_L6:
        j = 0x7f020093;
        i = 3;
        continue; /* Loop/switch isn't completed */
_L8:
        j = 0x7f02008c;
        i = 3;
        if(true) goto _L10; else goto _L9
_L9:
        if(d.length > 0)
        {
            c.setImageResource(d[0]);
            e = 0;
        }
        return;
    }

    private android.content.Context a;
    private android.view.View b;
    private android.widget.ImageSwitcher c;
    private int d[];
    private int e;
    private android.os.Handler f;
    private android.widget.ViewSwitcher.ViewFactory g;
}
