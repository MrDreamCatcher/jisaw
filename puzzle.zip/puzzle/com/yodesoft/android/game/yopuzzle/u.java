// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            ai, az, ba

public class u
{

    public u(android.content.Context context)
    {
        g = -1;
        i = true;
        a = context;
    }

    static android.content.DialogInterface.OnClickListener a(com.yodesoft.android.game.yopuzzle.u u1)
    {
        return u1.j;
    }

    static android.content.DialogInterface.OnClickListener b(com.yodesoft.android.game.yopuzzle.u u1)
    {
        return u1.k;
    }

    public com.yodesoft.android.game.yopuzzle.ai a()
    {
        java.lang.Object obj;
        obj = (android.view.LayoutInflater)a.getSystemService("layout_inflater");
        com.yodesoft.android.game.yopuzzle.ai ai1 = new ai(a, 0x7f080009);
        obj = ((android.view.LayoutInflater) (obj)).inflate(0x7f030002, null);
        ai1.addContentView(((android.view.View) (obj)), new android.widget.RelativeLayout.LayoutParams(-1, -2));
        android.widget.ImageView imageview = (android.widget.ImageView)((android.view.View) (obj)).findViewById(0x7f09000f);
        if(g > 0)
            imageview.setImageResource(g);
        else
        if(h != null)
            imageview.setImageDrawable(h);
        else
            imageview.setVisibility(8);
        ((android.widget.TextView)((android.view.View) (obj)).findViewById(0x7f090010)).setText(b);
        if(d != null)
        {
            ((android.widget.Button)((android.view.View) (obj)).findViewById(0x7f090013)).setText(d);
            if(j != null)
                ((android.widget.Button)((android.view.View) (obj)).findViewById(0x7f090013)).setOnClickListener(new az(this, ai1));
        } else
        {
            ((android.view.View) (obj)).findViewById(0x7f090013).setVisibility(8);
        }
        if(e != null)
        {
            ((android.widget.Button)((android.view.View) (obj)).findViewById(0x7f090014)).setText(e);
            if(k != null)
                ((android.widget.Button)((android.view.View) (obj)).findViewById(0x7f090014)).setOnClickListener(new ba(this, ai1));
        } else
        {
            ((android.view.View) (obj)).findViewById(0x7f090014).setVisibility(8);
        }
        if(c == null) goto _L2; else goto _L1
_L1:
        ((android.widget.TextView)((android.view.View) (obj)).findViewById(0x7f090012)).setText(c);
_L4:
        ai1.setContentView(((android.view.View) (obj)));
        ai1.setCancelable(i);
        return ai1;
_L2:
        if(f != null)
        {
            ((android.widget.LinearLayout)((android.view.View) (obj)).findViewById(0x7f090011)).removeAllViews();
            ((android.widget.LinearLayout)((android.view.View) (obj)).findViewById(0x7f090011)).addView(f);
        }
        if(true) goto _L4; else goto _L3
_L3:
    }

    public com.yodesoft.android.game.yopuzzle.u a(int l)
    {
        c = (java.lang.String)a.getText(l);
        return this;
    }

    public com.yodesoft.android.game.yopuzzle.u a(int l, android.content.DialogInterface.OnClickListener onclicklistener)
    {
        d = (java.lang.String)a.getText(l);
        j = onclicklistener;
        return this;
    }

    public com.yodesoft.android.game.yopuzzle.u a(java.lang.String s)
    {
        c = s;
        return this;
    }

    public com.yodesoft.android.game.yopuzzle.u a(java.lang.String s, android.content.DialogInterface.OnClickListener onclicklistener)
    {
        d = s;
        j = onclicklistener;
        return this;
    }

    public com.yodesoft.android.game.yopuzzle.u a(boolean flag)
    {
        i = flag;
        return this;
    }

    public com.yodesoft.android.game.yopuzzle.u b(int l)
    {
        b = (java.lang.String)a.getText(l);
        return this;
    }

    public com.yodesoft.android.game.yopuzzle.u b(int l, android.content.DialogInterface.OnClickListener onclicklistener)
    {
        e = (java.lang.String)a.getText(l);
        k = onclicklistener;
        return this;
    }

    public com.yodesoft.android.game.yopuzzle.u c(int l)
    {
        g = l;
        return this;
    }

    private android.content.Context a;
    private java.lang.String b;
    private java.lang.String c;
    private java.lang.String d;
    private java.lang.String e;
    private android.view.View f;
    private int g;
    private android.graphics.drawable.Drawable h;
    private boolean i;
    private android.content.DialogInterface.OnClickListener j;
    private android.content.DialogInterface.OnClickListener k;
}
