// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.content.Context;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.Gallery;
import android.widget.LinearLayout;
import android.widget.ViewFlipper;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            q, k, r, av, 
//            ah

public class bl
{

    bl(android.content.Context context, android.os.Handler handler, com.yodesoft.android.game.yopuzzle.av av, com.yodesoft.android.game.yopuzzle.ah ah, int i1)
    {
        o = 0;
        p = 0;
        q = 0;
        r = 0;
        s = 0;
        u = new q(this);
        a = av;
        b = context;
        c = ah;
        v = handler;
        k = android.view.animation.AnimationUtils.makeInAnimation(b, true);
        l = android.view.animation.AnimationUtils.makeInAnimation(b, false);
        m = android.view.animation.AnimationUtils.makeOutAnimation(b, false);
        n = android.view.animation.AnimationUtils.makeOutAnimation(b, true);
        b();
        a(i1);
    }

    private int a(android.widget.Gallery gallery, boolean flag)
    {
        byte byte0;
        if(flag)
            byte0 = 22;
        else
            byte0 = 21;
        gallery.onKeyDown(byte0, new KeyEvent(0, 0));
        return gallery.getSelectedItemPosition();
    }

    private int a(android.widget.ViewFlipper viewflipper, boolean flag)
    {
        viewflipper.stopFlipping();
        int i1 = viewflipper.getDisplayedChild();
        int j1 = viewflipper.getChildCount();
        if(flag)
        {
            viewflipper.setInAnimation(k);
            viewflipper.setOutAnimation(n);
            if(i1 + 1 >= j1)
                viewflipper.setDisplayedChild(1);
            else
                viewflipper.showNext();
        } else
        {
            viewflipper.setInAnimation(l);
            viewflipper.setOutAnimation(m);
            if(i1 - 1 < 1)
                viewflipper.setDisplayedChild(j1 - 1);
            else
                viewflipper.showPrevious();
        }
        return viewflipper.getDisplayedChild() - 1;
    }

    static int a(com.yodesoft.android.game.yopuzzle.bl bl1, int i1)
    {
        bl1.r = i1;
        return i1;
    }

    static int a(com.yodesoft.android.game.yopuzzle.bl bl1, android.widget.Gallery gallery, boolean flag)
    {
        return bl1.a(gallery, flag);
    }

    static int a(com.yodesoft.android.game.yopuzzle.bl bl1, android.widget.ViewFlipper viewflipper, boolean flag)
    {
        return bl1.a(viewflipper, flag);
    }

    static com.yodesoft.android.game.yopuzzle.ah a(com.yodesoft.android.game.yopuzzle.bl bl1)
    {
        return bl1.c;
    }

    static int b(com.yodesoft.android.game.yopuzzle.bl bl1, int i1)
    {
        bl1.o = i1;
        return i1;
    }

    static android.os.Handler b(com.yodesoft.android.game.yopuzzle.bl bl1)
    {
        return bl1.v;
    }

    private void b()
    {
        d = ((android.view.LayoutInflater)b.getSystemService("layout_inflater")).inflate(0x7f030003, null, false);
        ((android.widget.Button)d.findViewById(0x7f090027)).setOnClickListener(u);
        ((android.widget.Button)d.findViewById(0x7f090026)).setOnClickListener(u);
        ((android.widget.Button)d.findViewById(0x7f090025)).setOnClickListener(u);
        ((android.widget.Button)d.findViewById(0x7f090023)).setOnClickListener(u);
        ((android.widget.Button)d.findViewById(0x7f090019)).setOnClickListener(u);
        ((android.widget.Button)d.findViewById(0x7f090017)).setOnClickListener(u);
        ((android.widget.Button)d.findViewById(0x7f090021)).setOnClickListener(u);
        ((android.widget.Button)d.findViewById(0x7f09001f)).setOnClickListener(u);
        ((android.widget.Button)d.findViewById(0x7f09001d)).setOnClickListener(u);
        ((android.widget.Button)d.findViewById(0x7f09001b)).setOnClickListener(u);
        e = (android.widget.ViewFlipper)d.findViewById(0x7f090020);
        f = (android.widget.ViewFlipper)d.findViewById(0x7f09001c);
        g = (android.widget.ViewFlipper)d.findViewById(0x7f090024);
        i = (android.widget.LinearLayout)d.findViewById(0x7f090016);
        j = (android.widget.LinearLayout)d.findViewById(0x7f09001a);
        h = (android.widget.Gallery)d.findViewById(0x7f090018);
        int ai[] = new int[t];
        for(int i1 = 0; i1 < t; i1++)
            ai[i1] = 0x7f020052 + i1;

        com.yodesoft.android.game.yopuzzle.k k1 = new k(b, ai);
        k1.a(64, 64);
        k1.a(0x7f070052);
        h.setAdapter(k1);
        h.setOnItemSelectedListener(new r(this));
    }

    static int c(com.yodesoft.android.game.yopuzzle.bl bl1)
    {
        int i1 = bl1.o;
        bl1.o = i1 - 1;
        return i1;
    }

    static int c(com.yodesoft.android.game.yopuzzle.bl bl1, int i1)
    {
        bl1.p = i1;
        return i1;
    }

    static int d(com.yodesoft.android.game.yopuzzle.bl bl1)
    {
        return bl1.o;
    }

    static int d(com.yodesoft.android.game.yopuzzle.bl bl1, int i1)
    {
        bl1.q = i1;
        return i1;
    }

    static int e(com.yodesoft.android.game.yopuzzle.bl bl1)
    {
        return bl1.q;
    }

    static int f(com.yodesoft.android.game.yopuzzle.bl bl1)
    {
        return bl1.p;
    }

    static int g(com.yodesoft.android.game.yopuzzle.bl bl1)
    {
        return bl1.r;
    }

    static com.yodesoft.android.game.yopuzzle.av h(com.yodesoft.android.game.yopuzzle.bl bl1)
    {
        return bl1.a;
    }

    static android.widget.ViewFlipper i(com.yodesoft.android.game.yopuzzle.bl bl1)
    {
        return bl1.g;
    }

    static android.widget.Gallery j(com.yodesoft.android.game.yopuzzle.bl bl1)
    {
        return bl1.h;
    }

    static android.widget.ViewFlipper k(com.yodesoft.android.game.yopuzzle.bl bl1)
    {
        return bl1.e;
    }

    static android.widget.ViewFlipper l(com.yodesoft.android.game.yopuzzle.bl bl1)
    {
        return bl1.f;
    }

    public android.view.View a()
    {
        return d;
    }

    public void a(int i1)
    {
        if(i1 != s) goto _L2; else goto _L1
_L1:
        return;
_L2:
        s = i1;
        i.setVisibility(0);
        j.setVisibility(0);
        f.setDisplayedChild(0);
        e.setDisplayedChild(0);
        g.setDisplayedChild(0);
        h.setVisibility(0);
        h.setSelection(0);
        o = 0;
        q = 0;
        p = 0;
        r = 0;
        switch(i1)
        {
        default:
            return;

        case 1: // '\001'
        case 6: // '\006'
            break;

        case 2: // '\002'
        case 3: // '\003'
        case 4: // '\004'
        case 7: // '\007'
            i.setVisibility(8);
            j.setVisibility(8);
            return;

        case 5: // '\005'
            j.setVisibility(8);
            break; /* Loop/switch isn't completed */
        }
        if(true) goto _L1; else goto _L3
_L3:
    }

    private com.yodesoft.android.game.yopuzzle.av a;
    private android.content.Context b;
    private com.yodesoft.android.game.yopuzzle.ah c;
    private android.view.View d;
    private android.widget.ViewFlipper e;
    private android.widget.ViewFlipper f;
    private android.widget.ViewFlipper g;
    private android.widget.Gallery h;
    private android.widget.LinearLayout i;
    private android.widget.LinearLayout j;
    private final android.view.animation.Animation k;
    private final android.view.animation.Animation l;
    private final android.view.animation.Animation m;
    private final android.view.animation.Animation n;
    private int o;
    private int p;
    private int q;
    private int r;
    private int s;
    private final int t = 41;
    private android.view.View.OnClickListener u;
    private android.os.Handler v;
}
