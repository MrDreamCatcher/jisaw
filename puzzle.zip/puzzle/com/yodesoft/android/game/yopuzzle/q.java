// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.os.Handler;
import android.os.Message;
import android.view.View;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            bl, ah, av

class q
    implements android.view.View.OnClickListener
{

    q(com.yodesoft.android.game.yopuzzle.bl bl1)
    {
        a = bl1;
        super();
    }

    public void onClick(android.view.View view)
    {
        com.yodesoft.android.game.yopuzzle.bl.a(a).b();
        switch(view.getId())
        {
        case 2131296280: 
        case 2131296282: 
        case 2131296284: 
        case 2131296286: 
        case 2131296288: 
        case 2131296290: 
        case 2131296292: 
        default:
            return;

        case 2131296295: 
            view = new Message();
            view.what = 2;
            com.yodesoft.android.game.yopuzzle.bl.b(a).sendMessage(view);
            return;

        case 2131296294: 
            com.yodesoft.android.game.yopuzzle.bl.c(a);
            com.yodesoft.android.game.yopuzzle.bl.h(a).a(com.yodesoft.android.game.yopuzzle.bl.d(a), com.yodesoft.android.game.yopuzzle.bl.e(a), com.yodesoft.android.game.yopuzzle.bl.f(a), com.yodesoft.android.game.yopuzzle.bl.g(a));
            view = new Message();
            view.what = 0;
            com.yodesoft.android.game.yopuzzle.bl.b(a).sendMessage(view);
            return;

        case 2131296291: 
            com.yodesoft.android.game.yopuzzle.bl.a(a, com.yodesoft.android.game.yopuzzle.bl.a(a, com.yodesoft.android.game.yopuzzle.bl.i(a), false));
            return;

        case 2131296293: 
            com.yodesoft.android.game.yopuzzle.bl.a(a, com.yodesoft.android.game.yopuzzle.bl.a(a, com.yodesoft.android.game.yopuzzle.bl.i(a), true));
            return;

        case 2131296279: 
            com.yodesoft.android.game.yopuzzle.bl.b(a, com.yodesoft.android.game.yopuzzle.bl.a(a, com.yodesoft.android.game.yopuzzle.bl.j(a), false));
            return;

        case 2131296281: 
            com.yodesoft.android.game.yopuzzle.bl.b(a, com.yodesoft.android.game.yopuzzle.bl.a(a, com.yodesoft.android.game.yopuzzle.bl.j(a), true));
            return;

        case 2131296287: 
            com.yodesoft.android.game.yopuzzle.bl.c(a, com.yodesoft.android.game.yopuzzle.bl.a(a, com.yodesoft.android.game.yopuzzle.bl.k(a), false));
            return;

        case 2131296289: 
            com.yodesoft.android.game.yopuzzle.bl.c(a, com.yodesoft.android.game.yopuzzle.bl.a(a, com.yodesoft.android.game.yopuzzle.bl.k(a), true));
            return;

        case 2131296283: 
            com.yodesoft.android.game.yopuzzle.bl.d(a, com.yodesoft.android.game.yopuzzle.bl.a(a, com.yodesoft.android.game.yopuzzle.bl.l(a), false));
            return;

        case 2131296285: 
            com.yodesoft.android.game.yopuzzle.bl.d(a, com.yodesoft.android.game.yopuzzle.bl.a(a, com.yodesoft.android.game.yopuzzle.bl.l(a), true));
            return;
        }
    }

    final com.yodesoft.android.game.yopuzzle.bl a;
}
