// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.graphics.Bitmap;
import java.util.ArrayList;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            bg

class d
{

    d()
    {
        a = new ArrayList();
    }

    private boolean a(com.yodesoft.android.game.yopuzzle.bg bg1, com.yodesoft.android.game.yopuzzle.bg bg2)
    {
        if(java.lang.Math.abs(bg1.b - bg2.b) + java.lang.Math.abs(bg1.c - bg2.c) == 1)
            return true;
        int i1 = bg2.j.size();
        for(int i = 0; i < i1; i++)
        {
            com.yodesoft.android.game.yopuzzle.bg bg3 = (com.yodesoft.android.game.yopuzzle.bg)bg2.j.get(i);
            if(java.lang.Math.abs(bg1.b - bg3.b) + java.lang.Math.abs(bg1.c - bg3.c) == 1)
                return true;
        }

        int j1 = bg1.j.size();
        for(int j = 0; j < j1; j++)
        {
            com.yodesoft.android.game.yopuzzle.bg bg4 = (com.yodesoft.android.game.yopuzzle.bg)bg1.j.get(j);
            if(java.lang.Math.abs(bg2.b - bg4.b) + java.lang.Math.abs(bg2.c - bg4.c) == 1)
                return true;
        }

        for(int k = 0; k < j1; k++)
        {
            for(int l = 0; l < i1; l++)
            {
                com.yodesoft.android.game.yopuzzle.bg bg5 = (com.yodesoft.android.game.yopuzzle.bg)bg1.j.get(k);
                com.yodesoft.android.game.yopuzzle.bg bg6 = (com.yodesoft.android.game.yopuzzle.bg)bg2.j.get(l);
                int k1 = java.lang.Math.abs(bg6.b - bg5.b);
                if(java.lang.Math.abs(bg6.c - bg5.c) + k1 == 1)
                    return true;
            }

        }

        return false;
    }

    public com.yodesoft.android.game.yopuzzle.bg a(float f, float f1)
    {
        int i = a.size() - 1;
_L2:
        com.yodesoft.android.game.yopuzzle.bg bg1;
        if(i < 0)
            break MISSING_BLOCK_LABEL_270;
        bg1 = (com.yodesoft.android.game.yopuzzle.bg)a.get(i);
        if(f <= bg1.m || f1 <= bg1.n || f >= bg1.m + (float)bg1.o || f1 >= bg1.n + (float)bg1.p)
            break MISSING_BLOCK_LABEL_130;
        if(bg1.h.getPixel((int)(f - bg1.m), (int)(f1 - bg1.n)) != 0)
            break; /* Loop/switch isn't completed */
_L3:
        i--;
        if(true) goto _L2; else goto _L1
_L1:
        a.remove(bg1);
        a.add(bg1);
        return bg1;
        int j = bg1.j.size() - 1;
        while(j >= 0) 
        {
            com.yodesoft.android.game.yopuzzle.bg bg2 = (com.yodesoft.android.game.yopuzzle.bg)bg1.j.get(j);
            if(f <= bg2.m || f1 <= bg2.n || f >= bg2.m + (float)bg2.o || f1 >= bg2.n + (float)bg2.p || bg2.h.getPixel((int)(f - bg2.m), (int)(f1 - bg2.n)) == 0)
            {
                j--;
            } else
            {
                a.remove(bg1);
                a.add(bg1);
                return bg1;
            }
        }
          goto _L3
        return null;
    }

    public com.yodesoft.android.game.yopuzzle.bg a(com.yodesoft.android.game.yopuzzle.bg bg1, int i)
    {
        if(bg1.k == 0 && java.lang.Math.abs((bg1.m + (float)bg1.q) - (float)bg1.d) <= (float)i && java.lang.Math.abs((bg1.n + (float)bg1.r) - (float)bg1.e) <= (float)i)
        {
            bg1.m = bg1.d - bg1.q;
            bg1.n = bg1.e - bg1.r;
            a.remove(bg1);
            return bg1;
        } else
        {
            return null;
        }
    }

    public void a(com.yodesoft.android.game.yopuzzle.bg bg1)
    {
        bg1.j.add(bg1);
        int k = bg1.j.size();
        int i = 0;
        do
        {
            if(i >= k)
                break;
            com.yodesoft.android.game.yopuzzle.bg bg2 = (com.yodesoft.android.game.yopuzzle.bg)bg1.j.get(i);
            int j = 0;
            while(j < k) 
            {
                com.yodesoft.android.game.yopuzzle.bg bg3 = (com.yodesoft.android.game.yopuzzle.bg)bg1.j.get(j);
                if(bg2 != bg3)
                {
                    if(bg2.s == bg3.v && bg2.t == bg3.u)
                    {
                        bg2.w = false;
                        bg3.y = false;
                    }
                    if(bg2.t == bg3.s && bg2.u == bg3.v)
                    {
                        bg2.x = false;
                        bg3.z = false;
                    }
                    if(bg2.u == bg3.t && bg2.v == bg3.s)
                    {
                        bg2.y = false;
                        bg3.w = false;
                    }
                    if(bg2.v == bg3.u && bg2.s == bg3.t)
                    {
                        bg2.z = false;
                        bg3.x = false;
                    }
                }
                j++;
            }
            i++;
        } while(true);
        bg1.j.remove(bg1);
    }

    public void a(com.yodesoft.android.game.yopuzzle.bg abg[], int i, int j)
    {
        int k = 0;
        do
        {
            if(k >= i)
                break;
            int l = 0;
            while(l < j) 
            {
                int i1 = k * j + l;
                com.yodesoft.android.game.yopuzzle.bg bg5 = abg[i1];
                if(bg5 != null)
                {
                    com.yodesoft.android.game.yopuzzle.bg bg1;
                    com.yodesoft.android.game.yopuzzle.bg bg2;
                    com.yodesoft.android.game.yopuzzle.bg bg3;
                    com.yodesoft.android.game.yopuzzle.bg bg4;
                    if(l < j - 1)
                        bg1 = abg[i1 + 1];
                    else
                        bg1 = null;
                    if(l > 0)
                        bg2 = abg[i1 - 1];
                    else
                        bg2 = null;
                    if(k < i - 1)
                        bg3 = abg[i1 + j];
                    else
                        bg3 = null;
                    if(k > 0)
                        bg4 = abg[i1 - j];
                    else
                        bg4 = null;
                    if(bg2 != null)
                        if(bg2.a == bg5.a - 1)
                        {
                            bg2.x = false;
                            bg5.z = false;
                        } else
                        {
                            bg2.x = true;
                            bg5.z = true;
                        }
                    if(bg1 != null)
                        if(bg1.a == bg5.a + 1)
                        {
                            bg1.z = false;
                            bg5.x = false;
                        } else
                        {
                            bg1.z = true;
                            bg5.x = true;
                        }
                    if(bg4 != null)
                        if(bg4.a == bg5.a - j)
                        {
                            bg4.y = false;
                            bg5.w = false;
                        } else
                        {
                            bg4.y = true;
                            bg5.w = true;
                        }
                    if(bg3 != null)
                        if(bg3.a == bg5.a + j)
                        {
                            bg3.w = false;
                            bg5.y = false;
                        } else
                        {
                            bg3.w = true;
                            bg5.y = true;
                        }
                }
                l++;
            }
            k++;
        } while(true);
    }

    public boolean a()
    {
        return a.size() == 1;
    }

    public boolean a(com.yodesoft.android.game.yopuzzle.bg abg[])
    {
        for(int i = 0; i < abg.length; i++)
            if(abg[i].a != i)
                return false;

        return true;
    }

    public boolean a(com.yodesoft.android.game.yopuzzle.bg abg[], int i)
    {
        int j;
        int k;
        k = abg.length;
        j = 0;
_L2:
        if(j >= k)
            break MISSING_BLOCK_LABEL_51;
        if(j != i)
            break; /* Loop/switch isn't completed */
_L4:
        j++;
        if(true) goto _L2; else goto _L1
_L1:
        com.yodesoft.android.game.yopuzzle.bg bg1;
        bg1 = abg[j];
        if(bg1 == null)
            return false;
        if(bg1.a == j) goto _L4; else goto _L3
_L3:
        return false;
        return true;
    }

    public com.yodesoft.android.game.yopuzzle.bg b(com.yodesoft.android.game.yopuzzle.bg bg1, int i)
    {
        int j = a.size() - 1;
_L3:
        com.yodesoft.android.game.yopuzzle.bg bg2;
        do
        {
            if(j < 0)
                break MISSING_BLOCK_LABEL_246;
            bg2 = (com.yodesoft.android.game.yopuzzle.bg)a.get(j);
            if(bg2 == bg1)
            {
                j--;
            } else
            {
label0:
                {
                    if(bg2.k == bg1.k)
                        break label0;
                    j--;
                }
            }
        } while(true);
        float f;
        float f1;
        float f2;
        float f3;
        float f4;
        float f5;
        float f6;
        float f7;
        f = bg1.m;
        f1 = bg1.q;
        f2 = bg1.n;
        f3 = bg1.r;
        f4 = bg2.m;
        f5 = bg2.q;
        f6 = bg2.n;
        f7 = bg2.r;
        if(java.lang.Math.abs((float)(bg1.d - bg2.d) - ((f + f1) - (f4 + f5))) > (float)i || java.lang.Math.abs((float)(bg1.e - bg2.e) - ((f2 + f3) - (f6 + f7))) > (float)i || !a(bg1, bg2)) goto _L2; else goto _L1
_L1:
        if(bg2 != null)
        {
            bg1.b(bg2);
            a.remove(j);
            a.remove(bg1);
            a.add(bg1);
            return bg1;
        } else
        {
            return null;
        }
_L2:
        j--;
          goto _L3
        bg2 = null;
          goto _L1
    }

    public boolean b()
    {
        return a.size() == 0;
    }

    public void c()
    {
        int j = a.size();
        for(int i = 0; i < j; i++)
        {
            com.yodesoft.android.game.yopuzzle.bg bg1 = (com.yodesoft.android.game.yopuzzle.bg)a.get(i);
            bg1.h.recycle();
            bg1.i.recycle();
        }

        a.clear();
        java.lang.System.gc();
    }

    public java.util.ArrayList a;
}
