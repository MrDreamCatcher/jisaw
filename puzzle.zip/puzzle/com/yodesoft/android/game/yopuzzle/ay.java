// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.content.Context;
import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.CycleInterpolator;
import java.util.ArrayList;
import java.util.Random;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            x, aa

public class ay extends android.view.View
{

    public ay(android.content.Context context)
    {
        super(context);
        d = 320;
        e = 480;
        c = context;
        f = new Random();
        g = 1600;
        h = 36;
        i = 3;
        k = new x(this, g);
        java.lang.Object obj = (android.view.WindowManager)c.getSystemService("window");
        context = new DisplayMetrics();
        ((android.view.WindowManager) (obj)).getDefaultDisplay().getMetrics(context);
        obj = ((android.view.WindowManager) (obj)).getDefaultDisplay();
        d = ((android.view.Display) (obj)).getWidth();
        e = ((android.view.Display) (obj)).getHeight();
        q = ((android.util.DisplayMetrics) (context)).density;
        l = new Paint();
        m = new AccelerateDecelerateInterpolator();
        n = new CycleInterpolator(1.0F);
        p = new BlurMaskFilter(3F, android.graphics.BlurMaskFilter.Blur.INNER);
        j = new ArrayList();
        b();
    }

    static float a(com.yodesoft.android.game.yopuzzle.ay ay1, float f1)
    {
        ay1.o = f1;
        return f1;
    }

    private void a(long l1)
    {
        int i1 = j.size();
        if(i1 <= 0)
        {
            k.cancel();
            return;
        }
        i1--;
        while(i1 >= 0) 
        {
            com.yodesoft.android.game.yopuzzle.aa aa1 = (com.yodesoft.android.game.yopuzzle.aa)j.get(i1);
            aa1.f = (int)(n.getInterpolation(o) * aa1.i * 255F);
            float f1;
            if(aa1.f < 0)
                aa1.f = aa1.f * -1;
            else
            if(aa1.f > 255)
                aa1.f = 255;
            f1 = m.getInterpolation(o) * aa1.i * (float)aa1.g;
            aa1.c = aa1.a + (int)(java.lang.Math.cos(aa1.h) * (double)f1);
            aa1.d = aa1.b + (int)(java.lang.Math.sin(aa1.h) * (double)f1);
            if(f1 >= (float)aa1.g)
                j.remove(i1);
            i1--;
        }
        postInvalidate();
    }

    static void a(com.yodesoft.android.game.yopuzzle.ay ay1, long l1)
    {
        ay1.a(l1);
    }

    private void b()
    {
        if(j.size() != h * i)
        {
            j.clear();
            int k1 = d / 2;
            int l1 = e / 2;
            int i2 = k1 / 4;
            int j2 = 360 / (i * 2);
            float f1 = (float)java.lang.Math.toRadians(f.nextInt(360));
            int i1 = 0;
            while(i1 < i) 
            {
                f1 += (float)java.lang.Math.toRadians(f.nextInt(j2) + j2);
                int k2 = (int)(java.lang.Math.cos(f1) * (double)(k1 / 2));
                int l2 = (int)(java.lang.Math.sin(f1) * (double)(l1 / 2));
                int j1 = 0;
                while(j1 < h) 
                {
                    com.yodesoft.android.game.yopuzzle.aa aa1 = new aa(this, null);
                    aa1.h = (float)java.lang.Math.toRadians(f.nextInt(360));
                    aa1.a = k2 + k1;
                    aa1.b = l2 + l1;
                    aa1.e = 96;
                    aa1.g = i2 * 3 + f.nextInt(i2);
                    aa1.j = 2;
                    aa1.i = 1.1F + (float)f.nextInt(80) / 100F;
                    aa1.l = a[f.nextInt(a.length)];
                    if(aa1.j == 0)
                        aa1.k = f.nextInt(4) + 4;
                    else
                    if(aa1.j == 1)
                    {
                        aa1.k = f.nextInt(4) + 8;
                    } else
                    {
                        aa1.k = f.nextInt(4) + 20;
                        aa1.m = b[f.nextInt(b.length)];
                    }
                    aa1.k = (int)((float)aa1.k * q);
                    j.add(aa1);
                    j1++;
                }
                i1++;
            }
        }
    }

    public void a()
    {
        k.cancel();
        b();
        setVisibility(0);
        k.start();
    }

    public void onDraw(android.graphics.Canvas canvas)
    {
        canvas.save();
        int j1 = j.size();
        int i1 = 0;
        while(i1 < j1) 
        {
            com.yodesoft.android.game.yopuzzle.aa aa1 = (com.yodesoft.android.game.yopuzzle.aa)j.get(i1);
            l.setColor(aa1.l);
            l.setAlpha(aa1.f);
            l.setMaskFilter(p);
            int k1 = aa1.c;
            int l1 = aa1.d;
            int i2 = aa1.k;
            if(aa1.j == 0)
                canvas.drawCircle(k1, l1, i2, l);
            else
            if(aa1.j == 1)
            {
                i2 /= 2;
                canvas.drawRect(k1 - i2, l1 - i2, k1 + i2, i2 + l1, l);
            } else
            {
                l.setMaskFilter(null);
                l.setTextSize(i2);
                l.setAntiAlias(true);
                l.setTextAlign(android.graphics.Paint.Align.CENTER);
                canvas.drawText(aa1.m, k1, l1, l);
            }
            i1++;
        }
        canvas.restore();
    }

    public void onSizeChanged(int i1, int j1, int k1, int l1)
    {
        d = i1;
        e = j1;
        b();
    }

    private static final int a[] = {
        0x6699ff, 0x99cc33, 0xffcc00, 0x3366cc, 52224, 0xff9900, 13209, 0xff6600, 0xff6600, 0xcc0000
    };
    private static final java.lang.String b[] = {
        "\u2605", "\u2606"
    };
    private android.content.Context c;
    private int d;
    private int e;
    private java.util.Random f;
    private int g;
    private int h;
    private int i;
    private java.util.ArrayList j;
    private com.yodesoft.android.game.yopuzzle.x k;
    private android.graphics.Paint l;
    private android.view.animation.AccelerateDecelerateInterpolator m;
    private android.view.animation.CycleInterpolator n;
    private float o;
    private android.graphics.BlurMaskFilter p;
    private float q;

}
