// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import java.util.ArrayList;
import java.util.Random;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            bk, bg, d, w, 
//            ah

class t extends com.yodesoft.android.game.yopuzzle.bk
{

    t(android.content.Context context)
    {
        super(context);
        k = 5;
        u = new com.yodesoft.android.game.yopuzzle.bg[0];
    }

    private void a(android.graphics.Canvas canvas, android.graphics.Paint paint)
    {
        int j = u.length;
        for(int i = 0; i < j; i++)
            if(t[i])
            {
                paint = u[i];
                canvas.drawBitmap(((com.yodesoft.android.game.yopuzzle.bg) (paint)).h, ((com.yodesoft.android.game.yopuzzle.bg) (paint)).m, ((com.yodesoft.android.game.yopuzzle.bg) (paint)).n, null);
            }

    }

    private boolean h()
    {
        int j = t.length;
        for(int i = 0; i < j; i++)
            if(!t[i])
                return false;

        return true;
    }

    public void a(int i, int j)
    {
        super.a(i, j);
        java.util.Random random = new Random();
        j = e.a.size();
        t = new boolean[j];
        u = new com.yodesoft.android.game.yopuzzle.bg[j];
        for(i = 0; i < j; i++)
        {
            com.yodesoft.android.game.yopuzzle.bg bg1 = (com.yodesoft.android.game.yopuzzle.bg)e.a.get(i);
            bg1.m = bg1.m + (float)p;
            bg1.n = bg1.n + (float)q;
            t[i] = true;
            u[i] = bg1;
        }

        int k = this.i.a;
        int l = this.i.b;
        for(i = 0; i < k * 61 * l; i++)
        {
            int i1 = random.nextInt(j);
            a(u[i1], this.i.a, this.i.b);
        }

        if(n != null)
            n.recycle();
        n = a(m);
        r = false;
    }

    void a(com.yodesoft.android.game.yopuzzle.bg bg1, int i, int j)
    {
        boolean aflag[] = t;
        int k = bg1.a;
        byte byte0;
        if(!t[bg1.a])
            byte0 = 1;
        else
            byte0 = 0;
        aflag[k] = byte0;
        if(bg1.b > 0)
        {
            int l = bg1.a - j;
            boolean aflag1[] = t;
            if(!t[l])
                byte0 = 1;
            else
                byte0 = 0;
            aflag1[l] = byte0;
        }
        if(bg1.b < i - 1)
        {
            i = bg1.a + j;
            aflag1 = t;
            if(!t[i])
                byte0 = 1;
            else
                byte0 = 0;
            aflag1[i] = byte0;
        }
        if(bg1.c > 0)
        {
            i = bg1.a - 1;
            aflag1 = t;
            if(!t[i])
                byte0 = 1;
            else
                byte0 = 0;
            aflag1[i] = byte0;
        }
        if(bg1.c < j - 1)
        {
            i = bg1.a + 1;
            bg1 = t;
            if(!t[i])
                byte0 = 1;
            else
                byte0 = 0;
            bg1[i] = byte0;
        }
    }

    public void onDraw(android.graphics.Canvas canvas)
    {
        l.setAlpha(128);
        if(n != null && !n.isRecycled())
            canvas.drawBitmap(n, p, q, l);
        l.setAlpha(255);
        canvas.save();
        canvas.translate(p, q);
        a(canvas, l, e.a);
        canvas.restore();
        a(canvas, ((android.graphics.Paint) (null)));
        if(a)
            b(canvas, l, e.a);
    }

    public boolean onTouchEvent(android.view.MotionEvent motionevent)
    {
        float f;
        float f1;
        if(super.onTouchEvent(motionevent))
            return true;
        f = motionevent.getX();
        f1 = motionevent.getY();
        motionevent.getAction();
        JVM INSTR tableswitch 0 0: default 44
    //                   0 50;
           goto _L1 _L2
_L1:
        invalidate();
        return true;
_L2:
        motionevent = e.a(f, f1);
        if(motionevent != null)
        {
            c();
            a(motionevent, i.a, i.b);
            g.h();
            if(h())
                d();
        }
        if(true) goto _L1; else goto _L3
_L3:
    }

    private boolean t[];
    private com.yodesoft.android.game.yopuzzle.bg u[];
}
