// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import java.util.ArrayList;
import java.util.Random;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            bk, bg, w, d, 
//            af, ah

class m extends com.yodesoft.android.game.yopuzzle.bk
{

    m(android.content.Context context)
    {
        super(context);
        k = 4;
        t = new com.yodesoft.android.game.yopuzzle.bg[0];
    }

    private void a(android.graphics.Canvas canvas, android.graphics.Paint paint)
    {
        int j = t.length;
        for(int i = 0; i < j; i++)
        {
            paint = t[i];
            canvas.drawBitmap(((com.yodesoft.android.game.yopuzzle.bg) (paint)).h, ((com.yodesoft.android.game.yopuzzle.bg) (paint)).m, ((com.yodesoft.android.game.yopuzzle.bg) (paint)).n, null);
        }

    }

    private void a(com.yodesoft.android.game.yopuzzle.bg bg1, android.graphics.Canvas canvas, android.graphics.Paint paint)
    {
        int k = -1;
        for(int i = 0; i < t.length; i++)
            if(t[i] == bg1)
                k = i;

        int j = k / this.i.b;
        k %= this.i.b;
        l.setColor(0xc0ffcc00);
        l.setStrokeWidth(5F);
        l.setMaskFilter(s);
        float f = bg1.m;
        float f1 = bg1.n;
        float f2 = bg1.m;
        float f3 = bg1.f;
        float f4 = bg1.n;
        canvas.drawRect(f, f1, f3 + f2, (float)bg1.g + f4, l);
        l.setStrokeWidth(4F);
        f = bg1.m;
        if(k > 0)
            f = bg1.m - (float)bg1.f;
        f1 = bg1.m;
        f2 = bg1.f;
        if(k < this.i.b - 1)
            f1 = bg1.m + (float)(bg1.f * 2);
        else
            f1 += f2;
        f2 = bg1.n;
        f3 = bg1.n;
        canvas.drawRect(f, f2, f1, (float)bg1.g + f3, l);
        f = bg1.n;
        if(j > 0)
            f = bg1.n - (float)bg1.g;
        f1 = bg1.n;
        f2 = bg1.g;
        if(j < this.i.a - 1)
            f1 = bg1.n + (float)(bg1.g * 2);
        else
            f1 += f2;
        f2 = bg1.m;
        f3 = bg1.m;
        canvas.drawRect(f2, f, (float)bg1.f + f3, f1, l);
    }

    private boolean a(com.yodesoft.android.game.yopuzzle.bg bg1, com.yodesoft.android.game.yopuzzle.bg bg2, int i, int j)
    {
        int k = 0;
_L6:
        int l;
        if(k >= i)
            break; /* Loop/switch isn't completed */
        l = 0;
_L2:
        int i1;
        if(l >= j)
            break MISSING_BLOCK_LABEL_138;
        i1 = k * j + l;
        if(t[i1] == bg1)
            break; /* Loop/switch isn't completed */
_L4:
        l++;
        if(true) goto _L2; else goto _L1
_L1:
        if(l < j - 1 && bg2 == t[i1 + 1])
            return true;
        if(l > 0 && bg2 == t[i1 - 1])
            return true;
        if(k < i - 1 && bg2 == t[i1 + j])
            return true;
        if(k <= 0 || bg2 != t[i1 - j]) goto _L4; else goto _L3
_L3:
        return true;
        k++;
        if(true) goto _L6; else goto _L5
_L5:
        return false;
    }

    public void a(int i, int j)
    {
        super.a(i, j);
        java.util.Random random = new Random();
        j = e.a.size();
        t = new com.yodesoft.android.game.yopuzzle.bg[j];
        for(i = 0; i < j; i++)
        {
            com.yodesoft.android.game.yopuzzle.bg bg1 = (com.yodesoft.android.game.yopuzzle.bg)e.a.get(i);
            bg1.m = bg1.m + (float)p;
            bg1.n = bg1.n + (float)q;
            t[i] = bg1;
        }

        for(i = 0; i < j; i++)
        {
            int k;
            do
                k = random.nextInt(j);
            while(k == i);
            com.yodesoft.android.game.yopuzzle.bg bg2 = t[i];
            com.yodesoft.android.game.yopuzzle.bg bg3 = t[k];
            float f = bg2.m;
            float f1 = bg2.n;
            bg2.m = bg3.m;
            bg2.n = bg3.n;
            bg3.m = f;
            bg3.n = f1;
            t[i] = bg3;
            t[k] = bg2;
        }

        e.a(t, this.i.a, this.i.b);
        this.f.a(t, this.i.k);
        r = false;
    }

    void a(com.yodesoft.android.game.yopuzzle.bg bg1, com.yodesoft.android.game.yopuzzle.bg bg2)
    {
        int i;
        int j;
        int k;
        i = 0;
        k = -1;
        j = -1;
_L3:
        if(i >= t.length)
            break MISSING_BLOCK_LABEL_128;
        com.yodesoft.android.game.yopuzzle.bg bg3 = t[i];
        if(bg3 == bg1)
            j = i;
        if(bg3 == bg2)
            k = i;
        if(j <= -1 || k <= -1) goto _L2; else goto _L1
_L1:
        i = j;
_L4:
        float f = bg1.m;
        float f1 = bg1.n;
        bg1.m = bg2.m;
        bg1.n = bg2.n;
        bg2.m = f;
        bg2.n = f1;
        t[i] = bg2;
        t[k] = bg1;
        return;
_L2:
        i++;
          goto _L3
        i = j;
          goto _L4
    }

    public void onDraw(android.graphics.Canvas canvas)
    {
        canvas.save();
        canvas.translate(p, q);
        a(canvas, l, e.a);
        canvas.restore();
        a(canvas, ((android.graphics.Paint) (null)));
        if(d != null)
            a(d, canvas, l);
        if(a)
            b(canvas, l, e.a);
    }

    public boolean onTouchEvent(android.view.MotionEvent motionevent)
    {
        float f;
        float f1;
        if(super.onTouchEvent(motionevent))
            return true;
        f = motionevent.getX();
        f1 = motionevent.getY();
        motionevent.getAction();
        JVM INSTR tableswitch 0 0: default 44
    //                   0 50;
           goto _L1 _L2
_L1:
        invalidate();
        return true;
_L2:
        motionevent = e.a(f, f1);
        if(motionevent == null || motionevent == d)
            d = null;
        else
        if(d == null)
            d = motionevent;
        else
        if(a(d, motionevent, i.a, i.b))
        {
            c();
            a(d, motionevent);
            d = null;
            e.a(t, i.a, i.b);
            this.f.a(t, i.k);
            g.j();
            if(e.a(t))
                d();
        } else
        {
            d = null;
            g.i();
        }
        if(true) goto _L1; else goto _L3
_L3:
    }

    private com.yodesoft.android.game.yopuzzle.bg t[];
}
