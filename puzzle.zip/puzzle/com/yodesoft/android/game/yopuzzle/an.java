// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.content.DialogInterface;
import android.os.Handler;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            n, ah, bk, a

class an
    implements android.content.DialogInterface.OnClickListener
{

    an(com.yodesoft.android.game.yopuzzle.n n1)
    {
        a = n1;
        super();
    }

    public void onClick(android.content.DialogInterface dialoginterface, int i)
    {
        com.yodesoft.android.game.yopuzzle.n.j(a).b();
        if(i != -1) goto _L2; else goto _L1
_L1:
        com.yodesoft.android.game.yopuzzle.n.H(a);
        JVM INSTR tableswitch 0 4: default 56
    //                   0 57
    //                   1 75
    //                   2 86
    //                   3 100
    //                   4 114;
           goto _L2 _L3 _L4 _L5 _L6 _L7
_L2:
        return;
_L3:
        com.yodesoft.android.game.yopuzzle.n.m(a);
        com.yodesoft.android.game.yopuzzle.n.d(a).a();
        return;
_L4:
        com.yodesoft.android.game.yopuzzle.n.i(a).c();
        return;
_L5:
        com.yodesoft.android.game.yopuzzle.n.t(a).sendEmptyMessage(6);
        return;
_L6:
        com.yodesoft.android.game.yopuzzle.n.t(a).sendEmptyMessage(7);
        return;
_L7:
        a.g();
        com.yodesoft.android.game.yopuzzle.n.t(a).sendEmptyMessage(1);
        return;
    }

    final com.yodesoft.android.game.yopuzzle.n a;
}
