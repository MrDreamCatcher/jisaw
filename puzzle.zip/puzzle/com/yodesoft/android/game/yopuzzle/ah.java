// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.content.Context;
import android.media.AudioManager;
import android.media.SoundPool;
import java.util.HashMap;

class ah
{

    private ah(android.content.Context context)
    {
        d = context;
        e = true;
        f = (android.media.AudioManager)d.getSystemService("audio");
        k();
    }

    public static com.yodesoft.android.game.yopuzzle.ah a(android.content.Context context)
    {
        if(a == null)
            a = new ah(context);
        return a;
    }

    private void k()
    {
        b = new SoundPool(5, 3, 0);
        c = new HashMap();
        c.put(java.lang.Integer.valueOf(1), java.lang.Integer.valueOf(b.load(d, 0x7f050008, 1)));
        c.put(java.lang.Integer.valueOf(2), java.lang.Integer.valueOf(b.load(d, 0x7f050000, 1)));
        c.put(java.lang.Integer.valueOf(3), java.lang.Integer.valueOf(b.load(d, 0x7f050005, 1)));
        c.put(java.lang.Integer.valueOf(4), java.lang.Integer.valueOf(b.load(d, 0x7f050001, 1)));
        c.put(java.lang.Integer.valueOf(5), java.lang.Integer.valueOf(b.load(d, 0x7f050004, 1)));
        c.put(java.lang.Integer.valueOf(6), java.lang.Integer.valueOf(b.load(d, 0x7f050002, 1)));
        c.put(java.lang.Integer.valueOf(7), java.lang.Integer.valueOf(b.load(d, 0x7f050003, 1)));
        c.put(java.lang.Integer.valueOf(9), java.lang.Integer.valueOf(b.load(d, 0x7f050009, 1)));
        c.put(java.lang.Integer.valueOf(8), java.lang.Integer.valueOf(b.load(d, 0x7f050007, 1)));
        c.put(java.lang.Integer.valueOf(10), java.lang.Integer.valueOf(b.load(d, 0x7f050006, 1)));
    }

    public void a()
    {
        a(3);
    }

    public void a(int l)
    {
        if(!e)
        {
            return;
        } else
        {
            float f1 = (float)f.getStreamVolume(3) / (float)f.getStreamMaxVolume(3);
            b.play(((java.lang.Integer)c.get(java.lang.Integer.valueOf(l))).intValue(), f1, f1, 1, 0, 1.0F);
            return;
        }
    }

    public void a(boolean flag)
    {
        e = flag;
    }

    public void b()
    {
        a(2);
    }

    public void c()
    {
        a(1);
    }

    public void d()
    {
        a(4);
    }

    public void e()
    {
        a(5);
    }

    public void f()
    {
        a(6);
    }

    public void g()
    {
        a(7);
    }

    public void h()
    {
        a(8);
    }

    public void i()
    {
        a(9);
    }

    public void j()
    {
        a(10);
    }

    private static com.yodesoft.android.game.yopuzzle.ah a = null;
    private android.media.SoundPool b;
    private java.util.HashMap c;
    private android.content.Context d;
    private boolean e;
    private android.media.AudioManager f;

}
