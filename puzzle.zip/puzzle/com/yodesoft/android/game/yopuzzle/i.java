// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.widget.Toast;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            YoPuzzle, ah, av

class i
    implements android.content.DialogInterface.OnClickListener
{

    i(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        a = yopuzzle;
        super();
    }

    public void onClick(android.content.DialogInterface dialoginterface, int j)
    {
        a.a.b();
        if(j != -1) goto _L2; else goto _L1
_L1:
        com.yodesoft.android.game.yopuzzle.YoPuzzle.w(a);
        JVM INSTR tableswitch 0 6: default 64
    //                   0 65
    //                   1 107
    //                   2 64
    //                   3 124
    //                   4 166
    //                   5 64
    //                   6 107;
           goto _L3 _L4 _L5 _L3 _L6 _L7 _L3 _L5
_L3:
        return;
_L4:
        dialoginterface = android.widget.Toast.makeText(a.getApplicationContext(), 0x7f07005c, 1);
        if(a.b.f())
            dialoginterface.show();
        com.yodesoft.android.game.yopuzzle.YoPuzzle.n(a).finish();
        return;
_L5:
        a.startActivity(new Intent("android.settings.WIRELESS_SETTINGS"));
        return;
_L6:
        dialoginterface = a.b.g();
        if(dialoginterface.length() > 4)
        {
            dialoginterface = new Intent("android.intent.action.VIEW", android.net.Uri.parse(dialoginterface));
            a.startActivity(dialoginterface);
            return;
        }
        continue; /* Loop/switch isn't completed */
_L7:
        com.yodesoft.android.game.yopuzzle.YoPuzzle.x(a);
        return;
_L2:
        if(j == -2)
        {
            if(com.yodesoft.android.game.yopuzzle.YoPuzzle.w(a) == 4)
            {
                com.yodesoft.android.game.yopuzzle.YoPuzzle.a(a, null);
                return;
            }
            if(com.yodesoft.android.game.yopuzzle.YoPuzzle.w(a) == 6)
            {
                com.yodesoft.android.game.yopuzzle.YoPuzzle.y(a);
                return;
            }
        }
        if(true) goto _L3; else goto _L8
_L8:
    }

    final com.yodesoft.android.game.yopuzzle.YoPuzzle a;
}
