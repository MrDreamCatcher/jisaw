// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Handler;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            av, bb

final class v
    implements java.lang.Runnable
{

    v(com.yodesoft.android.game.yopuzzle.av av1, android.os.Handler handler)
    {
        a = av1;
        super();
        b = handler;
    }

    public void run()
    {
        android.os.Handler handler = b;
        java.lang.Object obj = com.yodesoft.android.game.yopuzzle.av.a(a).getPackageName();
        int i;
        try
        {
            i = com.yodesoft.android.game.yopuzzle.av.a(a).getPackageManager().getPackageInfo(((java.lang.String) (obj)), 0).versionCode;
        }
        catch(android.content.pm.PackageManager.NameNotFoundException namenotfoundexception)
        {
            namenotfoundexception.printStackTrace();
            return;
        }
        obj = (new bb()).a(((java.lang.String) (obj)), java.lang.String.valueOf(i));
        if(obj == null || ((java.lang.String) (obj)).length() <= 4)
            break MISSING_BLOCK_LABEL_105;
        try
        {
            obj = new JSONObject(((java.lang.String) (obj)));
            i = ((org.json.JSONObject) (obj)).getInt("err");
            obj = ((org.json.JSONObject) (obj)).getString("url");
        }
        catch(org.json.JSONException jsonexception)
        {
            jsonexception.printStackTrace();
            return;
        }
        if(i != 0)
            break MISSING_BLOCK_LABEL_105;
        com.yodesoft.android.game.yopuzzle.av.a(a, ((java.lang.String) (obj)));
        handler.sendEmptyMessage(9);
    }

    final com.yodesoft.android.game.yopuzzle.av a;
    private android.os.Handler b;
}
