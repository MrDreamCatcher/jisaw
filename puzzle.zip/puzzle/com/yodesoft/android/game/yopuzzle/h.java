// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.view.animation.OvershootInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            YoPuzzle

class h
    implements java.lang.Runnable
{

    h(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle, android.widget.ImageView imageview)
    {
        b = yopuzzle;
        a = imageview;
        super();
    }

    public void run()
    {
        android.view.animation.RotateAnimation rotateanimation = new RotateAnimation(-5F, 5F, (float)a.getWidth() * 0.5F, (float)a.getHeight() * 0.5F);
        rotateanimation.setRepeatCount(-1);
        rotateanimation.setRepeatMode(2);
        rotateanimation.setDuration(1200L);
        rotateanimation.setFillAfter(true);
        rotateanimation.setInterpolator(new OvershootInterpolator());
        a.startAnimation(rotateanimation);
    }

    final android.widget.ImageView a;
    final com.yodesoft.android.game.yopuzzle.YoPuzzle b;
}
