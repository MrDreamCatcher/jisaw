// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.os.CountDownTimer;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            ay

final class x extends android.os.CountDownTimer
{

    public x(com.yodesoft.android.game.yopuzzle.ay ay1, int i)
    {
        a = ay1;
        super(i * 2, 30L);
        c = i;
        b = c;
    }

    public void onFinish()
    {
        b = c;
        a.postInvalidate();
    }

    public void onTick(long l)
    {
        long l1 = b;
        b = l;
        com.yodesoft.android.game.yopuzzle.ay.a(a, 2.0F - (float)b / (float)c);
        com.yodesoft.android.game.yopuzzle.ay.a(a, l1 - l);
    }

    final com.yodesoft.android.game.yopuzzle.ay a;
    private long b;
    private long c;
}
