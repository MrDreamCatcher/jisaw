// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import java.util.Random;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            ax, bg

public class o
{

    public o()
    {
        h = 1.2F;
    }

    static float a(com.yodesoft.android.game.yopuzzle.o o1)
    {
        return o1.h;
    }

    public void a()
    {
        f = com.yodesoft.android.game.yopuzzle.ax.a(b, d, c, e);
        h = 1.05F + (float)com.yodesoft.android.game.yopuzzle.ax.b().nextInt(6) / 10F;
    }

    public void b()
    {
        g = (float)java.lang.Math.toRadians(com.yodesoft.android.game.yopuzzle.ax.b(b, d, c, e));
    }

    public com.yodesoft.android.game.yopuzzle.bg a;
    public float b;
    public float c;
    public float d;
    public float e;
    public float f;
    public float g;
    private float h;
}
