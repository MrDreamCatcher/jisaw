// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.MotionEvent;
import java.util.ArrayList;
import java.util.Random;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            bk, aw, a, w, 
//            ah

class ae extends com.yodesoft.android.game.yopuzzle.bk
{

    ae(android.content.Context context)
    {
        super(context);
        u = new ArrayList();
        k = 7;
        v = new Rect();
        w = new Rect();
    }

    private com.yodesoft.android.game.yopuzzle.aw a(java.util.ArrayList arraylist, float f, float f1)
    {
        for(int i = arraylist.size() - 1; i >= 0; i--)
        {
            com.yodesoft.android.game.yopuzzle.aw aw1 = (com.yodesoft.android.game.yopuzzle.aw)arraylist.get(i);
            if(f >= (float)aw1.g && f1 >= (float)aw1.h && f <= (float)aw1.i && f1 <= (float)aw1.j)
                return aw1;
        }

        return null;
    }

    private void a(com.yodesoft.android.game.yopuzzle.aw aw1, com.yodesoft.android.game.yopuzzle.aw aw2)
    {
        int i = aw1.g;
        int j = aw1.h;
        int k = aw1.i;
        int l = aw1.j;
        aw1.i = aw2.i;
        aw1.j = aw2.j;
        aw1.g = aw2.g;
        aw1.h = aw2.h;
        aw2.i = k;
        aw2.j = l;
        aw2.g = i;
        aw2.h = j;
        i = u.indexOf(aw1);
        j = u.indexOf(aw2);
        u.set(i, aw2);
        u.set(j, aw1);
    }

    private void a(java.util.ArrayList arraylist)
    {
        for(int i = arraylist.size() - 1; i >= 0; i--)
            ((com.yodesoft.android.game.yopuzzle.aw)arraylist.get(i)).f.recycle();

        arraylist.clear();
    }

    private void b(java.util.ArrayList arraylist)
    {
        arraylist = new Random();
        int k = u.size() - 1;
        for(int i = k; i >= 0; i--)
        {
            com.yodesoft.android.game.yopuzzle.aw aw1 = (com.yodesoft.android.game.yopuzzle.aw)u.get(i);
            int j;
            for(j = arraylist.nextInt(k); j == i; j = arraylist.nextInt(k));
            a(aw1, (com.yodesoft.android.game.yopuzzle.aw)u.get(j));
        }

    }

    private boolean c(java.util.ArrayList arraylist)
    {
        for(int i = arraylist.size() - 1; i >= 0; i--)
            if(((com.yodesoft.android.game.yopuzzle.aw)arraylist.get(i)).a != i)
                return false;

        return true;
    }

    public void a(int i, int j)
    {
        java.util.Random random;
        android.graphics.Canvas canvas;
        android.graphics.Rect rect;
        android.graphics.Rect rect1;
        int k;
        int l;
        int k1;
        int l1;
        int k2;
        int l2;
        int i3;
        int j3;
        a(u);
        m = this.j.a();
        k2 = m.getWidth();
        l2 = m.getHeight();
        p = (i - k2) / 2;
        q = (j - l2) / 2;
        i3 = k2 / this.i.b;
        j3 = l2 / this.i.a;
        random = new Random();
        canvas = new Canvas();
        rect = new Rect();
        rect1 = new Rect();
        k1 = i3 / 5;
        l1 = j3 / 5;
        k = 0;
        l = 0;
        i = 0;
        j = 0;
_L8:
        int i1;
        if(l >= this.i.a)
            break; /* Loop/switch isn't completed */
        i1 = i;
        boolean flag = false;
        i = k;
        k = i1;
        i1 = ((flag) ? 1 : 0);
_L6:
        com.yodesoft.android.game.yopuzzle.aw aw1;
        if(i1 >= this.i.b)
            break MISSING_BLOCK_LABEL_748;
        aw1 = new aw(this, null);
        random.nextInt(4);
        JVM INSTR tableswitch 0 3: default 224
    //                   0 682
    //                   1 688
    //                   2 695
    //                   3 702;
           goto _L1 _L2 _L3 _L4 _L5
_L1:
        aw1.d = i3 + j;
        aw1.e = j3 + k;
        if(i1 > 0)
        {
            com.yodesoft.android.game.yopuzzle.aw aw2 = (com.yodesoft.android.game.yopuzzle.aw)u.get(i - 1);
            int i2 = aw2.d;
            aw1.b = aw2.b + aw2.d;
            aw1.d = aw1.d - (i2 - i3);
        }
        if(l > 0)
        {
            java.lang.Object obj = (com.yodesoft.android.game.yopuzzle.aw)u.get(i - this.i.b);
            com.yodesoft.android.game.yopuzzle.aw aw3 = (com.yodesoft.android.game.yopuzzle.aw)u.get((i - this.i.b) + 1);
            int j2 = ((com.yodesoft.android.game.yopuzzle.aw) (obj)).e;
            aw1.c = ((com.yodesoft.android.game.yopuzzle.aw) (obj)).c + ((com.yodesoft.android.game.yopuzzle.aw) (obj)).e;
            aw1.e = aw1.e - (j2 - j3);
            if(((com.yodesoft.android.game.yopuzzle.aw) (obj)).c + ((com.yodesoft.android.game.yopuzzle.aw) (obj)).e > aw3.c + aw3.e)
                aw1.d = (((com.yodesoft.android.game.yopuzzle.aw) (obj)).b + ((com.yodesoft.android.game.yopuzzle.aw) (obj)).d) - aw1.b;
            else
            if(aw3.c + aw3.e > aw1.c)
                aw1.d = aw3.b - aw1.b;
        }
        if(i1 == this.i.b - 1)
            aw1.d = k2 - aw1.b;
        if(l == this.i.a - 1)
            aw1.e = l2 - aw1.c;
        aw1.a = i;
        aw1.g = aw1.b + p;
        aw1.h = aw1.c + q;
        aw1.i = aw1.g + aw1.d;
        aw1.j = aw1.h + aw1.e;
        obj = android.graphics.Bitmap.createBitmap(aw1.d, aw1.e, android.graphics.Bitmap.Config.ARGB_8888);
        canvas.setBitmap(((android.graphics.Bitmap) (obj)));
        aw1.f = ((android.graphics.Bitmap) (obj));
        rect.set(aw1.b, aw1.c, aw1.b + aw1.d, aw1.c + aw1.e);
        rect1.set(0, 0, aw1.d, aw1.e);
        canvas.drawBitmap(m, rect, rect1, null);
        u.add(aw1);
        i++;
        i1++;
        if(true) goto _L6; else goto _L2
_L2:
        j = k1;
          goto _L1
_L3:
        k = l1;
          goto _L1
_L4:
        j = -k1;
          goto _L1
_L5:
        k = -l1;
          goto _L1
        l++;
        int j1 = i;
        i = k;
        k = j1;
        if(true) goto _L8; else goto _L7
_L7:
        b(u);
        return;
    }

    public void onDraw(android.graphics.Canvas canvas)
    {
        l.setColor(0xc0ffffff);
        l.setStrokeWidth(3F);
        l.setStyle(android.graphics.Paint.Style.STROKE);
        for(int i = u.size() - 1; i >= 0; i--)
        {
            com.yodesoft.android.game.yopuzzle.aw aw1 = (com.yodesoft.android.game.yopuzzle.aw)u.get(i);
            v.set(0, 0, aw1.d, aw1.e);
            w.set(aw1.g, aw1.h, aw1.i, aw1.j);
            canvas.drawBitmap(aw1.f, v, w, null);
            canvas.drawRect(aw1.g, aw1.h, aw1.i, aw1.j, l);
        }

        if(t != null)
        {
            l.setColor(0xc0ff0000);
            com.yodesoft.android.game.yopuzzle.aw aw2 = t;
            canvas.drawRect(aw2.g, aw2.h, aw2.i, aw2.j, l);
        }
    }

    public boolean onTouchEvent(android.view.MotionEvent motionevent)
    {
        float f;
        float f1;
        if(super.onTouchEvent(motionevent))
            return true;
        f = motionevent.getX();
        f1 = motionevent.getY();
        motionevent.getAction();
        JVM INSTR tableswitch 1 1: default 44
    //                   1 50;
           goto _L1 _L2
_L1:
        invalidate();
        return true;
_L2:
        motionevent = a(u, f, f1);
        if(motionevent == null || motionevent == t)
            t = null;
        else
        if(t == null)
        {
            t = motionevent;
        } else
        {
            c();
            a(t, motionevent);
            t = null;
            g.j();
            if(c(u))
                d();
        }
        if(true) goto _L1; else goto _L3
_L3:
    }

    private com.yodesoft.android.game.yopuzzle.aw t;
    private java.util.ArrayList u;
    private android.graphics.Rect v;
    private android.graphics.Rect w;
}
