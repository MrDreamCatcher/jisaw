// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.content.Context;
import android.os.Handler;
import java.io.IOException;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            a

final class bi
    implements java.lang.Runnable
{

    bi(com.yodesoft.android.game.yopuzzle.a a1)
    {
        a = a1;
        super();
    }

    public void run()
    {
        android.os.Handler handler = com.yodesoft.android.game.yopuzzle.a.a(a);
        try
        {
            com.yodesoft.android.game.yopuzzle.a.l(a).setWallpaper(com.yodesoft.android.game.yopuzzle.a.b(a));
            handler.sendMessage(handler.obtainMessage(5));
            return;
        }
        catch(java.io.IOException ioexception)
        {
            handler.sendMessage(handler.obtainMessage(6));
            ioexception.printStackTrace();
            return;
        }
    }

    final com.yodesoft.android.game.yopuzzle.a a;
}
