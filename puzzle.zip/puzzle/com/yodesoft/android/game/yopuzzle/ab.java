// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import java.util.ArrayList;
import java.util.Random;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            bk, bg, d, w, 
//            af, ah

class ab extends com.yodesoft.android.game.yopuzzle.bk
{

    ab(android.content.Context context)
    {
        super(context);
        k = 2;
        t = new com.yodesoft.android.game.yopuzzle.bg[0];
    }

    private void a(android.graphics.Canvas canvas, android.graphics.Paint paint)
    {
        int j = t.length;
        for(int i = 0; i < j; i++)
        {
            paint = t[i];
            if(paint != null)
                canvas.drawBitmap(((com.yodesoft.android.game.yopuzzle.bg) (paint)).h, ((com.yodesoft.android.game.yopuzzle.bg) (paint)).m, ((com.yodesoft.android.game.yopuzzle.bg) (paint)).n, null);
        }

    }

    public void a(int i, int j)
    {
        super.a(i, j);
        j = e.a.size();
        t = new com.yodesoft.android.game.yopuzzle.bg[j];
        for(i = 0; i < j; i++)
        {
            com.yodesoft.android.game.yopuzzle.bg bg1 = (com.yodesoft.android.game.yopuzzle.bg)e.a.get(i);
            bg1.m = bg1.m + (float)p;
            bg1.n = bg1.n + (float)q;
            t[i] = bg1;
        }

        v.nextInt(4);
        1;
        JVM INSTR tableswitch 0 3: default 128
    //                   0 185
    //                   1 200
    //                   2 231
    //                   3 278;
           goto _L1 _L2 _L3 _L4 _L5
_L1:
        break; /* Loop/switch isn't completed */
_L5:
        break MISSING_BLOCK_LABEL_278;
_L6:
        int k = this.i.a;
        int l = this.i.b;
        i = 0;
        while(i < k * 61 * l) 
        {
            com.yodesoft.android.game.yopuzzle.bg bg2 = t[v.nextInt(j)];
            if(bg2 != null)
                a(bg2, this.i.a, this.i.b);
            i++;
        }
        break MISSING_BLOCK_LABEL_319;
_L2:
        t[0] = null;
        u = 0;
          goto _L6
_L3:
        t[this.i.b - 1] = null;
        u = this.i.b - 1;
          goto _L6
_L4:
        t[(this.i.a - 1) * this.i.b] = null;
        u = (this.i.a - 1) * this.i.b;
          goto _L6
        t[j - 1] = null;
        u = j - 1;
          goto _L6
        e.a(t, this.i.a, this.i.b);
        f.a(t, this.i.k);
        r = false;
        return;
    }

    void a(com.yodesoft.android.game.yopuzzle.bg bg1, int i, int j)
    {
        int k;
        int l;
        l = t.length;
        k = 0;
_L5:
        if(k >= l)
            break MISSING_BLOCK_LABEL_258;
        if(t[k] != bg1) goto _L2; else goto _L1
_L1:
        if(k != -1) goto _L4; else goto _L3
_L3:
        return;
_L2:
        k++;
          goto _L5
_L4:
        int i1 = k / j;
        l = k % j;
        if(i1 > 0)
        {
            int j1 = k - j;
            if(t[j1] == null)
            {
                t[j1] = bg1;
                t[k] = null;
                bg1.n = bg1.n - (float)bg1.g;
            }
        }
        if(i1 < i - 1)
        {
            i = k + j;
            if(t[i] == null)
            {
                t[i] = bg1;
                t[k] = null;
                bg1.n = bg1.n + (float)bg1.g;
            }
        }
        if(l > 0)
        {
            i = k - 1;
            if(t[i] == null)
            {
                t[i] = bg1;
                t[k] = null;
                bg1.m = bg1.m - (float)bg1.f;
            }
        }
        if(l >= j - 1) goto _L3; else goto _L6
_L6:
        i = k + 1;
        if(t[i] != null) goto _L3; else goto _L7
_L7:
        t[i] = bg1;
        t[k] = null;
        bg1.m = bg1.m + (float)bg1.f;
        return;
        k = -1;
          goto _L1
    }

    public void onDraw(android.graphics.Canvas canvas)
    {
        canvas.save();
        canvas.translate(p, q);
        a(canvas, l, e.a);
        canvas.restore();
        a(canvas, ((android.graphics.Paint) (null)));
        if(a)
            b(canvas, l, e.a);
    }

    public boolean onTouchEvent(android.view.MotionEvent motionevent)
    {
        float f;
        float f1;
        if(super.onTouchEvent(motionevent))
            return true;
        f = motionevent.getX();
        f1 = motionevent.getY();
        motionevent.getAction();
        JVM INSTR tableswitch 0 0: default 44
    //                   0 50;
           goto _L1 _L2
_L1:
        invalidate();
        return true;
_L2:
        motionevent = e.a(f, f1);
        if(motionevent != null && ((com.yodesoft.android.game.yopuzzle.bg) (motionevent)).a != u)
        {
            c();
            a(motionevent, i.a, i.b);
            e.a(t, i.a, i.b);
            this.f.a(t, i.k);
            g.g();
            if(e.a(t, u))
                d();
        }
        if(true) goto _L1; else goto _L3
_L3:
    }

    private com.yodesoft.android.game.yopuzzle.bg t[];
    private int u;
    private final java.util.Random v = new Random();
}
