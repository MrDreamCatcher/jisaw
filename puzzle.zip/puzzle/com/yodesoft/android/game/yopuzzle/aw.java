// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.graphics.Bitmap;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            ae, ac

class aw
{

    private aw(com.yodesoft.android.game.yopuzzle.ae ae)
    {
        k = ae;
        super();
    }

    aw(com.yodesoft.android.game.yopuzzle.ae ae, com.yodesoft.android.game.yopuzzle.ac ac)
    {
        this(ae);
    }

    public int a;
    public int b;
    public int c;
    public int d;
    public int e;
    public android.graphics.Bitmap f;
    public int g;
    public int h;
    public int i;
    public int j;
    final com.yodesoft.android.game.yopuzzle.ae k;
}
