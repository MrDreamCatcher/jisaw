// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.os.Handler;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.ViewFlipper;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            n, ah, w, a, 
//            bk, av

class ap
    implements android.view.View.OnClickListener
{

    ap(com.yodesoft.android.game.yopuzzle.n n1)
    {
        a = n1;
        super();
    }

    public void onClick(android.view.View view)
    {
        com.yodesoft.android.game.yopuzzle.n.j(a).b();
        view.getId();
        JVM INSTR tableswitch 2131296298 2131296330: default 160
    //                   2131296298 375
    //                   2131296299 254
    //                   2131296300 213
    //                   2131296301 228
    //                   2131296302 398
    //                   2131296303 160
    //                   2131296304 160
    //                   2131296305 160
    //                   2131296306 431
    //                   2131296307 161
    //                   2131296308 182
    //                   2131296309 190
    //                   2131296310 160
    //                   2131296311 160
    //                   2131296312 445
    //                   2131296313 601
    //                   2131296314 160
    //                   2131296315 160
    //                   2131296316 254
    //                   2131296317 236
    //                   2131296318 160
    //                   2131296319 160
    //                   2131296320 160
    //                   2131296321 160
    //                   2131296322 160
    //                   2131296323 416
    //                   2131296324 160
    //                   2131296325 160
    //                   2131296326 160
    //                   2131296327 160
    //                   2131296328 160
    //                   2131296329 160
    //                   2131296330 205;
           goto _L1 _L2 _L3 _L4 _L5 _L6 _L1 _L1 _L1 _L7 _L8 _L9 _L10 _L1 _L1 _L11 _L12 _L1 _L1 _L3 _L13 _L1 _L1 _L1 _L1 _L1 _L14 _L1 _L1 _L1 _L1 _L1 _L1 _L15
_L1:
        return;
_L8:
        com.yodesoft.android.game.yopuzzle.n.i(a).a(com.yodesoft.android.game.yopuzzle.n.k(a).h);
        return;
_L9:
        com.yodesoft.android.game.yopuzzle.n.l(a);
        return;
_L10:
        com.yodesoft.android.game.yopuzzle.n.m(a);
        com.yodesoft.android.game.yopuzzle.n.n(a);
        return;
_L15:
        com.yodesoft.android.game.yopuzzle.n.o(a);
        return;
_L4:
        com.yodesoft.android.game.yopuzzle.n.m(a);
        com.yodesoft.android.game.yopuzzle.n.p(a);
        return;
_L5:
        com.yodesoft.android.game.yopuzzle.n.q(a);
        return;
_L13:
        com.yodesoft.android.game.yopuzzle.n.m(a);
        com.yodesoft.android.game.yopuzzle.n.d(a).a();
        return;
_L3:
        com.yodesoft.android.game.yopuzzle.n.m(a);
        if(com.yodesoft.android.game.yopuzzle.n.r(a) && !com.yodesoft.android.game.yopuzzle.n.k(a).e())
        {
            com.yodesoft.android.game.yopuzzle.n.s(a);
            return;
        }
        a.g();
        com.yodesoft.android.game.yopuzzle.n.t(a).sendMessage(com.yodesoft.android.game.yopuzzle.n.t(a).obtainMessage(1));
        if(com.yodesoft.android.game.yopuzzle.n.u(a) && com.yodesoft.android.game.yopuzzle.n.k(a).e() && com.yodesoft.android.game.yopuzzle.n.v(a) && !com.yodesoft.android.game.yopuzzle.n.h(a).v)
        {
            com.yodesoft.android.game.yopuzzle.n.w(a);
            return;
        }
          goto _L1
_L2:
        com.yodesoft.android.game.yopuzzle.n.t(a).sendMessage(com.yodesoft.android.game.yopuzzle.n.t(a).obtainMessage(3));
        return;
_L6:
        com.yodesoft.android.game.yopuzzle.n.m(a);
        com.yodesoft.android.game.yopuzzle.n.d(a).f();
        return;
_L14:
        com.yodesoft.android.game.yopuzzle.n.m(a);
        com.yodesoft.android.game.yopuzzle.n.n(a);
        return;
_L7:
        com.yodesoft.android.game.yopuzzle.n.t(a).sendEmptyMessage(8);
        return;
_L11:
        android.widget.EditText edittext = (android.widget.EditText)com.yodesoft.android.game.yopuzzle.n.f(a).findViewById(0x7f090037);
        java.lang.String s1 = edittext.getText().toString();
        java.lang.String s = s1;
        if(s1 != null)
            s = s1.trim();
        if(s == null || s.length() == 0)
        {
            android.widget.Toast.makeText(com.yodesoft.android.game.yopuzzle.n.e(a), 0x7f070031, 0).show();
            return;
        }
        if(s.length() < 3 || s.length() > 30)
        {
            android.widget.Toast.makeText(com.yodesoft.android.game.yopuzzle.n.e(a), 0x7f070032, 0).show();
            return;
        } else
        {
            com.yodesoft.android.game.yopuzzle.n.h(a).a(edittext.getText().toString());
            com.yodesoft.android.game.yopuzzle.n.k(a).a(com.yodesoft.android.game.yopuzzle.n.c(a));
            android.widget.Toast.makeText(com.yodesoft.android.game.yopuzzle.n.e(a), 0x7f070033, 0).show();
            view.setEnabled(false);
            return;
        }
_L12:
        ((android.widget.ViewFlipper)com.yodesoft.android.game.yopuzzle.n.f(a).findViewById(0x7f090031)).setDisplayedChild(0);
        return;
    }

    final com.yodesoft.android.game.yopuzzle.n a;
}
