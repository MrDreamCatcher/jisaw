// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Environment;
import android.os.Handler;
import android.preference.PreferenceManager;
import java.io.File;
import java.io.IOException;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            av, bc, z, ag, 
//            l, bi

class a
{

    private a(android.content.Context context)
    {
        C = null;
        b = context;
        d = b.getResources();
        e = "YoPuzzle2/favorites/";
        r = (new StringBuilder()).append(android.os.Environment.getExternalStorageDirectory().getAbsolutePath()).append(java.io.File.separator).append(e).toString();
        g = (new StringBuilder()).append(android.os.Environment.getExternalStorageDirectory().getAbsolutePath()).append(java.io.File.separator).append("YoPuzzle2/albums/").toString();
        h = (new StringBuilder()).append(android.os.Environment.getExternalStorageDirectory().getAbsolutePath()).append(java.io.File.separator).append("YoPuzzle2/albums/cache/").toString();
        x = false;
        m();
        y = (new StringBuilder()).append(b.getFilesDir().getAbsolutePath()).append(java.io.File.separator).append("web_img.jpg").toString();
        f = android.preference.PreferenceManager.getDefaultSharedPreferences(b);
        o = new boolean[3];
        p = new int[3];
        for(int i1 = 0; i1 < 3; i1++)
        {
            o[i1] = f.getBoolean((new StringBuilder()).append("played_").append(i1).toString(), false);
            p[i1] = f.getInt((new StringBuilder()).append("last_game_").append(i1).toString(), 0);
        }

        l = f.getInt("album_locale", 0);
        i = f.getString("album_name", "");
        j = f.getString("album_id", "");
        k = f.getInt("album_count", 0);
        t = com.yodesoft.android.game.yopuzzle.av.a(b);
        u = new android.graphics.BitmapFactory.Options();
        u.inPurgeable = true;
        u.inDither = true;
        int j1 = t.q;
        if(t.n && j1 > 640)
        {
            v = 640;
            w = 640;
        } else
        {
            v = (int)(t.s * 320F);
            w = (int)(t.s * 320F);
        }
        z = false;
    }

    static android.graphics.Bitmap a(com.yodesoft.android.game.yopuzzle.a a1, int i1)
    {
        return a1.f(i1);
    }

    static android.graphics.Bitmap a(com.yodesoft.android.game.yopuzzle.a a1, android.graphics.Bitmap bitmap)
    {
        a1.c = bitmap;
        return bitmap;
    }

    static android.os.Handler a(com.yodesoft.android.game.yopuzzle.a a1)
    {
        return a1.q;
    }

    public static com.yodesoft.android.game.yopuzzle.a a(android.content.Context context)
    {
        if(a == null)
            a = new a(context);
        return a;
    }

    static android.graphics.Bitmap b(com.yodesoft.android.game.yopuzzle.a a1)
    {
        return a1.c;
    }

    static android.graphics.Bitmap b(com.yodesoft.android.game.yopuzzle.a a1, int i1)
    {
        return a1.e(i1);
    }

    static android.graphics.Bitmap c(com.yodesoft.android.game.yopuzzle.a a1, int i1)
    {
        return a1.d(i1);
    }

    static boolean c(com.yodesoft.android.game.yopuzzle.a a1)
    {
        return a1.z;
    }

    private android.graphics.Bitmap d(int i1)
    {
        if(i.length() != 0 && i1 >= 1) goto _L2; else goto _L1
_L1:
        java.lang.Object obj = null;
_L4:
        return ((android.graphics.Bitmap) (obj));
_L2:
        android.graphics.Bitmap bitmap;
        java.lang.String s1;
        obj = new StringBuilder();
        ((java.lang.StringBuilder) (obj)).append("http://www.yopuzzle.com/m/albums/img/");
        ((java.lang.StringBuilder) (obj)).append(j);
        ((java.lang.StringBuilder) (obj)).append("/");
        ((java.lang.StringBuilder) (obj)).append(i1);
        ((java.lang.StringBuilder) (obj)).append("/");
        s1 = ((java.lang.StringBuilder) (obj)).toString();
        if(!x)
            break; /* Loop/switch isn't completed */
        ((java.lang.StringBuilder) (obj)).delete(0, ((java.lang.StringBuilder) (obj)).length());
        ((java.lang.StringBuilder) (obj)).append(h);
        ((java.lang.StringBuilder) (obj)).append(j);
        ((java.lang.StringBuilder) (obj)).append("/");
        ((java.lang.StringBuilder) (obj)).append(i1);
        ((java.lang.StringBuilder) (obj)).append(".jpg");
        obj = ((java.lang.StringBuilder) (obj)).toString();
        if(!(new File(((java.lang.String) (obj)))).exists())
            break; /* Loop/switch isn't completed */
        u.inJustDecodeBounds = true;
        android.graphics.BitmapFactory.decodeFile(((java.lang.String) (obj)), u);
        r();
        bitmap = android.graphics.BitmapFactory.decodeFile(((java.lang.String) (obj)), u);
        obj = bitmap;
        if(bitmap != null) goto _L4; else goto _L3
_L3:
        obj = y;
        if(!com.yodesoft.android.game.yopuzzle.bc.a(s1, ((java.lang.String) (obj))))
            return null;
        u.inJustDecodeBounds = true;
        android.graphics.BitmapFactory.decodeFile(((java.lang.String) (obj)), u);
        r();
        android.graphics.Bitmap bitmap1 = android.graphics.BitmapFactory.decodeFile(((java.lang.String) (obj)), u);
        if(bitmap1 != null)
        {
            obj = bitmap1;
            if(x)
            {
                (new Thread(new z(this, j, i1))).start();
                return bitmap1;
            }
        } else
        {
            return null;
        }
        if(true) goto _L4; else goto _L5
_L5:
    }

    static android.graphics.Bitmap d(com.yodesoft.android.game.yopuzzle.a a1)
    {
        return a1.q();
    }

    static int e(com.yodesoft.android.game.yopuzzle.a a1)
    {
        return a1.l;
    }

    private android.graphics.Bitmap e(int i1)
    {
        if(i1 < 1)
            return null;
        if(i1 >= s.length)
            i1 = s.length;
        java.lang.String s1 = s[i1 - 1].getAbsolutePath();
        u.inJustDecodeBounds = true;
        android.graphics.BitmapFactory.decodeFile(s1, u);
        r();
        return android.graphics.BitmapFactory.decodeFile(s1, u);
    }

    static int f(com.yodesoft.android.game.yopuzzle.a a1)
    {
        return a1.v;
    }

    private android.graphics.Bitmap f(int i1)
    {
        byte byte0 = 20;
        if(i1 < 0)
            return null;
        if(i1 >= 20)
            i1 = byte0;
        i1 = (i1 + 0x7f020033) - 1;
        u.inJustDecodeBounds = true;
        android.graphics.BitmapFactory.decodeResource(d, i1, u);
        r();
        return android.graphics.BitmapFactory.decodeResource(d, i1, u);
    }

    static int g(com.yodesoft.android.game.yopuzzle.a a1)
    {
        return a1.w;
    }

    static boolean h(com.yodesoft.android.game.yopuzzle.a a1)
    {
        return a1.x;
    }

    static java.lang.String i(com.yodesoft.android.game.yopuzzle.a a1)
    {
        return a1.r;
    }

    static java.lang.String j(com.yodesoft.android.game.yopuzzle.a a1)
    {
        return a1.j;
    }

    static java.lang.String k(com.yodesoft.android.game.yopuzzle.a a1)
    {
        return a1.A;
    }

    static android.content.Context l(com.yodesoft.android.game.yopuzzle.a a1)
    {
        return a1.b;
    }

    static java.lang.String m(com.yodesoft.android.game.yopuzzle.a a1)
    {
        return a1.y;
    }

    static java.lang.String n(com.yodesoft.android.game.yopuzzle.a a1)
    {
        return a1.h;
    }

    private android.graphics.Bitmap q()
    {
        java.lang.Object obj = new StringBuilder();
        ((java.lang.StringBuilder) (obj)).append("http://www.yopuzzle.com/api/images/get/");
        ((java.lang.StringBuilder) (obj)).append(B);
        ((java.lang.StringBuilder) (obj)).append("/");
        obj = ((java.lang.StringBuilder) (obj)).toString();
        java.lang.Object obj1 = y;
        if(!com.yodesoft.android.game.yopuzzle.bc.a(((java.lang.String) (obj)), ((java.lang.String) (obj1))))
        {
            obj = null;
        } else
        {
            u.inJustDecodeBounds = true;
            android.graphics.BitmapFactory.decodeFile(((java.lang.String) (obj1)), u);
            r();
            obj1 = android.graphics.BitmapFactory.decodeFile(((java.lang.String) (obj1)), u);
            obj = obj1;
            if(obj1 == null)
                return null;
        }
        return ((android.graphics.Bitmap) (obj));
    }

    private void r()
    {
        int i1 = v;
        int j1 = u.outWidth;
        if(j1 == -1 || j1 != u.outHeight)
        {
            q.sendMessage(q.obtainMessage(2));
            u.inJustDecodeBounds = true;
            return;
        }
        if(j1 != i1 && j1 > i1)
            u.inSampleSize = j1 / i1;
        u.inJustDecodeBounds = false;
    }

    private java.lang.String s()
    {
        i = f.getString("album_name", "");
        return i;
    }

    private void t()
    {
        s = null;
        if(x)
            s = (new File(r)).listFiles();
        if(s == null)
        {
            n = 0;
            q.sendMessage(q.obtainMessage(7));
            return;
        } else
        {
            n = s.length;
            return;
        }
    }

    private void u()
    {
        j = f.getString("album_id", "");
        i = f.getString("album_name", "");
        k = f.getInt("album_count", 0);
        n = k;
    }

    private void v()
    {
        java.io.File file;
        file = new File(r);
        if(!file.exists())
            file.mkdirs();
        file = new File(g);
        if(!file.exists())
            file.mkdirs();
        file = new File(h);
        if(!file.exists())
            file.mkdirs();
        file = new File((new StringBuilder()).append(h).append(".nomedia").toString());
        if(file.exists())
            break MISSING_BLOCK_LABEL_115;
        file.createNewFile();
        return;
        java.io.IOException ioexception;
        ioexception;
        ioexception.printStackTrace();
        return;
    }

    public android.graphics.Bitmap a()
    {
        return c;
    }

    public void a(int i1)
    {
        (new Thread(new ag(this, i1))).start();
    }

    public void a(int i1, android.os.Handler handler)
    {
        if(C == null || !C.isAlive())
        {
            C = new Thread(new l(this, i1));
            C.start();
        }
    }

    public void a(android.os.Handler handler)
    {
        q = handler;
    }

    public void a(java.lang.String s1, java.lang.String s2)
    {
        A = s1;
        B = s2;
        z = true;
    }

    public void a(java.lang.String s1, java.lang.String s2, int i1)
    {
        while(s1 == null || s2 == null || j.compareTo(s1) == 0) 
            return;
        j = s1;
        i = s2;
        k = i1;
        s1 = f.edit();
        s1.putString("album_name", i);
        s1.putString("album_id", j);
        s1.putInt("album_count", k);
        s1.putBoolean("played_2", false);
        s1.commit();
    }

    public java.lang.String b()
    {
        return e;
    }

    public void b(int i1)
    {
        l = i1;
        android.content.SharedPreferences.Editor editor = f.edit();
        editor.putInt("album_locale", i1);
        editor.commit();
    }

    public void c()
    {
        (new Thread(new bi(this))).start();
    }

    public void c(int i1)
    {
        if(z)
        {
            return;
        } else
        {
            android.content.SharedPreferences.Editor editor = f.edit();
            editor.putInt((new StringBuilder()).append("last_game_").append(l).toString(), i1);
            editor.commit();
            p[l] = i1;
            return;
        }
    }

    public int d()
    {
        return l;
    }

    public boolean e()
    {
        return o[l];
    }

    public boolean f()
    {
        return l == 2 && !z;
    }

    public boolean g()
    {
        return l != m;
    }

    public int h()
    {
        return p[l];
    }

    public java.lang.String i()
    {
        java.lang.String s1;
        if(l == 0)
        {
            s1 = d.getString(0x7f070055);
        } else
        {
            if(l == 1)
                return d.getString(0x7f070056);
            java.lang.String s2 = s();
            s1 = s2;
            if(s2.length() < 1)
                return d.getString(0x7f070057);
        }
        return s1;
    }

    public java.lang.String j()
    {
        return j;
    }

    public int k()
    {
        if(z)
            return 1;
        else
            return n;
    }

    public int l()
    {
        m();
        android.content.SharedPreferences.Editor editor = f.edit();
        if(l == 0)
            n = 20;
        else
        if(l == 1)
            t();
        else
            u();
        o[l] = true;
        editor.putBoolean((new StringBuilder()).append("played_").append(l).toString(), true);
        m = l;
        editor.commit();
        return k();
    }

    public boolean m()
    {
        boolean flag = android.os.Environment.getExternalStorageState().equals("mounted");
        if(!x && flag)
            v();
        x = flag;
        return x;
    }

    public java.lang.String n()
    {
        return A;
    }

    public void o()
    {
        A = null;
        B = null;
        z = false;
    }

    public boolean p()
    {
        return z;
    }

    private static com.yodesoft.android.game.yopuzzle.a a = null;
    private java.lang.String A;
    private java.lang.String B;
    private java.lang.Thread C;
    private android.content.Context b;
    private android.graphics.Bitmap c;
    private android.content.res.Resources d;
    private java.lang.String e;
    private android.content.SharedPreferences f;
    private final java.lang.String g;
    private final java.lang.String h;
    private java.lang.String i;
    private java.lang.String j;
    private int k;
    private int l;
    private int m;
    private int n;
    private boolean o[];
    private int p[];
    private android.os.Handler q;
    private final java.lang.String r;
    private java.io.File s[];
    private com.yodesoft.android.game.yopuzzle.av t;
    private android.graphics.BitmapFactory.Options u;
    private final int v;
    private final int w;
    private boolean x;
    private java.lang.String y;
    private boolean z;

}
