// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.content.Context;
import android.os.Handler;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Random;
import org.apache.http.util.ByteArrayBuffer;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            av, a, bb, b, 
//            aj

class w
{

    w(android.content.Context context, int i1)
    {
        m = null;
        p = i1;
        o = context;
        l = new Random();
        q = com.yodesoft.android.game.yopuzzle.av.a(o);
        q.a();
        r = com.yodesoft.android.game.yopuzzle.a.a(context);
        w = 1;
    }

    static int a(com.yodesoft.android.game.yopuzzle.w w1, int i1)
    {
        w1.w = i1;
        return i1;
    }

    private int a(org.json.JSONObject jsonobject)
    {
        if(jsonobject == null)
            return 0;
        int i1;
        try
        {
            i1 = jsonobject.getInt("GameMode");
        }
        // Misplaced declaration of an exception variable
        catch(org.json.JSONObject jsonobject)
        {
            return 0;
        }
        return i1;
    }

    static com.yodesoft.android.game.yopuzzle.a a(com.yodesoft.android.game.yopuzzle.w w1)
    {
        return w1.r;
    }

    private void a(int i1, int j1, int k1)
    {
        switch(i1)
        {
        case 0: // '\0'
        default:
            return;

        case 1: // '\001'
        case 6: // '\006'
            d(j1, k1);
            return;

        case 2: // '\002'
        case 3: // '\003'
        case 4: // '\004'
        case 7: // '\007'
            b(j1, k1);
            return;

        case 5: // '\005'
            c(j1, k1);
            break;
        }
    }

    private void a(int i1, int j1, int k1, int l1, int i2)
    {
        org.json.JSONObject jsonobject;
        com.yodesoft.android.game.yopuzzle.bb bb1;
        java.util.Random random;
        if(r.p())
            return;
        jsonobject = new JSONObject();
        new JSONArray();
        bb1 = new bb();
        random = new Random();
        java.lang.String s3;
        jsonobject.put("GameMode", i1);
        jsonobject.put("LastLevel", j1);
        jsonobject.put("LastShape", k1);
        jsonobject.put("rows", a);
        jsonobject.put("cols", b);
        jsonobject.put("rotation", e);
        jsonobject.put("style", k);
        jsonobject.put("distortion", i);
        s3 = bb1.d(java.lang.String.valueOf((float)l1 + random.nextFloat()));
        java.lang.String s1;
        s1 = s3;
        if(s3 == null)
            s1 = "";
        jsonobject.put("TotalScore", s1);
        float f1 = i2;
        s3 = bb1.d(java.lang.String.valueOf(random.nextFloat() + f1));
        java.lang.String s2 = s3;
        if(s3 == null)
            s2 = "";
        try
        {
            jsonobject.put("TotalTime", s2);
            s2 = jsonobject.toString();
            o.openFileOutput(m, 0).write(s2.getBytes());
            return;
        }
        catch(org.json.JSONException jsonexception)
        {
            jsonexception.printStackTrace();
            return;
        }
        catch(java.io.FileNotFoundException filenotfoundexception)
        {
            filenotfoundexception.printStackTrace();
            return;
        }
        catch(java.io.IOException ioexception)
        {
            ioexception.printStackTrace();
        }
        return;
    }

    static void a(com.yodesoft.android.game.yopuzzle.w w1, int i1, int j1, int k1, int l1, int i2)
    {
        w1.a(i1, j1, k1, l1, i2);
    }

    static boolean a(com.yodesoft.android.game.yopuzzle.w w1, boolean flag)
    {
        w1.x = flag;
        return flag;
    }

    static int b(com.yodesoft.android.game.yopuzzle.w w1)
    {
        return w1.p;
    }

    private int b(org.json.JSONObject jsonobject)
    {
        if(jsonobject == null)
            return 1;
        int i1;
        try
        {
            i1 = jsonobject.getInt("LastLevel");
        }
        // Misplaced declaration of an exception variable
        catch(org.json.JSONObject jsonobject)
        {
            return 1;
        }
        return i1;
    }

    static boolean b(com.yodesoft.android.game.yopuzzle.w w1, boolean flag)
    {
        w1.y = flag;
        return flag;
    }

    static int c(com.yodesoft.android.game.yopuzzle.w w1)
    {
        return w1.u;
    }

    private int c(org.json.JSONObject jsonobject)
    {
        if(jsonobject == null)
            return 0;
        int i1;
        try
        {
            i1 = jsonobject.getInt("LastShape");
        }
        // Misplaced declaration of an exception variable
        catch(org.json.JSONObject jsonobject)
        {
            return 0;
        }
        return i1;
    }

    static int d(com.yodesoft.android.game.yopuzzle.w w1)
    {
        return w1.v;
    }

    private int d(org.json.JSONObject jsonobject)
    {
        if(jsonobject == null)
            return 0;
        int i1;
        try
        {
            jsonobject = (new bb()).e(jsonobject.getString("TotalScore"));
        }
        // Misplaced declaration of an exception variable
        catch(org.json.JSONObject jsonobject)
        {
            return 0;
        }
        if(jsonobject == null)
            break MISSING_BLOCK_LABEL_57;
        if(jsonobject.length() <= 0)
            break MISSING_BLOCK_LABEL_57;
        i1 = java.lang.Integer.parseInt(jsonobject.substring(0, jsonobject.indexOf(".")));
        return i1;
        return 0;
    }

    private int e(int i1, int j1)
    {
        int k1;
        if(a <= 3 && b <= 3)
            k1 = 10;
        else
            k1 = (a - 3) * (b - 3) * 10 + 10;
        return k1 + d / (d - i1) + 100 / j1;
    }

    private int e(org.json.JSONObject jsonobject)
    {
        if(jsonobject == null)
            return 0;
        int i1;
        try
        {
            jsonobject = (new bb()).e(jsonobject.getString("TotalTime"));
        }
        // Misplaced declaration of an exception variable
        catch(org.json.JSONObject jsonobject)
        {
            return 0;
        }
        if(jsonobject == null)
            break MISSING_BLOCK_LABEL_57;
        if(jsonobject.length() <= 0)
            break MISSING_BLOCK_LABEL_57;
        i1 = java.lang.Integer.parseInt(jsonobject.substring(0, jsonobject.indexOf(".")));
        return i1;
        return 0;
    }

    static com.yodesoft.android.game.yopuzzle.av e(com.yodesoft.android.game.yopuzzle.w w1)
    {
        return w1.q;
    }

    private void f(org.json.JSONObject jsonobject)
    {
        if(jsonobject == null)
            m();
        try
        {
            e = jsonobject.getInt("rotation");
            k = jsonobject.getInt("style");
            a = jsonobject.getInt("rows");
            b = jsonobject.getInt("cols");
            i = jsonobject.getInt("distortion");
            if(a > 2 && b > 2)
            {
                q.h = e;
                q.i = k;
                q.k = a;
                q.l = b;
                q.g = j;
            }
            return;
        }
        // Misplaced declaration of an exception variable
        catch(org.json.JSONObject jsonobject)
        {
            m();
        }
    }

    private java.lang.String l()
    {
        return java.lang.String.format("game_%d_%d.config", new java.lang.Object[] {
            java.lang.Integer.valueOf(p), java.lang.Integer.valueOf(r.d())
        });
    }

    private void m()
    {
        j = q.g;
        if(j < 0)
            j = l.nextInt(41);
        e = q.h;
        k = q.i;
        a = q.k;
        b = q.l;
    }

    public void a()
    {
        org.json.JSONObject jsonobject;
        s = r.k();
        m = l();
        jsonobject = null;
        java.lang.Object obj;
        byte abyte0[];
        org.apache.http.util.ByteArrayBuffer bytearraybuffer;
        obj = o.openFileInput(m);
        abyte0 = new byte[1024];
        bytearraybuffer = new ByteArrayBuffer(1024);
_L3:
        int i1 = ((java.io.InputStream) (obj)).read(abyte0);
        if(i1 == -1) goto _L2; else goto _L1
_L1:
        bytearraybuffer.append(abyte0, 0, i1);
          goto _L3
        obj;
        ((java.io.IOException) (obj)).printStackTrace();
_L5:
        if(jsonobject == null)
        {
            a(0);
            return;
        }
        break; /* Loop/switch isn't completed */
_L2:
        java.lang.String s1 = new String(bytearraybuffer.toByteArray(), "utf-8");
        ((java.io.InputStream) (obj)).close();
        obj = new JSONObject(s1);
        jsonobject = ((org.json.JSONObject) (obj));
        continue; /* Loop/switch isn't completed */
        java.lang.Object obj1;
        obj1;
        ((org.json.JSONException) (obj1)).printStackTrace();
        continue; /* Loop/switch isn't completed */
        obj1;
        ((android.content.res.Resources.NotFoundException) (obj1)).printStackTrace();
        if(true) goto _L5; else goto _L4
_L4:
        h = b(jsonobject);
        g = a(jsonobject);
        j = c(jsonobject) - 1;
        if(h > s)
        {
            a(g);
            return;
        }
        u = d(jsonobject);
        v = e(jsonobject);
        w = 1;
        x = false;
        y = false;
        z = r.p();
        A = r.f();
        B = 0;
        if(g == 2)
        {
            j = c(jsonobject);
            f(jsonobject);
        }
        a(p, g, h);
        return;
    }

    public void a(int i1)
    {
        u = 0;
        v = 0;
        x = false;
        w = 1;
        y = false;
        z = r.p();
        A = r.f();
        s = r.k();
        h = 1;
        g = i1;
        j = 0;
        m = l();
        a(p, g, h);
        a(g, h, j, u, v);
    }

    public void a(int i1, int j1)
    {
        if(e())
        {
            return;
        } else
        {
            B = e(i1, j1);
            u = u + B;
            v = v + i1;
            h = h + 1;
            a(p, g, h);
            a(g, h, j, u, v);
            return;
        }
    }

    public void a(android.os.Handler handler)
    {
        if(!A || w != 1)
        {
            return;
        } else
        {
            (new Thread(new b(this, handler))).start();
            w = 2;
            return;
        }
    }

    public void a(java.lang.String s1)
    {
        while(s1 == null || s1.length() < 3 || !A || !e()) 
            return;
        x = true;
        w = 1;
    }

    public int b()
    {
        int j1 = h;
        int i1 = j1;
        if(j1 > s)
            i1 = s;
        return i1;
    }

    public void b(int i1, int j1)
    {
        k = 2;
        e = 0;
        j = 0;
        i = 0;
        float f1 = (float)j1 / (float)s;
        switch(i1)
        {
        default:
            return;

        case 0: // '\0'
            if((double)f1 <= 0.20000000000000001D)
            {
                d = 300;
                a = 3;
                b = 3;
                return;
            }
            if((double)f1 <= 0.40000000000000002D)
            {
                d = 240;
                a = 3;
                b = 4;
                return;
            }
            if((double)f1 <= 0.59999999999999998D)
            {
                d = 240;
                a = 4;
                b = 4;
                return;
            }
            if((double)f1 <= 0.80000000000000004D)
            {
                d = 240;
                a = 4;
                b = 5;
                return;
            } else
            {
                d = 240;
                a = 5;
                b = 5;
                return;
            }

        case 1: // '\001'
            d = 0;
            a = 3;
            b = 3;
            return;

        case 2: // '\002'
            d = 0;
            m();
            j = 0;
            e = 0;
            return;
        }
    }

    public void b(android.os.Handler handler)
    {
        if(!z || y)
        {
            return;
        } else
        {
            (new Thread(new aj(this, r.n(), handler))).start();
            y = true;
            return;
        }
    }

    public int c()
    {
        return B;
    }

    public void c(int i1, int j1)
    {
        float f1;
        k = 2;
        e = 0;
        f1 = (float)j1 / (float)s;
        if(j1 == 1)
        {
            t = 0;
        } else
        {
            t = t + 1;
            if(t >= n.length)
            {
                t = 0;
                if(f1 > 0.2F)
                {
                    i = i + 1;
                    if(i > 7)
                        i = 2;
                }
            }
        }
        j = n[t];
        i1;
        JVM INSTR tableswitch 0 2: default 68
    //                   0 144
    //                   1 305
    //                   2 328;
           goto _L1 _L2 _L3 _L4
_L1:
        if(j > 40)
            j = 0;
        return;
_L2:
        if((double)f1 <= 0.20000000000000001D)
        {
            d = 300;
            a = 3;
            b = 3;
            if(j1 == 1)
            {
                j = 0;
                t = 0;
                i = 2;
            }
        } else
        if((double)f1 <= 0.40000000000000002D)
        {
            d = 300;
            a = 3;
            b = 4;
        } else
        if((double)f1 <= 0.59999999999999998D)
        {
            d = 300;
            a = 4;
            b = 4;
        } else
        if((double)f1 <= 0.80000000000000004D)
        {
            d = 300;
            a = 4;
            b = 5;
        } else
        {
            d = 300;
            a = 5;
            b = 5;
        }
        i = 0;
        continue; /* Loop/switch isn't completed */
_L3:
        d = 0;
        i = 0;
        a = 3;
        b = 3;
        continue; /* Loop/switch isn't completed */
_L4:
        d = 0;
        m();
        e = 0;
        i = 0;
        if(true) goto _L1; else goto _L5
_L5:
    }

    public int d()
    {
        return s;
    }

    public void d(int i1, int j1)
    {
        float f1;
        f1 = (float)j1 / (float)s;
        k = 2;
        f = 12;
        i1;
        JVM INSTR tableswitch 0 2: default 48
    //                   0 49
    //                   1 422
    //                   2 520;
           goto _L1 _L2 _L3 _L4
_L1:
        return;
_L2:
        if((double)f1 > 0.20000000000000001D)
            break; /* Loop/switch isn't completed */
        a = 3;
        b = 3;
        c = 30;
        d = 300;
        e = 0;
        if(j1 == 1)
        {
            j = 1;
            i = 2;
            return;
        }
        j = j + 1;
        if(j > 40)
        {
            j = 0;
            return;
        }
        if(true) goto _L1; else goto _L5
_L5:
        if((double)f1 > 0.40000000000000002D)
            break; /* Loop/switch isn't completed */
        a = 3;
        b = 4;
        c = 20;
        d = 300;
        e = 0;
        j = j + 1;
        if(j > 40)
        {
            j = 0;
            i = i + 1;
            if(i > 7)
            {
                i = 2;
                return;
            }
        }
        if(true) goto _L1; else goto _L6
_L6:
        if((double)f1 <= 0.59999999999999998D)
        {
            a = 4;
            b = 4;
            c = 20;
            d = 240;
            e = 1;
            j = j + 1;
            if(j > 40)
            {
                j = 0;
                i = i + 1;
                if(i > 7)
                {
                    i = 2;
                    return;
                }
            }
        } else
        if((double)f1 <= 0.80000000000000004D)
        {
            a = 4;
            b = 5;
            c = 10;
            d = 240;
            e = 1;
            j = l.nextInt(41);
            i = l.nextInt(6) + 2;
            return;
        } else
        {
            a = 5;
            b = 5;
            c = 10;
            d = 180;
            e = 1;
            j = l.nextInt(41);
            i = l.nextInt(6) + 2;
            return;
        }
        continue; /* Loop/switch isn't completed */
_L3:
        a = 3;
        b = 3;
        c = 30;
        d = 0;
        e = 0;
        f = 20;
        if(j1 == 1)
        {
            t = 1;
        } else
        {
            t = t + 1;
            if(t >= n.length)
                t = 0;
        }
        j = n[t];
        if(j > 40)
        {
            j = 0;
            return;
        }
        continue; /* Loop/switch isn't completed */
_L4:
        c = 30;
        d = 0;
        m();
        return;
        if(true) goto _L1; else goto _L7
_L7:
    }

    public boolean e()
    {
        return s > 0 && h > s;
    }

    public void f()
    {
        a(g);
    }

    public int g()
    {
        return u;
    }

    public boolean h()
    {
        return x;
    }

    public boolean i()
    {
        return e() && A;
    }

    public boolean j()
    {
        return z;
    }

    public boolean k()
    {
        return A;
    }

    private static final int n[] = {
        0, 1, 2, 3, 4, 5, 7, 9, 10, 13, 
        15, 16, 17, 19, 20, 21, 22, 27, 30, 31, 
        36, 38
    };
    private boolean A;
    private int B;
    public int a;
    public int b;
    public int c;
    public int d;
    public int e;
    public int f;
    public int g;
    public int h;
    public int i;
    public int j;
    public int k;
    private java.util.Random l;
    private java.lang.String m;
    private android.content.Context o;
    private int p;
    private com.yodesoft.android.game.yopuzzle.av q;
    private com.yodesoft.android.game.yopuzzle.a r;
    private int s;
    private int t;
    private int u;
    private int v;
    private int w;
    private boolean x;
    private boolean y;
    private boolean z;

}
