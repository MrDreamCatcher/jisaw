// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import java.util.ArrayList;
import java.util.Random;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            ad, bg

class af
{

    af()
    {
        a = new ArrayList();
        b = 1.0F;
        c = 0.0F;
        d = new Canvas();
        e = new Paint();
        f = new Random();
    }

    private double a(float f1, float f2)
    {
        return java.lang.Math.floor(java.lang.Math.random() * (double)((f2 - f1) + 1.0F)) + (double)f1;
    }

    private void a(com.yodesoft.android.game.yopuzzle.ad ad1, int i, int j, int k, int l, int i1, int j1, 
            int k1, int l1, int i2)
    {
        if(i2 < 0 || i2 > 7)
            i1 = 0;
        else
            i1 = i2;
        if(i1 != 0) goto _L2; else goto _L1
_L1:
        b = 1.0F;
        ad1.a = j * k1;
        ad1.b = i * l1;
        if(j > 0 && j < l)
            if(java.lang.Math.random() > 0.5D)
                ad1.d = 1;
            else
                ad1.d = -1;
        if(i <= 0 || i >= k) goto _L4; else goto _L3
_L3:
        if(java.lang.Math.random() <= 0.5D) goto _L6; else goto _L5
_L5:
        ad1.c = 1;
_L4:
        return;
_L6:
        ad1.c = -1;
        return;
_L2:
        if(i1 != 1)
            break; /* Loop/switch isn't completed */
        b = 1.0F;
        ad1.a = j * k1;
        ad1.b = i * l1;
        if(j > 0 && j < l)
        {
            ad1.a = (int)((double)ad1.a + ((double)c * java.lang.Math.random() * (double)k1) / 9D);
            ad1.d = 1;
        }
        if(i > 0 && i < k)
        {
            ad1.b = (int)((double)ad1.b + ((double)c * java.lang.Math.random() * (double)l1) / 9D);
            ad1.c = -1;
            return;
        }
        if(true) goto _L4; else goto _L7
_L7:
        if(i1 != 2)
            break; /* Loop/switch isn't completed */
        b = 1.0F;
        ad1.a = j * k1;
        ad1.b = i * l1;
        if(j > 0 && j < l)
            if(j % 2 > 0)
            {
                if(i % 2 > 0)
                    ad1.d = 1;
                else
                    ad1.d = -1;
            } else
            if(i % 2 > 0)
                ad1.d = -1;
            else
                ad1.d = 1;
        if(i > 0 && i < k)
        {
            if(i % 2 > 0)
                if(j % 2 > 0)
                {
                    ad1.c = 1;
                    return;
                } else
                {
                    ad1.c = -1;
                    return;
                }
            if(j % 2 > 0)
            {
                ad1.c = -1;
                return;
            } else
            {
                ad1.c = 1;
                return;
            }
        }
        if(true) goto _L4; else goto _L8
_L8:
        if(i1 != 3)
            break; /* Loop/switch isn't completed */
        b = 0.6F;
        ad1.a = j * k1;
        ad1.b = i * l1;
        if(j > 0 && j < l)
            if(j % 2 > 0)
            {
                if(i % 2 > 0)
                    ad1.d = 1;
                else
                    ad1.d = -1;
            } else
            if(i % 2 > 0)
                ad1.d = -1;
            else
                ad1.d = 1;
        if(i > 0 && i < k)
            if(i % 2 > 0)
            {
                if(j % 2 > 0)
                    ad1.c = 1;
                else
                    ad1.c = -1;
            } else
            if(j % 2 > 0)
                ad1.c = -1;
            else
                ad1.c = 1;
        if(j > 0 && j < l)
            if(i % 2 > 0)
            {
                ad1.a = j * k1 + k1 / 2;
                return;
            } else
            {
                ad1.a = j * k1 - k1 / 2;
                return;
            }
        if(true) goto _L4; else goto _L9
_L9:
        if(i1 != 4)
            break; /* Loop/switch isn't completed */
        b = 0.4F;
        ad1.a = (int)((double)(j * k1) + a(-k1 / 2, k1 / 2));
        ad1.b = (int)((double)(i * l1) + a(-l1 / 2, l1 / 2));
        if(j > 0 && j < l)
            if(java.lang.Math.random() > 0.5D)
                ad1.d = 1;
            else
                ad1.d = -1;
        if(i > 0 && i < k)
            if(java.lang.Math.random() > 0.5D)
                ad1.c = 1;
            else
                ad1.c = -1;
        if(j == l || j == 0)
            ad1.a = j * k1;
        if(i == k || i == 0)
        {
            ad1.b = i * l1;
            return;
        }
        if(true) goto _L4; else goto _L10
_L10:
        if(i1 != 5)
            break; /* Loop/switch isn't completed */
        b = 0.4F;
        ad1.a = j * k1;
        ad1.b = i * l1;
        if(j > 0 && j < l)
            if(java.lang.Math.random() > 0.5D)
                ad1.d = 1;
            else
                ad1.d = -1;
        if(i > 0 && i < k)
            if(java.lang.Math.random() > 0.5D)
                ad1.c = 1;
            else
                ad1.c = -1;
        if(j % 2 > 0)
        {
            if(i % 2 > 0)
                ad1.b = i * l1 + l1 / 2;
            else
                ad1.b = i * l1 - l1 / 2;
        } else
        if(i % 2 > 0)
            ad1.b = i * l1 - l1 / 2;
        else
            ad1.b = i * l1 + l1 / 2;
        if(i == k || i == 0)
            ad1.b = i * l1;
        if(i % 2 > 0)
        {
            if(j % 2 > 0)
                ad1.a = j * k1 - k1 / 2;
            else
                ad1.a = j * k1 + k1 / 2;
        } else
        if(j % 2 > 0)
            ad1.a = j * k1 + k1 / 2;
        else
            ad1.a = j * k1 - k1 / 2;
        if(j == l || j == 0)
        {
            ad1.a = j * k1;
            return;
        }
        if(true) goto _L4; else goto _L11
_L11:
        if(i1 != 6)
            break; /* Loop/switch isn't completed */
        b = 0.5F;
        ad1.a = j * k1;
        ad1.b = i * l1;
        if(j > 0 && j < l)
            if(j % 2 > 0)
            {
                if(i % 2 > 0)
                    ad1.d = 1;
                else
                    ad1.d = -1;
            } else
            if(i % 2 > 0)
                ad1.d = -1;
            else
                ad1.d = 1;
        if(i > 0 && i < k)
            if(i % 2 > 0)
            {
                if(j % 2 > 0)
                    ad1.c = 1;
                else
                    ad1.c = -1;
            } else
            if(j % 2 > 0)
                ad1.c = -1;
            else
                ad1.c = 1;
        if(j > 0 && j < l)
            if(i % 2 > 0)
                ad1.a = j * k1 + k1 / 2;
            else
                ad1.a = j * k1 - k1 / 2;
        if(i % 2 > 0)
        {
            if(j % 2 > 0)
                ad1.a = j * k1 + k1 / 2;
            else
                ad1.a = j * k1 - k1 / 2;
        } else
        if(j % 2 > 0)
            ad1.a = j * k1 - k1 / 2;
        else
            ad1.a = j * k1 + k1 / 2;
        if(j == l || j == 0)
        {
            ad1.a = j * k1;
            return;
        }
        if(true) goto _L4; else goto _L12
_L12:
        if(i1 != 7)
            continue; /* Loop/switch isn't completed */
        b = 0.5F;
        ad1.a = j * k1;
        ad1.b = i * l1;
        if(j > 0 && j < l)
            if(j % 2 > 0)
            {
                if(i % 2 > 0)
                    ad1.d = 1;
                else
                    ad1.d = -1;
            } else
            if(i % 2 > 0)
                ad1.d = -1;
            else
                ad1.d = 1;
        if(i > 0 && i < k)
            if(i % 2 > 0)
            {
                if(j % 2 > 0)
                    ad1.c = 1;
                else
                    ad1.c = -1;
            } else
            if(j % 2 > 0)
                ad1.c = -1;
            else
                ad1.c = 1;
        if(j % 2 > 0)
        {
            if(i % 2 > 0)
                ad1.b = i * l1 - (i % 2) * l1;
            else
                ad1.b = i * l1 + (i % 2) * l1;
        } else
        if(i % 2 > 0)
            ad1.b = i * l1 + (i % 2) * l1;
        else
            ad1.b = i * l1 - (i % 2) * l1;
        if(i == k || i == 0)
        {
            ad1.b = i * l1;
            return;
        }
        continue; /* Loop/switch isn't completed */
        if(i1 != 8) goto _L4; else goto _L13
_L13:
        b = 1.0F;
        ad1.a = j * k1;
        ad1.b = i * l1;
        if(j > 0 && j < l)
            if(j % 2 > 0)
            {
                if(i % 2 > 0)
                    ad1.d = 1;
                else
                    ad1.d = -1;
            } else
            if(i % 2 > 0)
                ad1.d = -1;
            else
                ad1.d = 1;
        if(i > 0 && i < k)
        {
            if(i % 2 > 0)
                if(j % 2 > 0)
                {
                    ad1.c = -1;
                    return;
                } else
                {
                    ad1.c = 1;
                    return;
                }
            if(j % 2 > 0)
            {
                ad1.c = 1;
                return;
            } else
            {
                ad1.c = -1;
                return;
            }
        }
        if(true) goto _L4; else goto _L14
_L14:
    }

    public java.util.ArrayList a(java.util.ArrayList arraylist, int i, int j, android.graphics.Bitmap bitmap, int k, int l, int i1, 
            int j1)
    {
        android.graphics.Path path;
        android.graphics.RectF rectf;
        android.graphics.Rect rect;
        int i2;
        int j2;
        int k2;
        int l2;
        i2 = bitmap.getWidth();
        int k1 = bitmap.getHeight();
        i2 = (int)java.lang.Math.floor(i2 / l);
        j2 = (int)java.lang.Math.floor(k1 / k);
        k2 = i2 * l;
        l2 = j2 * k;
        a(k, l, k2, l2, i2, j2, j1);
        path = new Path();
        rectf = new RectF();
        rect = new Rect();
        j1 = 0;
_L10:
        int l1;
        if(j1 >= k)
            break; /* Loop/switch isn't completed */
        l1 = 0;
_L8:
        com.yodesoft.android.game.yopuzzle.bg bg1;
        if(l1 >= l)
            break MISSING_BLOCK_LABEL_1101;
        android.graphics.Rect rect1 = new Rect();
        bg1 = new bg(j1, l1);
        arraylist.add(bg1);
        int i3 = (l + 1) * j1 + l1;
        int j3 = i3 + 1;
        int k3 = j3 + l + 1;
        bg1.s = (com.yodesoft.android.game.yopuzzle.ad)a.get(i3);
        bg1.t = (com.yodesoft.android.game.yopuzzle.ad)a.get(j3);
        bg1.u = (com.yodesoft.android.game.yopuzzle.ad)a.get(k3);
        bg1.v = (com.yodesoft.android.game.yopuzzle.ad)a.get(k3 - 1);
        bg1.a = j1 * l + l1;
        bg1.d = bg1.s.a;
        bg1.e = bg1.s.b;
        bg1.f = i2;
        bg1.g = j2;
        bg1.w = true;
        bg1.x = true;
        bg1.y = true;
        bg1.z = true;
        bg1.l = i;
        bg1.E = k2;
        bg1.F = l2;
        path.reset();
        path.moveTo(bg1.s.a, bg1.s.b);
        a(path, i, bg1.s.a, bg1.s.b, bg1.t.a, bg1.t.b, -bg1.s.c, bg1.s.e, i2);
        a(path, i, bg1.t.a, bg1.t.b, bg1.u.a, bg1.u.b, -bg1.t.d, bg1.t.f, j2);
        a(path, i, bg1.u.a, bg1.u.b, bg1.v.a, bg1.v.b, bg1.v.c, bg1.v.e, i2);
        a(path, i, bg1.v.a, bg1.v.b, bg1.s.a, bg1.s.b, bg1.s.d, bg1.s.f, j2);
        path.close();
        path.computeBounds(rectf, true);
        if(rectf.left < 0.0F)
            rectf.left = 0.0F;
        if(rectf.top < 0.0F)
            rectf.top = 0.0F;
        if(rectf.right > (float)k2)
            rectf.right = k2;
        if(rectf.bottom > (float)l2)
            rectf.bottom = l2;
        bg1.m = java.lang.Math.round(rectf.left);
        bg1.n = java.lang.Math.round(rectf.top);
        bg1.o = (int)java.lang.Math.floor(rectf.width()) + 1;
        bg1.p = (int)java.lang.Math.floor(rectf.height()) + 1;
        bg1.q = (int)((float)bg1.d - bg1.m);
        bg1.r = (int)((float)bg1.e - bg1.n);
        bg1.h = android.graphics.Bitmap.createBitmap(bg1.o, bg1.p, android.graphics.Bitmap.Config.ARGB_8888);
        android.graphics.Bitmap bitmap1 = android.graphics.Bitmap.createBitmap(bg1.o, bg1.p, android.graphics.Bitmap.Config.ARGB_8888);
        bg1.i = bitmap1;
        d.setBitmap(bitmap1);
        rect1.set((int)bg1.m, (int)bg1.n, (int)bg1.m + bg1.o, (int)bg1.n + bg1.p);
        bg1.A = rect1;
        rect.set(rect1);
        rect.offsetTo(0, 0);
        d.save();
        d.translate(-rect1.left, -rect1.top);
        d.clipPath(path);
        d.translate(rect1.left, rect1.top);
        rectf.offsetTo(0.0F, 0.0F);
        d.drawBitmap(bitmap, rect1, rect, null);
        d.restore();
        if(i1 != 1) goto _L2; else goto _L1
_L1:
        f.nextInt(4);
        JVM INSTR tableswitch 0 2: default 1048
    //                   0 1069
    //                   1 1079
    //                   2 1090;
           goto _L3 _L4 _L5 _L6
_L6:
        break MISSING_BLOCK_LABEL_1090;
_L3:
        break; /* Loop/switch isn't completed */
_L4:
        break; /* Loop/switch isn't completed */
_L2:
        b(bg1, j);
        bg1.b();
        l1++;
        if(true) goto _L8; else goto _L7
_L7:
        bg1.b(90);
          goto _L2
_L5:
        bg1.b(180);
          goto _L2
        bg1.b(270);
          goto _L2
        j1++;
        if(true) goto _L10; else goto _L9
_L9:
        return arraylist;
    }

    public void a(int i, int j, int k, int l, int i1, int j1, int k1)
    {
        if(a == null)
            a = new ArrayList();
        a.clear();
        for(int l1 = 0; l1 <= i; l1++)
        {
            for(int i2 = 0; i2 <= j; i2++)
            {
                com.yodesoft.android.game.yopuzzle.ad ad1 = new ad();
                a.add(ad1);
                a(ad1, l1, i2, i, j, k, l, i1, j1, k1);
            }

        }

    }

    public void a(android.graphics.Path path, int i, float f1, float f2, float f3, float f4, float f5, 
            float f6, float f7)
    {
        float f8;
        float f9;
        float f10;
        float f11;
        float f12;
        int j;
        f8 = f3 - f1;
        f9 = f4 - f2;
        f10 = f8 / 2.0F + f1;
        f11 = f9 / 2.0F + f2;
        j = (int)java.lang.Math.sqrt(f8 * f8 + f9 * f9);
        f12 = ((f7 / (float)j) * f9) / 10F;
        f7 = ((f7 / (float)j) * f8) / 10F;
        f5 = b * f5;
        path.lineTo(f1, f2);
        if(f5 == 0.0F || j <= 5) goto _L2; else goto _L1
_L1:
        if(i != 1) goto _L4; else goto _L3
_L3:
        path.lineTo(f10 - f8 / 10F, f11 - f9 / 10F);
        path.lineTo(f10 - f8 / 10F - f6 * f5 * f12, (f11 - f9 / 10F) + f6 * f5 * f7);
        path.quadTo(f10 - 0.2F * f8 - 2.5F * f5 * f12, (f11 - 0.2F * f9) + 2.5F * f5 * f7, f10 - 2.5F * f5 * f12, 2.5F * f5 * f7 + f11);
        path.quadTo((0.2F * f8 + f10) - 2.5F * f5 * f12, 0.2F * f9 + f11 + 2.5F * f5 * f7, (f8 / 10F + f10) - f12 * (f6 * f5), f7 * (f5 * f6) + (f9 / 10F + f11));
        path.lineTo(f8 / 10F + f10, f9 / 10F + f11);
_L2:
        path.lineTo(f3, f4);
        return;
_L4:
        if(i == 2)
        {
            path.quadTo((f10 - 0.25F * f8) + 1.5F * f5 * f12, f11 - 0.15F * f9 - 1.5F * f5 * f7, f10 - f8 / 9F, f11 - f9 / 9F);
            path.quadTo(f10 - 0.2F * f8 - 2.5F * f5 * f12, (f11 - 0.2F * f9) + 2.5F * f5 * f7, f10 - 2.5F * f5 * f12, 2.5F * f5 * f7 + f11);
            path.quadTo((0.2F * f8 + f10) - 2.5F * f5 * f12, 0.2F * f9 + f11 + 2.5F * f5 * f7, f8 / 9F + f10, f9 / 9F + f11);
            path.quadTo(f8 * 0.25F + f10 + 1.5F * f5 * f12, (f9 * 0.15F + f11) - 1.5F * f5 * f7, f3, f4);
        } else
        if(i == 3)
        {
            path.lineTo(f10 - f8 / 4F, f11 - f9 / 4F);
            path.lineTo(f10 - 2.5F * f5 * f12, 2.5F * f5 * f7 + f11);
            path.lineTo(f8 / 4F + f10, f9 / 4F + f11);
        } else
        if(i == 4)
        {
            if(f5 > 0.0F)
            {
                path.lineTo(f10 - ((3F * f5) / 9F) * f9, ((3F * f5) / 9F) * f8 + f11);
                path.lineTo(f8 / 7F + f10, f9 / 7F + f11);
            } else
            {
                path.lineTo(f10 - f8 / 7F, f11 - f9 / 7F);
                path.lineTo(f10 - f9 * ((3F * f5) / 9F), f8 * ((3F * f5) / 9F) + f11);
            }
        } else
        if(i == 5)
        {
            path.quadTo((f10 - 0.25F * f8) + 1.5F * f5 * f12, f11 - 0.25F * f9 - 1.5F * f5 * f7, f10 - f8 / 30F, f11 - f9 / 30F);
            path.quadTo(f10 - 0.4F * f8 - 1.5F * f5 * f12, (f11 - 0.4F * f9) + 1.5F * f5 * f7, f10 - 2.0F * f5 * f12, 2.0F * f5 * f7 + f11);
            path.quadTo((0.4F * f8 + f10) - 1.5F * f5 * f12, 0.4F * f9 + f11 + 1.5F * f5 * f7, f8 / 30F + f10, f9 / 30F + f11);
            path.quadTo(f8 * 0.25F + f10 + 1.5F * f5 * f12, (f9 * 0.25F + f11) - 1.5F * f5 * f7, f3, f4);
        } else
        if(i == 6)
        {
            if(f5 > 0.0F)
            {
                path.quadTo(f10 - 0.2F * f8 - 2.5F * f5 * f12, (f11 - 0.2F * f9) + 2.5F * f5 * f7, f10 - 2.5F * f5 * f12, 2.5F * f5 * f7 + f11);
                path.quadTo((0.2F * f8 + f10) - 2.5F * f5 * f12, 0.2F * f9 + f11 + 2.5F * f5 * f7, f10, f11);
                path.quadTo((f10 - 0.2F * f8) + 2.5F * f5 * f12, f11 - 0.2F * f9 - 2.5F * f5 * f7, 2.5F * f5 * f12 + f10, f11 - 2.5F * f5 * f7);
                path.quadTo(f8 * 0.2F + f10 + 2.5F * f5 * f12, (f9 * 0.2F + f11) - 2.5F * f5 * f7, f3, f4);
            } else
            {
                path.quadTo((f10 - 0.2F * f8) + 2.5F * f5 * f12, f11 - 0.2F * f9 - 2.5F * f5 * f7, 2.5F * f5 * f12 + f10, f11 - 2.5F * f5 * f7);
                path.quadTo(0.2F * f8 + f10 + 2.5F * f5 * f12, (0.2F * f9 + f11) - 2.5F * f5 * f7, f10, f11);
                path.quadTo(f10 - 0.2F * f8 - 2.5F * f5 * f12, (f11 - 0.2F * f9) + 2.5F * f5 * f7, f10 - 2.5F * f5 * f12, 2.5F * f5 * f7 + f11);
                path.quadTo((f8 * 0.2F + f10) - 2.5F * f5 * f12, f9 * 0.2F + f11 + 2.5F * f5 * f7, f3, f4);
            }
        } else
        if(i == 7)
        {
            path.lineTo(f10 - f8 / 3F, f11 - f9 / 3F);
            path.quadTo(f10 - 0.2F * f8 - 4.5F * f5 * f12, (f11 - 0.2F * f9) + 4.5F * f5 * f7, f10 - f8 / 10F, f11 - f9 / 10F);
            path.lineTo(f10 - f8 / 10F, f11 - f9 / 10F);
            path.lineTo(f8 / 10F + f10, f9 / 10F + f11);
            path.quadTo((0.2F * f8 + f10) - f12 * (4.5F * f5), 0.2F * f9 + f11 + f7 * (f5 * 4.5F), f8 / 3F + f10, f9 / 3F + f11);
            path.lineTo(f8 / 3F + f10, f9 / 3F + f11);
        } else
        if(i == 8)
        {
            if(f5 > 0.0F)
            {
                path.quadTo(f10 - 0.2F * f8 - 3.5F * f5 * f12, (f11 - 0.2F * f9) + 3.5F * f5 * f7, 3.5F * f5 * f12 + f10, f11 - 3.5F * f5 * f7);
                path.quadTo((0.2F * f8 + f10) - 3.5F * f5 * f12, 0.2F * f9 + f11 + 3.5F * f5 * f7, f10 - 3.5F * f5 * f12, 3.5F * f5 * f7 + f11);
                path.quadTo((f8 * 0.2F + f10) - 3.5F * f5 * f12, f9 * 0.2F + f11 + 3.5F * f5 * f7, f3, f4);
            } else
            {
                path.quadTo(f10 - 0.2F * f8 - 3.5F * f5 * f12, (f11 - 0.2F * f9) + 3.5F * f5 * f7, f10 - 3.5F * f5 * f12, 3.5F * f5 * f7 + f11);
                path.quadTo(f10 - 0.2F * f8 - 3.5F * f5 * f12, (f11 - 0.2F * f9) + 3.5F * f5 * f7, 3.5F * f5 * f12 + f10, f11 - 3.5F * f5 * f7);
                path.quadTo((f8 * 0.2F + f10) - 3.5F * f5 * f12, f9 * 0.2F + f11 + 3.5F * f5 * f7, f3, f4);
            }
        } else
        if(i == 9)
        {
            if(f5 > 0.0F)
                path.lineTo(f10 - f9 * ((1.0F * f5) / 3F), f8 * ((1.0F * f5) / 3F) + f11);
            else
                path.lineTo(f10 - f9 * ((1.0F * f5) / 3F), f8 * ((1.0F * f5) / 3F) + f11);
        } else
        if(i == 10)
        {
            path.quadTo(f10 - 0.2F * f8 - 3F * f5 * f12, (f11 - 0.2F * f9) + 3F * f5 * f7, f10, f11);
            path.lineTo(f10, f11);
            path.quadTo((f8 * 0.2F + f10) - 3F * f5 * f12, f9 * 0.2F + f11 + 3F * f5 * f7, f3, f4);
        } else
        if(i == 11)
        {
            if(f5 > 0.0F)
            {
                path.quadTo(f10 - 0.5222222F * f8 - ((3F * f5) / 9F) * f9, (f11 - 0.5222222F * f9) + ((3F * f5) / 9F) * f8, f10 - ((3F * f5) / 9F) * f9, ((f5 * 3F) / 9F) * f8 + f11);
                path.quadTo(f8 / 7F + f10, f9 / 7F + f11, f3, f4);
            } else
            {
                path.quadTo(f10 - f8 / 7F, f11 - f9 / 7F, f10 - ((3F * f5) / 9F) * f9, ((3F * f5) / 9F) * f8 + f11);
                path.quadTo((f10 + 0.5222222F * f8) - ((3F * f5) / 9F) * f9, f8 * ((3F * f5) / 9F) + (f9 * 0.5222222F + f11), f3, f4);
            }
        } else
        if(i == 12)
        {
            if(f5 > 0.0F)
            {
                path.quadTo(f10 - 0.18F * f8 - ((1.0F * f5) / 3F) * f9, (f11 - 0.18F * f9) + ((1.0F * f5) / 3F) * f8, f10 - ((1.0F * f5) / 3F) * f9, ((1.0F * f5) / 3F) * f8 + f11);
                path.quadTo((f10 + 0.18F * f8) - ((1.0F * f5) / 3F) * f9, f8 * ((1.0F * f5) / 3F) + (f9 * 0.18F + f11), f3, f4);
            } else
            {
                path.quadTo(f10 - 0.18F * f8 - ((1.0F * f5) / 3F) * f9, (f11 - 0.18F * f9) + ((1.0F * f5) / 3F) * f8, f10 - ((1.0F * f5) / 3F) * f9, ((1.0F * f5) / 3F) * f8 + f11);
                path.quadTo((f10 + 0.18F * f8) - ((1.0F * f5) / 3F) * f9, f8 * ((1.0F * f5) / 3F) + (f9 * 0.18F + f11), f3, f4);
            }
        } else
        if(i == 13)
        {
            if(f5 > 0.0F)
            {
                path.quadTo(f10 - 0.2F * f8 - 2.5F * f5 * f12, (f11 - 0.2F * f9) + 2.5F * f5 * f7, f10 - 1.0F * f5 * f12, 1.0F * f5 * f7 + f11);
                path.quadTo((0.2F * f8 + f10) - 2.5F * f5 * f12, 0.2F * f9 + f11 + 2.5F * f5 * f7, f10, f11);
                path.quadTo((f10 - 0.2F * f8) + 2.5F * f5 * f12, f11 - 0.2F * f9 - 2.5F * f5 * f7, 1.0F * f5 * f12 + f10, f11 - 1.0F * f5 * f7);
                path.quadTo(f8 * 0.2F + f10 + 2.5F * f5 * f12, (f9 * 0.2F + f11) - 2.5F * f5 * f7, f3, f4);
            } else
            {
                path.quadTo((f10 - 0.2F * f8) + 2.5F * f5 * f12, f11 - 0.2F * f9 - 2.5F * f5 * f7, 1.0F * f5 * f12 + f10, f11 - 1.0F * f5 * f7);
                path.quadTo(0.2F * f8 + f10 + 2.5F * f5 * f12, (0.2F * f9 + f11) - 2.5F * f5 * f7, f10, f11);
                path.quadTo(f10 - 0.2F * f8 - 2.5F * f5 * f12, (f11 - 0.2F * f9) + 2.5F * f5 * f7, f10 - 1.0F * f5 * f12, 1.0F * f5 * f7 + f11);
                path.quadTo((f8 * 0.2F + f10) - 2.5F * f5 * f12, f9 * 0.2F + f11 + 2.5F * f5 * f7, f3, f4);
            }
        } else
        if(i == 14)
        {
            path.quadTo((f10 - 0.25F * f8) + 2.5F * f5 * f12, f11 - 0.25F * f9 - 2.5F * f5 * f7, f10, f11);
            path.quadTo(f10 - 0.2F * f8 - 2.5F * f5 * f12, (f11 - 0.2F * f9) + 2.5F * f5 * f7, f10 - 3.5F * f5 * f12, 3.5F * f5 * f7 + f11);
            path.quadTo((0.2F * f8 + f10) - 2.5F * f5 * f12, 0.2F * f9 + f11 + 2.5F * f5 * f7, f10, f11);
            path.quadTo(f8 * 0.25F + f10 + 2.5F * f5 * f12, (f9 * 0.25F + f11) - 2.5F * f5 * f7, f3, f4);
        } else
        if(i == 15)
            path.lineTo(f10, (f8 / 2.0F) * f5 + f11);
        else
        if(i == 16)
        {
            if(f5 > 0.0F)
            {
                path.lineTo(f10 - ((1.0F * f5) / 3F) * f9, f11);
                path.lineTo(((1.0F * f5) / 3F) * f9 + f10, f11);
            } else
            {
                path.lineTo(((1.0F * f5) / 3F) * f9 + f10, f11);
                path.lineTo(f10 - ((1.0F * f5) / 3F) * f9, f11);
            }
        } else
        if(i == 17)
        {
            path.lineTo(f10 - f8 / 2.0F, f11 - f9 / 2.0F);
            path.lineTo(f10 - 0.1F * f8 - 1.5F * f5 * f12, (f11 - 0.1F * f9) + 1.5F * f5 * f7);
            path.lineTo((0.1F * f8 + f10) - f12 * (1.5F * f5), 0.1F * f9 + f11 + f7 * (f5 * 1.5F));
            path.lineTo(f8 / 2.0F + f10, f9 / 2.0F + f11);
        } else
        if(i == 18)
        {
            path.quadTo((f10 - 0.2F * f8) + 2.5F * f5 * f12, f11 - 0.2F * f9 - 2.5F * f5 * f7, f10 - f8 / 3F - f6 * f5 * f12, (f11 - f9 / 3F) + f6 * f5 * f7);
            path.quadTo(f10 - 0.2F * f8 - 3.5F * f5 * f12, (f11 - 0.2F * f9) + 3.5F * f5 * f7, f10 - 3.5F * f5 * f12, 3.5F * f5 * f7 + f11);
            path.quadTo((0.2F * f8 + f10) - 3.5F * f5 * f12, 0.2F * f9 + f11 + 3.5F * f5 * f7, (f8 / 3F + f10) - f6 * f5 * f12, f9 / 3F + f11 + f6 * f5 * f7);
            path.quadTo(f8 * 0.2F + f10 + 2.5F * f5 * f12, (f9 * 0.2F + f11) - 2.5F * f5 * f7, f3, f4);
        } else
        if(i == 19)
        {
            path.lineTo(f10 - f8 / 2.0F, f11 - f9 / 2.0F);
            path.lineTo(f10 - 0.2F * f8 - 2.5F * f5 * f12, (f11 - 0.2F * f9) + 2.5F * f5 * f7);
            path.lineTo(f10, f11);
            path.lineTo((0.2F * f8 + f10) - f12 * (2.5F * f5), 0.2F * f9 + f11 + f7 * (f5 * 2.5F));
            path.lineTo(f8 / 2.0F + f10, f9 / 2.0F + f11);
        } else
        if(i == 20)
        {
            path.lineTo(f10 - f8 / 5F, f11 - f9 / 5F);
            path.lineTo(f10 - 0.28F * f8 - 1.5F * f5 * f12, (f11 - 0.28F * f9) + 1.5F * f5 * f7);
            path.lineTo(f10, f6 * f5 * f7 + f11);
            path.lineTo((0.28F * f8 + f10) - f12 * (1.5F * f5), 0.28F * f9 + f11 + f7 * (f5 * 1.5F));
            path.lineTo(f8 / 5F + f10, f9 / 5F + f11);
        } else
        if(i == 21)
        {
            path.quadTo(f10 - 0.25F * f8 - 3.5F * f5 * f12, (f11 - 0.2F * f9) + 2.5F * f5 * f7, f10 - f8 / 4F - f6 * f5 * f12, (f11 - f9 / 4F) + f6 * f5 * f7);
            path.quadTo((f10 - 0.35F * f8) + 3.5F * f5 * f12, f11 - 0.2F * f9 - 3.5F * f5 * f7, f10 - 1.0F * f5 * f12, 1.0F * f5 * f7 + f11);
            path.quadTo(0.35F * f8 + f10 + 3.5F * f5 * f12, (0.2F * f9 + f11) - 3.5F * f5 * f7, (f8 / 4F + f10) - f6 * f5 * f12, f9 / 4F + f11 + f6 * f5 * f7);
            path.quadTo((f8 * 0.25F + f10) - 3.5F * f5 * f12, f9 * 0.2F + f11 + 2.5F * f5 * f7, f3, f4);
        } else
        if(i == 22)
        {
            if(f5 > 0.0F)
            {
                path.quadTo(f10 - f9 / 10F, f11 - f9 / 10F, f10 - ((3F * f5) / 9F) * f9, ((f5 * 3F) / 9F) * f8 + f11);
                path.quadTo(f8 / 7F + f10, f9 / 7F + f11, f3, f4);
            } else
            {
                path.quadTo(f10 - f8 / 7F, f11 - f9 / 7F, f10 - ((3F * f5) / 9F) * f9, f8 * ((f5 * 3F) / 9F) + f11);
                path.quadTo(f9 / 10F + f10, f9 / 10F + f11, f3, f4);
            }
        } else
        if(i == 23)
        {
            if(f5 > 0.0F)
            {
                path.quadTo(f10 - f9 / 10F, f11 - f9 / 10F, f10 - f9 / 2.0F, f11 - f9 / 2.0F);
                path.quadTo(f10 - f8 / 9F, f11 - f9 / 9F, f3, f4);
            } else
            {
                path.quadTo(f8 / 10F + f10, f9 / 10F + f11, f9 / 2.0F + f10, f9 / 2.0F + f11);
                path.quadTo(f9 / 9F + f10, f9 / 9F + f11, f3, f4);
            }
        } else
        if(i == 24)
        {
            f1 = 1.5F * f5;
            path.lineTo(f10 - f8 / 4F, f11 - f9 / 3F);
            path.lineTo(f10 - f12 * (2.5F * f1), f1 * 2.5F * f7 + f11);
            path.lineTo(f8 / 4F + f10, f9 / 3F + f11);
        } else
        if(i == 25)
        {
            if(f5 > 0.0F)
            {
                path.quadTo(f10 - 0.5F * f8 - 4F * f5 * f12, (f11 - 0.5F * f9) + 4F * f5 * f7, 3F * f5 * f12 + f10, f11 - 3F * f5 * f7);
                path.quadTo((0.2F * f8 + f10) - 1.0F * f5 * f12, 0.1F * f9 + f11 + 1.0F * f5 * f7, f10, f11);
                path.quadTo((f10 - 0.2F * f8) + 1.0F * f5 * f12, f11 - 0.1F * f9 - 1.0F * f5 * f7, f10 - 3F * f5 * f12, 3F * f5 * f7 + f11);
                path.quadTo(f8 * 0.5F + f10 + 4F * f5 * f12, (f9 * 0.5F + f11) - 4F * f5 * f7, f3, f4);
            } else
            {
                path.quadTo((f10 - 0.5F * f8) + 4F * f5 * f12, f11 - 0.5F * f9 - 4F * f5 * f7, f10 - 3F * f5 * f12, 3F * f5 * f7 + f11);
                path.quadTo(0.2F * f8 + f10 + 1.0F * f5 * f12, (0.1F * f9 + f11) - 1.0F * f5 * f7, f10, f11);
                path.quadTo(f10 - 0.2F * f8 - 1.0F * f5 * f12, (f11 - 0.1F * f9) + 1.0F * f5 * f7, 3F * f5 * f12 + f10, f11 - 3F * f5 * f7);
                path.quadTo((f8 * 0.5F + f10) - 4F * f5 * f12, f9 * 0.5F + f11 + 4F * f5 * f7, f3, f4);
            }
        } else
        if(i == 26)
        {
            f1 = 1.5F * f5;
            path.lineTo(f10 - f8 / 4F, f11 - f9 / 3F);
            path.lineTo(f10 - f1 * f12 * 2.5F, f1 * f7 * 2.5F + f11);
            path.lineTo(f10 - f8 / 8F, f11 - f9 / 6F);
            path.lineTo(f1 * f12 * 2.5F + f10, f11 - f1 * f7 * 2.5F);
            path.lineTo(f8 / 8F + f10, f9 / 6F + f11);
            path.lineTo(f10 - f12 * f1 * 2.5F, f1 * f7 * 2.5F + f11);
            path.lineTo(f8 / 4F + f10, f9 / 3F + f11);
        } else
        if(i == 27)
        {
            path.lineTo(f10 - f8 / 4F, f11 - f9 / 4F);
            path.lineTo(f10 - 0.2F * f8 - 2.5F * f5 * f12, (f11 - 0.2F * f9) + 2.5F * f5 * f7);
            path.lineTo((0.2F * f8 + f10) - f12 * (2.5F * f5), 0.2F * f9 + f11 + f7 * (f5 * 2.5F));
            path.lineTo(f8 / 4F + f10, f9 / 4F + f11);
        } else
        if(i == 28)
        {
            path.lineTo(f10 - f8 / 2.0F, f11 - f9 / 2.0F);
            path.quadTo(f10 - 0.2F * f8 - 2.5F * f5 * f12, (f11 - 0.2F * f9) + 2.5F * f5 * f7, 4.5F * f5 * f12 + f10, 4.5F * f5 * f7 + f11);
            path.lineTo(4.5F * f5 * f12 + f10, 4.5F * f5 * f7 + f11);
            path.quadTo((0.2F * f8 + f10) - f12 * (2.5F * f5), 0.2F * f9 + f11 + f7 * (f5 * 2.5F), f8 / 2.0F + f10, f9 / 2.0F + f11);
            path.lineTo(f8 / 2.0F + f10, f9 / 2.0F + f11);
        } else
        if(i == 29)
        {
            if(f5 > 0.0F)
            {
                path.quadTo((f10 - 0.4F * f8) + 5F * f5 * f12, f11 - 0.5F * f9 - 5F * f5 * f7, 3F * f5 * f12 + f10, f11 - 3F * f5 * f7);
                path.quadTo((0.3F * f8 + f10) - 1.0F * f5 * f12, 0.3F * f9 + f11 + 1.0F * f5 * f7, f10, f11);
                path.quadTo((f10 - 0.3F * f8) + 1.0F * f5 * f12, f11 - 0.3F * f9 - 1.0F * f5 * f7, f10 - 3F * f5 * f12, 3F * f5 * f7 + f11);
                path.quadTo((f8 * 0.4F + f10) - 5F * f5 * f12, f9 * 0.5F + f11 + 5F * f5 * f7, f3, f4);
            } else
            {
                path.quadTo(f10 - 0.4F * f8 - 5F * f5 * f12, (f11 - 0.5F * f9) + 5F * f5 * f7, f10 - 3F * f5 * f12, 3F * f5 * f7 + f11);
                path.quadTo(0.3F * f8 + f10 + 1.0F * f5 * f12, (0.3F * f9 + f11) - 1.0F * f5 * f7, f10, f11);
                path.quadTo(f10 - 0.3F * f8 - 1.0F * f5 * f12, (f11 - 0.3F * f9) + 1.0F * f5 * f7, 3F * f5 * f12 + f10, f11 - 3F * f5 * f7);
                path.quadTo(f8 * 0.4F + f10 + 5F * f5 * f12, (f9 * 0.5F + f11) - 5F * f5 * f7, f3, f4);
            }
        } else
        if(i == 30)
        {
            path.lineTo(f10 - (7F * f8) / 24F, f11 - (7F * f9) / 24F);
            path.lineTo(f10 - 0.35F * f8 - 1.5F * f5 * f12, (f11 - 0.35F * f9) + 1.5F * f5 * f7);
            path.lineTo(f10 - 0.07F * f8 - 1.5F * f5 * f12, (f11 - 0.07F * f9) + 1.5F * f5 * f7);
            path.lineTo(f10 - f8 / 8F, f11 - f9 / 8F);
            path.lineTo(f8 / 8F + f10, f9 / 8F + f11);
            path.lineTo((0.07F * f8 + f10) - 1.5F * f5 * f12, 0.07F * f9 + f11 + 1.5F * f5 * f7);
            path.lineTo((0.35F * f8 + f10) - f12 * (1.5F * f5), 0.35F * f9 + f11 + f7 * (f5 * 1.5F));
            path.lineTo((f8 * 7F) / 24F + f10, (f9 * 7F) / 24F + f11);
        } else
        if(i == 31)
        {
            path.lineTo(f10 - f8 / 4F, f11 - f9 / 4F);
            path.quadTo(f10 - 0.3F * f8 - 3F * f5 * f12, (f11 - 0.3F * f9) + 3F * f5 * f7, 3F * f5 * f12 + f10, 3F * f5 * f7 + f11);
            path.lineTo(3F * f5 * f12 + f10, 3F * f5 * f7 + f11);
            path.quadTo((0.3F * f8 + f10) - f12 * (3F * f5), 0.3F * f9 + f11 + f7 * (f5 * 3F), f8 / 4F + f10, f9 / 4F + f11);
            path.lineTo(f8 / 4F + f10, f9 / 4F + f11);
        } else
        if(i == 32)
        {
            if(f5 > 0.0F)
            {
                path.quadTo(f10 - 0.1F * f8 - 2.5F * f5 * f12, (f11 - 0.1F * f9) + 2.5F * f5 * f7, f9 / 2.0F + f10, f9 / 4F + f11);
                path.lineTo(f9 / 2.0F + f10, f9 / 4F + f11);
                path.quadTo((f8 * 0.1F + f10) - 2.5F * f5 * f12, f9 * 0.1F + f11 + 2.5F * f5 * f7, f3, f4);
            } else
            {
                path.quadTo(f10 - 0.1F * f8 - 2.5F * f5 * f12, (f11 - 0.1F * f9) + 2.5F * f5 * f7, f10 - f9 / 2.0F, f11 - f9 / 4F);
                path.lineTo(f10 - f9 / 2.0F, f11 - f9 / 4F);
                path.quadTo((f8 * 0.1F + f10) - 2.5F * f5 * f12, f9 * 0.1F + f11 + 2.5F * f5 * f7, f3, f4);
            }
        } else
        if(i == 33)
        {
            path.lineTo(f8 / 2.0F + f10, f9 / 2.0F + f11);
            path.lineTo((0.2F * f8 + f10) - 3F * f5 * f12, 0.2F * f9 + f11 + 3F * f5 * f7);
            path.lineTo(f10 - 0.2F * f8 - f12 * (3F * f5), (f11 - 0.2F * f9) + f7 * (f5 * 3F));
            path.lineTo(f10 - f8 / 2.0F, f11 - f9 / 2.0F);
        } else
        if(i == 34)
        {
            if(f5 > 0.0F)
            {
                path.quadTo(f10 - 0.3F * f8 - 3.5F * f5 * f12, (f11 - 0.3F * f9) + 3.5F * f5 * f7, f10 - 3.5F * f5 * f12, 3.5F * f5 * f7 + f11);
                path.quadTo((f8 * 0.3F + f10) - 3.5F * f5 * f12, f9 * 0.3F + f11 + 3.5F * f5 * f7, f10 - f6 * f5 * f12, f11 + f6 * f5 * f7);
            } else
            {
                path.lineTo(f10 - f6 * f5 * f12, f6 * f5 * f7 + f11);
                path.quadTo(f10 - 0.3F * f8 - 3.5F * f5 * f12, (f11 - 0.3F * f9) + 3.5F * f5 * f7, f10 - 3.5F * f5 * f12, 3.5F * f5 * f7 + f11);
                path.quadTo((f8 * 0.3F + f10) - 3.5F * f5 * f12, f9 * 0.3F + f11 + 3.5F * f5 * f7, f3, f4);
            }
        } else
        if(i == 35)
        {
            if(f5 > 0.0F)
            {
                path.quadTo(f9 / 8F + f10, f9 / 8F + f11, f10 - 3.5F * f5 * f12, 3.5F * f5 * f7 + f11);
                path.quadTo((0.2F * f8 + f10) - 3.5F * f5 * f12, 0.2F * f9 + f11 + 3.5F * f5 * f7, f12 * (3.5F * f5) + f10, f11 - f7 * (f5 * 3.5F));
                path.quadTo(f8 / 6F + f10, f9 / 6F + f11, f3, f4);
            } else
            if(f5 < 0.0F)
            {
                path.quadTo(f10 - f8 / 6F, f11 - f9 / 6F, 3.5F * f5 * f12 + f10, f11 - 3.5F * f5 * f7);
                path.quadTo(f10 - f8 * 0.2F - 3.5F * f5 * f12, (f11 - 0.2F * f9) + 3.5F * f5 * f7, f10 - f12 * (3.5F * f5), f7 * (f5 * 3.5F) + f11);
                path.quadTo(f10 - f9 / 8F, f11 - f9 / 8F, f3, f4);
            }
        } else
        if(i == 36)
        {
            if(f5 > 0.0F)
            {
                path.lineTo(f10 - 0.1222222F * f8 - ((1.0F * f5) / 3F) * f9, f8 * ((1.0F * f5) / 3F) + (f11 - f9 * 0.1222222F));
                path.lineTo(f10, f11);
            } else
            {
                path.lineTo(f10, f11);
                path.lineTo((f10 + 0.1222222F * f8) - ((1.0F * f5) / 3F) * f9, f8 * ((1.0F * f5) / 3F) + (f9 * 0.1222222F + f11));
            }
        } else
        if(i == 37)
        {
            if(f5 > 0.0F)
            {
                path.quadTo(f10 - 0.3F * f8 - 2.5F * f5 * f12, (f11 - 0.3F * f9) + 2.5F * f5 * f7, f10 - 3F * f5 * f12, 3F * f5 * f7 + f11);
                path.quadTo(0.3F * f8 + f10 + 2.5F * f5 * f12, (0.3F * f9 + f11) - 2.5F * f5 * f7, f1, f2);
                path.lineTo(f1, f2);
                path.quadTo(f8 * 0.1F + f10 + 4F * f5 * f12, (f9 * 0.1F + f11) - 4F * f5 * f7, f3, f4);
            } else
            {
                path.quadTo((f10 - 0.1F * f8) + 4F * f5 * f12, f11 - 0.1F * f9 - 4F * f5 * f7, f3, f4);
                path.lineTo(f3, f4);
                path.quadTo((f10 - 0.3F * f8) + 2.5F * f5 * f12, f11 - 0.3F * f9 - 2.5F * f5 * f7, f10 - 3F * f5 * f12, 3F * f5 * f7 + f11);
                path.quadTo((f8 * 0.3F + f10) - 2.5F * f5 * f12, f9 * 0.3F + f11 + 2.5F * f5 * f7, f3, f4);
            }
        } else
        if(i == 38)
        {
            if(f5 > 0.0F)
            {
                path.lineTo(f8 / 7F + f10, f9 / 7F + f11);
                path.lineTo(f10 - f9 * ((3F * f5) / 9F), f8 * ((3F * f5) / 9F) + f11);
            } else
            {
                path.lineTo(f10 - ((3F * f5) / 9F) * f9, ((3F * f5) / 9F) * f8 + f11);
                path.lineTo(f10 - f8 / 7F, f11 - f9 / 7F);
            }
        } else
        if(i == 39)
        {
            path.quadTo((f10 - 0.2F * f8) + 2.5F * f5 * f12, f11 - 0.2F * f9 - 2.5F * f5 * f7, f10 - f8 / 3F - f6 * f5 * f12, (f11 - f9 / 3F) + f6 * f5 * f7);
            path.quadTo(f10 - 0.2F * f8 - 3.5F * f5 * f12, (f11 - 0.2F * f9) + 3.5F * f5 * f7, 3.5F * f5 * f12 + f10, f11 - 3.5F * f5 * f7);
            path.quadTo((0.2F * f8 + f10) - 3.5F * f5 * f12, 0.2F * f9 + f11 + 3.5F * f5 * f7, (f8 / 3F + f10) - f6 * f5 * f12, f9 / 3F + f11 + f6 * f5 * f7);
            path.quadTo(f8 * 0.2F + f10 + 2.5F * f5 * f12, (f9 * 0.2F + f11) - 2.5F * f5 * f7, f3, f4);
        } else
        if(i == 40)
            if(f5 > 0.0F)
            {
                path.quadTo((f10 - 0.4F * f8) + 5F * f5 * f12, f11 - 0.5F * f9 - 5F * f5 * f7, 2.5F * f5 * f12 + f10, f11 - 2.5F * f5 * f7);
                path.lineTo(f10 - 2.5F * f5 * f12, 2.5F * f5 * f7 + f11);
                path.quadTo((f8 * 0.4F + f10) - 5F * f5 * f12, f9 * 0.5F + f11 + 5F * f5 * f7, f3, f4);
            } else
            {
                path.quadTo(f10 - 0.4F * f8 - 5F * f5 * f12, (f11 - 0.5F * f9) + 5F * f5 * f7, f10 - 2.5F * f5 * f12, 2.5F * f5 * f7 + f11);
                path.lineTo(2.5F * f5 * f12 + f10, f11 - 2.5F * f5 * f7);
                path.quadTo(f8 * 0.4F + f10 + 5F * f5 * f12, (f9 * 0.5F + f11) - 5F * f5 * f7, f3, f4);
            }
        if(true) goto _L2; else goto _L5
_L5:
    }

    public void a(com.yodesoft.android.game.yopuzzle.bg bg1, int i)
    {
        b(bg1, i);
        int k = bg1.j.size();
        for(int j = 0; j < k; j++)
            b((com.yodesoft.android.game.yopuzzle.bg)bg1.j.get(j), i);

    }

    public void a(com.yodesoft.android.game.yopuzzle.bg abg[], int i)
    {
        int k = abg.length;
        for(int j = 0; j < k; j++)
            b(abg[j], i);

    }

    public void b(com.yodesoft.android.game.yopuzzle.bg bg1, int i)
    {
        if(bg1 == null)
            return;
        e.setAntiAlias(true);
        e.setStyle(android.graphics.Paint.Style.STROKE);
        e.setStrokeCap(android.graphics.Paint.Cap.ROUND);
        e.setStrokeJoin(android.graphics.Paint.Join.ROUND);
        android.graphics.Path path = new Path();
        d.setBitmap(bg1.h);
        bg1.h.eraseColor(0);
        android.graphics.Matrix matrix;
        int j;
        int k;
        int l;
        int i1;
        if(bg1.k == 90)
        {
            k = 0x60ffffff;
            l = 0x60ffffff;
            i1 = 0x60000000;
            j = 0x60000000;
        } else
        if(bg1.k == 180)
        {
            k = 0x60000000;
            l = 0x60ffffff;
            i1 = 0x60ffffff;
            j = 0x60000000;
        } else
        if(bg1.k == 270)
        {
            k = 0x60000000;
            l = 0x60000000;
            i1 = 0x60ffffff;
            j = 0x60ffffff;
        } else
        {
            k = 0x60ffffff;
            l = 0x60000000;
            i1 = 0x60000000;
            j = 0x60ffffff;
        }
        d.save();
        matrix = new Matrix();
        matrix.postRotate(bg1.k);
        if(bg1.k == 90)
            matrix.postTranslate(bg1.A.height(), 0.0F);
        else
        if(bg1.k == 180)
            matrix.postTranslate(bg1.A.width(), bg1.A.height());
        else
        if(bg1.k == 270)
            matrix.postTranslate(0.0F, bg1.A.width());
        d.drawBitmap(bg1.i, matrix, null);
        d.rotate(bg1.k);
        if(bg1.k == 90)
            d.translate(0.0F, -bg1.A.height());
        else
        if(bg1.k == 180)
            d.translate(-bg1.A.width(), -bg1.A.height());
        else
        if(bg1.k == 270)
            d.translate(-bg1.A.width(), 0.0F);
        d.translate(-bg1.A.left, -bg1.A.top);
        if(i == 1)
        {
            e.setStrokeWidth(1.0F);
            e.setColor(0x60000000);
            if(bg1.w)
            {
                path.reset();
                path.moveTo(bg1.s.a, bg1.s.b);
                a(path, bg1.l, bg1.s.a, bg1.s.b, bg1.t.a, bg1.t.b, -bg1.s.c, bg1.s.e, bg1.f);
                d.drawPath(path, e);
            }
            if(bg1.x)
            {
                path.reset();
                path.moveTo(bg1.t.a, bg1.t.b);
                a(path, bg1.l, bg1.t.a, bg1.t.b, bg1.u.a, bg1.u.b, -bg1.t.d, bg1.t.f, bg1.g);
                d.drawPath(path, e);
            }
            if(bg1.y)
            {
                path.reset();
                path.moveTo(bg1.u.a, bg1.u.b);
                a(path, bg1.l, bg1.u.a, bg1.u.b, bg1.v.a, bg1.v.b, bg1.v.c, bg1.v.e, bg1.f);
                d.drawPath(path, e);
            }
            if(bg1.z)
            {
                path.reset();
                path.moveTo(bg1.v.a, bg1.v.b);
                a(path, bg1.l, bg1.v.a, bg1.v.b, bg1.s.a, bg1.s.b, bg1.s.d, bg1.s.f, bg1.g);
                d.drawPath(path, e);
            }
        } else
        if(i == 2)
        {
            e.setStrokeWidth(2.0F);
            if(bg1.w)
            {
                e.setColor(j);
                path.reset();
                path.moveTo(bg1.s.a, bg1.s.b);
                a(path, bg1.l, bg1.s.a, bg1.s.b, bg1.t.a, bg1.t.b, -bg1.s.c, bg1.s.e, bg1.f);
                d.drawPath(path, e);
            }
            if(bg1.x)
            {
                e.setColor(i1);
                path.reset();
                path.moveTo(bg1.t.a, bg1.t.b);
                a(path, bg1.l, bg1.t.a, bg1.t.b, bg1.u.a, bg1.u.b, -bg1.t.d, bg1.t.f, bg1.g);
                d.drawPath(path, e);
            }
            if(bg1.y)
            {
                e.setColor(l);
                path.reset();
                path.moveTo(bg1.u.a, bg1.u.b);
                a(path, bg1.l, bg1.u.a, bg1.u.b, bg1.v.a, bg1.v.b, bg1.v.c, bg1.v.e, bg1.f);
                d.drawPath(path, e);
            }
            if(bg1.z)
            {
                e.setColor(k);
                path.reset();
                path.moveTo(bg1.v.a, bg1.v.b);
                a(path, bg1.l, bg1.v.a, bg1.v.b, bg1.s.a, bg1.s.b, bg1.s.d, bg1.s.f, bg1.g);
                d.drawPath(path, e);
            }
        }
        d.restore();
    }

    java.util.ArrayList a;
    private float b;
    private float c;
    private android.graphics.Canvas d;
    private android.graphics.Paint e;
    private java.util.Random f;
}
