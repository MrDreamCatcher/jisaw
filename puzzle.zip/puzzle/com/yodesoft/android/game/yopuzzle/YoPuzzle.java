// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AnimationUtils;
import android.webkit.CookieSyncManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.Gallery;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextSwitcher;
import android.widget.TextView;
import android.widget.ViewAnimator;
import android.widget.ViewFlipper;
import com.google.ads.GoogleAdView;
import com.google.ads.c;
import com.google.ads.w;
import java.util.Random;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            s, f, g, i, 
//            n, al, p, bl, 
//            a, av, u, bb, 
//            bj, k, c, e, 
//            ah, FixedViewFlipper, h

public class YoPuzzle extends android.app.Activity
{

    public YoPuzzle()
    {
        z = 0;
        B = new f(this);
        E = new g(this);
        F = null;
        G = null;
        H = null;
        O = false;
        Q = -1;
        R = new i(this);
    }

    private void A()
    {
        while(O || z != 0 || h.getDisplayedChild() != 0) 
            return;
        d(3);
        O = true;
    }

    private void B()
    {
        d(4);
    }

    private void C()
    {
        d(5);
    }

    private int a(android.widget.Gallery gallery, boolean flag)
    {
        byte byte0;
        if(flag)
            byte0 = 22;
        else
            byte0 = 21;
        gallery.onKeyDown(byte0, new KeyEvent(0, 0));
        return gallery.getSelectedItemPosition();
    }

    static int a(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle, int i1)
    {
        yopuzzle.z = i1;
        return i1;
    }

    static int a(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle, android.widget.Gallery gallery, boolean flag)
    {
        return yopuzzle.a(gallery, flag);
    }

    static com.yodesoft.android.game.yopuzzle.n a(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        return yopuzzle.i;
    }

    static com.yodesoft.android.game.yopuzzle.p a(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle, com.yodesoft.android.game.yopuzzle.p p1)
    {
        yopuzzle.y = p1;
        return p1;
    }

    private void a(int i1)
    {
        if(u() || i1 >= 20) goto _L2; else goto _L1
_L1:
        if(i1 != 0) goto _L4; else goto _L3
_L3:
        x();
_L6:
        return;
_L4:
        w();
        return;
_L2:
        int j1 = h.getDisplayedChild();
        if(j1 == 3)
            i.g();
        if(j1 != 4 || n.b() != i1)
        {
            n.b(h.getDisplayedChild());
            h.setDisplayedChild(4);
            n.a(i1);
            f.requestChildFocus(h.getChildAt(0), null);
            return;
        }
        if(true) goto _L6; else goto _L5
_L5:
    }

    private void a(android.widget.ViewAnimator viewanimator)
    {
        if((new Random()).nextBoolean())
        {
            viewanimator.setInAnimation(android.view.animation.AnimationUtils.loadAnimation(this, 0x10a0000));
            viewanimator.setOutAnimation(android.view.animation.AnimationUtils.loadAnimation(this, 0x10a0001));
            return;
        } else
        {
            viewanimator.setInAnimation(android.view.animation.AnimationUtils.loadAnimation(this, 0x10a0002));
            viewanimator.setOutAnimation(android.view.animation.AnimationUtils.loadAnimation(this, 0x10a0003));
            return;
        }
    }

    static void a(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle, boolean flag)
    {
        yopuzzle.a(flag);
    }

    private void a(boolean flag)
    {
        if(flag && h.getCurrentView() != n.a())
        {
            e();
            return;
        }
        if(y == null)
        {
            i.a(flag, s, t);
        } else
        {
            i.a(flag, y.d, y.e);
            y = null;
        }
        h.setDisplayedChild(3);
        z = 1;
    }

    private void a(int ai[], int ai1[], int i1)
    {
        if(ai.length == ai1.length)
        {
            int j1 = 0;
            while(j1 < ai1.length) 
            {
                android.widget.RadioButton radiobutton = (android.widget.RadioButton)h.findViewById(ai[j1]);
                radiobutton.setOnClickListener(B);
                if(ai1[j1] == i1)
                    radiobutton.setChecked(true);
                j1++;
            }
        }
    }

    static android.widget.ViewFlipper b(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        return yopuzzle.h;
    }

    private void b()
    {
        int i1;
        if(l == null)
            l = new bl(this, d, b, a, s);
        else
            l.a(s);
        k.removeAllViews();
        k.addView(l.a());
        i1 = h.indexOfChild(k);
        h.setDisplayedChild(i1);
    }

    private void b(int i1)
    {
        c.b(i1);
        m();
        if(A != null)
            t();
    }

    static void b(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle, int i1)
    {
        yopuzzle.b(i1);
    }

    static int c(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle, int i1)
    {
        yopuzzle.s = i1;
        return i1;
    }

    private void c()
    {
        if(y == null)
        {
            return;
        } else
        {
            com.yodesoft.android.game.yopuzzle.p p1 = y;
            c.a(p1.a, p1.b, p1.c);
            b.a(p1.i, p1.j, p1.f, p1.g, p1.h, p1.k);
            b(2);
            a(true);
            return;
        }
    }

    private void c(int i1)
    {
        if(i1 >= 3)
            return;
        t = i1;
        G.setText(F[t]);
        if(i1 == 2)
        {
            I.setVisibility(8);
            J.setVisibility(0);
            return;
        } else
        {
            I.setVisibility(0);
            J.setVisibility(8);
            return;
        }
    }

    static void c(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        yopuzzle.t();
    }

    private void d()
    {
        if(y == null)
        {
            return;
        } else
        {
            com.yodesoft.android.game.yopuzzle.p p1 = y;
            c.a(p1.l, p1.m);
            b.a(p1.i, p1.j, p1.f, p1.g, p1.h, p1.k);
            a(true);
            return;
        }
    }

    private void d(int i1)
    {
        int j1;
        int l1;
        l1 = 0x108009b;
        j1 = 0x7f070000;
        if(P == null || Q != i1) goto _L2; else goto _L1
_L1:
        P.show();
_L11:
        return;
_L2:
        i1;
        JVM INSTR tableswitch 0 6: default 76
    //                   0 198
    //                   1 223
    //                   2 254
    //                   3 272
    //                   4 292
    //                   5 312
    //                   6 337;
           goto _L3 _L4 _L5 _L6 _L7 _L8 _L9 _L10
_L3:
        java.lang.String s1;
        java.lang.String s2;
        boolean flag;
        int k1;
        flag = false;
        j1 = 0;
        k1 = 0;
        l1 = 0;
        s2 = null;
        s1 = null;
_L12:
        if(l1 != 0)
        {
            com.yodesoft.android.game.yopuzzle.u u1 = new u(this);
            u1.c(l1).b(k1).a(j1).a(false);
            if(s1 != null)
                u1.a(s1);
            if(s2 == null)
                u1.a(0x1040013, R);
            else
                u1.a(s2, R);
            if(flag)
                u1.b(0x1040009, R);
            P = u1.a();
            P.show();
            Q = i1;
            return;
        }
        if(true) goto _L11; else goto _L4
_L4:
        l1 = 0x1080027;
        k1 = 0x7f070000;
        j1 = 0x7f070010;
        flag = true;
        s1 = null;
        s2 = null;
          goto _L12
_L5:
        s2 = getString(0x7f070061);
        l1 = 0x1080027;
        k1 = 0x7f07005e;
        s1 = null;
        j1 = 0x7f07005f;
        flag = true;
          goto _L12
_L6:
        s1 = z();
        flag = false;
        k1 = 0x7f070000;
        s2 = null;
          goto _L12
_L7:
        j1 = 0x7f07006e;
        k1 = 0x7f07006d;
        flag = true;
        s1 = null;
        s2 = null;
          goto _L12
_L8:
        j1 = 0x7f070070;
        k1 = 0x7f07006f;
        flag = true;
        s1 = null;
        s2 = null;
          goto _L12
_L9:
        l1 = 0x1080027;
        k1 = 0x7f070000;
        j1 = 0x7f070075;
        flag = false;
        s1 = null;
        s2 = null;
          goto _L12
_L10:
        s2 = getString(0x7f070061);
        l1 = 0x1080027;
        k1 = 0x7f070000;
        j1 = 0x7f070060;
        s1 = null;
        flag = true;
          goto _L12
    }

    static void d(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        yopuzzle.m();
    }

    static void d(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle, int i1)
    {
        yopuzzle.c(i1);
    }

    private void e()
    {
        a(0);
    }

    static void e(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        yopuzzle.f();
    }

    private void f()
    {
        a(1);
    }

    static void f(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        yopuzzle.A();
    }

    private void g()
    {
        a(2);
    }

    static void g(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        yopuzzle.C();
    }

    private void h()
    {
        a(4);
    }

    static void h(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        yopuzzle.B();
    }

    private void i()
    {
        a(21);
    }

    static void i(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        yopuzzle.d();
    }

    private void j()
    {
        java.lang.String s1 = com.yodesoft.android.game.yopuzzle.bb.a();
        if(s1 == null)
        {
            w.setText(0x7f07006b);
            return;
        } else
        {
            s1 = (new StringBuilder()).append(getString(0x7f07006c)).append(s1).toString();
            w.setText(s1);
            return;
        }
    }

    static boolean j(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        return yopuzzle.u();
    }

    private void k()
    {
        int i1 = n.d();
        h.setDisplayedChild(i1);
        if(i1 == 3)
            i.f();
        j();
    }

    static void k(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        yopuzzle.w();
    }

    static int l(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        return yopuzzle.t;
    }

    private void l()
    {
        int i1;
        if(m == null)
            m = new bj(this, d, s);
        else
            m.a(s);
        k.removeAllViews();
        k.addView(m.a());
        i1 = h.indexOfChild(k);
        h.setDisplayedChild(i1);
        z = 3;
    }

    private void m()
    {
        java.lang.String s1 = c.i();
        o.setText(s1);
    }

    static void m(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        yopuzzle.b();
    }

    static com.yodesoft.android.game.yopuzzle.YoPuzzle n(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        return yopuzzle.e;
    }

    private void n()
    {
        o = (android.widget.TextSwitcher)h.findViewById(0x7f090044);
        o.setFactory(E);
        b(c.d());
    }

    private void o()
    {
        F = getResources().getStringArray(0x7f060000);
        G = (android.widget.TextSwitcher)h.findViewById(0x7f090007);
        G.setFactory(E);
        a(new int[] {
            0x7f090008, 0x7f09000a, 0x7f09000b
        }, new int[] {
            0, 1, 2
        }, 0);
        c(0);
    }

    static void o(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        yopuzzle.l();
    }

    private void p()
    {
        H = getResources().getStringArray(0x7f060001);
        q = (android.widget.TextSwitcher)h.findViewById(0x7f090002);
        q.setFactory(E);
        D = (android.widget.Gallery)h.findViewById(0x7f090005);
        int j1 = com.yodesoft.android.game.yopuzzle.av.a.length;
        int ai[] = new int[j1];
        for(int i1 = 0; i1 < j1; i1++)
            ai[i1] = 0x7f02001d + i1;

        com.yodesoft.android.game.yopuzzle.k k1 = new k(this, ai);
        k1.a(100, 100);
        D.setAdapter(k1);
        D.setClickable(true);
        D.setFocusable(true);
        D.setFocusableInTouchMode(true);
        D.setOnItemSelectedListener(new com.yodesoft.android.game.yopuzzle.c(this));
        D.setOnItemClickListener(new e(this));
    }

    static void p(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        yopuzzle.g();
    }

    static android.widget.Gallery q(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        return yopuzzle.D;
    }

    private void q()
    {
        ((android.widget.Button)h.findViewById(0x7f09000e)).setOnClickListener(B);
        ((android.widget.Button)h.findViewById(0x7f090003)).setOnClickListener(B);
        android.widget.Button button = (android.widget.Button)h.findViewById(0x7f09000c);
        button.setOnClickListener(B);
        I = button;
        button = (android.widget.Button)h.findViewById(0x7f09000d);
        button.setOnClickListener(B);
        J = button;
        button = (android.widget.Button)h.findViewById(0x7f090004);
        button.setOnClickListener(B);
        K = button;
        button = (android.widget.Button)h.findViewById(0x7f090006);
        button.setOnClickListener(B);
        L = button;
        p();
        o();
    }

    private void r()
    {
        ((android.widget.Button)h.findViewById(0x7f090046)).setOnClickListener(B);
        A = (android.widget.Button)h.findViewById(0x7f090047);
        A.setOnClickListener(B);
        ((android.widget.Button)h.findViewById(0x7f090048)).setOnClickListener(B);
    }

    static java.lang.String[] r(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        return yopuzzle.H;
    }

    static int s(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        return yopuzzle.s;
    }

    private void s()
    {
        java.lang.String s1 = (new StringBuilder()).append(c.i()).append(getString(0x7f070068)).toString();
        java.lang.StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append(getString(0x7f070069));
        stringbuilder.append("http://www.yopuzzle.com/m/games");
        android.content.Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("text/plain");
        intent.putExtra("android.intent.extra.SUBJECT", s1);
        intent.putExtra("android.intent.extra.TEXT", stringbuilder.toString());
        startActivity(android.content.Intent.createChooser(intent, getString(0x7f070067)));
    }

    static android.widget.TextSwitcher t(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        return yopuzzle.q;
    }

    private void t()
    {
        if(c.h() != 0 && c.e())
            A.setVisibility(0);
        else
            A.setVisibility(8);
        if(z == 0)
        {
            if(!O && b.h() && h.getDisplayedChild() == 0)
                A();
            f.requestChildFocus(h.getChildAt(0), null);
        }
    }

    static android.widget.Button u(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        return yopuzzle.K;
    }

    private boolean u()
    {
        if(u == null)
            u = (android.net.ConnectivityManager)getSystemService("connectivity");
        return u.getActiveNetworkInfo() != null;
    }

    static android.widget.Button v(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        return yopuzzle.L;
    }

    private void v()
    {
        d(0);
    }

    static int w(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        return yopuzzle.Q;
    }

    private void w()
    {
        d(1);
    }

    private void x()
    {
        d(6);
    }

    static void x(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        yopuzzle.c();
    }

    private void y()
    {
        d(2);
    }

    static void y(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        yopuzzle.i();
    }

    private java.lang.String z()
    {
        java.lang.String s1 = " ";
        java.lang.String s2 = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        s1 = s2;
_L2:
        java.lang.StringBuilder stringbuilder = new StringBuilder();
        stringbuilder.append(getString(0x7f070063));
        stringbuilder.append(s1);
        stringbuilder.append("\n");
        stringbuilder.append(getString(0x7f070064));
        stringbuilder.append("\n");
        stringbuilder.append(getString(0x7f070065));
        return stringbuilder.toString();
        android.content.pm.PackageManager.NameNotFoundException namenotfoundexception;
        namenotfoundexception;
        if(true) goto _L2; else goto _L1
_L1:
    }

    public void a()
    {
        startActivity(new Intent("android.intent.action.VIEW", android.net.Uri.parse("http://www.yodesoft.com/m/mobile-games/index.html")));
    }

    public void onCreate(android.os.Bundle bundle)
    {
        super.onCreate(bundle);
        android.webkit.CookieSyncManager.createInstance(this);
        com.yodesoft.android.game.yopuzzle.bb.b();
        e = this;
        b = com.yodesoft.android.game.yopuzzle.av.a(e);
        bundle = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(bundle);
        b.n = false;
        if(((android.util.DisplayMetrics) (bundle)).widthPixels >= 640 || ((android.util.DisplayMetrics) (bundle)).densityDpi <= 160 && ((android.util.DisplayMetrics) (bundle)).widthPixels >= 480)
        {
            setRequestedOrientation(0);
            b.n = true;
        }
        requestWindowFeature(1);
        getWindow().setFlags(1024, 1024);
        setVolumeControlStream(3);
        b.a();
        b.q = ((android.util.DisplayMetrics) (bundle)).widthPixels;
        b.r = ((android.util.DisplayMetrics) (bundle)).heightPixels;
        b.s = ((android.util.DisplayMetrics) (bundle)).density;
        b.o = (int)(320F * ((android.util.DisplayMetrics) (bundle)).density);
        b.p = (int)(((android.util.DisplayMetrics) (bundle)).density * 48F);
        a = com.yodesoft.android.game.yopuzzle.ah.a(e.getApplicationContext());
        a.a(b.b);
        c = com.yodesoft.android.game.yopuzzle.a.a(e);
        f = new FrameLayout(this);
        f.setBackgroundResource(0x7f020001);
        setContentView(f);
        h = new FixedViewFlipper(this);
        g = new android.widget.FrameLayout.LayoutParams(-1, -1, 48);
        f.addView(h, g);
        android.view.View view;
        byte byte0;
        if(b.n)
            byte0 = 85;
        else
            byte0 = 49;
        p = new android.widget.FrameLayout.LayoutParams(-2, -2, byte0);
        j = new GoogleAdView(this);
        j.a(30);
        C = new c("ca-mb-app-pub-4795619137662126");
        C.c("Yodesoft").a("Yo Puzzle2").b("8006324758").a(com.google.ads.w.c).a(false).d("android mobile game application shopping music video movie finance fun free kid");
        f.addView(j, p);
        j.a(C);
        r = true;
        bundle = android.view.LayoutInflater.from(this);
        a(h);
        view = bundle.inflate(0x7f030009, null);
        w = (android.widget.TextView)view.findViewById(0x7f090049);
        w.setOnClickListener(B);
        h.addView(view, 0);
        bundle = bundle.inflate(0x7f030001, null);
        h.addView(bundle, 1);
        k = new FrameLayout(this);
        h.addView(k, 2);
        i = new n(this, d);
        h.addView(i.a(), 3);
        v = new JSHandler(this, d);
        n = new al(this, v);
        bundle = n.a();
        h.addView(bundle, 4);
        r();
        n();
        q();
        t();
        j();
        x = true;
    }

    public boolean onCreateOptionsMenu(android.view.Menu menu)
    {
        if(b.b)
        {
            N = menu.add(0, 1, 0, 0x7f070006);
            N.setIcon(0x7f02002d);
        } else
        {
            N = menu.add(0, 1, 0, 0x7f070005);
            N.setIcon(0x7f02002e);
        }
        b.b(false);
        if(b.d)
        {
            M = menu.add(0, 3, 0, 0x7f07000a);
            M.setIcon(0x7f02002f);
        } else
        {
            M = menu.add(0, 3, 0, 0x7f070009);
            M.setIcon(0x7f020030);
        }
        menu.add(0, 0, 0, 0x7f07000b).setIcon(0x7f020028);
        menu.add(0, 9, 0, 0x7f070066).setIcon(0x7f02002a);
        menu.add(0, 4, 0, 0x7f070062).setIcon(0x7f020026);
        menu.add(0, 5, 0, 0x7f07000e).setIcon(0x7f020027);
        menu.add(0, 6, 0, 0x7f07000d).setIcon(0x7f020029);
        menu.add(0, 8, 0, 0x7f07005d).setIcon(0x7f020024);
        menu.add(0, 10, 0, 0x7f07006a).setIcon(0x7f02002b);
        return super.onCreateOptionsMenu(menu);
    }

    public boolean onKeyDown(int i1, android.view.KeyEvent keyevent)
    {
        switch(i1)
        {
        default:
            return false;

        case 4: // '\004'
            i1 = h.getDisplayedChild();
            break;
        }
        if(z != 0) goto _L2; else goto _L1
_L1:
        i1;
        JVM INSTR lookupswitch 2: default 64
    //                   0: 73
    //                   4: 80;
           goto _L3 _L4 _L5
_L3:
        h.showPrevious();
_L7:
        return true;
_L4:
        v();
        continue; /* Loop/switch isn't completed */
_L5:
        k();
        continue; /* Loop/switch isn't completed */
_L2:
        if(z == 1 || z == 2)
        {
            a.b();
            if(i1 == 4)
            {
                k();
            } else
            {
                h.setDisplayedChild(0);
                z = 0;
                t();
                i.g();
            }
        }
        if(true) goto _L7; else goto _L6
_L6:
    }

    public boolean onOptionsItemSelected(android.view.MenuItem menuitem)
    {
        switch(menuitem.getItemId())
        {
        default:
            return false;

        case 1: // '\001'
            com.yodesoft.android.game.yopuzzle.av av1 = b;
            boolean flag;
            if(!b.b)
                flag = true;
            else
                flag = false;
            av1.a(flag);
            a.a(b.b);
            if(b.b)
            {
                menuitem.setTitle(0x7f070006);
                menuitem.setIcon(0x7f02002d);
                return true;
            } else
            {
                menuitem.setTitle(0x7f070005);
                menuitem.setIcon(0x7f02002e);
                return true;
            }

        case 2: // '\002'
            com.yodesoft.android.game.yopuzzle.av av2 = b;
            boolean flag1;
            if(!b.c)
                flag1 = true;
            else
                flag1 = false;
            av2.b(flag1);
            if(b.c)
            {
                menuitem.setTitle(0x7f070008);
                return true;
            } else
            {
                menuitem.setTitle(0x7f070007);
                return true;
            }

        case 3: // '\003'
            com.yodesoft.android.game.yopuzzle.av av3 = b;
            boolean flag2;
            if(!b.d)
                flag2 = true;
            else
                flag2 = false;
            av3.c(flag2);
            i.a(b.d);
            if(b.d)
            {
                menuitem.setTitle(0x7f07000a);
                menuitem.setIcon(0x7f02002f);
                return true;
            } else
            {
                menuitem.setTitle(0x7f070009);
                menuitem.setIcon(0x7f020030);
                return true;
            }

        case 0: // '\0'
            a();
            return true;

        case 4: // '\004'
            y();
            return true;

        case 5: // '\005'
            h();
            return true;

        case 6: // '\006'
            n.c();
            return true;

        case 8: // '\b'
            onKeyDown(4, new KeyEvent(0, 0));
            return true;

        case 7: // '\007'
            l();
            return true;

        case 9: // '\t'
            s();
            return true;

        case 10: // '\n'
            g();
            return true;
        }
    }

    public void onPause()
    {
        super.onPause();
        ((android.widget.ImageView)h.findViewById(0x7f090028)).clearAnimation();
    }

    public boolean onPrepareOptionsMenu(android.view.Menu menu)
    {
        int i1 = h.getDisplayedChild();
        if(i1 == 3 && z == 1 && !i.h())
        {
            M.setVisible(true);
            N.setVisible(true);
        } else
        {
            M.setVisible(false);
            N.setVisible(false);
        }
        if(i1 == 0)
            menu.findItem(4).setVisible(true);
        else
            menu.findItem(4).setVisible(false);
        if(i1 == 4)
        {
            menu.findItem(6).setVisible(true);
            menu.findItem(5).setVisible(false);
            menu.findItem(8).setVisible(true);
            menu.findItem(10).setVisible(false);
            return true;
        } else
        {
            menu.findItem(6).setVisible(false);
            menu.findItem(5).setVisible(true);
            menu.findItem(8).setVisible(false);
            menu.findItem(10).setVisible(true);
            return true;
        }
    }

    public void onResume()
    {
        super.onResume();
        java.lang.Object obj = (android.widget.ImageView)h.findViewById(0x7f090028);
        if(((android.widget.ImageView) (obj)).getAnimation() == null)
        {
            obj = new h(this, ((android.widget.ImageView) (obj)));
            d.postDelayed(((java.lang.Runnable) (obj)), 1000L);
        }
        if(x)
            b.a(d);
        x = false;
    }

    private android.widget.Button A;
    private android.view.View.OnClickListener B;
    private com.google.ads.c C;
    private android.widget.Gallery D;
    private android.widget.ViewSwitcher.ViewFactory E;
    private java.lang.String F[];
    private android.widget.TextSwitcher G;
    private java.lang.String H[];
    private android.widget.Button I;
    private android.widget.Button J;
    private android.widget.Button K;
    private android.widget.Button L;
    private android.view.MenuItem M;
    private android.view.MenuItem N;
    private boolean O;
    private android.app.Dialog P;
    private int Q;
    private android.content.DialogInterface.OnClickListener R;
    public com.yodesoft.android.game.yopuzzle.ah a;
    public com.yodesoft.android.game.yopuzzle.av b;
    public com.yodesoft.android.game.yopuzzle.a c;
    final android.os.Handler d = new s(this);
    private com.yodesoft.android.game.yopuzzle.YoPuzzle e;
    private android.widget.FrameLayout f;
    private android.view.ViewGroup.LayoutParams g;
    private android.widget.ViewFlipper h;
    private com.yodesoft.android.game.yopuzzle.n i;
    private com.google.ads.GoogleAdView j;
    private android.widget.FrameLayout k;
    private com.yodesoft.android.game.yopuzzle.bl l;
    private com.yodesoft.android.game.yopuzzle.bj m;
    private com.yodesoft.android.game.yopuzzle.al n;
    private android.widget.TextSwitcher o;
    private android.view.ViewGroup.LayoutParams p;
    private android.widget.TextSwitcher q;
    private boolean r;
    private int s;
    private int t;
    private android.net.ConnectivityManager u;
    private com.yodesoft.android.game.yopuzzle.JSHandler v;
    private android.widget.TextView w;
    private boolean x;
    private com.yodesoft.android.game.yopuzzle.p y;
    private int z;

    private class JSHandler
    {

        public void challenge_master(java.lang.String s1, java.lang.String s2, int i1, int j1, int k1, int l1, int i2, 
                int j2, int k2, int l2, int i3)
        {
            if(i1 < 1 || j1 < 0 || k1 < 0 || l1 < 1 || i2 < 1)
            {
                return;
            } else
            {
                s1 = new p(s1, s2, i1, j1, k1, l1, i2, j2, k2, l2, i3);
                s2 = new Message();
                s2.what = 10;
                s2.obj = s1;
                b.sendMessage(s2);
                return;
            }
        }

        public void selected_album(java.lang.String s1, java.lang.String s2, int i1)
        {
_L2:
            return;
            if(s1 == null || s1.length() == 0 || s2 == null || s2.length() == 0) goto _L2; else goto _L1
_L1:
            int j1;
            j1 = java.lang.Integer.parseInt(s1);
            if(j1 >= 0)
            {
                if(i1 <= 0)
                    continue; /* Loop/switch isn't completed */
                a.a(s1, s2, i1);
                a.b(2);
            } else
            {
                if(j1 != -1)
                    continue; /* Loop/switch isn't completed */
                a.b(0);
            }
_L4:
            b.sendEmptyMessage(4);
            return;
            if(j1 != -2) goto _L2; else goto _L3
_L3:
            a.b(1);
              goto _L4
            if(true) goto _L2; else goto _L5
_L5:
        }

        public void selected_bottle(java.lang.String s1, java.lang.String s2, int i1, int j1, int k1, int l1, int i2, 
                int j2, int k2)
        {
            if(i1 < 0 || j1 < 1 || k1 < 1)
            {
                return;
            } else
            {
                com.yodesoft.android.game.yopuzzle.p p1 = new p(s1, "", 0, i1, 2, j1, k1, l1, i2, j2, k2);
                p1.l = s1;
                p1.m = s2;
                s1 = new Message();
                s1.what = 11;
                s1.obj = p1;
                b.sendMessage(s1);
                return;
            }
        }

        private com.yodesoft.android.game.yopuzzle.a a;
        private android.os.Handler b;

        JSHandler(android.content.Context context, android.os.Handler handler)
        {
            a = com.yodesoft.android.game.yopuzzle.a.a(context);
            b = handler;
        }
    }

}
