// Decompiled by Jad v1.5.8g. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://www.kpdus.com/jad.html
// Decompiler options: fullnames 

package com.yodesoft.android.game.yopuzzle;

import android.view.View;
import android.widget.TextView;

// Referenced classes of package com.yodesoft.android.game.yopuzzle:
//            YoPuzzle

class g
    implements android.widget.ViewSwitcher.ViewFactory
{

    g(com.yodesoft.android.game.yopuzzle.YoPuzzle yopuzzle)
    {
        a = yopuzzle;
        super();
    }

    public android.view.View makeView()
    {
        android.widget.TextView textview = new TextView(a);
        textview.setTextAppearance(a, 0x7f080007);
        textview.setGravity(17);
        return textview;
    }

    final com.yodesoft.android.game.yopuzzle.YoPuzzle a;
}
