package com.google.android.gms.games;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.location.LocationStatusCodes;

public class c implements Creator<PlayerEntity> {
    static void a(PlayerEntity playerEntity, Parcel parcel, int i) {
        int k = b.k(parcel);
        b.a(parcel, 1, playerEntity.getPlayerId(), false);
        b.c(parcel, LocationStatusCodes.GEOFENCE_NOT_AVAILABLE, playerEntity.getVersionCode());
        b.a(parcel, 2, playerEntity.getDisplayName(), false);
        b.a(parcel, 3, playerEntity.getIconImageUri(), i, false);
        b.a(parcel, 4, playerEntity.getHiResImageUri(), i, false);
        b.a(parcel, 5, playerEntity.getRetrievedTimestamp());
        b.C(parcel, k);
    }

    public PlayerEntity[] L(int i) {
        return new PlayerEntity[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return u(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return L(i);
    }

    public PlayerEntity u(Parcel parcel) {
        String str = null;
        int j = a.j(parcel);
        int i = 0;
        long j2 = 0;
        String str2 = null;
        Uri uri = null;
        Uri uri2 = null;
        while (parcel.dataPosition() < j) {
            int i2 = a.i(parcel);
            switch (a.y(i2)) {
                case 1:
                    str = a.l(parcel, i2);
                    break;
                case 2:
                    str2 = a.l(parcel, i2);
                    break;
                case 3:
                    uri = (Uri) a.a(parcel, i2, Uri.CREATOR);
                    break;
                case 4:
                    uri2 = (Uri) a.a(parcel, i2, Uri.CREATOR);
                    break;
                case 5:
                    j2 = a.g(parcel, i2);
                    break;
                case LocationStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i = a.f(parcel, i2);
                    break;
                default:
                    a.b(parcel, i2);
                    break;
            }
        }
        if (parcel.dataPosition() == j) {
            return new PlayerEntity(i, str, str2, uri, uri2, j2);
        }
        throw new a.a("Overread allowed size end=" + j, parcel);
    }
}
