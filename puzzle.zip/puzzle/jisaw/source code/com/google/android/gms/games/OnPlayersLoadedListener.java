package com.google.android.gms.games;

public interface OnPlayersLoadedListener {
    void onPlayersLoaded(int i, PlayerBuffer playerBuffer);
}
