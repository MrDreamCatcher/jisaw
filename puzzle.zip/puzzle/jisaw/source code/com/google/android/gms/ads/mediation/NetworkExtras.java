package com.google.android.gms.ads.mediation;

public interface NetworkExtras {
}
