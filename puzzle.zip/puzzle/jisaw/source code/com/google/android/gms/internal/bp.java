package com.google.android.gms.internal;

import android.content.Context;

public final class bp {

    public interface a {
        void a(ce ceVar);
    }

    public static cg a(Context context, com.google.android.gms.internal.bu.a aVar, h hVar, cq cqVar, aw awVar, a aVar2) {
        cg bqVar = new bq(context, aVar, hVar, cqVar, awVar, aVar2);
        bqVar.start();
        return bqVar;
    }
}
