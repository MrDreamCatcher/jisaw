package com.google.android.gms.games.multiplayer;

import android.os.Parcel;
import com.google.android.gms.common.data.d;
import com.google.android.gms.games.Game;
import com.google.android.gms.internal.dm;
import java.util.ArrayList;

public final class b extends com.google.android.gms.common.data.b implements Invitation {
    private final ArrayList<Participant> nQ;
    private final Game nS;
    private final d nT;

    b(d dVar, int i, int i2) {
        super(dVar, i);
        this.nS = new com.google.android.gms.games.b(dVar, i);
        this.nQ = new ArrayList(i2);
        String string = getString("external_inviter_id");
        Object obj = null;
        for (int i3 = 0; i3 < i2; i3++) {
            d dVar2 = new d(this.jf, this.ji + i3);
            if (dVar2.getParticipantId().equals(string)) {
                obj = dVar2;
            }
            this.nQ.add(dVar2);
        }
        this.nT = (d) dm.a(obj, (Object) "Must have a valid inviter!");
    }

    public int ch() {
        return getInteger("type");
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        return InvitationEntity.a(this, obj);
    }

    public Invitation freeze() {
        return new InvitationEntity(this);
    }

    public long getCreationTimestamp() {
        return getLong("creation_timestamp");
    }

    public Game getGame() {
        return this.nS;
    }

    public String getInvitationId() {
        return getString("external_invitation_id");
    }

    public Participant getInviter() {
        return this.nT;
    }

    public ArrayList<Participant> getParticipants() {
        return this.nQ;
    }

    public int getVariant() {
        return getInteger("variant");
    }

    public int hashCode() {
        return InvitationEntity.a(this);
    }

    public String toString() {
        return InvitationEntity.b((Invitation) this);
    }

    public void writeToParcel(Parcel parcel, int i) {
        ((InvitationEntity) freeze()).writeToParcel(parcel, i);
    }
}
