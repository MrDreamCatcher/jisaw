package com.google.android.gms.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class bd implements Creator<be> {
    static void a(be beVar, Parcel parcel, int i) {
        int k = b.k(parcel);
        b.c(parcel, 1, beVar.versionCode);
        b.a(parcel, 2, beVar.fy, false);
        b.a(parcel, 3, beVar.fz, false);
        b.a(parcel, 4, beVar.mimeType, false);
        b.a(parcel, 5, beVar.packageName, false);
        b.a(parcel, 6, beVar.fA, false);
        b.a(parcel, 7, beVar.fB, false);
        b.a(parcel, 8, beVar.fC, false);
        b.C(parcel, k);
    }

    public be c(Parcel parcel) {
        String str = null;
        int j = a.j(parcel);
        int i = 0;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        String str5 = null;
        String str6 = null;
        String str7 = null;
        while (parcel.dataPosition() < j) {
            int i2 = a.i(parcel);
            switch (a.y(i2)) {
                case 1:
                    i = a.f(parcel, i2);
                    break;
                case 2:
                    str = a.l(parcel, i2);
                    break;
                case 3:
                    str2 = a.l(parcel, i2);
                    break;
                case 4:
                    str3 = a.l(parcel, i2);
                    break;
                case 5:
                    str4 = a.l(parcel, i2);
                    break;
                case 6:
                    str5 = a.l(parcel, i2);
                    break;
                case 7:
                    str6 = a.l(parcel, i2);
                    break;
                case 8:
                    str7 = a.l(parcel, i2);
                    break;
                default:
                    a.b(parcel, i2);
                    break;
            }
        }
        if (parcel.dataPosition() == j) {
            return new be(i, str, str2, str3, str4, str5, str6, str7);
        }
        throw new a.a("Overread allowed size end=" + j, parcel);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return c(parcel);
    }

    public be[] g(int i) {
        return new be[i];
    }

    public /* synthetic */ Object[] newArray(int i) {
        return g(i);
    }
}
