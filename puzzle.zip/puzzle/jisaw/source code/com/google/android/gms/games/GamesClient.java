package com.google.android.gms.games;

import android.content.Context;
import android.content.Intent;
import android.view.View;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks;
import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.games.achievement.OnAchievementUpdatedListener;
import com.google.android.gms.games.achievement.OnAchievementsLoadedListener;
import com.google.android.gms.games.leaderboard.LeaderboardScoreBuffer;
import com.google.android.gms.games.leaderboard.OnLeaderboardMetadataLoadedListener;
import com.google.android.gms.games.leaderboard.OnLeaderboardScoresLoadedListener;
import com.google.android.gms.games.leaderboard.OnScoreSubmittedListener;
import com.google.android.gms.games.multiplayer.OnInvitationReceivedListener;
import com.google.android.gms.games.multiplayer.OnInvitationsLoadedListener;
import com.google.android.gms.games.multiplayer.realtime.RealTimeReliableMessageSentListener;
import com.google.android.gms.games.multiplayer.realtime.RealTimeSocket;
import com.google.android.gms.games.multiplayer.realtime.Room;
import com.google.android.gms.games.multiplayer.realtime.RoomConfig;
import com.google.android.gms.games.multiplayer.realtime.RoomUpdateListener;
import com.google.android.gms.internal.dm;
import com.google.android.gms.internal.em;
import java.util.List;

public final class GamesClient implements GooglePlayServicesClient {
    public static final String EXTRA_EXCLUSIVE_BIT_MASK = "exclusive_bit_mask";
    public static final String EXTRA_INVITATION = "invitation";
    public static final String EXTRA_MAX_AUTOMATCH_PLAYERS = "max_automatch_players";
    public static final String EXTRA_MIN_AUTOMATCH_PLAYERS = "min_automatch_players";
    public static final String EXTRA_PLAYERS = "players";
    public static final String EXTRA_ROOM = "room";
    public static final int MAX_RELIABLE_MESSAGE_LEN = 1400;
    public static final int MAX_UNRELIABLE_MESSAGE_LEN = 1168;
    public static final int NOTIFICATION_TYPES_ALL = -1;
    public static final int NOTIFICATION_TYPES_MULTIPLAYER = 1;
    public static final int NOTIFICATION_TYPE_INVITATION = 1;
    public static final int STATUS_ACHIEVEMENT_NOT_INCREMENTAL = 3002;
    public static final int STATUS_ACHIEVEMENT_UNKNOWN = 3001;
    public static final int STATUS_ACHIEVEMENT_UNLOCKED = 3003;
    public static final int STATUS_ACHIEVEMENT_UNLOCK_FAILURE = 3000;
    public static final int STATUS_APP_MISCONFIGURED = 8;
    public static final int STATUS_CLIENT_RECONNECT_REQUIRED = 2;
    public static final int STATUS_INTERNAL_ERROR = 1;
    public static final int STATUS_INVALID_REAL_TIME_ROOM_ID = 7002;
    public static final int STATUS_LICENSE_CHECK_FAILED = 7;
    public static final int STATUS_MULTIPLAYER_ERROR_CREATION_NOT_ALLOWED = 6000;
    public static final int STATUS_MULTIPLAYER_ERROR_NOT_TRUSTED_TESTER = 6001;
    public static final int STATUS_NETWORK_ERROR_NO_DATA = 4;
    public static final int STATUS_NETWORK_ERROR_OPERATION_DEFERRED = 5;
    public static final int STATUS_NETWORK_ERROR_OPERATION_FAILED = 6;
    public static final int STATUS_NETWORK_ERROR_STALE_DATA = 3;
    public static final int STATUS_OK = 0;
    public static final int STATUS_PARTICIPANT_NOT_CONNECTED = 7003;
    public static final int STATUS_REAL_TIME_CONNECTION_FAILED = 7000;
    public static final int STATUS_REAL_TIME_INACTIVE_ROOM = 7005;
    public static final int STATUS_REAL_TIME_MESSAGE_FAILED = -1;
    public static final int STATUS_REAL_TIME_MESSAGE_SEND_FAILED = 7001;
    public static final int STATUS_REAL_TIME_ROOM_NOT_JOINED = 7004;
    private final em mz;

    public static final class Builder {
        private final ConnectionCallbacks iq;
        private final OnConnectionFailedListener ir;
        private String[] is = new String[]{Scopes.GAMES};
        private String it = "<<default account>>";
        private String mA;
        private int mB = 49;
        private View mC;
        private final Context mContext;

        public Builder(Context context, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
            this.mContext = context;
            this.mA = context.getPackageName();
            this.iq = connectionCallbacks;
            this.ir = onConnectionFailedListener;
        }

        public GamesClient create() {
            return new GamesClient(this.mContext, this.mA, this.it, this.iq, this.ir, this.is, this.mB, this.mC);
        }

        public Builder setAccountName(String str) {
            this.it = (String) dm.e(str);
            return this;
        }

        public Builder setGravityForPopups(int i) {
            this.mB = i;
            return this;
        }

        public Builder setScopes(String... strArr) {
            this.is = strArr;
            return this;
        }

        public Builder setViewForPopups(View view) {
            this.mC = (View) dm.e(view);
            return this;
        }
    }

    private GamesClient(Context context, String str, String str2, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener, String[] strArr, int i, View view) {
        this.mz = new em(context, str, str2, connectionCallbacks, onConnectionFailedListener, strArr, i, view, false);
    }

    public void clearAllNotifications() {
        this.mz.clearNotifications(-1);
    }

    public void clearNotifications(int i) {
        this.mz.clearNotifications(i);
    }

    public void connect() {
        this.mz.connect();
    }

    public void createRoom(RoomConfig roomConfig) {
        this.mz.createRoom(roomConfig);
    }

    public void declineRoomInvitation(String str) {
        this.mz.j(str, 0);
    }

    public void disconnect() {
        this.mz.disconnect();
    }

    public void dismissRoomInvitation(String str) {
        this.mz.i(str, 0);
    }

    public Intent getAchievementsIntent() {
        return this.mz.getAchievementsIntent();
    }

    public Intent getAllLeaderboardsIntent() {
        return this.mz.getAllLeaderboardsIntent();
    }

    public String getAppId() {
        return this.mz.getAppId();
    }

    public String getCurrentAccountName() {
        return this.mz.getCurrentAccountName();
    }

    public Game getCurrentGame() {
        return this.mz.getCurrentGame();
    }

    public Player getCurrentPlayer() {
        return this.mz.getCurrentPlayer();
    }

    public String getCurrentPlayerId() {
        return this.mz.getCurrentPlayerId();
    }

    public Intent getInvitationInboxIntent() {
        return this.mz.getInvitationInboxIntent();
    }

    public Intent getLeaderboardIntent(String str) {
        return this.mz.getLeaderboardIntent(str);
    }

    public RealTimeSocket getRealTimeSocketForParticipant(String str, String str2) {
        return this.mz.getRealTimeSocketForParticipant(str, str2);
    }

    public Intent getRealTimeWaitingRoomIntent(Room room, int i) {
        return this.mz.getRealTimeWaitingRoomIntent(room, i);
    }

    public Intent getSelectPlayersIntent(int i, int i2) {
        return this.mz.getSelectPlayersIntent(i, i2);
    }

    public Intent getSettingsIntent() {
        return this.mz.getSettingsIntent();
    }

    public void incrementAchievement(String str, int i) {
        this.mz.a(null, str, i);
    }

    public void incrementAchievementImmediate(OnAchievementUpdatedListener onAchievementUpdatedListener, String str, int i) {
        this.mz.a(onAchievementUpdatedListener, str, i);
    }

    public boolean isConnected() {
        return this.mz.isConnected();
    }

    public boolean isConnecting() {
        return this.mz.isConnecting();
    }

    public boolean isConnectionCallbacksRegistered(ConnectionCallbacks connectionCallbacks) {
        return this.mz.isConnectionCallbacksRegistered(connectionCallbacks);
    }

    public boolean isConnectionFailedListenerRegistered(OnConnectionFailedListener onConnectionFailedListener) {
        return this.mz.isConnectionFailedListenerRegistered(onConnectionFailedListener);
    }

    public void joinRoom(RoomConfig roomConfig) {
        this.mz.joinRoom(roomConfig);
    }

    public void leaveRoom(RoomUpdateListener roomUpdateListener, String str) {
        this.mz.leaveRoom(roomUpdateListener, str);
    }

    public void loadAchievements(OnAchievementsLoadedListener onAchievementsLoadedListener, boolean z) {
        this.mz.loadAchievements(onAchievementsLoadedListener, z);
    }

    public void loadGame(OnGamesLoadedListener onGamesLoadedListener) {
        this.mz.loadGame(onGamesLoadedListener);
    }

    public void loadInvitablePlayers(OnPlayersLoadedListener onPlayersLoadedListener, int i, boolean z) {
        this.mz.a(onPlayersLoadedListener, i, false, z);
    }

    public void loadInvitations(OnInvitationsLoadedListener onInvitationsLoadedListener) {
        this.mz.loadInvitations(onInvitationsLoadedListener);
    }

    @Deprecated
    public void loadLeaderboardMetadata(OnLeaderboardMetadataLoadedListener onLeaderboardMetadataLoadedListener) {
        loadLeaderboardMetadata(onLeaderboardMetadataLoadedListener, false);
    }

    @Deprecated
    public void loadLeaderboardMetadata(OnLeaderboardMetadataLoadedListener onLeaderboardMetadataLoadedListener, String str) {
        loadLeaderboardMetadata(onLeaderboardMetadataLoadedListener, str, false);
    }

    public void loadLeaderboardMetadata(OnLeaderboardMetadataLoadedListener onLeaderboardMetadataLoadedListener, String str, boolean z) {
        this.mz.loadLeaderboardMetadata(onLeaderboardMetadataLoadedListener, str, z);
    }

    public void loadLeaderboardMetadata(OnLeaderboardMetadataLoadedListener onLeaderboardMetadataLoadedListener, boolean z) {
        this.mz.loadLeaderboardMetadata(onLeaderboardMetadataLoadedListener, z);
    }

    public void loadMoreInvitablePlayers(OnPlayersLoadedListener onPlayersLoadedListener, int i) {
        this.mz.a(onPlayersLoadedListener, i, true, false);
    }

    public void loadMoreScores(OnLeaderboardScoresLoadedListener onLeaderboardScoresLoadedListener, LeaderboardScoreBuffer leaderboardScoreBuffer, int i, int i2) {
        this.mz.loadMoreScores(onLeaderboardScoresLoadedListener, leaderboardScoreBuffer, i, i2);
    }

    public void loadPlayer(OnPlayersLoadedListener onPlayersLoadedListener, String str) {
        this.mz.loadPlayer(onPlayersLoadedListener, str);
    }

    public void loadPlayerCenteredScores(OnLeaderboardScoresLoadedListener onLeaderboardScoresLoadedListener, String str, int i, int i2, int i3) {
        this.mz.loadPlayerCenteredScores(onLeaderboardScoresLoadedListener, str, i, i2, i3, false);
    }

    public void loadPlayerCenteredScores(OnLeaderboardScoresLoadedListener onLeaderboardScoresLoadedListener, String str, int i, int i2, int i3, boolean z) {
        this.mz.loadPlayerCenteredScores(onLeaderboardScoresLoadedListener, str, i, i2, i3, z);
    }

    public void loadTopScores(OnLeaderboardScoresLoadedListener onLeaderboardScoresLoadedListener, String str, int i, int i2, int i3) {
        this.mz.loadTopScores(onLeaderboardScoresLoadedListener, str, i, i2, i3, false);
    }

    public void loadTopScores(OnLeaderboardScoresLoadedListener onLeaderboardScoresLoadedListener, String str, int i, int i2, int i3, boolean z) {
        this.mz.loadTopScores(onLeaderboardScoresLoadedListener, str, i, i2, i3, z);
    }

    public void reconnect() {
        this.mz.disconnect();
        this.mz.connect();
    }

    public void registerConnectionCallbacks(ConnectionCallbacks connectionCallbacks) {
        this.mz.registerConnectionCallbacks(connectionCallbacks);
    }

    public void registerConnectionFailedListener(OnConnectionFailedListener onConnectionFailedListener) {
        this.mz.registerConnectionFailedListener(onConnectionFailedListener);
    }

    public void registerInvitationListener(OnInvitationReceivedListener onInvitationReceivedListener) {
        this.mz.registerInvitationListener(onInvitationReceivedListener);
    }

    public void revealAchievement(String str) {
        this.mz.a(null, str);
    }

    public void revealAchievementImmediate(OnAchievementUpdatedListener onAchievementUpdatedListener, String str) {
        this.mz.a(onAchievementUpdatedListener, str);
    }

    public int sendReliableRealTimeMessage(RealTimeReliableMessageSentListener realTimeReliableMessageSentListener, byte[] bArr, String str, String str2) {
        return this.mz.sendReliableRealTimeMessage(realTimeReliableMessageSentListener, bArr, str, str2);
    }

    public int sendUnreliableRealTimeMessage(byte[] bArr, String str, String str2) {
        return this.mz.a(bArr, str, new String[]{str2});
    }

    public int sendUnreliableRealTimeMessage(byte[] bArr, String str, List<String> list) {
        return this.mz.a(bArr, str, (String[]) list.toArray(new String[list.size()]));
    }

    public int sendUnreliableRealTimeMessageToAll(byte[] bArr, String str) {
        return this.mz.sendUnreliableRealTimeMessageToAll(bArr, str);
    }

    public void setAchievementSteps(String str, int i) {
        this.mz.b(null, str, i);
    }

    public void setAchievementStepsImmediate(OnAchievementUpdatedListener onAchievementUpdatedListener, String str, int i) {
        this.mz.b(onAchievementUpdatedListener, str, i);
    }

    public void setGravityForPopups(int i) {
        this.mz.setGravityForPopups(i);
    }

    public void setUseNewPlayerNotificationsFirstParty(boolean z) {
        this.mz.setUseNewPlayerNotificationsFirstParty(z);
    }

    public void setViewForPopups(View view) {
        dm.e(view);
        this.mz.setViewForPopups(view);
    }

    public void signOut() {
        this.mz.signOut(null);
    }

    public void signOut(OnSignOutCompleteListener onSignOutCompleteListener) {
        this.mz.signOut(onSignOutCompleteListener);
    }

    public void submitScore(String str, long j) {
        this.mz.a(null, str, j, null);
    }

    public void submitScore(String str, long j, String str2) {
        this.mz.a(null, str, j, str2);
    }

    public void submitScoreImmediate(OnScoreSubmittedListener onScoreSubmittedListener, String str, long j) {
        this.mz.a(onScoreSubmittedListener, str, j, null);
    }

    public void submitScoreImmediate(OnScoreSubmittedListener onScoreSubmittedListener, String str, long j, String str2) {
        this.mz.a(onScoreSubmittedListener, str, j, str2);
    }

    public void unlockAchievement(String str) {
        this.mz.b(null, str);
    }

    public void unlockAchievementImmediate(OnAchievementUpdatedListener onAchievementUpdatedListener, String str) {
        this.mz.b(onAchievementUpdatedListener, str);
    }

    public void unregisterConnectionCallbacks(ConnectionCallbacks connectionCallbacks) {
        this.mz.unregisterConnectionCallbacks(connectionCallbacks);
    }

    public void unregisterConnectionFailedListener(OnConnectionFailedListener onConnectionFailedListener) {
        this.mz.unregisterConnectionFailedListener(onConnectionFailedListener);
    }

    public void unregisterInvitationListener() {
        this.mz.unregisterInvitationListener();
    }
}
