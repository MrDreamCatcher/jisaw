package com.google.android.gms.internal;

public interface bi {
    void B();

    void C();
}
