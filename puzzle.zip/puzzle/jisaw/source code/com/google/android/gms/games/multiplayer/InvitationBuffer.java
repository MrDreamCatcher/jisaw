package com.google.android.gms.games.multiplayer;

import com.google.android.gms.common.data.d;
import com.google.android.gms.common.data.f;

public final class InvitationBuffer extends f<Invitation> {
    public InvitationBuffer(d dVar) {
        super(dVar);
    }

    protected /* synthetic */ Object a(int i, int i2) {
        return getEntry(i, i2);
    }

    protected Invitation getEntry(int i, int i2) {
        return new b(this.jf, i, i2);
    }

    protected String getPrimaryDataMarkerColumn() {
        return "external_invitation_id";
    }
}
