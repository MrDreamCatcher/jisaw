package com.google.android.gms.appstate;

public interface OnStateDeletedListener {
    void onStateDeleted(int i, int i2);
}
