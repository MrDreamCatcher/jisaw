package com.google.android.gms.common.data;

import android.database.CursorWindow;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.location.LocationStatusCodes;

public class e implements Creator<d> {
    static void a(d dVar, Parcel parcel, int i) {
        int k = b.k(parcel);
        b.a(parcel, 1, dVar.aK(), false);
        b.c(parcel, LocationStatusCodes.GEOFENCE_NOT_AVAILABLE, dVar.getVersionCode());
        b.a(parcel, 2, dVar.aL(), i, false);
        b.c(parcel, 3, dVar.getStatusCode());
        b.a(parcel, 4, dVar.aM(), false);
        b.C(parcel, k);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return h(parcel);
    }

    public d h(Parcel parcel) {
        int i = 0;
        String[] strArr = null;
        int j = a.j(parcel);
        CursorWindow[] cursorWindowArr = null;
        Bundle bundle = null;
        int i2 = 0;
        while (parcel.dataPosition() < j) {
            int i3 = a.i(parcel);
            switch (a.y(i3)) {
                case 1:
                    strArr = a.w(parcel, i3);
                    break;
                case 2:
                    cursorWindowArr = (CursorWindow[]) a.b(parcel, i3, CursorWindow.CREATOR);
                    break;
                case 3:
                    i2 = a.f(parcel, i3);
                    break;
                case 4:
                    bundle = a.n(parcel, i3);
                    break;
                case LocationStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i = a.f(parcel, i3);
                    break;
                default:
                    a.b(parcel, i3);
                    break;
            }
        }
        if (parcel.dataPosition() != j) {
            throw new a.a("Overread allowed size end=" + j, parcel);
        }
        d dVar = new d(i, strArr, cursorWindowArr, i2, bundle);
        dVar.aJ();
        return dVar;
    }

    public /* synthetic */ Object[] newArray(int i) {
        return s(i);
    }

    public d[] s(int i) {
        return new d[i];
    }
}
