package com.google.android.gms.games.achievement;

public interface OnAchievementsLoadedListener {
    void onAchievementsLoaded(int i, AchievementBuffer achievementBuffer);
}
