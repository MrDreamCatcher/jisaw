package com.google.android.gms.games.leaderboard;

public interface OnLeaderboardMetadataLoadedListener {
    void onLeaderboardMetadataLoaded(int i, LeaderboardBuffer leaderboardBuffer);
}
