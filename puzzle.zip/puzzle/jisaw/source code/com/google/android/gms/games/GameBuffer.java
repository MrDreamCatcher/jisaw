package com.google.android.gms.games;

import com.google.android.gms.common.data.DataBuffer;
import com.google.android.gms.common.data.d;

public final class GameBuffer extends DataBuffer<Game> {
    public GameBuffer(d dVar) {
        super(dVar);
    }

    public Game get(int i) {
        return new b(this.jf, i);
    }
}
