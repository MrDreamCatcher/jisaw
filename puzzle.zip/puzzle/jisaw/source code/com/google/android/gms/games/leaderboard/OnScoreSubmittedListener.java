package com.google.android.gms.games.leaderboard;

public interface OnScoreSubmittedListener {
    void onScoreSubmitted(int i, SubmitScoreResult submitScoreResult);
}
