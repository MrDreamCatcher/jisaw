package com.google.android.gms.appstate;

public interface OnStateListLoadedListener {
    void onStateListLoaded(int i, AppStateBuffer appStateBuffer);
}
