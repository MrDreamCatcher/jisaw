package com.google.android.gms.auth;

public class GoogleAuthException extends Exception {
    public GoogleAuthException(String str) {
        super(str);
    }
}
