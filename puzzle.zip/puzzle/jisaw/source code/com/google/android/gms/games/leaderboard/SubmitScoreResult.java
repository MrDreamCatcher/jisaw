package com.google.android.gms.games.leaderboard;

import com.google.android.gms.common.data.d;
import com.google.android.gms.internal.dl;
import com.google.android.gms.internal.dl.a;
import com.google.android.gms.internal.dm;
import com.google.android.gms.internal.ev;
import java.util.HashMap;

public final class SubmitScoreResult {
    private static final String[] nI = new String[]{"leaderboardId", "playerId", "timeSpan", "hasResult", "rawScore", "formattedScore", "newBest", "scoreTag"};
    private int iC;
    private String mD;
    private String nJ;
    private HashMap<Integer, Result> nK;

    public static final class Result {
        public final String formattedScore;
        public final boolean newBest;
        public final long rawScore;
        public final String scoreTag;

        public Result(long j, String str, String str2, boolean z) {
            this.rawScore = j;
            this.formattedScore = str;
            this.scoreTag = str2;
            this.newBest = z;
        }

        public String toString() {
            return dl.d(this).a("RawScore", Long.valueOf(this.rawScore)).a("FormattedScore", this.formattedScore).a("ScoreTag", this.scoreTag).a("NewBest", Boolean.valueOf(this.newBest)).toString();
        }
    }

    public SubmitScoreResult(int i, String str, String str2) {
        this(i, str, str2, new HashMap());
    }

    public SubmitScoreResult(int i, String str, String str2, HashMap<Integer, Result> hashMap) {
        this.iC = i;
        this.nJ = str;
        this.mD = str2;
        this.nK = hashMap;
    }

    public SubmitScoreResult(d dVar) {
        this.iC = dVar.getStatusCode();
        this.nK = new HashMap();
        int count = dVar.getCount();
        dm.m(count == 3);
        for (int i = 0; i < count; i++) {
            int q = dVar.q(i);
            if (i == 0) {
                this.nJ = dVar.c("leaderboardId", i, q);
                this.mD = dVar.c("playerId", i, q);
            }
            if (dVar.d("hasResult", i, q)) {
                a(new Result(dVar.a("rawScore", i, q), dVar.c("formattedScore", i, q), dVar.c("scoreTag", i, q), dVar.d("newBest", i, q)), dVar.b("timeSpan", i, q));
            }
        }
    }

    private void a(Result result, int i) {
        this.nK.put(Integer.valueOf(i), result);
    }

    public String getLeaderboardId() {
        return this.nJ;
    }

    public String getPlayerId() {
        return this.mD;
    }

    public Result getScoreResult(int i) {
        return (Result) this.nK.get(Integer.valueOf(i));
    }

    public int getStatusCode() {
        return this.iC;
    }

    public String toString() {
        a a = dl.d(this).a("PlayerId", this.mD).a("StatusCode", Integer.valueOf(this.iC));
        for (int i = 0; i < 3; i++) {
            Result result = (Result) this.nK.get(Integer.valueOf(i));
            a.a("TimesSpan", ev.R(i));
            a.a("Result", result == null ? "null" : result.toString());
        }
        return a.toString();
    }
}
