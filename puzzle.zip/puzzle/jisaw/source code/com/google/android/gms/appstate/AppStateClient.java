package com.google.android.gms.appstate;

import android.content.Context;
import com.google.android.gms.common.GooglePlayServicesClient;
import com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks;
import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.internal.cw;
import com.google.android.gms.internal.dm;

public final class AppStateClient implements GooglePlayServicesClient {
    public static final int STATUS_CLIENT_RECONNECT_REQUIRED = 2;
    public static final int STATUS_DEVELOPER_ERROR = 7;
    public static final int STATUS_INTERNAL_ERROR = 1;
    public static final int STATUS_NETWORK_ERROR_NO_DATA = 4;
    public static final int STATUS_NETWORK_ERROR_OPERATION_DEFERRED = 5;
    public static final int STATUS_NETWORK_ERROR_OPERATION_FAILED = 6;
    public static final int STATUS_NETWORK_ERROR_STALE_DATA = 3;
    public static final int STATUS_OK = 0;
    public static final int STATUS_STATE_KEY_LIMIT_EXCEEDED = 2003;
    public static final int STATUS_STATE_KEY_NOT_FOUND = 2002;
    public static final int STATUS_WRITE_OUT_OF_DATE_VERSION = 2000;
    public static final int STATUS_WRITE_SIZE_EXCEEDED = 2001;
    private final cw io;

    public static final class Builder {
        private static final String[] ip = new String[]{Scopes.APP_STATE};
        private ConnectionCallbacks iq;
        private OnConnectionFailedListener ir;
        private String[] is = ip;
        private String it = "<<default account>>";
        private Context mContext;

        public Builder(Context context, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener) {
            this.mContext = context;
            this.iq = connectionCallbacks;
            this.ir = onConnectionFailedListener;
        }

        public AppStateClient create() {
            return new AppStateClient(this.mContext, this.iq, this.ir, this.it, this.is);
        }

        public Builder setAccountName(String str) {
            this.it = (String) dm.e(str);
            return this;
        }

        public Builder setScopes(String... strArr) {
            this.is = strArr;
            return this;
        }
    }

    private AppStateClient(Context context, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener, String str, String[] strArr) {
        this.io = new cw(context, connectionCallbacks, onConnectionFailedListener, str, strArr);
    }

    public void connect() {
        this.io.connect();
    }

    public void deleteState(OnStateDeletedListener onStateDeletedListener, int i) {
        this.io.deleteState(onStateDeletedListener, i);
    }

    public void disconnect() {
        this.io.disconnect();
    }

    public int getMaxNumKeys() {
        return this.io.getMaxNumKeys();
    }

    public int getMaxStateSize() {
        return this.io.getMaxStateSize();
    }

    public boolean isConnected() {
        return this.io.isConnected();
    }

    public boolean isConnecting() {
        return this.io.isConnecting();
    }

    public boolean isConnectionCallbacksRegistered(ConnectionCallbacks connectionCallbacks) {
        return this.io.isConnectionCallbacksRegistered(connectionCallbacks);
    }

    public boolean isConnectionFailedListenerRegistered(OnConnectionFailedListener onConnectionFailedListener) {
        return this.io.isConnectionFailedListenerRegistered(onConnectionFailedListener);
    }

    public void listStates(OnStateListLoadedListener onStateListLoadedListener) {
        this.io.listStates(onStateListLoadedListener);
    }

    public void loadState(OnStateLoadedListener onStateLoadedListener, int i) {
        this.io.loadState(onStateLoadedListener, i);
    }

    public void reconnect() {
        this.io.disconnect();
        this.io.connect();
    }

    public void registerConnectionCallbacks(ConnectionCallbacks connectionCallbacks) {
        this.io.registerConnectionCallbacks(connectionCallbacks);
    }

    public void registerConnectionFailedListener(OnConnectionFailedListener onConnectionFailedListener) {
        this.io.registerConnectionFailedListener(onConnectionFailedListener);
    }

    public void resolveState(OnStateLoadedListener onStateLoadedListener, int i, String str, byte[] bArr) {
        this.io.resolveState(onStateLoadedListener, i, str, bArr);
    }

    public void signOut() {
        this.io.signOut(null);
    }

    public void signOut(OnSignOutCompleteListener onSignOutCompleteListener) {
        dm.a((Object) onSignOutCompleteListener, (Object) "Must provide a valid listener");
        this.io.signOut(onSignOutCompleteListener);
    }

    public void unregisterConnectionCallbacks(ConnectionCallbacks connectionCallbacks) {
        this.io.unregisterConnectionCallbacks(connectionCallbacks);
    }

    public void unregisterConnectionFailedListener(OnConnectionFailedListener onConnectionFailedListener) {
        this.io.unregisterConnectionFailedListener(onConnectionFailedListener);
    }

    public void updateState(int i, byte[] bArr) {
        this.io.a(null, i, bArr);
    }

    public void updateStateImmediate(OnStateLoadedListener onStateLoadedListener, int i, byte[] bArr) {
        dm.a((Object) onStateLoadedListener, (Object) "Must provide a valid listener");
        this.io.a(onStateLoadedListener, i, bArr);
    }
}
