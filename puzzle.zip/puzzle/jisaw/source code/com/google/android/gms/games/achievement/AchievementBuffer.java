package com.google.android.gms.games.achievement;

import com.google.android.gms.common.data.DataBuffer;
import com.google.android.gms.common.data.d;

public final class AchievementBuffer extends DataBuffer<Achievement> {
    public AchievementBuffer(d dVar) {
        super(dVar);
    }

    public Achievement get(int i) {
        return new a(this.jf, i);
    }
}
