package com.google.android.gms.internal;

import android.content.Context;
import android.text.TextUtils;
import com.google.android.gms.internal.by.a;
import com.google.android.gms.location.LocationStatusCodes;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Map;

public final class bz extends a {
    private static final Object gL = new Object();
    private static bz gM;
    private final al gN;
    private final Context mContext;

    private bz(Context context, al alVar) {
        this.mContext = context;
        this.gN = alVar;
    }

    private static bw a(final Context context, al alVar, final bu buVar) {
        cn.m("Starting ad request from service.");
        alVar.init();
        cd cdVar = new cd(context);
        if (cdVar.hs == -1) {
            cn.m("Device is offline.");
            return new bw(2);
        }
        final cb cbVar = new cb();
        final String a = ca.a(buVar, cdVar, alVar.a(250));
        if (a == null) {
            return new bw(0);
        }
        cm.hO.post(new Runnable() {
            public void run() {
                cq a = cq.a(context, new x(), false, false, null, buVar.eg);
                a.setWillNotDraw(true);
                cbVar.b(a);
                cr aw = a.aw();
                aw.a("/invalidRequest", cbVar.gU);
                aw.a("/loadAdURL", cbVar.gV);
                aw.a("/log", ah.eE);
                cn.m("Getting the ad request URL.");
                a.loadDataWithBaseURL("http://googleads.g.doubleclick.net", "<!DOCTYPE html><html><head><script src=\"http://googleads.g.doubleclick.net/mads/static/sdk/native/sdk-core-v40.js\"></script><script>AFMA_buildAdURL(" + a + ");</script></head><body></body></html>", "text/html", "UTF-8", null);
            }
        });
        a = cbVar.aj();
        return TextUtils.isEmpty(a) ? new bw(cbVar.getErrorCode()) : a(context, buVar.eg.hP, a);
    }

    private static bw a(Context context, String str, String str2) {
        HttpURLConnection httpURLConnection;
        try {
            int responseCode;
            bw bwVar;
            cc ccVar = new cc();
            URL url = new URL(str2);
            int i = 0;
            while (true) {
                httpURLConnection = (HttpURLConnection) url.openConnection();
                ci.a(context, str, false, httpURLConnection);
                responseCode = httpURLConnection.getResponseCode();
                Map headerFields = httpURLConnection.getHeaderFields();
                if (responseCode < 200 || responseCode >= 300) {
                    a(url.toString(), headerFields, null, responseCode);
                    if (responseCode < 300 || responseCode >= 400) {
                        break;
                    }
                    Object headerField = httpURLConnection.getHeaderField("Location");
                    if (TextUtils.isEmpty(headerField)) {
                        cn.q("No location header to follow redirect.");
                        bwVar = new bw(0);
                        httpURLConnection.disconnect();
                        return bwVar;
                    }
                    url = new URL(headerField);
                    i++;
                    if (i > 5) {
                        cn.q("Too many redirects.");
                        bwVar = new bw(0);
                        httpURLConnection.disconnect();
                        return bwVar;
                    }
                    ccVar.d(headerFields);
                    httpURLConnection.disconnect();
                } else {
                    String url2 = url.toString();
                    String a = ci.a(new InputStreamReader(httpURLConnection.getInputStream()));
                    a(url2, headerFields, a, responseCode);
                    ccVar.a(url2, headerFields, a);
                    bwVar = ccVar.ak();
                    httpURLConnection.disconnect();
                    return bwVar;
                }
            }
            cn.q("Received error HTTP response code: " + responseCode);
            bwVar = new bw(0);
            httpURLConnection.disconnect();
            return bwVar;
        } catch (IOException e) {
            cn.q("Error while connecting to ad server: " + e.getMessage());
            return new bw(2);
        } catch (Throwable th) {
            httpURLConnection.disconnect();
        }
    }

    public static bz a(Context context, al alVar) {
        bz bzVar;
        synchronized (gL) {
            if (gM == null) {
                gM = new bz(context.getApplicationContext(), alVar);
            }
            bzVar = gM;
        }
        return bzVar;
    }

    private static void a(String str, Map<String, List<String>> map, String str2, int i) {
        if (cn.k(2)) {
            cn.p("Http Response: {\n  URL:\n    " + str + "\n  Headers:");
            if (map != null) {
                for (String str3 : map.keySet()) {
                    cn.p("    " + str3 + ":");
                    for (String str32 : (List) map.get(str32)) {
                        cn.p("      " + str32);
                    }
                }
            }
            cn.p("  Body:");
            if (str2 != null) {
                for (int i2 = 0; i2 < Math.min(str2.length(), 100000); i2 += LocationStatusCodes.GEOFENCE_NOT_AVAILABLE) {
                    cn.p(str2.substring(i2, Math.min(str2.length(), i2 + LocationStatusCodes.GEOFENCE_NOT_AVAILABLE)));
                }
            } else {
                cn.p("    null");
            }
            cn.p("  Response Code:\n    " + i + "\n}");
        }
    }

    public bw a(bu buVar) {
        return a(this.mContext, this.gN, buVar);
    }
}
