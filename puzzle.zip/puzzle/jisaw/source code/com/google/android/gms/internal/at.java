package com.google.android.gms.internal;

public final class at {
    public final int fl;
    public final ao fm;
    public final ax fn;
    public final String fo;
    public final ar fp;

    public interface a {
        void d(int i);
    }

    public at(int i) {
        this(null, null, null, null, i);
    }

    public at(ao aoVar, ax axVar, String str, ar arVar, int i) {
        this.fm = aoVar;
        this.fn = axVar;
        this.fo = str;
        this.fp = arVar;
        this.fl = i;
    }
}
