package com.google.android.gms.games.multiplayer;

public interface OnInvitationsLoadedListener {
    void onInvitationsLoaded(int i, InvitationBuffer invitationBuffer);
}
