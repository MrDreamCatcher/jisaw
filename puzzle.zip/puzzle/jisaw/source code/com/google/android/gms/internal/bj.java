package com.google.android.gms.internal;

import android.content.Context;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnErrorListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.widget.FrameLayout;
import android.widget.FrameLayout.LayoutParams;
import android.widget.MediaController;
import android.widget.VideoView;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;

public final class bj extends FrameLayout implements OnCompletionListener, OnErrorListener, OnPreparedListener {
    private final cq fG;
    private final MediaController gb;
    private final a gc = new a(this);
    private final VideoView gd;
    private long ge;
    private String gf;

    private static final class a {
        private final Runnable el;
        private volatile boolean gg = false;

        public a(final bj bjVar) {
            this.el = new Runnable(this) {
                private final WeakReference<bj> gh = new WeakReference(bjVar);
                final /* synthetic */ a gj;

                public void run() {
                    bj bjVar = (bj) this.gh.get();
                    if (!this.gj.gg && bjVar != null) {
                        bjVar.aa();
                        this.gj.ab();
                    }
                }
            };
        }

        public void ab() {
            cm.hO.postDelayed(this.el, 250);
        }

        public void cancel() {
            this.gg = true;
            cm.hO.removeCallbacks(this.el);
        }
    }

    public bj(Context context, cq cqVar) {
        super(context);
        this.fG = cqVar;
        this.gd = new VideoView(context);
        addView(this.gd, new LayoutParams(-1, -1, 17));
        this.gb = new MediaController(context);
        this.gc.ab();
        this.gd.setOnCompletionListener(this);
        this.gd.setOnPreparedListener(this);
        this.gd.setOnErrorListener(this);
    }

    private static void a(cq cqVar, String str) {
        a(cqVar, str, new HashMap(1));
    }

    public static void a(cq cqVar, String str, String str2) {
        Object obj = str2 == null ? 1 : null;
        Map hashMap = new HashMap(obj != null ? 2 : 3);
        hashMap.put("what", str);
        if (obj == null) {
            hashMap.put("extra", str2);
        }
        a(cqVar, "error", hashMap);
    }

    private static void a(cq cqVar, String str, String str2, String str3) {
        Map hashMap = new HashMap(2);
        hashMap.put(str2, str3);
        a(cqVar, str, hashMap);
    }

    private static void a(cq cqVar, String str, Map<String, String> map) {
        map.put("event", str);
        cqVar.a("onVideoEvent", (Map) map);
    }

    public void Z() {
        if (TextUtils.isEmpty(this.gf)) {
            a(this.fG, "no_src", null);
        } else {
            this.gd.setVideoPath(this.gf);
        }
    }

    public void aa() {
        long currentPosition = (long) this.gd.getCurrentPosition();
        if (this.ge != currentPosition) {
            a(this.fG, "timeupdate", "time", String.valueOf(((float) currentPosition) / 1000.0f));
            this.ge = currentPosition;
        }
    }

    public void b(MotionEvent motionEvent) {
        this.gd.dispatchTouchEvent(motionEvent);
    }

    public void destroy() {
        this.gc.cancel();
        this.gd.stopPlayback();
    }

    public void f(boolean z) {
        if (z) {
            this.gd.setMediaController(this.gb);
            return;
        }
        this.gb.hide();
        this.gd.setMediaController(null);
    }

    public void i(String str) {
        this.gf = str;
    }

    public void onCompletion(MediaPlayer mediaPlayer) {
        a(this.fG, "ended");
    }

    public boolean onError(MediaPlayer mediaPlayer, int i, int i2) {
        a(this.fG, String.valueOf(i), String.valueOf(i2));
        return true;
    }

    public void onPrepared(MediaPlayer mediaPlayer) {
        a(this.fG, "canplaythrough", "duration", String.valueOf(((float) this.gd.getDuration()) / 1000.0f));
    }

    public void pause() {
        this.gd.pause();
    }

    public void play() {
        this.gd.start();
    }

    public void seekTo(int i) {
        this.gd.seekTo(i);
    }
}
