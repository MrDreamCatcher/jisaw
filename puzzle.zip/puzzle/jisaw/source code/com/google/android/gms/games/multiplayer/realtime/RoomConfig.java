package com.google.android.gms.games.multiplayer.realtime;

import android.os.Bundle;
import com.google.android.gms.games.GamesClient;
import com.google.android.gms.internal.dm;
import java.util.ArrayList;
import java.util.Arrays;

public final class RoomConfig {
    private final String nM;
    private final int nR;
    private final RoomUpdateListener od;
    private final RoomStatusUpdateListener oe;
    private final RealTimeMessageReceivedListener of;
    private final String[] og;
    private final Bundle oh;
    private final boolean oi;

    public static final class Builder {
        int nR;
        final RoomUpdateListener od;
        RoomStatusUpdateListener oe;
        RealTimeMessageReceivedListener of;
        Bundle oh;
        boolean oi;
        String oj;
        ArrayList<String> ok;

        private Builder(RoomUpdateListener roomUpdateListener) {
            this.oj = null;
            this.nR = -1;
            this.ok = new ArrayList();
            this.oi = false;
            this.od = (RoomUpdateListener) dm.a((Object) roomUpdateListener, (Object) "Must provide a RoomUpdateListener");
        }

        public Builder addPlayersToInvite(ArrayList<String> arrayList) {
            dm.e(arrayList);
            this.ok.addAll(arrayList);
            return this;
        }

        public Builder addPlayersToInvite(String... strArr) {
            dm.e(strArr);
            this.ok.addAll(Arrays.asList(strArr));
            return this;
        }

        public RoomConfig build() {
            return new RoomConfig();
        }

        public Builder setAutoMatchCriteria(Bundle bundle) {
            this.oh = bundle;
            return this;
        }

        public Builder setInvitationIdToAccept(String str) {
            dm.e(str);
            this.oj = str;
            return this;
        }

        public Builder setMessageReceivedListener(RealTimeMessageReceivedListener realTimeMessageReceivedListener) {
            this.of = realTimeMessageReceivedListener;
            return this;
        }

        public Builder setRoomStatusUpdateListener(RoomStatusUpdateListener roomStatusUpdateListener) {
            this.oe = roomStatusUpdateListener;
            return this;
        }

        public Builder setSocketCommunicationEnabled(boolean z) {
            this.oi = z;
            return this;
        }

        public Builder setVariant(int i) {
            this.nR = i;
            return this;
        }
    }

    private RoomConfig(Builder builder) {
        this.od = builder.od;
        this.oe = builder.oe;
        this.of = builder.of;
        this.nM = builder.oj;
        this.nR = builder.nR;
        this.oh = builder.oh;
        this.oi = builder.oi;
        this.og = (String[]) builder.ok.toArray(new String[builder.ok.size()]);
        if (this.of == null) {
            dm.a(this.oi, (Object) "Must either enable sockets OR specify a message listener");
        }
    }

    public static Builder builder(RoomUpdateListener roomUpdateListener) {
        return new Builder(roomUpdateListener);
    }

    public static Bundle createAutoMatchCriteria(int i, int i2, long j) {
        Bundle bundle = new Bundle();
        bundle.putInt(GamesClient.EXTRA_MIN_AUTOMATCH_PLAYERS, i);
        bundle.putInt(GamesClient.EXTRA_MAX_AUTOMATCH_PLAYERS, i2);
        bundle.putLong(GamesClient.EXTRA_EXCLUSIVE_BIT_MASK, j);
        return bundle;
    }

    public Bundle getAutoMatchCriteria() {
        return this.oh;
    }

    public String getInvitationId() {
        return this.nM;
    }

    public String[] getInvitedPlayerIds() {
        return this.og;
    }

    public RealTimeMessageReceivedListener getMessageReceivedListener() {
        return this.of;
    }

    public RoomStatusUpdateListener getRoomStatusUpdateListener() {
        return this.oe;
    }

    public RoomUpdateListener getRoomUpdateListener() {
        return this.od;
    }

    public int getVariant() {
        return this.nR;
    }

    public boolean isSocketEnabled() {
        return this.oi;
    }
}
