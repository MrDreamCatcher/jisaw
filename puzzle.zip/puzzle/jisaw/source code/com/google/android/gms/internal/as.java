package com.google.android.gms.internal;

import android.content.Context;
import android.os.SystemClock;
import com.google.android.gms.dynamic.c;
import com.google.android.gms.internal.at.a;

public final class as implements a {
    private final aw dZ;
    private final Object eJ = new Object();
    private final v em;
    private final String fd;
    private final long fe;
    private final ao ff;
    private final x fg;
    private ax fh;
    private int fi = -2;
    private final Context mContext;

    public as(Context context, String str, aw awVar, ap apVar, ao aoVar, v vVar, x xVar) {
        this.mContext = context;
        this.fd = str;
        this.dZ = awVar;
        this.fe = apVar.eV != -1 ? apVar.eV : 10000;
        this.ff = aoVar;
        this.em = vVar;
        this.fg = xVar;
    }

    private ax P() {
        cn.o("Instantiating mediation adapter: " + this.fd);
        try {
            return this.dZ.g(this.fd);
        } catch (Throwable e) {
            cn.a("Could not instantiate mediation adapter: " + this.fd, e);
            return null;
        }
    }

    private void a(long j, long j2, long j3, long j4) {
        while (this.fi == -2) {
            b(j, j2, j3, j4);
        }
    }

    private void a(ar arVar) {
        try {
            if (this.fg.ex) {
                this.fh.a(c.g(this.mContext), this.em, this.ff.eS, arVar);
            } else {
                this.fh.a(c.g(this.mContext), this.fg, this.em, this.ff.eS, arVar);
            }
        } catch (Throwable e) {
            cn.b("Could not request ad from mediation adapter.", e);
            d(5);
        }
    }

    private void b(long j, long j2, long j3, long j4) {
        long elapsedRealtime = SystemClock.elapsedRealtime();
        long j5 = j2 - (elapsedRealtime - j);
        elapsedRealtime = j4 - (elapsedRealtime - j3);
        if (j5 <= 0 || elapsedRealtime <= 0) {
            cn.o("Timed out waiting for adapter.");
            this.fi = 3;
            return;
        }
        try {
            this.eJ.wait(Math.min(j5, elapsedRealtime));
        } catch (InterruptedException e) {
            this.fi = -1;
        }
    }

    public at b(long j, long j2) {
        at atVar;
        synchronized (this.eJ) {
            long elapsedRealtime = SystemClock.elapsedRealtime();
            final ar arVar = new ar();
            cm.hO.post(new Runnable(this) {
                final /* synthetic */ as fk;

                public void run() {
                    synchronized (this.fk.eJ) {
                        if (this.fk.fi != -2) {
                            return;
                        }
                        this.fk.fh = this.fk.P();
                        if (this.fk.fh == null) {
                            this.fk.d(4);
                            return;
                        }
                        arVar.a(this.fk);
                        this.fk.a(arVar);
                    }
                }
            });
            a(elapsedRealtime, this.fe, j, j2);
            atVar = new at(this.ff, this.fh, this.fd, arVar, this.fi);
        }
        return atVar;
    }

    public void cancel() {
        synchronized (this.eJ) {
            try {
                if (this.fh != null) {
                    this.fh.destroy();
                }
            } catch (Throwable e) {
                cn.b("Could not destroy mediation adapter.", e);
            }
            this.fi = -1;
            this.eJ.notify();
        }
    }

    public void d(int i) {
        synchronized (this.eJ) {
            this.fi = i;
            this.eJ.notify();
        }
    }
}
