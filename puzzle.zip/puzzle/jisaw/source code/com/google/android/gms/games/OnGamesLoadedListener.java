package com.google.android.gms.games;

public interface OnGamesLoadedListener {
    void onGamesLoaded(int i, GameBuffer gameBuffer);
}
