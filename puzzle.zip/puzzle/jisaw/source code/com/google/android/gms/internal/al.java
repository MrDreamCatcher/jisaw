package com.google.android.gms.internal;

import android.location.Location;

public interface al {
    Location a(long j);

    void init();
}
