package com.google.android.gms.internal;

public interface ag {
    void a(String str, String str2);
}
