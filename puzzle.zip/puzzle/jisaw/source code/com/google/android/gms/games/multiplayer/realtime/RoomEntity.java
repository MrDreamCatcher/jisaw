package com.google.android.gms.games.multiplayer.realtime;

import android.database.CharArrayBuffer;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.games.Player;
import com.google.android.gms.games.multiplayer.Participant;
import com.google.android.gms.games.multiplayer.ParticipantEntity;
import com.google.android.gms.internal.dd;
import com.google.android.gms.internal.dl;
import com.google.android.gms.internal.eg;
import com.google.android.gms.internal.en;
import java.util.ArrayList;

public final class RoomEntity extends en implements Room {
    public static final Creator<RoomEntity> CREATOR = new a();
    private final int iM;
    private final String mo;
    private final long nN;
    private final ArrayList<ParticipantEntity> nQ;
    private final int nR;
    private final String nb;
    private final Bundle oh;
    private final String ol;
    private final int om;
    private final int on;

    static final class a extends b {
        a() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return y(parcel);
        }

        public RoomEntity y(Parcel parcel) {
            if (en.c(dd.aW()) || dd.y(RoomEntity.class.getCanonicalName())) {
                return super.y(parcel);
            }
            String readString = parcel.readString();
            String readString2 = parcel.readString();
            long readLong = parcel.readLong();
            int readInt = parcel.readInt();
            String readString3 = parcel.readString();
            int readInt2 = parcel.readInt();
            Bundle readBundle = parcel.readBundle();
            int readInt3 = parcel.readInt();
            ArrayList arrayList = new ArrayList(readInt3);
            for (int i = 0; i < readInt3; i++) {
                arrayList.add(ParticipantEntity.CREATOR.createFromParcel(parcel));
            }
            return new RoomEntity(2, readString, readString2, readLong, readInt, readString3, readInt2, readBundle, arrayList, -1);
        }
    }

    RoomEntity(int i, String str, String str2, long j, int i2, String str3, int i3, Bundle bundle, ArrayList<ParticipantEntity> arrayList, int i4) {
        this.iM = i;
        this.nb = str;
        this.ol = str2;
        this.nN = j;
        this.om = i2;
        this.mo = str3;
        this.nR = i3;
        this.oh = bundle;
        this.nQ = arrayList;
        this.on = i4;
    }

    public RoomEntity(Room room) {
        this.iM = 2;
        this.nb = room.getRoomId();
        this.ol = room.getCreatorId();
        this.nN = room.getCreationTimestamp();
        this.om = room.getStatus();
        this.mo = room.getDescription();
        this.nR = room.getVariant();
        this.oh = room.getAutoMatchCriteria();
        ArrayList participants = room.getParticipants();
        int size = participants.size();
        this.nQ = new ArrayList(size);
        for (int i = 0; i < size; i++) {
            this.nQ.add((ParticipantEntity) ((Participant) participants.get(i)).freeze());
        }
        this.on = room.getAutoMatchWaitEstimateSeconds();
    }

    static int a(Room room) {
        return dl.hashCode(room.getRoomId(), room.getCreatorId(), Long.valueOf(room.getCreationTimestamp()), Integer.valueOf(room.getStatus()), room.getDescription(), Integer.valueOf(room.getVariant()), room.getAutoMatchCriteria(), room.getParticipants(), Integer.valueOf(room.getAutoMatchWaitEstimateSeconds()));
    }

    static boolean a(Room room, Object obj) {
        if (!(obj instanceof Room)) {
            return false;
        }
        if (room != obj) {
            Room room2 = (Room) obj;
            if (!(dl.equal(room2.getRoomId(), room.getRoomId()) && dl.equal(room2.getCreatorId(), room.getCreatorId()) && dl.equal(Long.valueOf(room2.getCreationTimestamp()), Long.valueOf(room.getCreationTimestamp())) && dl.equal(Integer.valueOf(room2.getStatus()), Integer.valueOf(room.getStatus())) && dl.equal(room2.getDescription(), room.getDescription()) && dl.equal(Integer.valueOf(room2.getVariant()), Integer.valueOf(room.getVariant())) && dl.equal(room2.getAutoMatchCriteria(), room.getAutoMatchCriteria()) && dl.equal(room2.getParticipants(), room.getParticipants()) && dl.equal(Integer.valueOf(room2.getAutoMatchWaitEstimateSeconds()), Integer.valueOf(room.getAutoMatchWaitEstimateSeconds())))) {
                return false;
            }
        }
        return true;
    }

    static String b(Room room) {
        return dl.d(room).a("RoomId", room.getRoomId()).a("CreatorId", room.getCreatorId()).a("CreationTimestamp", Long.valueOf(room.getCreationTimestamp())).a("RoomStatus", Integer.valueOf(room.getStatus())).a("Description", room.getDescription()).a("Variant", Integer.valueOf(room.getVariant())).a("AutoMatchCriteria", room.getAutoMatchCriteria()).a("Participants", room.getParticipants()).a("AutoMatchWaitEstimateSeconds", Integer.valueOf(room.getAutoMatchWaitEstimateSeconds())).toString();
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        return a(this, obj);
    }

    public Room freeze() {
        return this;
    }

    public Bundle getAutoMatchCriteria() {
        return this.oh;
    }

    public int getAutoMatchWaitEstimateSeconds() {
        return this.on;
    }

    public long getCreationTimestamp() {
        return this.nN;
    }

    public String getCreatorId() {
        return this.ol;
    }

    public String getDescription() {
        return this.mo;
    }

    public void getDescription(CharArrayBuffer charArrayBuffer) {
        eg.b(this.mo, charArrayBuffer);
    }

    public String getParticipantId(String str) {
        int size = this.nQ.size();
        for (int i = 0; i < size; i++) {
            Participant participant = (Participant) this.nQ.get(i);
            Player player = participant.getPlayer();
            if (player != null && player.getPlayerId().equals(str)) {
                return participant.getParticipantId();
            }
        }
        return null;
    }

    public ArrayList<String> getParticipantIds() {
        int size = this.nQ.size();
        ArrayList<String> arrayList = new ArrayList(size);
        for (int i = 0; i < size; i++) {
            arrayList.add(((ParticipantEntity) this.nQ.get(i)).getParticipantId());
        }
        return arrayList;
    }

    public int getParticipantStatus(String str) {
        int size = this.nQ.size();
        for (int i = 0; i < size; i++) {
            Participant participant = (Participant) this.nQ.get(i);
            if (participant.getParticipantId().equals(str)) {
                return participant.getStatus();
            }
        }
        throw new IllegalStateException("Participant " + str + " is not in room " + getRoomId());
    }

    public ArrayList<Participant> getParticipants() {
        return new ArrayList(this.nQ);
    }

    public String getRoomId() {
        return this.nb;
    }

    public int getStatus() {
        return this.om;
    }

    public int getVariant() {
        return this.nR;
    }

    public int getVersionCode() {
        return this.iM;
    }

    public int hashCode() {
        return a(this);
    }

    public boolean isDataValid() {
        return true;
    }

    public String toString() {
        return b((Room) this);
    }

    public void writeToParcel(Parcel parcel, int i) {
        if (aX()) {
            parcel.writeString(this.nb);
            parcel.writeString(this.ol);
            parcel.writeLong(this.nN);
            parcel.writeInt(this.om);
            parcel.writeString(this.mo);
            parcel.writeInt(this.nR);
            parcel.writeBundle(this.oh);
            int size = this.nQ.size();
            parcel.writeInt(size);
            for (int i2 = 0; i2 < size; i2++) {
                ((ParticipantEntity) this.nQ.get(i2)).writeToParcel(parcel, i);
            }
            return;
        }
        b.a(this, parcel, i);
    }
}
