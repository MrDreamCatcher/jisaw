package com.google.android.gms.games.leaderboard;

import android.database.CharArrayBuffer;
import android.net.Uri;
import com.google.android.gms.games.Player;
import com.google.android.gms.games.PlayerEntity;
import com.google.android.gms.internal.dl;
import com.google.android.gms.internal.dm;
import com.google.android.gms.internal.eg;

public final class c implements LeaderboardScore {
    private final long nA;
    private final long nB;
    private final String nC;
    private final Uri nD;
    private final Uri nE;
    private final PlayerEntity nF;
    private final String nG;
    private final long nx;
    private final String ny;
    private final String nz;

    public c(LeaderboardScore leaderboardScore) {
        this.nx = leaderboardScore.getRank();
        this.ny = (String) dm.e(leaderboardScore.getDisplayRank());
        this.nz = (String) dm.e(leaderboardScore.getDisplayScore());
        this.nA = leaderboardScore.getRawScore();
        this.nB = leaderboardScore.getTimestampMillis();
        this.nC = leaderboardScore.getScoreHolderDisplayName();
        this.nD = leaderboardScore.getScoreHolderIconImageUri();
        this.nE = leaderboardScore.getScoreHolderHiResImageUri();
        Player scoreHolder = leaderboardScore.getScoreHolder();
        this.nF = scoreHolder == null ? null : (PlayerEntity) scoreHolder.freeze();
        this.nG = leaderboardScore.getScoreTag();
    }

    static int a(LeaderboardScore leaderboardScore) {
        return dl.hashCode(Long.valueOf(leaderboardScore.getRank()), leaderboardScore.getDisplayRank(), Long.valueOf(leaderboardScore.getRawScore()), leaderboardScore.getDisplayScore(), Long.valueOf(leaderboardScore.getTimestampMillis()), leaderboardScore.getScoreHolderDisplayName(), leaderboardScore.getScoreHolderIconImageUri(), leaderboardScore.getScoreHolderHiResImageUri(), leaderboardScore.getScoreHolder());
    }

    static boolean a(LeaderboardScore leaderboardScore, Object obj) {
        if (!(obj instanceof LeaderboardScore)) {
            return false;
        }
        if (leaderboardScore != obj) {
            LeaderboardScore leaderboardScore2 = (LeaderboardScore) obj;
            if (!(dl.equal(Long.valueOf(leaderboardScore2.getRank()), Long.valueOf(leaderboardScore.getRank())) && dl.equal(leaderboardScore2.getDisplayRank(), leaderboardScore.getDisplayRank()) && dl.equal(Long.valueOf(leaderboardScore2.getRawScore()), Long.valueOf(leaderboardScore.getRawScore())) && dl.equal(leaderboardScore2.getDisplayScore(), leaderboardScore.getDisplayScore()) && dl.equal(Long.valueOf(leaderboardScore2.getTimestampMillis()), Long.valueOf(leaderboardScore.getTimestampMillis())) && dl.equal(leaderboardScore2.getScoreHolderDisplayName(), leaderboardScore.getScoreHolderDisplayName()) && dl.equal(leaderboardScore2.getScoreHolderIconImageUri(), leaderboardScore.getScoreHolderIconImageUri()) && dl.equal(leaderboardScore2.getScoreHolderHiResImageUri(), leaderboardScore.getScoreHolderHiResImageUri()) && dl.equal(leaderboardScore2.getScoreHolder(), leaderboardScore.getScoreHolder()) && dl.equal(leaderboardScore2.getScoreTag(), leaderboardScore.getScoreTag()))) {
                return false;
            }
        }
        return true;
    }

    static String b(LeaderboardScore leaderboardScore) {
        return dl.d(leaderboardScore).a("Rank", Long.valueOf(leaderboardScore.getRank())).a("DisplayRank", leaderboardScore.getDisplayRank()).a("Score", Long.valueOf(leaderboardScore.getRawScore())).a("DisplayScore", leaderboardScore.getDisplayScore()).a("Timestamp", Long.valueOf(leaderboardScore.getTimestampMillis())).a("DisplayName", leaderboardScore.getScoreHolderDisplayName()).a("IconImageUri", leaderboardScore.getScoreHolderIconImageUri()).a("HiResImageUri", leaderboardScore.getScoreHolderHiResImageUri()).a("Player", leaderboardScore.getScoreHolder() == null ? null : leaderboardScore.getScoreHolder()).a("ScoreTag", leaderboardScore.getScoreTag()).toString();
    }

    public LeaderboardScore cd() {
        return this;
    }

    public boolean equals(Object obj) {
        return a(this, obj);
    }

    public /* synthetic */ Object freeze() {
        return cd();
    }

    public String getDisplayRank() {
        return this.ny;
    }

    public void getDisplayRank(CharArrayBuffer charArrayBuffer) {
        eg.b(this.ny, charArrayBuffer);
    }

    public String getDisplayScore() {
        return this.nz;
    }

    public void getDisplayScore(CharArrayBuffer charArrayBuffer) {
        eg.b(this.nz, charArrayBuffer);
    }

    public long getRank() {
        return this.nx;
    }

    public long getRawScore() {
        return this.nA;
    }

    public Player getScoreHolder() {
        return this.nF;
    }

    public String getScoreHolderDisplayName() {
        return this.nF == null ? this.nC : this.nF.getDisplayName();
    }

    public void getScoreHolderDisplayName(CharArrayBuffer charArrayBuffer) {
        if (this.nF == null) {
            eg.b(this.nC, charArrayBuffer);
        } else {
            this.nF.getDisplayName(charArrayBuffer);
        }
    }

    public Uri getScoreHolderHiResImageUri() {
        return this.nF == null ? this.nE : this.nF.getHiResImageUri();
    }

    public Uri getScoreHolderIconImageUri() {
        return this.nF == null ? this.nD : this.nF.getIconImageUri();
    }

    public String getScoreTag() {
        return this.nG;
    }

    public long getTimestampMillis() {
        return this.nB;
    }

    public int hashCode() {
        return a(this);
    }

    public boolean isDataValid() {
        return true;
    }

    public String toString() {
        return b(this);
    }
}
