package com.google.android.gms.common.data;

import android.database.CharArrayBuffer;
import android.net.Uri;
import com.google.android.gms.internal.dl;
import com.google.android.gms.internal.dm;

public abstract class b {
    protected final d jf;
    protected final int ji;
    private final int jj;

    public b(d dVar, int i) {
        this.jf = (d) dm.e(dVar);
        boolean z = i >= 0 && i < dVar.getCount();
        dm.k(z);
        this.ji = i;
        this.jj = dVar.q(this.ji);
    }

    protected void a(String str, CharArrayBuffer charArrayBuffer) {
        this.jf.a(str, this.ji, this.jj, charArrayBuffer);
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        return dl.equal(Integer.valueOf(bVar.ji), Integer.valueOf(this.ji)) && dl.equal(Integer.valueOf(bVar.jj), Integer.valueOf(this.jj)) && bVar.jf == this.jf;
    }

    protected boolean getBoolean(String str) {
        return this.jf.d(str, this.ji, this.jj);
    }

    protected byte[] getByteArray(String str) {
        return this.jf.e(str, this.ji, this.jj);
    }

    protected int getInteger(String str) {
        return this.jf.b(str, this.ji, this.jj);
    }

    protected long getLong(String str) {
        return this.jf.a(str, this.ji, this.jj);
    }

    protected String getString(String str) {
        return this.jf.c(str, this.ji, this.jj);
    }

    public int hashCode() {
        return dl.hashCode(Integer.valueOf(this.ji), Integer.valueOf(this.jj), this.jf);
    }

    public boolean isDataValid() {
        return !this.jf.isClosed();
    }

    protected Uri u(String str) {
        return this.jf.f(str, this.ji, this.jj);
    }

    protected boolean v(String str) {
        return this.jf.g(str, this.ji, this.jj);
    }
}
