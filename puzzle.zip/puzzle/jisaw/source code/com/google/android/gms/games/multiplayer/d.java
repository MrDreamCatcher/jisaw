package com.google.android.gms.games.multiplayer;

import android.database.CharArrayBuffer;
import android.net.Uri;
import android.os.Parcel;
import com.google.android.gms.common.data.b;
import com.google.android.gms.games.Player;

public final class d extends b implements Participant {
    private final com.google.android.gms.games.d nZ;

    public d(com.google.android.gms.common.data.d dVar, int i) {
        super(dVar, i);
        this.nZ = new com.google.android.gms.games.d(dVar, i);
    }

    public String ci() {
        return getString("client_address");
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        return ParticipantEntity.a(this, obj);
    }

    public Participant freeze() {
        return new ParticipantEntity(this);
    }

    public int getCapabilities() {
        return getInteger("capabilities");
    }

    public String getDisplayName() {
        return v("external_player_id") ? getString("default_display_name") : this.nZ.getDisplayName();
    }

    public void getDisplayName(CharArrayBuffer charArrayBuffer) {
        if (v("external_player_id")) {
            a("default_display_name", charArrayBuffer);
        } else {
            this.nZ.getDisplayName(charArrayBuffer);
        }
    }

    public Uri getHiResImageUri() {
        return v("external_player_id") ? null : this.nZ.getHiResImageUri();
    }

    public Uri getIconImageUri() {
        return v("external_player_id") ? u("default_display_image_uri") : this.nZ.getIconImageUri();
    }

    public String getParticipantId() {
        return getString("external_participant_id");
    }

    public Player getPlayer() {
        return v("external_player_id") ? null : this.nZ;
    }

    public int getStatus() {
        return getInteger("player_status");
    }

    public int hashCode() {
        return ParticipantEntity.a(this);
    }

    public boolean isConnectedToRoom() {
        return getInteger("connected") > 0;
    }

    public String toString() {
        return ParticipantEntity.b((Participant) this);
    }

    public void writeToParcel(Parcel parcel, int i) {
        ((ParticipantEntity) freeze()).writeToParcel(parcel, i);
    }
}
