package com.google.android.gms.appstate;

public interface OnSignOutCompleteListener {
    void onSignOutComplete();
}
