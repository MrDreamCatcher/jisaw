package com.google.android.gms.internal;

import android.app.Activity;
import android.content.Intent;
import android.os.IBinder;
import com.google.android.gms.dynamic.c;
import com.google.android.gms.dynamic.e;

public final class bm extends e<bo> {
    private static final bm gl = new bm();

    private static final class a extends Exception {
        public a(String str) {
            super(str);
        }
    }

    private bm() {
        super("com.google.android.gms.ads.AdOverlayCreatorImpl");
    }

    public static bn a(Activity activity) {
        try {
            if (!b(activity)) {
                return gl.c(activity);
            }
            cn.m("Using AdOverlay from the client jar.");
            return new bf(activity);
        } catch (a e) {
            cn.q(e.getMessage());
            return null;
        }
    }

    private static boolean b(Activity activity) throws a {
        Intent intent = activity.getIntent();
        if (intent.hasExtra("com.google.android.gms.ads.internal.overlay.useClientJar")) {
            return intent.getBooleanExtra("com.google.android.gms.ads.internal.overlay.useClientJar", false);
        }
        throw new a("Ad overlay requires the useClientJar flag in intent extras.");
    }

    private bn c(Activity activity) {
        try {
            return com.google.android.gms.internal.bn.a.m(((bo) t(activity)).a(c.g(activity)));
        } catch (Throwable e) {
            cn.b("Could not create remote AdOverlay.", e);
            return null;
        } catch (Throwable e2) {
            cn.b("Could not create remote AdOverlay.", e2);
            return null;
        }
    }

    protected /* synthetic */ Object d(IBinder iBinder) {
        return l(iBinder);
    }

    protected bo l(IBinder iBinder) {
        return com.google.android.gms.internal.bo.a.n(iBinder);
    }
}
