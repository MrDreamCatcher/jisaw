package com.google.android.gms.common.data;

import android.database.CharArrayBuffer;
import android.database.CursorIndexOutOfBoundsException;
import android.database.CursorWindow;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.util.Log;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;
import com.google.android.gms.internal.dm;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public final class d implements SafeParcelable {
    public static final e CREATOR = new e();
    private static final a ju = new a(new String[0], null) {
    };
    private final int iC;
    private final int iM;
    private final String[] jm;
    Bundle jn;
    private final CursorWindow[] jo;
    private final Bundle jp;
    int[] jq;
    int jr;
    private Object js;
    private boolean jt;
    boolean mClosed;

    public static class a {
        private final String[] jm;
        private final ArrayList<HashMap<String, Object>> jv;
        private final String jw;
        private final HashMap<Object, Integer> jx;
        private boolean jy;
        private String jz;

        private a(String[] strArr, String str) {
            this.jm = (String[]) dm.e(strArr);
            this.jv = new ArrayList();
            this.jw = str;
            this.jx = new HashMap();
            this.jy = false;
            this.jz = null;
        }
    }

    d(int i, String[] strArr, CursorWindow[] cursorWindowArr, int i2, Bundle bundle) {
        this.mClosed = false;
        this.jt = true;
        this.iM = i;
        this.jm = strArr;
        this.jo = cursorWindowArr;
        this.iC = i2;
        this.jp = bundle;
    }

    private d(a aVar, int i, Bundle bundle) {
        this(aVar.jm, a(aVar), i, bundle);
    }

    public d(String[] strArr, CursorWindow[] cursorWindowArr, int i, Bundle bundle) {
        this.mClosed = false;
        this.jt = true;
        this.iM = 1;
        this.jm = (String[]) dm.e(strArr);
        this.jo = (CursorWindow[]) dm.e(cursorWindowArr);
        this.iC = i;
        this.jp = bundle;
        aJ();
    }

    public static d a(int i, Bundle bundle) {
        return new d(ju, i, bundle);
    }

    private static CursorWindow[] a(a aVar) {
        int i;
        int i2 = 0;
        if (aVar.jm.length == 0) {
            return new CursorWindow[0];
        }
        ArrayList c = aVar.jv;
        int size = c.size();
        CursorWindow cursorWindow = new CursorWindow(false);
        ArrayList arrayList = new ArrayList();
        arrayList.add(cursorWindow);
        cursorWindow.setNumColumns(aVar.jm.length);
        int i3 = 0;
        int i4 = 0;
        while (i4 < size) {
            int i5;
            int i6;
            CursorWindow cursorWindow2;
            CursorWindow cursorWindow3;
            if (cursorWindow.allocRow()) {
                i5 = i3;
            } else {
                Log.d("DataHolder", "Allocating additional cursor window for large data set (row " + i4 + ")");
                cursorWindow = new CursorWindow(false);
                cursorWindow.setNumColumns(aVar.jm.length);
                arrayList.add(cursorWindow);
                if (cursorWindow.allocRow()) {
                    i5 = 0;
                } else {
                    Log.e("DataHolder", "Unable to allocate row to hold data.");
                    arrayList.remove(cursorWindow);
                    return (CursorWindow[]) arrayList.toArray(new CursorWindow[arrayList.size()]);
                }
            }
            Map map = (Map) c.get(i4);
            boolean z = true;
            for (int i7 = 0; i7 < aVar.jm.length && z; i7++) {
                String str = aVar.jm[i7];
                Object obj = map.get(str);
                if (obj == null) {
                    z = cursorWindow.putNull(i5, i7);
                } else if (obj instanceof String) {
                    z = cursorWindow.putString((String) obj, i5, i7);
                } else if (obj instanceof Long) {
                    z = cursorWindow.putLong(((Long) obj).longValue(), i5, i7);
                } else if (obj instanceof Integer) {
                    z = cursorWindow.putLong((long) ((Integer) obj).intValue(), i5, i7);
                } else if (obj instanceof Boolean) {
                    z = cursorWindow.putLong(((Boolean) obj).booleanValue() ? 1 : 0, i5, i7);
                } else if (obj instanceof byte[]) {
                    z = cursorWindow.putBlob((byte[]) obj, i5, i7);
                } else {
                    throw new IllegalArgumentException("Unsupported object for column " + str + ": " + obj);
                }
            }
            if (z) {
                i6 = i4;
                cursorWindow2 = cursorWindow;
                i = i5 + 1;
                cursorWindow3 = cursorWindow2;
            } else {
                try {
                    Log.d("DataHolder", "Couldn't populate window data for row " + i4 + " - allocating new window.");
                    cursorWindow.freeLastRow();
                    cursorWindow3 = new CursorWindow(false);
                    cursorWindow3.setNumColumns(aVar.jm.length);
                    arrayList.add(cursorWindow3);
                    i6 = i4 - 1;
                    i = 0;
                } catch (RuntimeException e) {
                    RuntimeException runtimeException = e;
                    i = arrayList.size();
                    while (i2 < i) {
                        ((CursorWindow) arrayList.get(i2)).close();
                        i2++;
                    }
                    throw runtimeException;
                }
            }
            i4 = i6 + 1;
            cursorWindow2 = cursorWindow3;
            i3 = i;
            cursorWindow = cursorWindow2;
        }
        return (CursorWindow[]) arrayList.toArray(new CursorWindow[arrayList.size()]);
    }

    private void b(String str, int i) {
        if (this.jn == null || !this.jn.containsKey(str)) {
            throw new IllegalArgumentException("No such column: " + str);
        } else if (isClosed()) {
            throw new IllegalArgumentException("Buffer is closed.");
        } else if (i < 0 || i >= this.jr) {
            throw new CursorIndexOutOfBoundsException(i, this.jr);
        }
    }

    public static d r(int i) {
        return a(i, null);
    }

    public long a(String str, int i, int i2) {
        b(str, i);
        return this.jo[i2].getLong(i - this.jq[i2], this.jn.getInt(str));
    }

    public void a(String str, int i, int i2, CharArrayBuffer charArrayBuffer) {
        b(str, i);
        this.jo[i2].copyStringToBuffer(i - this.jq[i2], this.jn.getInt(str), charArrayBuffer);
    }

    public void aJ() {
        int i;
        int i2 = 0;
        this.jn = new Bundle();
        for (i = 0; i < this.jm.length; i++) {
            this.jn.putInt(this.jm[i], i);
        }
        this.jq = new int[this.jo.length];
        for (i = 0; i < this.jo.length; i++) {
            this.jq[i] = i2;
            i2 += this.jo[i].getNumRows();
        }
        this.jr = i2;
    }

    String[] aK() {
        return this.jm;
    }

    CursorWindow[] aL() {
        return this.jo;
    }

    public Bundle aM() {
        return this.jp;
    }

    public int b(String str, int i, int i2) {
        b(str, i);
        return this.jo[i2].getInt(i - this.jq[i2], this.jn.getInt(str));
    }

    public void b(Object obj) {
        this.js = obj;
    }

    public String c(String str, int i, int i2) {
        b(str, i);
        return this.jo[i2].getString(i - this.jq[i2], this.jn.getInt(str));
    }

    public void close() {
        synchronized (this) {
            if (!this.mClosed) {
                this.mClosed = true;
                for (CursorWindow close : this.jo) {
                    close.close();
                }
            }
        }
    }

    public boolean d(String str, int i, int i2) {
        b(str, i);
        return Long.valueOf(this.jo[i2].getLong(i - this.jq[i2], this.jn.getInt(str))).longValue() == 1;
    }

    public int describeContents() {
        return 0;
    }

    public byte[] e(String str, int i, int i2) {
        b(str, i);
        return this.jo[i2].getBlob(i - this.jq[i2], this.jn.getInt(str));
    }

    public Uri f(String str, int i, int i2) {
        String c = c(str, i, i2);
        return c == null ? null : Uri.parse(c);
    }

    protected void finalize() throws Throwable {
        try {
            if (this.jt && this.jo.length > 0 && !isClosed()) {
                Log.e("DataHolder", "Internal data leak within a DataBuffer object detected!  Be sure to explicitly call close() on all DataBuffer extending objects when you are done with them. (" + (this.js == null ? "internal object: " + toString() : this.js.toString()) + ")");
                close();
            }
            super.finalize();
        } catch (Throwable th) {
            super.finalize();
        }
    }

    public boolean g(String str, int i, int i2) {
        b(str, i);
        return this.jo[i2].isNull(i - this.jq[i2], this.jn.getInt(str));
    }

    public int getCount() {
        return this.jr;
    }

    public int getStatusCode() {
        return this.iC;
    }

    int getVersionCode() {
        return this.iM;
    }

    public boolean isClosed() {
        boolean z;
        synchronized (this) {
            z = this.mClosed;
        }
        return z;
    }

    public int q(int i) {
        int i2 = 0;
        boolean z = i >= 0 && i < this.jr;
        dm.k(z);
        while (i2 < this.jq.length) {
            if (i < this.jq[i2]) {
                i2--;
                break;
            }
            i2++;
        }
        return i2 == this.jq.length ? i2 - 1 : i2;
    }

    public void writeToParcel(Parcel parcel, int i) {
        e.a(this, parcel, i);
    }
}
