package com.google.android.gms.internal;

import com.google.ads.AdRequest.ErrorCode;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.mediation.MediationBannerListener;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.ads.mediation.MediationInterstitialListener;
import com.google.ads.mediation.MediationServerParameters;
import com.google.ads.mediation.NetworkExtras;

public final class ba<NETWORK_EXTRAS extends NetworkExtras, SERVER_PARAMETERS extends MediationServerParameters> implements MediationBannerListener, MediationInterstitialListener {
    private final ay ft;

    public ba(ay ayVar) {
        this.ft = ayVar;
    }

    public void onClick(MediationBannerAdapter<?, ?> mediationBannerAdapter) {
        cn.m("Adapter called onClick.");
        if (cm.ar()) {
            try {
                this.ft.y();
                return;
            } catch (Throwable e) {
                cn.b("Could not call onAdClicked.", e);
                return;
            }
        }
        cn.q("onClick must be called on the main UI thread.");
        cm.hO.post(new Runnable(this) {
            final /* synthetic */ ba fu;

            {
                this.fu = r1;
            }

            public void run() {
                try {
                    this.fu.ft.y();
                } catch (Throwable e) {
                    cn.b("Could not call onAdClicked.", e);
                }
            }
        });
    }

    public void onDismissScreen(MediationBannerAdapter<?, ?> mediationBannerAdapter) {
        cn.m("Adapter called onDismissScreen.");
        if (cm.ar()) {
            try {
                this.ft.onAdClosed();
                return;
            } catch (Throwable e) {
                cn.b("Could not call onAdClosed.", e);
                return;
            }
        }
        cn.q("onDismissScreen must be called on the main UI thread.");
        cm.hO.post(new Runnable(this) {
            final /* synthetic */ ba fu;

            {
                this.fu = r1;
            }

            public void run() {
                try {
                    this.fu.ft.onAdClosed();
                } catch (Throwable e) {
                    cn.b("Could not call onAdClosed.", e);
                }
            }
        });
    }

    public void onDismissScreen(MediationInterstitialAdapter<?, ?> mediationInterstitialAdapter) {
        cn.m("Adapter called onDismissScreen.");
        if (cm.ar()) {
            try {
                this.ft.onAdClosed();
                return;
            } catch (Throwable e) {
                cn.b("Could not call onAdClosed.", e);
                return;
            }
        }
        cn.q("onDismissScreen must be called on the main UI thread.");
        cm.hO.post(new Runnable(this) {
            final /* synthetic */ ba fu;

            {
                this.fu = r1;
            }

            public void run() {
                try {
                    this.fu.ft.onAdClosed();
                } catch (Throwable e) {
                    cn.b("Could not call onAdClosed.", e);
                }
            }
        });
    }

    public void onFailedToReceiveAd(MediationBannerAdapter<?, ?> mediationBannerAdapter, final ErrorCode errorCode) {
        cn.m("Adapter called onFailedToReceiveAd with error. " + errorCode);
        if (cm.ar()) {
            try {
                this.ft.onAdFailedToLoad(bb.a(errorCode));
                return;
            } catch (Throwable e) {
                cn.b("Could not call onAdFailedToLoad.", e);
                return;
            }
        }
        cn.q("onFailedToReceiveAd must be called on the main UI thread.");
        cm.hO.post(new Runnable(this) {
            final /* synthetic */ ba fu;

            public void run() {
                try {
                    this.fu.ft.onAdFailedToLoad(bb.a(errorCode));
                } catch (Throwable e) {
                    cn.b("Could not call onAdFailedToLoad.", e);
                }
            }
        });
    }

    public void onFailedToReceiveAd(MediationInterstitialAdapter<?, ?> mediationInterstitialAdapter, final ErrorCode errorCode) {
        cn.m("Adapter called onFailedToReceiveAd with error " + errorCode + ".");
        if (cm.ar()) {
            try {
                this.ft.onAdFailedToLoad(bb.a(errorCode));
                return;
            } catch (Throwable e) {
                cn.b("Could not call onAdFailedToLoad.", e);
                return;
            }
        }
        cn.q("onFailedToReceiveAd must be called on the main UI thread.");
        cm.hO.post(new Runnable(this) {
            final /* synthetic */ ba fu;

            public void run() {
                try {
                    this.fu.ft.onAdFailedToLoad(bb.a(errorCode));
                } catch (Throwable e) {
                    cn.b("Could not call onAdFailedToLoad.", e);
                }
            }
        });
    }

    public void onLeaveApplication(MediationBannerAdapter<?, ?> mediationBannerAdapter) {
        cn.m("Adapter called onLeaveApplication.");
        if (cm.ar()) {
            try {
                this.ft.onAdLeftApplication();
                return;
            } catch (Throwable e) {
                cn.b("Could not call onAdLeftApplication.", e);
                return;
            }
        }
        cn.q("onLeaveApplication must be called on the main UI thread.");
        cm.hO.post(new Runnable(this) {
            final /* synthetic */ ba fu;

            {
                this.fu = r1;
            }

            public void run() {
                try {
                    this.fu.ft.onAdLeftApplication();
                } catch (Throwable e) {
                    cn.b("Could not call onAdLeftApplication.", e);
                }
            }
        });
    }

    public void onLeaveApplication(MediationInterstitialAdapter<?, ?> mediationInterstitialAdapter) {
        cn.m("Adapter called onLeaveApplication.");
        if (cm.ar()) {
            try {
                this.ft.onAdLeftApplication();
                return;
            } catch (Throwable e) {
                cn.b("Could not call onAdLeftApplication.", e);
                return;
            }
        }
        cn.q("onLeaveApplication must be called on the main UI thread.");
        cm.hO.post(new Runnable(this) {
            final /* synthetic */ ba fu;

            {
                this.fu = r1;
            }

            public void run() {
                try {
                    this.fu.ft.onAdLeftApplication();
                } catch (Throwable e) {
                    cn.b("Could not call onAdLeftApplication.", e);
                }
            }
        });
    }

    public void onPresentScreen(MediationBannerAdapter<?, ?> mediationBannerAdapter) {
        cn.m("Adapter called onPresentScreen.");
        if (cm.ar()) {
            try {
                this.ft.onAdOpened();
                return;
            } catch (Throwable e) {
                cn.b("Could not call onAdOpened.", e);
                return;
            }
        }
        cn.q("onPresentScreen must be called on the main UI thread.");
        cm.hO.post(new Runnable(this) {
            final /* synthetic */ ba fu;

            {
                this.fu = r1;
            }

            public void run() {
                try {
                    this.fu.ft.onAdOpened();
                } catch (Throwable e) {
                    cn.b("Could not call onAdOpened.", e);
                }
            }
        });
    }

    public void onPresentScreen(MediationInterstitialAdapter<?, ?> mediationInterstitialAdapter) {
        cn.m("Adapter called onPresentScreen.");
        if (cm.ar()) {
            try {
                this.ft.onAdOpened();
                return;
            } catch (Throwable e) {
                cn.b("Could not call onAdOpened.", e);
                return;
            }
        }
        cn.q("onPresentScreen must be called on the main UI thread.");
        cm.hO.post(new Runnable(this) {
            final /* synthetic */ ba fu;

            {
                this.fu = r1;
            }

            public void run() {
                try {
                    this.fu.ft.onAdOpened();
                } catch (Throwable e) {
                    cn.b("Could not call onAdOpened.", e);
                }
            }
        });
    }

    public void onReceivedAd(MediationBannerAdapter<?, ?> mediationBannerAdapter) {
        cn.m("Adapter called onReceivedAd.");
        if (cm.ar()) {
            try {
                this.ft.onAdLoaded();
                return;
            } catch (Throwable e) {
                cn.b("Could not call onAdLoaded.", e);
                return;
            }
        }
        cn.q("onReceivedAd must be called on the main UI thread.");
        cm.hO.post(new Runnable(this) {
            final /* synthetic */ ba fu;

            {
                this.fu = r1;
            }

            public void run() {
                try {
                    this.fu.ft.onAdLoaded();
                } catch (Throwable e) {
                    cn.b("Could not call onAdLoaded.", e);
                }
            }
        });
    }

    public void onReceivedAd(MediationInterstitialAdapter<?, ?> mediationInterstitialAdapter) {
        cn.m("Adapter called onReceivedAd.");
        if (cm.ar()) {
            try {
                this.ft.onAdLoaded();
                return;
            } catch (Throwable e) {
                cn.b("Could not call onAdLoaded.", e);
                return;
            }
        }
        cn.q("onReceivedAd must be called on the main UI thread.");
        cm.hO.post(new Runnable(this) {
            final /* synthetic */ ba fu;

            {
                this.fu = r1;
            }

            public void run() {
                try {
                    this.fu.ft.onAdLoaded();
                } catch (Throwable e) {
                    cn.b("Could not call onAdLoaded.", e);
                }
            }
        });
    }
}
