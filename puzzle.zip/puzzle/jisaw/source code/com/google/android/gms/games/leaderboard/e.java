package com.google.android.gms.games.leaderboard;

import com.google.android.gms.common.data.b;
import com.google.android.gms.common.data.d;
import com.google.android.gms.internal.dl;
import com.google.android.gms.internal.eu;
import com.google.android.gms.internal.ev;

public final class e extends b implements LeaderboardVariant {
    e(d dVar, int i) {
        super(dVar, i);
    }

    public String ce() {
        return getString("top_page_token_next");
    }

    public String cf() {
        return getString("window_page_token_prev");
    }

    public String cg() {
        return getString("window_page_token_next");
    }

    public int getCollection() {
        return getInteger("collection");
    }

    public String getDisplayPlayerRank() {
        return getString("player_display_rank");
    }

    public String getDisplayPlayerScore() {
        return getString("player_display_score");
    }

    public long getNumScores() {
        return v("total_scores") ? -1 : getLong("total_scores");
    }

    public long getPlayerRank() {
        return v("player_rank") ? -1 : getLong("player_rank");
    }

    public String getPlayerScoreTag() {
        return getString("player_score_tag");
    }

    public long getRawPlayerScore() {
        return v("player_raw_score") ? -1 : getLong("player_raw_score");
    }

    public int getTimeSpan() {
        return getInteger("timespan");
    }

    public boolean hasPlayerInfo() {
        return !v("player_raw_score");
    }

    public String toString() {
        return dl.d(this).a("TimeSpan", ev.R(getTimeSpan())).a("Collection", eu.R(getCollection())).a("RawPlayerScore", hasPlayerInfo() ? Long.valueOf(getRawPlayerScore()) : "none").a("DisplayPlayerScore", hasPlayerInfo() ? getDisplayPlayerScore() : "none").a("PlayerRank", hasPlayerInfo() ? Long.valueOf(getPlayerRank()) : "none").a("DisplayPlayerRank", hasPlayerInfo() ? getDisplayPlayerRank() : "none").a("NumScores", Long.valueOf(getNumScores())).a("TopPageNextToken", ce()).a("WindowPageNextToken", cg()).a("WindowPagePrevToken", cf()).toString();
    }
}
