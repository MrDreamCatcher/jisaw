package com.google.android.gms.games.leaderboard;

import android.os.Bundle;

public final class b {
    private final Bundle nw;

    public b(Bundle bundle) {
        if (bundle == null) {
            bundle = new Bundle();
        }
        this.nw = bundle;
    }

    public Bundle cc() {
        return this.nw;
    }
}
