package com.google.android.gms.common.data;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class c<T extends SafeParcelable> extends DataBuffer<T> {
    private static final String[] jk = new String[]{"data"};
    private final Creator<T> jl;

    public c(d dVar, Creator<T> creator) {
        super(dVar);
        this.jl = creator;
    }

    public /* synthetic */ Object get(int i) {
        return p(i);
    }

    public T p(int i) {
        byte[] e = this.jf.e("data", i, 0);
        Parcel obtain = Parcel.obtain();
        obtain.unmarshall(e, 0, e.length);
        obtain.setDataPosition(0);
        SafeParcelable safeParcelable = (SafeParcelable) this.jl.createFromParcel(obtain);
        obtain.recycle();
        return safeParcelable;
    }
}
