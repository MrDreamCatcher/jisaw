package com.google.android.gms.games.multiplayer.realtime;

public interface RealTimeReliableMessageSentListener {
    void onRealTimeMessageSent(int i, int i2, String str);
}
