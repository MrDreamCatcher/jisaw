package com.google.android.gms.games;

import com.google.android.gms.common.data.DataBuffer;
import com.google.android.gms.common.data.d;

public final class PlayerBuffer extends DataBuffer<Player> {
    public PlayerBuffer(d dVar) {
        super(dVar);
    }

    public Player get(int i) {
        return new d(this.jf, i);
    }
}
