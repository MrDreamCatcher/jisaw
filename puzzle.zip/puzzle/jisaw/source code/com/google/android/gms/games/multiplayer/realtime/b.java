package com.google.android.gms.games.multiplayer.realtime;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.games.multiplayer.ParticipantEntity;
import com.google.android.gms.location.LocationStatusCodes;
import java.util.ArrayList;

public class b implements Creator<RoomEntity> {
    static void a(RoomEntity roomEntity, Parcel parcel, int i) {
        int k = com.google.android.gms.common.internal.safeparcel.b.k(parcel);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 1, roomEntity.getRoomId(), false);
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, LocationStatusCodes.GEOFENCE_NOT_AVAILABLE, roomEntity.getVersionCode());
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 2, roomEntity.getCreatorId(), false);
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 3, roomEntity.getCreationTimestamp());
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 4, roomEntity.getStatus());
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 5, roomEntity.getDescription(), false);
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 6, roomEntity.getVariant());
        com.google.android.gms.common.internal.safeparcel.b.a(parcel, 7, roomEntity.getAutoMatchCriteria(), false);
        com.google.android.gms.common.internal.safeparcel.b.b(parcel, 8, roomEntity.getParticipants(), false);
        com.google.android.gms.common.internal.safeparcel.b.c(parcel, 9, roomEntity.getAutoMatchWaitEstimateSeconds());
        com.google.android.gms.common.internal.safeparcel.b.C(parcel, k);
    }

    public RoomEntity[] V(int i) {
        return new RoomEntity[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return y(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return V(i);
    }

    public RoomEntity y(Parcel parcel) {
        int i = 0;
        String str = null;
        int j = a.j(parcel);
        long j2 = 0;
        String str2 = null;
        String str3 = null;
        Bundle bundle = null;
        ArrayList arrayList = null;
        int i2 = 0;
        int i3 = 0;
        int i4 = 0;
        while (parcel.dataPosition() < j) {
            int i5 = a.i(parcel);
            switch (a.y(i5)) {
                case 1:
                    str = a.l(parcel, i5);
                    break;
                case 2:
                    str2 = a.l(parcel, i5);
                    break;
                case 3:
                    j2 = a.g(parcel, i5);
                    break;
                case 4:
                    i2 = a.f(parcel, i5);
                    break;
                case 5:
                    str3 = a.l(parcel, i5);
                    break;
                case 6:
                    i3 = a.f(parcel, i5);
                    break;
                case 7:
                    bundle = a.n(parcel, i5);
                    break;
                case 8:
                    arrayList = a.c(parcel, i5, ParticipantEntity.CREATOR);
                    break;
                case 9:
                    i4 = a.f(parcel, i5);
                    break;
                case LocationStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i = a.f(parcel, i5);
                    break;
                default:
                    a.b(parcel, i5);
                    break;
            }
        }
        if (parcel.dataPosition() == j) {
            return new RoomEntity(i, str, str2, j2, i2, str3, i3, bundle, arrayList, i4);
        }
        throw new a.a("Overread allowed size end=" + j, parcel);
    }
}
