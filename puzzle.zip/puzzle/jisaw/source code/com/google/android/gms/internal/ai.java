package com.google.android.gms.internal;

import java.util.Map;

public interface ai {
    void a(cq cqVar, Map<String, String> map);
}
