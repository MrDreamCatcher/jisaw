package com.google.android.gms.appstate;

import com.google.android.gms.common.data.DataBuffer;
import com.google.android.gms.common.data.d;

public final class AppStateBuffer extends DataBuffer<AppState> {
    public AppStateBuffer(d dVar) {
        super(dVar);
    }

    public AppState get(int i) {
        return new b(this.jf, i);
    }
}
