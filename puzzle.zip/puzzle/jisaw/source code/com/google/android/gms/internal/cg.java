package com.google.android.gms.internal;

public abstract class cg {
    private final Runnable el = new Runnable(this) {
        final /* synthetic */ cg hE;

        {
            this.hE = r1;
        }

        public final void run() {
            this.hE.hD = Thread.currentThread();
            this.hE.ac();
        }
    };
    private volatile Thread hD;

    public abstract void ac();

    public final void cancel() {
        onStop();
        if (this.hD != null) {
            this.hD.interrupt();
        }
    }

    public abstract void onStop();

    public final void start() {
        ch.execute(this.el);
    }
}
