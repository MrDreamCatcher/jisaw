package com.google.android.gms.internal;

import android.app.Activity;
import android.os.RemoteException;
import com.google.ads.mediation.MediationAdapter;
import com.google.ads.mediation.MediationBannerAdapter;
import com.google.ads.mediation.MediationInterstitialAdapter;
import com.google.ads.mediation.MediationServerParameters;
import com.google.ads.mediation.NetworkExtras;
import com.google.ads.mediation.admob.AdMobServerParameters;
import com.google.android.gms.dynamic.b;
import com.google.android.gms.dynamic.c;
import com.google.android.gms.internal.ax.a;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONObject;

public final class az<NETWORK_EXTRAS extends NetworkExtras, SERVER_PARAMETERS extends MediationServerParameters> extends a {
    private final MediationAdapter<NETWORK_EXTRAS, SERVER_PARAMETERS> fr;
    private final NETWORK_EXTRAS fs;

    public az(MediationAdapter<NETWORK_EXTRAS, SERVER_PARAMETERS> mediationAdapter, NETWORK_EXTRAS network_extras) {
        this.fr = mediationAdapter;
        this.fs = network_extras;
    }

    private SERVER_PARAMETERS a(String str, int i) throws RemoteException {
        Map hashMap;
        SERVER_PARAMETERS server_parameters;
        if (str != null) {
            try {
                JSONObject jSONObject = new JSONObject(str);
                hashMap = new HashMap(jSONObject.length());
                Iterator keys = jSONObject.keys();
                while (keys.hasNext()) {
                    String str2 = (String) keys.next();
                    hashMap.put(str2, jSONObject.getString(str2));
                }
            } catch (Throwable th) {
                cn.b("Could not get MediationServerParameters.", th);
                RemoteException remoteException = new RemoteException();
            }
        } else {
            hashMap = new HashMap(0);
        }
        Class serverParametersType = this.fr.getServerParametersType();
        if (serverParametersType != null) {
            SERVER_PARAMETERS server_parameters2 = (MediationServerParameters) serverParametersType.newInstance();
            server_parameters2.load(hashMap);
            server_parameters = server_parameters2;
        } else {
            server_parameters = null;
        }
        if (server_parameters instanceof AdMobServerParameters) {
            ((AdMobServerParameters) server_parameters).tagForChildDirectedTreatment = i;
        }
        return server_parameters;
    }

    public void a(b bVar, v vVar, String str, ay ayVar) throws RemoteException {
        if (this.fr instanceof MediationInterstitialAdapter) {
            cn.m("Requesting interstitial ad from adapter.");
            try {
                ((MediationInterstitialAdapter) this.fr).requestInterstitialAd(new ba(ayVar), (Activity) c.b(bVar), a(str, vVar.tagForChildDirectedTreatment), bb.e(vVar), this.fs);
            } catch (Throwable th) {
                cn.b("Could not request interstitial ad from adapter.", th);
                RemoteException remoteException = new RemoteException();
            }
        } else {
            cn.q("MediationAdapter is not a MediationInterstitialAdapter: " + this.fr.getClass().getCanonicalName());
            throw new RemoteException();
        }
    }

    public void a(b bVar, x xVar, v vVar, String str, ay ayVar) throws RemoteException {
        if (this.fr instanceof MediationBannerAdapter) {
            cn.m("Requesting banner ad from adapter.");
            try {
                ((MediationBannerAdapter) this.fr).requestBannerAd(new ba(ayVar), (Activity) c.b(bVar), a(str, vVar.tagForChildDirectedTreatment), bb.a(xVar), bb.e(vVar), this.fs);
            } catch (Throwable th) {
                cn.b("Could not request banner ad from adapter.", th);
                RemoteException remoteException = new RemoteException();
            }
        } else {
            cn.q("MediationAdapter is not a MediationBannerAdapter: " + this.fr.getClass().getCanonicalName());
            throw new RemoteException();
        }
    }

    public void destroy() throws RemoteException {
        try {
            this.fr.destroy();
        } catch (Throwable th) {
            cn.b("Could not destroy adapter.", th);
            RemoteException remoteException = new RemoteException();
        }
    }

    public b getView() throws RemoteException {
        if (this.fr instanceof MediationBannerAdapter) {
            try {
                return c.g(((MediationBannerAdapter) this.fr).getBannerView());
            } catch (Throwable th) {
                cn.b("Could not get banner view from adapter.", th);
                RemoteException remoteException = new RemoteException();
            }
        } else {
            cn.q("MediationAdapter is not a MediationBannerAdapter: " + this.fr.getClass().getCanonicalName());
            throw new RemoteException();
        }
    }

    public void showInterstitial() throws RemoteException {
        if (this.fr instanceof MediationInterstitialAdapter) {
            cn.m("Showing interstitial from adapter.");
            try {
                ((MediationInterstitialAdapter) this.fr).showInterstitial();
            } catch (Throwable th) {
                cn.b("Could not show interstitial from adapter.", th);
                RemoteException remoteException = new RemoteException();
            }
        } else {
            cn.q("MediationAdapter is not a MediationInterstitialAdapter: " + this.fr.getClass().getCanonicalName());
            throw new RemoteException();
        }
    }
}
