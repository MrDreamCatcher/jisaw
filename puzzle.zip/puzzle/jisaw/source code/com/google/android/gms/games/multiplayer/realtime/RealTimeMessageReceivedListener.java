package com.google.android.gms.games.multiplayer.realtime;

public interface RealTimeMessageReceivedListener {
    void onRealTimeMessageReceived(RealTimeMessage realTimeMessage);
}
