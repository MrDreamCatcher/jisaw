package com.google.android.gms.auth;

import android.app.PendingIntent;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.SafeParcelable;

public class RecoveryDecision implements SafeParcelable {
    public static final RecoveryDecisionCreator CREATOR = new RecoveryDecisionCreator();
    final int iM;
    public boolean isRecoveryInfoNeeded;
    public boolean isRecoveryInterstitialAllowed;
    public PendingIntent recoveryIntent;
    public PendingIntent recoveryIntentWithoutIntro;
    public boolean showRecoveryInterstitial;

    public RecoveryDecision() {
        this.iM = 1;
    }

    RecoveryDecision(int i, PendingIntent pendingIntent, boolean z, boolean z2, boolean z3, PendingIntent pendingIntent2) {
        this.iM = i;
        this.recoveryIntent = pendingIntent;
        this.showRecoveryInterstitial = z;
        this.isRecoveryInfoNeeded = z2;
        this.isRecoveryInterstitialAllowed = z3;
        this.recoveryIntentWithoutIntro = pendingIntent2;
    }

    public int describeContents() {
        return 0;
    }

    public int getVersionCode() {
        return this.iM;
    }

    public void writeToParcel(Parcel parcel, int i) {
        RecoveryDecisionCreator.a(this, parcel, i);
    }
}
