package com.google.android.gms.games.leaderboard;

import com.google.android.gms.common.data.DataBuffer;
import com.google.android.gms.common.data.d;

public final class LeaderboardScoreBuffer extends DataBuffer<LeaderboardScore> {
    private final b nv;

    public LeaderboardScoreBuffer(d dVar) {
        super(dVar);
        this.nv = new b(dVar.aM());
    }

    public b cb() {
        return this.nv;
    }

    public LeaderboardScore get(int i) {
        return new d(this.jf, i);
    }
}
