package com.google.android.gms.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class bg implements Creator<bh> {
    static void a(bh bhVar, Parcel parcel, int i) {
        int k = b.k(parcel);
        b.c(parcel, 1, bhVar.versionCode);
        b.a(parcel, 2, bhVar.fR, i, false);
        b.a(parcel, 3, bhVar.U(), false);
        b.a(parcel, 4, bhVar.V(), false);
        b.a(parcel, 5, bhVar.W(), false);
        b.a(parcel, 6, bhVar.X(), false);
        b.a(parcel, 7, bhVar.fW, false);
        b.a(parcel, 8, bhVar.fX);
        b.a(parcel, 9, bhVar.fY, false);
        b.a(parcel, 10, bhVar.Y(), false);
        b.c(parcel, 11, bhVar.orientation);
        b.c(parcel, 12, bhVar.ga);
        b.a(parcel, 13, bhVar.fz, false);
        b.a(parcel, 14, bhVar.eg, i, false);
        b.C(parcel, k);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return d(parcel);
    }

    public bh d(Parcel parcel) {
        int j = a.j(parcel);
        int i = 0;
        be beVar = null;
        IBinder iBinder = null;
        IBinder iBinder2 = null;
        IBinder iBinder3 = null;
        IBinder iBinder4 = null;
        String str = null;
        boolean z = false;
        String str2 = null;
        IBinder iBinder5 = null;
        int i2 = 0;
        int i3 = 0;
        String str3 = null;
        co coVar = null;
        while (parcel.dataPosition() < j) {
            int i4 = a.i(parcel);
            switch (a.y(i4)) {
                case 1:
                    i = a.f(parcel, i4);
                    break;
                case 2:
                    beVar = (be) a.a(parcel, i4, be.CREATOR);
                    break;
                case 3:
                    iBinder = a.m(parcel, i4);
                    break;
                case 4:
                    iBinder2 = a.m(parcel, i4);
                    break;
                case 5:
                    iBinder3 = a.m(parcel, i4);
                    break;
                case 6:
                    iBinder4 = a.m(parcel, i4);
                    break;
                case 7:
                    str = a.l(parcel, i4);
                    break;
                case 8:
                    z = a.c(parcel, i4);
                    break;
                case 9:
                    str2 = a.l(parcel, i4);
                    break;
                case 10:
                    iBinder5 = a.m(parcel, i4);
                    break;
                case 11:
                    i2 = a.f(parcel, i4);
                    break;
                case 12:
                    i3 = a.f(parcel, i4);
                    break;
                case 13:
                    str3 = a.l(parcel, i4);
                    break;
                case 14:
                    coVar = (co) a.a(parcel, i4, co.CREATOR);
                    break;
                default:
                    a.b(parcel, i4);
                    break;
            }
        }
        if (parcel.dataPosition() == j) {
            return new bh(i, beVar, iBinder, iBinder2, iBinder3, iBinder4, str, z, str2, iBinder5, i2, i3, str3, coVar);
        }
        throw new a.a("Overread allowed size end=" + j, parcel);
    }

    public bh[] h(int i) {
        return new bh[i];
    }

    public /* synthetic */ Object[] newArray(int i) {
        return h(i);
    }
}
