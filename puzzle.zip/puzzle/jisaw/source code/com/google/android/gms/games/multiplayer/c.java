package com.google.android.gms.games.multiplayer;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;
import com.google.android.gms.games.PlayerEntity;
import com.google.android.gms.location.LocationStatusCodes;

public class c implements Creator<ParticipantEntity> {
    static void a(ParticipantEntity participantEntity, Parcel parcel, int i) {
        int k = b.k(parcel);
        b.a(parcel, 1, participantEntity.getParticipantId(), false);
        b.c(parcel, LocationStatusCodes.GEOFENCE_NOT_AVAILABLE, participantEntity.getVersionCode());
        b.a(parcel, 2, participantEntity.getDisplayName(), false);
        b.a(parcel, 3, participantEntity.getIconImageUri(), i, false);
        b.a(parcel, 4, participantEntity.getHiResImageUri(), i, false);
        b.c(parcel, 5, participantEntity.getStatus());
        b.a(parcel, 6, participantEntity.ci(), false);
        b.a(parcel, 7, participantEntity.isConnectedToRoom());
        b.a(parcel, 8, participantEntity.getPlayer(), i, false);
        b.c(parcel, 9, participantEntity.getCapabilities());
        b.C(parcel, k);
    }

    public ParticipantEntity[] T(int i) {
        return new ParticipantEntity[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return w(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return T(i);
    }

    public ParticipantEntity w(Parcel parcel) {
        boolean z = false;
        String str = null;
        int j = a.j(parcel);
        String str2 = null;
        Uri uri = null;
        Uri uri2 = null;
        String str3 = null;
        PlayerEntity playerEntity = null;
        int i = 0;
        int i2 = 0;
        int i3 = 0;
        while (parcel.dataPosition() < j) {
            int i4 = a.i(parcel);
            switch (a.y(i4)) {
                case 1:
                    str = a.l(parcel, i4);
                    break;
                case 2:
                    str2 = a.l(parcel, i4);
                    break;
                case 3:
                    uri = (Uri) a.a(parcel, i4, Uri.CREATOR);
                    break;
                case 4:
                    uri2 = (Uri) a.a(parcel, i4, Uri.CREATOR);
                    break;
                case 5:
                    i2 = a.f(parcel, i4);
                    break;
                case 6:
                    str3 = a.l(parcel, i4);
                    break;
                case 7:
                    z = a.c(parcel, i4);
                    break;
                case 8:
                    playerEntity = (PlayerEntity) a.a(parcel, i4, PlayerEntity.CREATOR);
                    break;
                case 9:
                    i3 = a.f(parcel, i4);
                    break;
                case LocationStatusCodes.GEOFENCE_NOT_AVAILABLE /*1000*/:
                    i = a.f(parcel, i4);
                    break;
                default:
                    a.b(parcel, i4);
                    break;
            }
        }
        if (parcel.dataPosition() == j) {
            return new ParticipantEntity(i, str, str2, uri, uri2, i2, str3, z, playerEntity, i3);
        }
        throw new a.a("Overread allowed size end=" + j, parcel);
    }
}
