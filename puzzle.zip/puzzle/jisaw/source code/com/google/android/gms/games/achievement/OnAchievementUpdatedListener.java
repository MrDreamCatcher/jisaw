package com.google.android.gms.games.achievement;

public interface OnAchievementUpdatedListener {
    void onAchievementUpdated(int i, String str);
}
