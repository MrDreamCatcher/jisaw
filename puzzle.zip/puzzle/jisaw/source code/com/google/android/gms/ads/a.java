package com.google.android.gms.ads;

public interface a {
    void a(String str, String str2);
}
