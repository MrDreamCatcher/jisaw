package com.google.android.gms.games;

public interface OnSignOutCompleteListener {
    void onSignOutComplete();
}
