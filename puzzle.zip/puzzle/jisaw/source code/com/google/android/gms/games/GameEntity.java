package com.google.android.gms.games;

import android.database.CharArrayBuffer;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.internal.dd;
import com.google.android.gms.internal.dl;
import com.google.android.gms.internal.eg;
import com.google.android.gms.internal.en;

public final class GameEntity extends en implements Game {
    public static final Creator<GameEntity> CREATOR = new a();
    private final int iM;
    private final String mk;
    private final String ml;
    private final String mm;
    private final String mn;
    private final String mo;
    private final String mp;
    private final Uri mq;
    private final Uri mr;
    private final Uri ms;
    private final boolean mt;
    private final boolean mu;
    private final String mv;
    private final int mw;
    private final int mx;
    private final int my;

    static final class a extends a {
        a() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return t(parcel);
        }

        public GameEntity t(Parcel parcel) {
            if (en.c(dd.aW()) || dd.y(GameEntity.class.getCanonicalName())) {
                return super.t(parcel);
            }
            String readString = parcel.readString();
            String readString2 = parcel.readString();
            String readString3 = parcel.readString();
            String readString4 = parcel.readString();
            String readString5 = parcel.readString();
            String readString6 = parcel.readString();
            String readString7 = parcel.readString();
            Uri parse = readString7 == null ? null : Uri.parse(readString7);
            readString7 = parcel.readString();
            Uri parse2 = readString7 == null ? null : Uri.parse(readString7);
            readString7 = parcel.readString();
            return new GameEntity(1, readString, readString2, readString3, readString4, readString5, readString6, parse, parse2, readString7 == null ? null : Uri.parse(readString7), parcel.readInt() > 0, parcel.readInt() > 0, parcel.readString(), parcel.readInt(), parcel.readInt(), parcel.readInt());
        }
    }

    GameEntity(int i, String str, String str2, String str3, String str4, String str5, String str6, Uri uri, Uri uri2, Uri uri3, boolean z, boolean z2, String str7, int i2, int i3, int i4) {
        this.iM = i;
        this.mk = str;
        this.ml = str2;
        this.mm = str3;
        this.mn = str4;
        this.mo = str5;
        this.mp = str6;
        this.mq = uri;
        this.mr = uri2;
        this.ms = uri3;
        this.mt = z;
        this.mu = z2;
        this.mv = str7;
        this.mw = i2;
        this.mx = i3;
        this.my = i4;
    }

    public GameEntity(Game game) {
        this.iM = 1;
        this.mk = game.getApplicationId();
        this.mm = game.getPrimaryCategory();
        this.mn = game.getSecondaryCategory();
        this.mo = game.getDescription();
        this.mp = game.getDeveloperName();
        this.ml = game.getDisplayName();
        this.mq = game.getIconImageUri();
        this.mr = game.getHiResImageUri();
        this.ms = game.getFeaturedImageUri();
        this.mt = game.isPlayEnabledGame();
        this.mu = game.isInstanceInstalled();
        this.mv = game.getInstancePackageName();
        this.mw = game.getGameplayAclStatus();
        this.mx = game.getAchievementTotalCount();
        this.my = game.getLeaderboardCount();
    }

    static int a(Game game) {
        return dl.hashCode(game.getApplicationId(), game.getDisplayName(), game.getPrimaryCategory(), game.getSecondaryCategory(), game.getDescription(), game.getDeveloperName(), game.getIconImageUri(), game.getHiResImageUri(), game.getFeaturedImageUri(), Boolean.valueOf(game.isPlayEnabledGame()), Boolean.valueOf(game.isInstanceInstalled()), game.getInstancePackageName(), Integer.valueOf(game.getGameplayAclStatus()), Integer.valueOf(game.getAchievementTotalCount()), Integer.valueOf(game.getLeaderboardCount()));
    }

    static boolean a(Game game, Object obj) {
        if (!(obj instanceof Game)) {
            return false;
        }
        if (game != obj) {
            Game game2 = (Game) obj;
            if (!(dl.equal(game2.getApplicationId(), game.getApplicationId()) && dl.equal(game2.getDisplayName(), game.getDisplayName()) && dl.equal(game2.getPrimaryCategory(), game.getPrimaryCategory()) && dl.equal(game2.getSecondaryCategory(), game.getSecondaryCategory()) && dl.equal(game2.getDescription(), game.getDescription()) && dl.equal(game2.getDeveloperName(), game.getDeveloperName()) && dl.equal(game2.getIconImageUri(), game.getIconImageUri()) && dl.equal(game2.getHiResImageUri(), game.getHiResImageUri()) && dl.equal(game2.getFeaturedImageUri(), game.getFeaturedImageUri()) && dl.equal(Boolean.valueOf(game2.isPlayEnabledGame()), Boolean.valueOf(game.isPlayEnabledGame())) && dl.equal(Boolean.valueOf(game2.isInstanceInstalled()), Boolean.valueOf(game.isInstanceInstalled())) && dl.equal(game2.getInstancePackageName(), game.getInstancePackageName()) && dl.equal(Integer.valueOf(game2.getGameplayAclStatus()), Integer.valueOf(game.getGameplayAclStatus())) && dl.equal(Integer.valueOf(game2.getAchievementTotalCount()), Integer.valueOf(game.getAchievementTotalCount())) && dl.equal(Integer.valueOf(game2.getLeaderboardCount()), Integer.valueOf(game.getLeaderboardCount())))) {
                return false;
            }
        }
        return true;
    }

    static String b(Game game) {
        return dl.d(game).a("ApplicationId", game.getApplicationId()).a("DisplayName", game.getDisplayName()).a("PrimaryCategory", game.getPrimaryCategory()).a("SecondaryCategory", game.getSecondaryCategory()).a("Description", game.getDescription()).a("DeveloperName", game.getDeveloperName()).a("IconImageUri", game.getIconImageUri()).a("HiResImageUri", game.getHiResImageUri()).a("FeaturedImageUri", game.getFeaturedImageUri()).a("PlayEnabledGame", Boolean.valueOf(game.isPlayEnabledGame())).a("InstanceInstalled", Boolean.valueOf(game.isInstanceInstalled())).a("InstancePackageName", game.getInstancePackageName()).a("GameplayAclStatus", Integer.valueOf(game.getGameplayAclStatus())).a("AchievementTotalCount", Integer.valueOf(game.getAchievementTotalCount())).a("LeaderboardCount", Integer.valueOf(game.getLeaderboardCount())).toString();
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        return a(this, obj);
    }

    public Game freeze() {
        return this;
    }

    public int getAchievementTotalCount() {
        return this.mx;
    }

    public String getApplicationId() {
        return this.mk;
    }

    public String getDescription() {
        return this.mo;
    }

    public void getDescription(CharArrayBuffer charArrayBuffer) {
        eg.b(this.mo, charArrayBuffer);
    }

    public String getDeveloperName() {
        return this.mp;
    }

    public void getDeveloperName(CharArrayBuffer charArrayBuffer) {
        eg.b(this.mp, charArrayBuffer);
    }

    public String getDisplayName() {
        return this.ml;
    }

    public void getDisplayName(CharArrayBuffer charArrayBuffer) {
        eg.b(this.ml, charArrayBuffer);
    }

    public Uri getFeaturedImageUri() {
        return this.ms;
    }

    public int getGameplayAclStatus() {
        return this.mw;
    }

    public Uri getHiResImageUri() {
        return this.mr;
    }

    public Uri getIconImageUri() {
        return this.mq;
    }

    public String getInstancePackageName() {
        return this.mv;
    }

    public int getLeaderboardCount() {
        return this.my;
    }

    public String getPrimaryCategory() {
        return this.mm;
    }

    public String getSecondaryCategory() {
        return this.mn;
    }

    public int getVersionCode() {
        return this.iM;
    }

    public int hashCode() {
        return a(this);
    }

    public boolean isDataValid() {
        return true;
    }

    public boolean isInstanceInstalled() {
        return this.mu;
    }

    public boolean isPlayEnabledGame() {
        return this.mt;
    }

    public String toString() {
        return b((Game) this);
    }

    public void writeToParcel(Parcel parcel, int i) {
        int i2 = 1;
        String str = null;
        if (aX()) {
            parcel.writeString(this.mk);
            parcel.writeString(this.ml);
            parcel.writeString(this.mm);
            parcel.writeString(this.mn);
            parcel.writeString(this.mo);
            parcel.writeString(this.mp);
            parcel.writeString(this.mq == null ? null : this.mq.toString());
            parcel.writeString(this.mr == null ? null : this.mr.toString());
            if (this.ms != null) {
                str = this.ms.toString();
            }
            parcel.writeString(str);
            parcel.writeInt(this.mt ? 1 : 0);
            if (!this.mu) {
                i2 = 0;
            }
            parcel.writeInt(i2);
            parcel.writeString(this.mv);
            parcel.writeInt(this.mw);
            parcel.writeInt(this.mx);
            parcel.writeInt(this.my);
            return;
        }
        a.a(this, parcel, i);
    }
}
