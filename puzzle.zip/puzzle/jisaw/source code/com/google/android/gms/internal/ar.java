package com.google.android.gms.internal;

import com.google.android.gms.internal.ay.a;

public final class ar extends a {
    private final Object eJ = new Object();
    private at.a fb;
    private aq fc;

    public void a(aq aqVar) {
        synchronized (this.eJ) {
            this.fc = aqVar;
        }
    }

    public void a(at.a aVar) {
        synchronized (this.eJ) {
            this.fb = aVar;
        }
    }

    public void onAdClosed() {
        synchronized (this.eJ) {
            if (this.fc != null) {
                this.fc.E();
            }
        }
    }

    public void onAdFailedToLoad(int i) {
        synchronized (this.eJ) {
            if (this.fb != null) {
                this.fb.d(i == 3 ? 1 : 2);
                this.fb = null;
            }
        }
    }

    public void onAdLeftApplication() {
        synchronized (this.eJ) {
            if (this.fc != null) {
                this.fc.F();
            }
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void onAdLoaded() {
        /*
        r3 = this;
        r1 = r3.eJ;
        monitor-enter(r1);
        r0 = r3.fb;	 Catch:{ all -> 0x001d }
        if (r0 == 0) goto L_0x0012;
    L_0x0007:
        r0 = r3.fb;	 Catch:{ all -> 0x001d }
        r2 = 0;
        r0.d(r2);	 Catch:{ all -> 0x001d }
        r0 = 0;
        r3.fb = r0;	 Catch:{ all -> 0x001d }
        monitor-exit(r1);	 Catch:{ all -> 0x001d }
    L_0x0011:
        return;
    L_0x0012:
        r0 = r3.fc;	 Catch:{ all -> 0x001d }
        if (r0 == 0) goto L_0x001b;
    L_0x0016:
        r0 = r3.fc;	 Catch:{ all -> 0x001d }
        r0.H();	 Catch:{ all -> 0x001d }
    L_0x001b:
        monitor-exit(r1);	 Catch:{ all -> 0x001d }
        goto L_0x0011;
    L_0x001d:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x001d }
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.internal.ar.onAdLoaded():void");
    }

    public void onAdOpened() {
        synchronized (this.eJ) {
            if (this.fc != null) {
                this.fc.G();
            }
        }
    }

    public void y() {
        synchronized (this.eJ) {
            if (this.fc != null) {
                this.fc.D();
            }
        }
    }
}
