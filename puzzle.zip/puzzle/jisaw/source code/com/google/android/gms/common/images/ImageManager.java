package com.google.android.gms.common.images;

import android.app.ActivityManager;
import android.content.ComponentCallbacks2;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.os.ResultReceiver;
import android.util.Log;
import android.widget.ImageView;
import com.google.android.gms.internal.db;
import com.google.android.gms.internal.dq;
import com.google.android.gms.internal.ek;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class ImageManager {
    private static final Object jC = new Object();
    private static HashSet<Uri> jD = new HashSet();
    private static ImageManager jE;
    private static ImageManager jF;
    private final ExecutorService jG = Executors.newFixedThreadPool(4);
    private final b jH;
    private final Map<a, ImageReceiver> jI;
    private final Map<Uri, ImageReceiver> jJ;
    private final Context mContext;
    private final Handler mHandler = new Handler(Looper.getMainLooper());

    private final class ImageReceiver extends ResultReceiver {
        private final ArrayList<a> jK;
        boolean jL = false;
        final /* synthetic */ ImageManager jM;
        private final Uri mUri;

        ImageReceiver(ImageManager imageManager, Uri uri) {
            this.jM = imageManager;
            super(new Handler(Looper.getMainLooper()));
            this.mUri = uri;
            this.jK = new ArrayList();
        }

        public void aR() {
            Intent intent = new Intent("com.google.android.gms.common.images.LOAD_IMAGE");
            intent.putExtra("com.google.android.gms.extras.uri", this.mUri);
            intent.putExtra("com.google.android.gms.extras.resultReceiver", this);
            intent.putExtra("com.google.android.gms.extras.priority", 3);
            this.jM.mContext.sendBroadcast(intent);
        }

        public void c(a aVar) {
            db.a(!this.jL, "Cannot add an ImageRequest when mHandlingRequests is true");
            db.w("ImageReceiver.addImageRequest() must be called in the main thread");
            this.jK.add(aVar);
        }

        public void d(a aVar) {
            db.a(!this.jL, "Cannot remove an ImageRequest when mHandlingRequests is true");
            db.w("ImageReceiver.removeImageRequest() must be called in the main thread");
            this.jK.remove(aVar);
        }

        public void onReceiveResult(int i, Bundle bundle) {
            this.jM.jG.execute(new c(this.jM, this.mUri, (ParcelFileDescriptor) bundle.getParcelable("com.google.android.gms.extra.fileDescriptor")));
        }
    }

    public interface OnImageLoadedListener {
        void onImageLoaded(Uri uri, Drawable drawable);
    }

    private static final class a {
        static int a(ActivityManager activityManager) {
            return activityManager.getLargeMemoryClass();
        }
    }

    private static final class b extends dq<com.google.android.gms.common.images.a.a, Bitmap> {
        public b(Context context) {
            super(q(context));
        }

        private static int q(Context context) {
            ActivityManager activityManager = (ActivityManager) context.getSystemService("activity");
            int memoryClass = (((context.getApplicationInfo().flags & 1048576) != 0 ? 1 : null) == null || !ek.bJ()) ? activityManager.getMemoryClass() : a.a(activityManager);
            return (int) (((float) (memoryClass * 1048576)) * 0.33f);
        }

        protected int a(com.google.android.gms.common.images.a.a aVar, Bitmap bitmap) {
            return bitmap.getHeight() * bitmap.getRowBytes();
        }

        protected void a(boolean z, com.google.android.gms.common.images.a.a aVar, Bitmap bitmap, Bitmap bitmap2) {
            super.entryRemoved(z, aVar, bitmap, bitmap2);
        }

        protected /* synthetic */ void entryRemoved(boolean z, Object obj, Object obj2, Object obj3) {
            a(z, (com.google.android.gms.common.images.a.a) obj, (Bitmap) obj2, (Bitmap) obj3);
        }

        protected /* synthetic */ int sizeOf(Object obj, Object obj2) {
            return a((com.google.android.gms.common.images.a.a) obj, (Bitmap) obj2);
        }
    }

    private final class c implements Runnable {
        final /* synthetic */ ImageManager jM;
        private final ParcelFileDescriptor jN;
        private final Uri mUri;

        public c(ImageManager imageManager, Uri uri, ParcelFileDescriptor parcelFileDescriptor) {
            this.jM = imageManager;
            this.mUri = uri;
            this.jN = parcelFileDescriptor;
        }

        public void run() {
            Bitmap bitmap = null;
            boolean z = false;
            db.x("LoadBitmapFromDiskRunnable can't be executed in the main thread");
            if (this.jN != null) {
                try {
                    bitmap = BitmapFactory.decodeFileDescriptor(this.jN.getFileDescriptor());
                } catch (Throwable e) {
                    Log.e("ImageManager", "OOM while loading bitmap for uri: " + this.mUri, e);
                    z = true;
                }
                try {
                    this.jN.close();
                } catch (Throwable e2) {
                    Log.e("ImageManager", "closed failed", e2);
                }
            }
            CountDownLatch countDownLatch = new CountDownLatch(1);
            this.jM.mHandler.post(new f(this.jM, this.mUri, bitmap, z, countDownLatch));
            try {
                countDownLatch.await();
            } catch (InterruptedException e3) {
                Log.w("ImageManager", "Latch interrupted while posting " + this.mUri);
            }
        }
    }

    private final class d implements Runnable {
        final /* synthetic */ ImageManager jM;
        private final a jO;

        public d(ImageManager imageManager, a aVar) {
            this.jM = imageManager;
            this.jO = aVar;
        }

        public void run() {
            db.w("LoadImageRunnable must be executed on the main thread");
            this.jM.b(this.jO);
            com.google.android.gms.common.images.a.a aVar = this.jO.jS;
            if (aVar.uri == null) {
                this.jO.b(this.jM.mContext, true);
                return;
            }
            Bitmap a = this.jM.a(aVar);
            if (a != null) {
                this.jO.a(this.jM.mContext, a, true);
                return;
            }
            this.jO.r(this.jM.mContext);
            ImageReceiver imageReceiver = (ImageReceiver) this.jM.jJ.get(aVar.uri);
            if (imageReceiver == null) {
                imageReceiver = new ImageReceiver(this.jM, aVar.uri);
                this.jM.jJ.put(aVar.uri, imageReceiver);
            }
            imageReceiver.c(this.jO);
            if (this.jO.jV != 1) {
                this.jM.jI.put(this.jO, imageReceiver);
            }
            synchronized (ImageManager.jC) {
                if (!ImageManager.jD.contains(aVar.uri)) {
                    ImageManager.jD.add(aVar.uri);
                    imageReceiver.aR();
                }
            }
        }
    }

    private static final class e implements ComponentCallbacks2 {
        private final b jH;

        public e(b bVar) {
            this.jH = bVar;
        }

        public void onConfigurationChanged(Configuration configuration) {
        }

        public void onLowMemory() {
            this.jH.evictAll();
        }

        public void onTrimMemory(int i) {
            if (i >= 60) {
                this.jH.evictAll();
            } else if (i >= 20) {
                this.jH.trimToSize(this.jH.size() / 2);
            }
        }
    }

    private final class f implements Runnable {
        final /* synthetic */ ImageManager jM;
        private final Bitmap jP;
        private final CountDownLatch jQ;
        private boolean jR;
        private final Uri mUri;

        public f(ImageManager imageManager, Uri uri, Bitmap bitmap, boolean z, CountDownLatch countDownLatch) {
            this.jM = imageManager;
            this.mUri = uri;
            this.jP = bitmap;
            this.jR = z;
            this.jQ = countDownLatch;
        }

        private void a(ImageReceiver imageReceiver, boolean z) {
            imageReceiver.jL = true;
            ArrayList a = imageReceiver.jK;
            int size = a.size();
            for (int i = 0; i < size; i++) {
                a aVar = (a) a.get(i);
                if (z) {
                    aVar.a(this.jM.mContext, this.jP, false);
                } else {
                    aVar.b(this.jM.mContext, false);
                }
                if (aVar.jV != 1) {
                    this.jM.jI.remove(aVar);
                }
            }
            imageReceiver.jL = false;
        }

        public void run() {
            db.w("OnBitmapLoadedRunnable must be executed in the main thread");
            boolean z = this.jP != null;
            if (this.jM.jH != null) {
                if (this.jR) {
                    this.jM.jH.evictAll();
                    System.gc();
                    this.jR = false;
                    this.jM.mHandler.post(this);
                    return;
                } else if (z) {
                    this.jM.jH.put(new com.google.android.gms.common.images.a.a(this.mUri), this.jP);
                }
            }
            ImageReceiver imageReceiver = (ImageReceiver) this.jM.jJ.remove(this.mUri);
            if (imageReceiver != null) {
                a(imageReceiver, z);
            }
            this.jQ.countDown();
            synchronized (ImageManager.jC) {
                ImageManager.jD.remove(this.mUri);
            }
        }
    }

    private ImageManager(Context context, boolean z) {
        this.mContext = context.getApplicationContext();
        if (z) {
            this.jH = new b(this.mContext);
            if (ek.bM()) {
                aO();
            }
        } else {
            this.jH = null;
        }
        this.jI = new HashMap();
        this.jJ = new HashMap();
    }

    private Bitmap a(com.google.android.gms.common.images.a.a aVar) {
        return this.jH == null ? null : (Bitmap) this.jH.get(aVar);
    }

    public static ImageManager a(Context context, boolean z) {
        if (z) {
            if (jF == null) {
                jF = new ImageManager(context, true);
            }
            return jF;
        }
        if (jE == null) {
            jE = new ImageManager(context, false);
        }
        return jE;
    }

    private void aO() {
        this.mContext.registerComponentCallbacks(new e(this.jH));
    }

    private boolean b(a aVar) {
        db.w("ImageManager.cleanupHashMaps() must be called in the main thread");
        if (aVar.jV == 1) {
            return true;
        }
        ImageReceiver imageReceiver = (ImageReceiver) this.jI.get(aVar);
        if (imageReceiver == null) {
            return true;
        }
        if (imageReceiver.jL) {
            return false;
        }
        this.jI.remove(aVar);
        imageReceiver.d(aVar);
        return true;
    }

    public static ImageManager create(Context context) {
        return a(context, false);
    }

    public void a(a aVar) {
        db.w("ImageManager.loadImage() must be called in the main thread");
        boolean b = b(aVar);
        Runnable dVar = new d(this, aVar);
        if (b) {
            dVar.run();
        } else {
            this.mHandler.post(dVar);
        }
    }

    public void loadImage(ImageView imageView, int i) {
        a aVar = new a(i);
        aVar.a(imageView);
        a(aVar);
    }

    public void loadImage(ImageView imageView, Uri uri) {
        a aVar = new a(uri);
        aVar.a(imageView);
        a(aVar);
    }

    public void loadImage(ImageView imageView, Uri uri, int i) {
        a aVar = new a(uri);
        aVar.v(i);
        aVar.a(imageView);
        a(aVar);
    }

    public void loadImage(OnImageLoadedListener onImageLoadedListener, Uri uri) {
        a aVar = new a(uri);
        aVar.a(onImageLoadedListener);
        a(aVar);
    }

    public void loadImage(OnImageLoadedListener onImageLoadedListener, Uri uri, int i) {
        a aVar = new a(uri);
        aVar.v(i);
        aVar.a(onImageLoadedListener);
        a(aVar);
    }
}
