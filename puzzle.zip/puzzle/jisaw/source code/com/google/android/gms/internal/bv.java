package com.google.android.gms.internal;

import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.a;
import com.google.android.gms.common.internal.safeparcel.b;

public class bv implements Creator<bu> {
    static void a(bu buVar, Parcel parcel, int i) {
        int k = b.k(parcel);
        b.c(parcel, 1, buVar.versionCode);
        b.a(parcel, 2, buVar.gA, false);
        b.a(parcel, 3, buVar.gB, i, false);
        b.a(parcel, 4, buVar.ed, i, false);
        b.a(parcel, 5, buVar.adUnitId, false);
        b.a(parcel, 6, buVar.applicationInfo, i, false);
        b.a(parcel, 7, buVar.gC, i, false);
        b.a(parcel, 8, buVar.gD, false);
        b.a(parcel, 9, buVar.gE, false);
        b.a(parcel, 10, buVar.gF, false);
        b.a(parcel, 11, buVar.eg, i, false);
        b.C(parcel, k);
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return e(parcel);
    }

    public bu e(Parcel parcel) {
        Bundle bundle = null;
        int j = a.j(parcel);
        int i = 0;
        v vVar = null;
        x xVar = null;
        String str = null;
        ApplicationInfo applicationInfo = null;
        PackageInfo packageInfo = null;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        co coVar = null;
        while (parcel.dataPosition() < j) {
            int i2 = a.i(parcel);
            switch (a.y(i2)) {
                case 1:
                    i = a.f(parcel, i2);
                    break;
                case 2:
                    bundle = a.n(parcel, i2);
                    break;
                case 3:
                    vVar = (v) a.a(parcel, i2, v.CREATOR);
                    break;
                case 4:
                    xVar = (x) a.a(parcel, i2, x.CREATOR);
                    break;
                case 5:
                    str = a.l(parcel, i2);
                    break;
                case 6:
                    applicationInfo = (ApplicationInfo) a.a(parcel, i2, ApplicationInfo.CREATOR);
                    break;
                case 7:
                    packageInfo = (PackageInfo) a.a(parcel, i2, PackageInfo.CREATOR);
                    break;
                case 8:
                    str2 = a.l(parcel, i2);
                    break;
                case 9:
                    str3 = a.l(parcel, i2);
                    break;
                case 10:
                    str4 = a.l(parcel, i2);
                    break;
                case 11:
                    coVar = (co) a.a(parcel, i2, co.CREATOR);
                    break;
                default:
                    a.b(parcel, i2);
                    break;
            }
        }
        if (parcel.dataPosition() == j) {
            return new bu(i, bundle, vVar, xVar, str, applicationInfo, packageInfo, str2, str3, str4, coVar);
        }
        throw new a.a("Overread allowed size end=" + j, parcel);
    }

    public bu[] i(int i) {
        return new bu[i];
    }

    public /* synthetic */ Object[] newArray(int i) {
        return i(i);
    }
}
