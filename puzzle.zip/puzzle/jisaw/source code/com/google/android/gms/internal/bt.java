package com.google.android.gms.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.RemoteException;
import com.google.android.gms.common.GooglePlayServicesClient.ConnectionCallbacks;
import com.google.android.gms.common.GooglePlayServicesClient.OnConnectionFailedListener;
import com.google.android.gms.internal.by.a;
import com.google.android.gms.internal.de.d;

public class bt extends de<by> {
    private final int gz;

    public bt(Context context, ConnectionCallbacks connectionCallbacks, OnConnectionFailedListener onConnectionFailedListener, int i) {
        super(context, connectionCallbacks, onConnectionFailedListener, new String[0]);
        this.gz = i;
    }

    protected void a(dj djVar, d dVar) throws RemoteException {
        djVar.g(dVar, this.gz, getContext().getPackageName(), new Bundle());
    }

    protected String ag() {
        return "com.google.android.gms.ads.service.START";
    }

    protected String ah() {
        return "com.google.android.gms.ads.internal.request.IAdRequestService";
    }

    public by ai() {
        return (by) super.bd();
    }

    protected by o(IBinder iBinder) {
        return a.q(iBinder);
    }

    protected /* synthetic */ IInterface p(IBinder iBinder) {
        return o(iBinder);
    }
}
