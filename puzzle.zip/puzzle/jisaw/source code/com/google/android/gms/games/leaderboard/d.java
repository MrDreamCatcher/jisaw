package com.google.android.gms.games.leaderboard;

import android.database.CharArrayBuffer;
import android.net.Uri;
import com.google.android.gms.common.data.b;
import com.google.android.gms.games.Player;

public final class d extends b implements LeaderboardScore {
    private final com.google.android.gms.games.d nH;

    d(com.google.android.gms.common.data.d dVar, int i) {
        super(dVar, i);
        this.nH = new com.google.android.gms.games.d(dVar, i);
    }

    public LeaderboardScore cd() {
        return new c(this);
    }

    public boolean equals(Object obj) {
        return c.a(this, obj);
    }

    public /* synthetic */ Object freeze() {
        return cd();
    }

    public String getDisplayRank() {
        return getString("display_rank");
    }

    public void getDisplayRank(CharArrayBuffer charArrayBuffer) {
        a("display_rank", charArrayBuffer);
    }

    public String getDisplayScore() {
        return getString("display_score");
    }

    public void getDisplayScore(CharArrayBuffer charArrayBuffer) {
        a("display_score", charArrayBuffer);
    }

    public long getRank() {
        return getLong("rank");
    }

    public long getRawScore() {
        return getLong("raw_score");
    }

    public Player getScoreHolder() {
        return v("external_player_id") ? null : this.nH;
    }

    public String getScoreHolderDisplayName() {
        return v("external_player_id") ? getString("default_display_name") : this.nH.getDisplayName();
    }

    public void getScoreHolderDisplayName(CharArrayBuffer charArrayBuffer) {
        if (v("external_player_id")) {
            a("default_display_name", charArrayBuffer);
        } else {
            this.nH.getDisplayName(charArrayBuffer);
        }
    }

    public Uri getScoreHolderHiResImageUri() {
        return v("external_player_id") ? null : this.nH.getHiResImageUri();
    }

    public Uri getScoreHolderIconImageUri() {
        return v("external_player_id") ? u("default_display_image_uri") : this.nH.getIconImageUri();
    }

    public String getScoreTag() {
        return getString("score_tag");
    }

    public long getTimestampMillis() {
        return getLong("achieved_timestamp");
    }

    public int hashCode() {
        return c.a(this);
    }

    public String toString() {
        return c.b(this);
    }
}
