package com.google.ads.mediation.customevent;

@Deprecated
public interface CustomEvent {
    void destroy();
}
