package com.dexati.adclient;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import com.google.android.gms.location.LocationStatusCodes;
import com.km.puzzle.jigsaw.R;
import java.net.URLEncoder;
import java.util.Random;

public class EndWall extends Activity {
    protected static final String TAG = "KM";
    public static String URL_SERVER = "http://apps.dexati.com/adserver/api/1/pages/end";
    private static boolean initialLoadFinished = false;
    private ProgressDialog progress;

    private void hideProgress() {
        if (this.progress != null && this.progress.isShowing()) {
            this.progress.dismiss();
        }
    }

    private void showProgress() {
        if (this.progress == null) {
            this.progress = new ProgressDialog(this);
            this.progress.setMessage("Loading...");
        }
        this.progress.show();
    }

    public void onClose(View view) {
        finish();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        setContentView(R.layout.endwall);
        WebView webView = (WebView) findViewById(R.id.adWebView);
        webView.setWebViewClient(new WebViewClient() {
            public void onPageFinished(WebView webView, String str) {
                Log.d(EndWall.TAG, "WebView onPageFinished");
                EndWall.this.hideProgress();
                EndWall.initialLoadFinished = true;
            }

            public void onReceivedError(WebView webView, int i, String str, String str2) {
                Log.i(EndWall.TAG, "WebView failed to load. Error code:" + i);
                if (!EndWall.initialLoadFinished) {
                    webView.setVisibility(4);
                    EndWall.this.hideProgress();
                    super.onReceivedError(webView, i, str, str2);
                    EndWall.this.finish();
                }
            }

            public boolean shouldOverrideUrlLoading(WebView webView, String str) {
                Log.d(EndWall.TAG, "URL: " + str);
                if (str.startsWith("http") || str.startsWith("https")) {
                    return false;
                }
                try {
                    EndWall.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
                    EndWall.this.finish();
                    return true;
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(EndWall.this, "Not supported on your device.", LocationStatusCodes.GEOFENCE_NOT_AVAILABLE).show();
                    EndWall.this.finish();
                    return true;
                }
            }
        });
        String str = URL_SERVER + "?random=" + new Random().nextInt(10000) + "&country=" + Dexati.country + "&package=" + Dexati.packageName + "&devid=" + Dexati.devId + "&model=" + URLEncoder.encode(Build.MODEL) + "&product=" + URLEncoder.encode(Build.PRODUCT) + "&manufacturer=" + URLEncoder.encode(Build.MANUFACTURER) + "&appversion=" + Dexati.versionCode + "&osversion=" + VERSION.SDK_INT;
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setInitialScale(1);
        webView.loadUrl(str);
        showProgress();
    }

    public void onPause() {
        super.onPause();
        hideProgress();
    }
}
