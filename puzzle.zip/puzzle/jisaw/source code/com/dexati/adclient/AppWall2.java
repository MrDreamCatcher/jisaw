package com.dexati.adclient;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import com.km.puzzle.jigsaw.R;

public class AppWall2 extends Activity {
    protected static final String TAG = "KM";
    private static boolean accepted = false;
    public static Bitmap imageURL;
    public static String url;
    public static WebView webView;
    ImageView adCloser;
    ImageView fullPage;
    RelativeLayout linearLayout = null;
    private ProgressDialog progress;

    private void hideProgress() {
        if (this.progress != null && this.progress.isShowing()) {
            this.progress.dismiss();
        }
    }

    public void onAdClick(View view) {
        accepted = true;
        Intent intent;
        if (!Dexati.preCache) {
            intent = new Intent("android.intent.action.VIEW", Uri.parse(url));
            intent.setFlags(268435456);
            startActivity(intent);
            finish();
        } else if (Dexati.urlStringFound != null) {
            intent = new Intent("android.intent.action.VIEW", Uri.parse(Dexati.urlStringFound));
            intent.setFlags(268435456);
            startActivity(intent);
            finish();
        } else {
            this.progress = ProgressDialog.show(this, "Your Free App", "Getting the Top App ..", true);
        }
    }

    public void onClose(View view) {
        finish();
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        setContentView(R.layout.appwall2);
        accepted = false;
        this.fullPage = (ImageView) findViewById(R.id.fullscreen);
        this.adCloser = (ImageView) findViewById(R.id.adcloser);
        this.fullPage.setImageBitmap(imageURL);
        if (Dexati.preCache) {
            webView = new WebView(this);
            webView.setWebViewClient(new WebViewClient() {
                public void onPageFinished(WebView webView, String str) {
                    Log.i(AppWall2.TAG, "onPageFinished:");
                }

                public void onReceivedError(WebView webView, int i, String str, String str2) {
                    Log.i(AppWall2.TAG, "WebView failed to load. Error code:" + i);
                }

                public boolean shouldOverrideUrlLoading(WebView webView, String str) {
                    Log.d(AppWall2.TAG, "URL: " + str);
                    if (str.startsWith("http") || str.startsWith("https")) {
                        return false;
                    }
                    try {
                        Dexati.urlStringFound = str;
                        if (!AppWall2.accepted) {
                            return true;
                        }
                        if (AppWall2.this.progress != null) {
                            AppWall2.this.runOnUiThread(new Runnable() {
                                public void run() {
                                    AppWall2.this.progress.dismiss();
                                }
                            });
                        }
                        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(str));
                        intent.setFlags(268435456);
                        AppWall2.this.startActivity(intent);
                        return true;
                    } catch (Throwable e) {
                        e.printStackTrace();
                        Log.v(AppWall2.TAG, "Error", e);
                        return true;
                    }
                }
            });
            webView.getSettings().setJavaScriptEnabled(true);
            webView.setInitialScale(1);
            webView.setBackgroundColor(0);
            webView.loadUrl(url);
        }
    }

    public void onPause() {
        super.onPause();
        hideProgress();
    }
}
