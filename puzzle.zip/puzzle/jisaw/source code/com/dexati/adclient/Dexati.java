package com.dexati.adclient;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import android.webkit.WebView;

public class Dexati {
    public static final long MINIMUM_INITIAL = 120000;
    protected static final String TAG = "KM";
    private static boolean accepted = false;
    public static boolean admob = false;
    public static boolean appDirect = false;
    public static String backURL = null;
    public static Context context;
    public static String country;
    public static String devId = "NA";
    public static boolean endAd = false;
    public static boolean haveResponse = false;
    public static long lastRequestStart = 0;
    public static String packageName;
    private static ProgressDialog pd = null;
    public static boolean preCache = true;
    private static boolean rejected = false;
    public static String text;
    public static String type;
    public static String urlStringFound = null;
    public static int versionCode = -1;
    public static WebView webView;

    private static class AdLoaderTask extends AsyncTask<String, Void, String> {
        private AdLoaderTask() {
        }

        protected String doInBackground(String... strArr) {
            Dexati.contactServer();
            return null;
        }

        protected void onPostExecute(String str) {
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void contactServer() {
        /*
        r0 = 0;
        r6 = 1;
        r4 = 0;
        r1 = context;	 Catch:{ Exception -> 0x009f }
        r1 = com.google.android.gms.ads.identifier.AdvertisingIdClient.getAdvertisingIdInfo(r1);	 Catch:{ Exception -> 0x009f }
        r2 = r1.isLimitAdTrackingEnabled();	 Catch:{ Exception -> 0x009f }
        if (r2 != 0) goto L_0x0015;
    L_0x000f:
        r1 = r1.getId();	 Catch:{ Exception -> 0x009f }
        devId = r1;	 Catch:{ Exception -> 0x009f }
    L_0x0015:
        r1 = new java.lang.StringBuilder;
        r2 = "http://apps.dexati.com/adserver/api/1/adservice?country=";
        r1.<init>(r2);
        r2 = country;
        r1 = r1.append(r2);
        r2 = "&package=";
        r1 = r1.append(r2);
        r2 = packageName;
        r1 = r1.append(r2);
        r2 = "&devid=";
        r1 = r1.append(r2);
        r2 = devId;
        r1 = r1.append(r2);
        r2 = "&type=startup&clientver=2";
        r1 = r1.append(r2);
        r2 = "&model=";
        r1 = r1.append(r2);
        r2 = android.os.Build.MODEL;
        r2 = java.net.URLEncoder.encode(r2);
        r1 = r1.append(r2);
        r2 = "&product=";
        r1 = r1.append(r2);
        r2 = android.os.Build.PRODUCT;
        r2 = java.net.URLEncoder.encode(r2);
        r1 = r1.append(r2);
        r2 = "&manufacturer=";
        r1 = r1.append(r2);
        r2 = android.os.Build.MANUFACTURER;
        r2 = java.net.URLEncoder.encode(r2);
        r1 = r1.append(r2);
        r2 = "&appversion=";
        r1 = r1.append(r2);
        r2 = versionCode;
        r1 = r1.append(r2);
        r2 = "&osversion=";
        r1 = r1.append(r2);
        r2 = android.os.Build.VERSION.SDK_INT;
        r1 = r1.append(r2);
        r1 = r1.toString();
        r2 = "KM";
        android.util.Log.v(r2, r1);
        r5 = com.dexati.adclient.JSONUtil.getJSONfromURL(r1);
        if (r5 != 0) goto L_0x00a9;
    L_0x0097:
        r0 = "KM";
        r1 = "Dexati app server down";
        android.util.Log.v(r0, r1);
    L_0x009e:
        return;
    L_0x009f:
        r1 = move-exception;
        r1 = "KM";
        r2 = "Error connecting to google Play Services";
        android.util.Log.v(r1, r2);
        goto L_0x0015;
    L_0x00a9:
        r2 = "Download Top Free App !!";
        r3 = "admob";
        r3 = r5.has(r3);	 Catch:{ Exception -> 0x0224 }
        if (r3 == 0) goto L_0x00f2;
    L_0x00b3:
        r3 = "admob";
        r3 = r5.getBoolean(r3);	 Catch:{ Exception -> 0x0224 }
        if (r3 == 0) goto L_0x00f2;
    L_0x00bb:
        r3 = r6;
    L_0x00bc:
        admob = r3;	 Catch:{ Exception -> 0x0224 }
    L_0x00be:
        r3 = "precache";
        r3 = r5.has(r3);	 Catch:{ Exception -> 0x0227 }
        if (r3 == 0) goto L_0x00ce;
    L_0x00c6:
        r3 = "precache";
        r3 = r5.getBoolean(r3);	 Catch:{ Exception -> 0x0227 }
        preCache = r3;	 Catch:{ Exception -> 0x0227 }
    L_0x00ce:
        r3 = "endwall";
        r3 = r5.has(r3);	 Catch:{ Exception -> 0x022a }
        if (r3 == 0) goto L_0x00f4;
    L_0x00d6:
        r3 = "endwall";
        r3 = r5.getBoolean(r3);	 Catch:{ Exception -> 0x022a }
        if (r3 == 0) goto L_0x00f4;
    L_0x00de:
        r3 = r6;
    L_0x00df:
        endAd = r3;	 Catch:{ Exception -> 0x022a }
    L_0x00e1:
        r3 = admob;
        if (r3 == 0) goto L_0x00f6;
    L_0x00e5:
        r0 = context;
        r0 = (android.app.Activity) r0;
        r1 = new com.dexati.adclient.Dexati$2;
        r1.<init>();
        r0.runOnUiThread(r1);
        goto L_0x009e;
    L_0x00f2:
        r3 = r4;
        goto L_0x00bc;
    L_0x00f4:
        r3 = r4;
        goto L_0x00df;
    L_0x00f6:
        r3 = "url";
        r3 = r5.has(r3);
        if (r3 == 0) goto L_0x0216;
    L_0x00fe:
        r3 = "url";
        r1 = r5.getString(r3);	 Catch:{ JSONException -> 0x01b1 }
        r3 = "text";
        r2 = r5.getString(r3);	 Catch:{ JSONException -> 0x01b1 }
        r3 = "app";
        r3 = r5.getString(r3);	 Catch:{ JSONException -> 0x01b1 }
        r7 = "image";
        r7 = r5.has(r7);	 Catch:{ JSONException -> 0x01b1 }
        if (r7 == 0) goto L_0x011e;
    L_0x0118:
        r7 = "image";
        r0 = r5.getString(r7);	 Catch:{ JSONException -> 0x01b1 }
    L_0x011e:
        r7 = "appdirect";
        r7 = r5.has(r7);	 Catch:{ JSONException -> 0x01b1 }
        if (r7 == 0) goto L_0x012e;
    L_0x0126:
        r7 = "appdirect";
        r7 = r5.getBoolean(r7);	 Catch:{ JSONException -> 0x01b1 }
        appDirect = r7;	 Catch:{ JSONException -> 0x01b1 }
    L_0x012e:
        r7 = "appurl";
        r7 = r5.has(r7);	 Catch:{ JSONException -> 0x01b1 }
        if (r7 == 0) goto L_0x013e;
    L_0x0136:
        r7 = "appurl";
        r7 = r5.getString(r7);	 Catch:{ JSONException -> 0x01b1 }
        backURL = r7;	 Catch:{ JSONException -> 0x01b1 }
    L_0x013e:
        r7 = context;	 Catch:{ NameNotFoundException -> 0x01a2 }
        r7 = r7.getPackageManager();	 Catch:{ NameNotFoundException -> 0x01a2 }
        r8 = 0;
        r3 = r7.getPackageInfo(r3, r8);	 Catch:{ NameNotFoundException -> 0x01a2 }
        if (r3 == 0) goto L_0x0241;
    L_0x014b:
        r3 = "more";
        r7 = r5.getJSONArray(r3);	 Catch:{ NameNotFoundException -> 0x01a2 }
        r3 = r4;
        r5 = r4;
        r12 = r0;
        r0 = r1;
        r1 = r2;
        r2 = r12;
    L_0x0157:
        r8 = r7.length();	 Catch:{ JSONException -> 0x022d }
        if (r3 < r8) goto L_0x016e;
    L_0x015d:
        r3 = r0;
    L_0x015e:
        if (r5 != 0) goto L_0x01b7;
    L_0x0160:
        r0 = context;
        r0 = (android.app.Activity) r0;
        r1 = new com.dexati.adclient.Dexati$3;
        r1.<init>();
        r0.runOnUiThread(r1);
        goto L_0x009e;
    L_0x016e:
        r8 = r7.getJSONObject(r3);	 Catch:{ JSONException -> 0x022d }
        r9 = "app";
        r9 = r8.getString(r9);	 Catch:{ JSONException -> 0x022d }
        r10 = context;	 Catch:{ NameNotFoundException -> 0x0185, JSONException -> 0x022d }
        r10 = r10.getPackageManager();	 Catch:{ NameNotFoundException -> 0x0185, JSONException -> 0x022d }
        r11 = 0;
        r10.getPackageInfo(r9, r11);	 Catch:{ NameNotFoundException -> 0x0185, JSONException -> 0x022d }
    L_0x0182:
        r3 = r3 + 1;
        goto L_0x0157;
    L_0x0185:
        r5 = move-exception;
        r5 = "url";
        r0 = r8.getString(r5);	 Catch:{ NameNotFoundException -> 0x023b }
        r5 = "text";
        r1 = r8.getString(r5);	 Catch:{ NameNotFoundException -> 0x023b }
        r5 = "image";
        r5 = r8.has(r5);	 Catch:{ NameNotFoundException -> 0x023b }
        if (r5 == 0) goto L_0x023e;
    L_0x019a:
        r5 = "image";
        r2 = r8.getString(r5);	 Catch:{ NameNotFoundException -> 0x023b }
        r5 = r6;
        goto L_0x0182;
    L_0x01a2:
        r3 = move-exception;
        r12 = r0;
        r0 = r1;
        r1 = r2;
        r2 = r12;
    L_0x01a7:
        r3 = "KM";
        r5 = "Application does not exist can show ad";
        android.util.Log.v(r3, r5);	 Catch:{ JSONException -> 0x0233 }
        r3 = r0;
        r5 = r6;
        goto L_0x015e;
    L_0x01b1:
        r3 = move-exception;
        r5 = r4;
    L_0x01b3:
        r3 = r1;
        r1 = r2;
        r2 = r0;
        goto L_0x015e;
    L_0x01b7:
        text = r1;
        if (r2 == 0) goto L_0x01e6;
    L_0x01bb:
        com.dexati.adclient.AppWall2.url = r3;
        r0 = new java.net.URL;	 Catch:{ Exception -> 0x01dc }
        r0.<init>(r2);	 Catch:{ Exception -> 0x01dc }
        r0 = r0.getContent();	 Catch:{ Exception -> 0x01dc }
        r0 = (java.io.InputStream) r0;	 Catch:{ Exception -> 0x01dc }
        r0 = android.graphics.BitmapFactory.decodeStream(r0);	 Catch:{ Exception -> 0x01dc }
        com.dexati.adclient.AppWall2.imageURL = r0;	 Catch:{ Exception -> 0x01dc }
        r0 = context;	 Catch:{ Exception -> 0x01dc }
        r0 = (android.app.Activity) r0;	 Catch:{ Exception -> 0x01dc }
        r1 = new com.dexati.adclient.Dexati$4;	 Catch:{ Exception -> 0x01dc }
        r1.<init>();	 Catch:{ Exception -> 0x01dc }
        r0.runOnUiThread(r1);	 Catch:{ Exception -> 0x01dc }
        goto L_0x009e;
    L_0x01dc:
        r0 = move-exception;
        r1 = "KM";
        r2 = "Error downloading image";
        android.util.Log.v(r1, r2, r0);
        goto L_0x009e;
    L_0x01e6:
        r0 = context;
        r0 = (android.app.Activity) r0;
        r1 = new com.dexati.adclient.Dexati$5;
        r1.<init>();
        r0.runOnUiThread(r1);
        r0 = webView;
        r1 = new com.dexati.adclient.Dexati$6;
        r1.<init>();
        r0.setWebViewClient(r1);
        r0 = webView;
        r0 = r0.getSettings();
        r0.setJavaScriptEnabled(r6);
        r0 = webView;
        r0.setInitialScale(r6);
        r0 = webView;
        r0.setBackgroundColor(r4);
        r0 = webView;
        r0.loadUrl(r3);
        goto L_0x009e;
    L_0x0216:
        r0 = context;
        r0 = (android.app.Activity) r0;
        r1 = new com.dexati.adclient.Dexati$7;
        r1.<init>();
        r0.runOnUiThread(r1);
        goto L_0x009e;
    L_0x0224:
        r3 = move-exception;
        goto L_0x00be;
    L_0x0227:
        r3 = move-exception;
        goto L_0x00ce;
    L_0x022a:
        r3 = move-exception;
        goto L_0x00e1;
    L_0x022d:
        r3 = move-exception;
        r12 = r2;
        r2 = r1;
        r1 = r0;
        r0 = r12;
        goto L_0x01b3;
    L_0x0233:
        r3 = move-exception;
        r5 = r6;
        r12 = r0;
        r0 = r2;
        r2 = r1;
        r1 = r12;
        goto L_0x01b3;
    L_0x023b:
        r3 = move-exception;
        goto L_0x01a7;
    L_0x023e:
        r5 = r6;
        goto L_0x0182;
    L_0x0241:
        r3 = r1;
        r5 = r4;
        r1 = r2;
        r2 = r0;
        goto L_0x015e;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.dexati.adclient.Dexati.contactServer():void");
    }

    public static void initialize(Context context) {
        context = context;
        accepted = false;
        rejected = false;
        pd = null;
        webView = new WebView(context);
        try {
            CookieSyncManager.createInstance(context);
            CookieManager.getInstance().removeAllCookie();
        } catch (Throwable th) {
        }
        if (System.currentTimeMillis() - lastRequestStart > MINIMUM_INITIAL) {
            try {
                if (country == null || versionCode == -1) {
                    country = context.getResources().getConfiguration().locale.getISO3Country();
                    type = "dexati";
                    PackageInfo packageInfo = context.getPackageManager().getPackageInfo(context.getPackageName(), 0);
                    packageName = packageInfo.packageName;
                    versionCode = packageInfo.versionCode;
                }
            } catch (Throwable e) {
                Log.v(TAG, "Error with basic info. something wrong with phone", e);
            }
            lastRequestStart = System.currentTimeMillis();
            urlStringFound = null;
            new AdLoaderTask().execute(new String[0]);
        } else if (urlStringFound != null) {
            ((Activity) context).runOnUiThread(new Runnable() {
                public void run() {
                    Builder builder = new Builder(Dexati.context);
                    builder.setTitle("Top Free App");
                    builder.setMessage(Dexati.text);
                    builder.setPositiveButton("Ok", new OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(Dexati.urlStringFound));
                            intent.setFlags(268435456);
                            Dexati.context.startActivity(intent);
                        }
                    });
                    builder.setNegativeButton("Cancel", new OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int i) {
                            Dexati.rejected = true;
                        }
                    });
                    try {
                        builder.show();
                    } catch (Exception e) {
                    }
                }
            });
        }
    }
}
