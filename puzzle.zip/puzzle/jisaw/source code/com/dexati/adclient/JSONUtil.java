package com.dexati.adclient;

import android.util.Log;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;

public class JSONUtil {
    public static JSONObject getJSONfromURL(String str) {
        InputStream content;
        String stringBuilder;
        String str2 = "";
        try {
            content = new DefaultHttpClient().execute(new HttpGet(str)).getEntity().getContent();
        } catch (Exception e) {
            content = null;
        }
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(content, "iso-8859-1"), 8);
            StringBuilder stringBuilder2 = new StringBuilder();
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    break;
                }
                stringBuilder2.append(new StringBuilder(String.valueOf(readLine)).append("\n").toString());
            }
            content.close();
            stringBuilder = stringBuilder2.toString();
        } catch (Exception e2) {
            stringBuilder = str2;
        }
        try {
            return new JSONObject(stringBuilder);
        } catch (JSONException e3) {
            Log.e("log_tag", "Error parsing data " + e3.toString());
            return null;
        }
    }
}
